# DevSecOps Test Repository

This repository intentionally contains:
- Hardcoded secret
- Use of eval()
- Old dependencies

Use only for testing security scanners.
