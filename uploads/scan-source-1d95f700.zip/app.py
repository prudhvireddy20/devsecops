API_KEY = "1234567890SECRET"

user_input = input("Enter command: ")
eval(user_input)  # Intentional vulnerability for testing

print("Hello")
