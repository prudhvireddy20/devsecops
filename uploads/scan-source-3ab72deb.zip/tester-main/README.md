# TraceON — Developer Reference

> **White-box + black-box security scanner with SAST/DAST correlation, LLM-assisted planning, and a React dashboard.**
>
> Version: `1.0.0` · Backend: FastAPI (Python 3.11) · Frontend: React 18 + Vite + TypeScript

---

## Table of Contents

1. [What Is TraceON?](#1-what-is-traceon)
2. [Architecture Overview](#2-architecture-overview)
3. [Repository Layout](#3-repository-layout)
4. [Scan Pipeline — How a Scan Runs](#4-scan-pipeline--how-a-scan-runs)
5. [Backend Modules](#5-backend-modules)
6. [Frontend](#6-frontend)
7. [WebSocket API](#7-websocket-api)
8. [REST API Reference](#8-rest-api-reference)
9. [Configuration Reference](#9-configuration-reference)
10. [Database](#10-database)
11. [Deployment](#11-deployment)
12. [External Tool Integration](#12-external-tool-integration)
13. [LLM Providers](#13-llm-providers)
14. [Security Design](#14-security-design)
15. [Queue Backends](#15-queue-backends)
16. [Testing](#16-testing)
17. [Contributing](#17-contributing)

---

## 1. What Is TraceON?

TraceON is a self-hosted application security testing platform that combines:

| Technique | What it does |
|-----------|-------------|
| **SAST** (Static) | Imports Semgrep / external JSON findings from source code analysis |
| **DAST** (Dynamic) | Runs OWASP ZAP active scans, spiders, and optional extended tools against a live target URL |
| **IAST** (Instrumented) | Embeddable Python and Node.js agents that hook dangerous runtime sinks at the application level |
| **Correlation** | Matches SAST and DAST findings by endpoint + vulnerability type: **Verified**, **Probable**, or **Observed** |
| **LLM Planning** | Optional AI-powered pre-scan planning and post-scan narrative synthesis |
| **Remediation** | Template-based code-fix generation with unified diffs |
| **Reporting** | HTML, PDF (via WeasyPrint), SARIF 2.1.0, and JSON export |

The UI is a React single-page application served by the same FastAPI process in production (or independently via `npm run dev` during development).

---

## 2. Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                       Browser / Client                        │
│                 React SPA (Vite + TypeScript)                  │
│  Dashboard · Projects · Scans · Findings · Reports · LLM     │
└──────────────────────┬───────────────────────────────────────┘
                       │  HTTP REST + WebSocket (ws://)
                       ▼
┌──────────────────────────────────────────────────────────────┐
│                   FastAPI  (Uvicorn)                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────┐  │
│  │ /api/v1/ │  │ /ws/scan │  │ /ws/     │  │ /api/       │  │
│  │ projects │  │ /{id}    │  │ dashboard│  │ manifest(CP)│  │
│  │ scans    │  └──────────┘  └──────────┘  └─────────────┘  │
│  │ findings │                                                 │
│  │ reports  │  Middleware: CORS · Rate-limit · Sec headers    │
│  │ llm      │                                                 │
│  │ users    │                                                 │
│  └────┬─────┘                                                 │
│       │                                                       │
│  ┌────▼──────────────────────────────────────────────────┐   │
│  │          ScanOrchestrator (core/orchestrator.py)       │   │
│  │  Phase 1: Import SAST / Path-fuzz (mode-dependent)    │   │
│  │  Phase 2: Endpoint Discovery · Tech Fingerprinting     │   │
│  │  Phase 3: Auth Setup · Spider · WAF Detection          │   │
│  │  Phase 4: ZAP Active Scan · Extended DAST tools        │   │
│  │  Phase 5: Correlation · Coverage · LLM Synthesis       │   │
│  └───────────────────────────┬────────────────────────────┘   │
│                              │                                 │
│  ┌───────────────────────────▼────────────────────────────┐   │
│  │                   Scanner Engines                       │   │
│  │  ZAP · Nuclei · ffuf · Feroxbuster · Nikto · Testssl   │   │
│  │  SQLMap · Dalfox · Wapiti · Playwright · gau            │   │
│  └─────────────────────────────────────────────────────────┘  │
│                                                               │
│  SQLite / PostgreSQL  (SQLAlchemy async)                      │
└──────────────────────────────────────────────────────────────┘
         │                          │
         ▼                          ▼
   OWASP ZAP                 LLM Providers
 (separate container)    Anthropic / OpenAI /
                         OpenRouter / Google /
                         GitHub Copilot
```

### Scan Pipeline Diagram

```
START
  │
  ├─[whitebox]──► Import SAST JSON (Semgrep output, custom format)
  │                      │
  │               Endpoint Discovery (OpenAPI / Postman / Journey files)
  │
  ├─[blackbox]──► Path Fuzzing (ffuf + Feroxbuster)
  │               Server Audit (Nikto + Testssl)
  │               Endpoint Discovery
  │
  └─[both]──────► Tech Fingerprinting
                  Attack Surface Analysis
                        │
                  Auth Setup  ←── Playwright browser OR REST API JWT login
                        │
                  Spider (ZAP traditional + optional AJAX)
                  Journey Replay Warmup (optional HAR/JSON)
                        │
                  WAF Detection
                        │
                  ZAP Active Scan  ←── DAST semaphore (1 concurrent)
                  LLM Planner checkpoint
                  Targeted Retry (if LLM requests)
                        │
                  Extended DAST:
                    ├── Nuclei (template CVE/vuln scanner)
                    ├── Wapiti (blackbox: XXE, LDAP, CRLF)
                    ├── SQLMap (SQLi endpoints from SAST hints)
                    └── Dalfox (XSS endpoints from SAST hints)
                        │
                  Correlation Engine
                  Coverage Analysis (optional)
                  LLM Post-Scan Synthesis
                        │
                  COMPLETE → persist findings → notify via WebSocket
```

---

## 3. Repository Layout

```
dynamic-code/
├── backend/
│   ├── app/
│   │   ├── main.py                      # FastAPI app, middleware, WebSocket endpoints
│   │   ├── api/
│   │   │   ├── projects.py              # Project CRUD, artifact upload
│   │   │   ├── scans.py                 # Scan create/cancel/list, queue worker
│   │   │   ├── findings.py              # Finding list, detail, update, fix
│   │   │   ├── reports.py               # Report generation (html/pdf/sarif/json)
│   │   │   ├── llm.py                   # LLM provider CRUD, validate, test
│   │   │   ├── users.py                 # User/API-key management
│   │   │   ├── websocket.py             # ConnectionManager (ws_manager singleton)
│   │   │   ├── cp_adapter.py            # CloudGuard CP manifest + SSO entry
│   │   │   └── trustscan_connector.py   # TrustScan Platform connector
│   │   ├── core/
│   │   │   ├── orchestrator.py          # ScanOrchestrator — 2400-line pipeline engine
│   │   │   ├── config.py                # Pydantic Settings + auto-key generation
│   │   │   ├── database.py              # SQLAlchemy async engine, migrations, sessions
│   │   │   ├── auth.py                  # require_api_key / get_current_user
│   │   │   ├── security.py              # Fernet encrypt_token / decrypt_token
│   │   │   ├── rate_limit.py            # In-memory sliding-window rate limiter
│   │   │   ├── scan_queue.py            # ScanQueue (local / SQS / Redis)
│   │   │   ├── url_safety.py            # SSRF-safe URL validator
│   │   │   ├── logging.py               # Structured JSON logging setup
│   │   │   ├── cp_bridge.py             # CloudGuard CP scan-slot claim
│   │   │   ├── cp_callback.py           # CP post-completion callbacks
│   │   │   ├── cp_hmac.py               # HMAC nonce/signature helpers
│   │   │   └── cp_session.py            # CP JWT-validated session management
│   │   ├── models/
│   │   │   ├── project.py               # Project ORM model
│   │   │   ├── scan.py                  # Scan ORM model
│   │   │   ├── finding.py               # Finding ORM model
│   │   │   ├── user.py                  # User + API key hash model
│   │   │   ├── llm_provider_credential.py  # Encrypted LLM credentials
│   │   │   ├── project_artifact.py      # Uploaded artifact metadata
│   │   │   └── workflow_graph.py        # WorkflowGraph / Step / AttackPoint
│   │   ├── scanners/
│   │   │   ├── dast_engine.py           # DASTEngine — ZAP API wrapper (1288 lines)
│   │   │   ├── nuclei_engine.py         # NucleiEngine — subprocess wrapper
│   │   │   ├── ffuf_engine.py           # FfufEngine — path fuzzer
│   │   │   ├── feroxbuster_engine.py    # FeroxbusterEngine
│   │   │   ├── nikto_engine.py          # NiktoEngine — server auditor
│   │   │   ├── testssl_engine.py        # TestSSLEngine — TLS auditor
│   │   │   ├── sqlmap_engine.py         # SQLMapEngine — SQL injection prober
│   │   │   ├── dalfox_engine.py         # DalfoxEngine — XSS prober
│   │   │   ├── wapiti_engine.py         # WapitiEngine — XXE/LDAP/CRLF
│   │   │   ├── playwright_spider.py     # Playwright browser spider
│   │   │   ├── external_importer.py     # SAST JSON importer (Semgrep + custom)
│   │   │   ├── replay_adapter.py        # Journey replay (HAR/JSON)
│   │   │   ├── spec_adapter.py          # OpenAPI + Postman route extractor
│   │   │   └── iast_engine.py           # IAST findings ingest + bridge
│   │   ├── analyzers/
│   │   │   ├── source_analyzer.py       # Tree-sitter AST framework detection
│   │   │   ├── route_extractor.py       # Route path extractor
│   │   │   ├── auth_detector.py         # Auth flow pattern detector
│   │   │   ├── sink_detector.py         # Dangerous sink detector
│   │   │   └── framework_parsers/       # Per-framework route parsers
│   │   ├── correlation/
│   │   │   ├── correlation_engine.py    # CorrelationEngine (37 KB) — SAST↔DAST matching
│   │   │   ├── confidence_scorer.py     # Confidence level assignment
│   │   │   ├── deduplicator.py          # Duplicate-finding detection
│   │   │   ├── iast_mapper.py           # IAST event → Finding mapper
│   │   │   └── risk_ranker.py           # Risk scoring
│   │   ├── iast/
│   │   │   ├── python_agent.py          # Python runtime instrumentation agent
│   │   │   └── nodejs_agent.js          # Node.js runtime instrumentation agent
│   │   ├── llm/
│   │   │   ├── client.py                # LLMClient — multi-provider async HTTP client
│   │   │   ├── provider_config.py       # Provider config resolution (scan > DB > env)
│   │   │   ├── catalog.py               # Default model catalog per provider
│   │   │   ├── prompts.py               # All LLM prompt templates
│   │   │   ├── pre_scan_planner.py      # PreScanPlanner — focus-area suggestions
│   │   │   ├── post_scan_synthesizer.py # Post-scan narrative + attack chains
│   │   │   ├── context_builder.py       # Finding context assembler for LLM
│   │   │   ├── context_compressor.py    # Token budget management
│   │   │   ├── goal_compiler.py         # Natural-language scan goal → intent
│   │   │   ├── planner.py               # Mid-scan adaptive planner
│   │   │   ├── redaction.py             # PII/secret redaction before LLM calls
│   │   │   └── schemas.py               # LLM response Pydantic schemas
│   │   ├── remediation/
│   │   │   ├── fix_generator.py         # FixGenerator — template-based code fixes
│   │   │   └── llm_fix_generator.py     # LLM-powered fix generator wrapper
│   │   ├── reports/
│   │   │   ├── html_report.py           # HTMLReportGenerator (Jinja2 + inline template)
│   │   │   ├── pdf_report.py            # PDFReportGenerator (WeasyPrint)
│   │   │   └── sarif_export.py          # SARIFExporter (SARIF 2.1.0)
│   │   ├── integrations/
│   │   │   ├── gitnexus_client.py       # GitNexus MCP client (code flow evidence)
│   │   │   └── trustscan_client.py      # TrustScan Platform HTTP client
│   │   ├── auth/
│   │   │   ├── api_auth.py              # REST API authenticator (JWT/Bearer discovery)
│   │   │   ├── auth_script_gen.py       # Playwright auth script generator
│   │   │   └── playwright_runner.py     # Playwright browser-based login runner
│   │   ├── workflow/
│   │   │   └── service.py               # Artifact ingestion, WorkflowGraph builder
│   │   └── utils/
│   │       └── normalizers.py           # Endpoint/path/param normalization utilities
│   ├── requirements.txt
│   └── pytest.ini
├── frontend/
│   ├── src/
│   │   ├── App.tsx                      # SPA shell, routing, sidebar nav
│   │   ├── pages/
│   │   │   ├── Dashboard.tsx            # Stats, recent scans summary
│   │   │   ├── Projects.tsx             # Project CRUD + scan launch wizard
│   │   │   ├── ScanConfig.tsx           # Advanced scan configuration form
│   │   │   ├── ScanProgress.tsx         # Real-time scan progress via WebSocket
│   │   │   ├── Scans.tsx                # Scan history list
│   │   │   ├── Findings.tsx             # Findings table with filters
│   │   │   ├── FindingDetail.tsx        # Full finding detail + code + fix diff
│   │   │   ├── Coverage.tsx             # Code coverage visualization
│   │   │   ├── Reports.tsx              # Report generation and download
│   │   │   └── LLMProviders.tsx         # LLM provider credential management
│   │   ├── components/
│   │   │   ├── ApiKeyGate.tsx           # API key initialization gate
│   │   │   ├── CodeViewer.tsx           # Monaco editor code viewer
│   │   │   ├── DataFlowDiagram.tsx      # Source→sink data flow diagram
│   │   │   ├── RouteGraph.tsx           # Endpoint route graph visualization
│   │   │   ├── TrustScanConnectModal.tsx # TrustScan connection modal
│   │   │   ├── SeverityBadge.tsx        # Severity color badge
│   │   │   ├── FindingConfidenceBadge.tsx # Verified/Probable/Observed badge
│   │   │   ├── StatusBadge.tsx          # Scan status badge
│   │   │   ├── PageHeader.tsx           # Shared page header component
│   │   │   └── Toast.tsx                # Ephemeral notification
│   │   ├── services/
│   │   │   └── api.ts                   # Axios-based API client
│   │   └── hooks/                       # Custom React hooks
│   ├── package.json
│   ├── vite.config.ts
│   └── tailwind.config.js
├── Dockerfile                           # Multi-stage (frontend + Python + Go tools)
├── docker-compose.yml                   # TraceON backend + OWASP ZAP services
└── .env.example                         # All configurable environment variables
```

---

## 4. Scan Pipeline — How a Scan Runs

The `ScanOrchestrator` class (`core/orchestrator.py`) drives the entire scan lifecycle. It is instantiated per-scan and run as an `asyncio.Task`.

### 4.1 Scan Modes

| Mode | Description |
|------|-------------|
| `whitebox` | Imports pre-generated SAST JSON findings first. DAST tools (SQLMap, Dalfox) target only the endpoints flagged by SAST. |
| `blackbox` | No SAST import. Runs path fuzzing (ffuf + Feroxbuster), server audits (Nikto, Testssl), then full DAST. |

### 4.2 Pipeline Phases (in order)

| Phase key | Progress % | Description |
|-----------|-----------|-------------|
| `importing` | 8 | Import external SAST findings (whitebox only) |
| `path_fuzzing` | 12 | ffuf + Feroxbuster hidden-path discovery (blackbox only) |
| `server_audit` | 16 | Nikto + Testssl server/TLS checks (blackbox only) |
| `endpoint_discovery` | 20 | Parse OpenAPI specs, Postman collections, journey replays |
| `fingerprinting` | 24 | Detect technology stack (framework, database, version) |
| `attack_surface` | 28 | Classify endpoints by risk, extract parameter attack points |
| `auth` | 45 | Playwright browser login OR REST API JWT discovery |
| `spider` | 55 | ZAP traditional spider + optional AJAX spider + journey replay warmup |
| `waf_detection` | 60 | Detect WAF presence; adjust ZAP delay/threads accordingly |
| `active_scan` | 75 | ZAP active scan (serialized via global `asyncio.Semaphore(1)`) |
| `dast_extended` | 85–89 | Nuclei, Wapiti, SQLMap, Dalfox (tool-dependent) |
| `correlation` | 90–95 | Correlate all findings; run LLM planner checkpoint |
| `complete` | 100 | Persist final summary, notify via WebSocket |

### 4.3 Multi-Role Scanning

If `auth_config` defines multiple **role profiles**, the pipeline runs the auth→spider→WAF→active-scan block **once per role**, accumulating role-tagged findings. Per-role stats are tracked in `_role_scan_stats`.

### 4.4 Scan Profiles

Four built-in profile presets (set via `scan_config.profile`):

| Profile | Depth | Timeout | Max Children | AJAX Spider |
|---------|-------|---------|--------------|-------------|
| `balanced` | 5 | 1800 s | 20 | No |
| `api` | 4 | 1200 s | 30 | No |
| `spa` | 6 | 2400 s | 80 | **Yes** |
| `auth_heavy` | 5 | 3000 s | 40 | **Yes** |

Max overall scan duration: **4 hours** (`_DEFAULT_MAX_DURATION = 14400 s`).

### 4.5 Cancellation

Cancellation is cooperative:
- Client sends `"cancel"` over the WebSocket, or calls `DELETE /api/v1/scans/{id}`.
- `_check_cancel_requested()` is called at every pipeline checkpoint.
- On `CancelledError`, scan status is set to `"cancelled"` and committed to DB.

### 4.6 Startup Recovery

On process start, `recover_interrupted_scans()` finds scans stuck in `pending` or `running` state (from a crashed process) and marks them `failed`, then notifies CloudGuard CP if configured.

---

## 5. Backend Modules

### 5.1 API Layer (`app/api/`)

All routes are protected by `require_api_key` (injected as `_auth_deps = [Depends(require_api_key)]`) except the health check and CloudGuard/TrustScan connectors which use their own HMAC or JWT auth.

#### `projects.py` — `/api/v1/projects`

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/projects` | Create project. Key fields: `name`, `description`, `scan_mode` (whitebox/blackbox), `target_url`, `source_type`, `llm_provider`, `llm_model`, `llm_api_key`, `openapi_spec_files`, `postman_collection_files`, `journey_replay_files`, `trustscan_url`, `trustscan_token`, `trustscan_job_id`, `auth_config`. |
| `GET` | `/projects` | List projects (admin sees all; regular user sees own). |
| `GET` | `/projects/{id}` | Get single project with artifact list. |
| `PUT` | `/projects/{id}` | Update project fields. |
| `DELETE` | `/projects/{id}` | Soft-delete (`is_active = False`). |
| `POST` | `/projects/{id}/upload` | Upload artifact (OpenAPI spec, Postman collection, journey replay, SAST JSON, coverage). |
| `GET` | `/projects/{id}/artifacts` | List uploaded artifacts. |
| `DELETE` | `/projects/{id}/artifacts/{artifact_id}` | Remove artifact. |
| `GET` | `/projects/{id}/workflow` | Get workflow graphs for the project. |
| `GET` | `/projects/{id}/source-tree` | Browse uploaded source tree. |

Input validation: `name` max 255 chars, `description` max 5000 chars (enforced in `ProjectCreate.__init__`).

#### `scans.py` — `/api/v1/scans`

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/scans` | Start a scan. Body: `ScanCreate`. Launches `ScanOrchestrator` as an asyncio task. |
| `GET` | `/scans` | List scans. Query params: `project_id`, `status`, `limit`, `offset`. |
| `GET` | `/scans/{id}` | Get scan status, progress, phase, results summary, log. |
| `DELETE` | `/scans/{id}` | Cancel a running scan. |
| `GET` | `/scans/{id}/log` | Full scan log text. |
| `POST` | `/scans/{id}/retry` | Retry a failed scan. |

**`ScanCreate` schema:**
```json
{
  "project_id": "uuid",
  "scan_type": "full",
  "scan_mode": null,
  "modules_enabled": {
    "dast": true, "nuclei": false, "coverage": false,
    "path_fuzzing": true, "server_audit": true,
    "sqlmap": true, "dalfox": true, "wapiti": true,
    "testssl": true, "feroxbuster": true
  },
  "auth_config": {},
  "scan_goals": ["Check for SQL injection in login endpoint"],
  "scan_config": {
    "scan_depth": 5, "timeout": 3600, "max_children": 10,
    "context_aware_payloads": true, "profile": "balanced",
    "ajax_spider": false, "llm_planner_enabled": false,
    "llm_provider": "anthropic", "llm_model": "",
    "openapi_spec_file": [], "postman_collection_file": [],
    "journey_replay_files": [], "external_findings_path": "",
    "external_findings_format": ""
  }
}
```

#### `findings.py` — `/api/v1/findings`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/findings` | List findings. Filters: `scan_id`, `project_id`, `severity`, `confidence`, `vulnerability_type`, `scanner_source`, `status`, `search`. Pagination: `limit`, `offset`. |
| `GET` | `/findings/summary` | Aggregate counts by severity and confidence. |
| `GET` | `/findings/{id}` | Full finding detail (code snippet, data flow, payload, repro bundle). |
| `PUT` | `/findings/{id}` | Update `status` (open/confirmed/false_positive/resolved) or `notes`. |
| `POST` | `/findings/{id}/fix` | Generate code fix. Returns `{original_code, fixed_code, diff, remediation_text}`. |
| `POST` | `/findings/{id}/apply-fix` | Mark fix as applied (`fix_applied = True`). |

**Confidence values:** `verified` (SAST + DAST match) · `probable` (SAST only) · `observed` (DAST only)

**Canonical vulnerability types:** `sqli`, `xss`, `cmdi`, `path_traversal`, `ssrf`, `deserialization`, `secret`, `config`, `info_disclosure`, `idor`, `auth`, `mass_assignment`, `weak_crypto`, `brute_force`, `cors`, `cookie`, `csrf`, `header`, `timestamp`, `absence`

#### `reports.py` — `/api/v1/reports`

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/reports` | Generate report. `format`: `html`, `pdf`, `sarif`, `json`. |
| `GET` | `/reports/{scan_id}/{format}` | Download a previously generated report file. |

Reports are generated only for completed/failed scans (HTTP 409 if still running).

#### `llm.py` — `/api/v1/llm`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/llm/providers` | List configured LLM providers for the current user. |
| `POST` | `/llm/providers` | Add or update a provider credential (stored encrypted). |
| `DELETE` | `/llm/providers/{provider}` | Remove a provider credential. |
| `POST` | `/llm/providers/{provider}/validate` | Validate credentials with a test chat request. |
| `GET` | `/llm/providers/{provider}/models` | List available models for a provider. |
| `POST` | `/llm/analyze` | Analyze a finding with LLM on-demand. |

#### `users.py` — `/api/v1/users`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/users/me` | Get current user info. |
| `GET` | `/users` | List all users (admin only). |
| `POST` | `/users` | Create user + API key (admin only). |
| `DELETE` | `/users/{id}` | Deactivate a user (admin only). |

#### `websocket.py` — `ConnectionManager`

Manages broadcast groups keyed by `scan_id`. The module-level `ws_manager` singleton is used by the orchestrator.

Key methods:
- `connect(ws, scan_id=None)` — register connection
- `disconnect(ws, scan_id=None)` — remove connection
- `send_scan_progress(scan_id, data)` — broadcast `{type: "progress", ...}`
- `send_scan_log(scan_id, message)` — broadcast `{type: "log", ...}`

#### `cp_adapter.py` — CloudGuard Control Plane

- `GET /api/manifest` — returns TraceON scanner identity for CP catalog registration.
- `GET /sso-entry` — validates CP launch JWT (JWKS-verified), creates/retrieves CP session, redirects to dashboard.

#### `trustscan_connector.py` — TrustScan Platform

- `POST /api/v1/trustscan/connect` — validate TrustScan PAT, store against project.
- `GET /api/v1/trustscan/jobs` — list TrustScan scan jobs.
- `POST /api/v1/trustscan/import` — import SAST findings from a TrustScan job.

---

### 5.2 Core (`app/core/`)

#### `orchestrator.py` — `ScanOrchestrator`

~2400 lines. Key internal methods:

| Method | Purpose |
|--------|---------|
| `run()` | Wraps `_run_pipeline()` in `asyncio.wait_for(timeout=max_duration)`. Handles `CancelledError`, `TimeoutError`, generic exceptions. |
| `_run_pipeline()` | Dispatches whitebox vs blackbox phases, then shared DAST pipeline, then correlation. |
| `_run_pre_scan_planning()` | Calls `PreScanPlanner` if LLM enabled and project description ≥ 15 chars. |
| `_run_endpoint_discovery()` | Loads routes from OpenAPI specs, Postman collections, journey files, workflow graphs. |
| `_run_tech_fingerprinting()` | ZAP fingerprinting + framework/stack detection. |
| `_run_attack_surface_analysis()` | Categorizes routes; populates `sast_sqli_targets`, `sast_xss_targets`, `high_risk_endpoints`. |
| `_setup_auth_safe(profile)` | Routes to Playwright browser login or REST API login based on `auth_type`. |
| `_run_spider()` | ZAP spider. Optionally adds AJAX spider for SPAs. |
| `_run_waf_detection()` | Probes with WAF-triggering payloads; adjusts ZAP delay/threads. |
| `_run_active_scan(auth_role)` | Acquires `_dast_semaphore`, runs ZAP active scan, releases. |
| `_run_dast_extended()` | Runs Nuclei against the target. |
| `_run_sqlmap()` | SQLMap — SAST-flagged endpoints (whitebox) or all (blackbox). |
| `_run_dalfox()` | Dalfox — SAST-flagged endpoints (whitebox) or all (blackbox). |
| `_run_correlation()` | Instantiates `CorrelationEngine`, deduplicates, persists to DB. |
| `_run_llm_planner_checkpoint(stage)` | Mid-scan LLM checkpoint; may request targeted retries. |
| `_finalize()` | Results summary, coverage %, post-scan LLM synthesis, mark `completed`. |

A global `asyncio.Semaphore(1)` (`_dast_semaphore`) serializes ZAP active scans across concurrent scan runs to prevent memory exhaustion in the ZAP container.

A per-orchestrator `asyncio.Lock` (`_db_lock`) serializes DB writes because `AsyncSession` is not safe for concurrent coroutine access.

#### `config.py` — `Settings`

`pydantic_settings.BaseSettings` loads from environment + `.env` file.

Auto-generation at import time (not `__init__`):
- `API_KEY` → persisted to `/data/db/.api_key`
- `ENCRYPTION_KEY` → persisted to `/data/db/.encryption_key`
- `ENCRYPTION_SALT` → persisted to `/data/db/.encryption_salt`

Directories auto-created: `PROJECTS_DIR`, `UPLOADS_DIR`, `REPORTS_DIR`, `COVERAGE_DIR`.

#### `database.py`

- SQLite: WAL journal mode, `synchronous=NORMAL`, `busy_timeout=5000 ms`, foreign keys ON.
- PostgreSQL: standard asyncpg engine.
- `run_migrations()` — `ALTER TABLE ADD COLUMN` for SQLite; column type widening for PostgreSQL. Runs at every startup (idempotent).
- `get_db()` — FastAPI dependency yielding `AsyncSession` with rollback on error.

#### `auth.py`

- `require_api_key(request)` — reads `X-API-Key` or `Authorization: Bearer`, SHA-256 hashes it, looks up `User`. In `DEBUG=true` on localhost, auto-injects the server key (dev convenience).
- `get_current_user(request, db)` — same flow, returns `User` object.

#### `security.py`

- `encrypt_token(plain: str) → str` — Fernet encryption with `ENCRYPTION_KEY` + `ENCRYPTION_SALT`.
- `decrypt_token(encrypted: str) → str` — decryption. Returns empty string on failure.

#### `rate_limit.py` — `RateLimiter`

In-memory sliding-window (60-second window). Global instance: **300 requests/minute** per IP.
- Health check paths and local/private-network IPs are exempt.
- Background cleanup task runs every 300 s to prevent memory leaks.
- Response headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Window`.

#### `scan_queue.py` — `ScanQueue`

| `SCAN_QUEUE_MODE` | Backend |
|-------------------|---------|
| `local` (default) | asyncio task, no external deps |
| `sqs` | AWS SQS via `boto3` |
| `redis` | Redis `LPUSH`/`BRPOP` via `redis-py` |

Methods: `enqueue(payload)`, `poll(wait_seconds, max_messages)`, `ack(receipt_handle)`.

#### `url_safety.py`

`validate_external_target_url(url) → (bool, str)` — SSRF guard. Blocks RFC-1918 private ranges, link-local (`169.254.*`), loopback. Returns `(False, reason)` for blocked URLs.

---

### 5.3 Scanners (`app/scanners/`)

#### `dast_engine.py` — `DASTEngine`

Wraps the OWASP ZAP Python API (`zapv2`). Maps 40+ ZAP alert IDs to TraceON vulnerability types via `ZAP_ALERT_MAP` and `ZAP_COMPATIBILITY_MAP`.

Key methods:
- `run_spider(target_url, max_depth, max_children, context_id)` — configures and starts ZAP traditional spider.
- `run_ajax_spider(target_url)` — ZAP AJAX spider for SPA content.
- `run_active_scan(target_url, context_id, scan_policy, timeout)` — polls ZAP active scan; implements adaptive timeout based on route count and stall detection (`DAST_STALL_TIMEOUT`).
- `get_alerts(target_url, risk_threshold)` — fetches and normalizes ZAP alerts to Finding format.
- `detect_waf(target_url)` — sends WAF-triggering payloads, inspects responses.
- `setup_authentication(target_url, auth_config, context_id)` — configures ZAP context with auth tokens or form-based auth.
- `setup_context(target_url)` — creates ZAP scan context with in-scope URL config.

WAF detection adjusts scan aggressiveness:
- **WAF detected** → ZAP: 500 ms delay, 5 threads; Nuclei: 10 req/s
- **No WAF** → ZAP: 0 ms delay (`ZAP_NO_WAF_DELAY_MS`), 20 threads (`ZAP_NO_WAF_THREADS`); Nuclei: 150 req/s

#### `external_importer.py` — `ExternalFindingImporter`

Imports SAST findings from JSON files (Semgrep SARIF/JSON, custom TraceON format). Normalizes to `Finding` model. Extracts `sast_sqli_targets` and `sast_xss_targets` endpoint lists to guide DAST tool targeting in whitebox mode.

#### `nuclei_engine.py` — `NucleiEngine`

Runs `nuclei` CLI as subprocess. Configures template categories based on LLM pre-scan plan. Parses JSONL output to finding format.

#### `ffuf_engine.py` — `FfufEngine`

Runs `ffuf` with SecLists `common.txt` (or custom `FFUF_WORDLIST_PATH`). Returns discovered path list. Depth-configurable via `scan_depth`.

#### `feroxbuster_engine.py` — `FeroxbusterEngine`

Runs `feroxbuster` for recursive directory/content discovery. Supplements ffuf output.

#### `nikto_engine.py` — `NiktoEngine`

Runs `nikto` CLI (at `/opt/nikto`). Returns server-level findings (outdated software, misconfigs).

#### `testssl_engine.py` — `TestSSLEngine`

Runs `testssl.sh` for TLS/SSL audit. Extracts cipher-suite weaknesses, protocol issues, certificate problems.

#### `sqlmap_engine.py` — `SQLMapEngine`

Runs `sqlmap` CLI. Whitebox mode: targets only `sast_sqli_targets`. Blackbox: scans all discovered endpoints.

#### `dalfox_engine.py` — `DalfoxEngine`

Runs `dalfox` CLI for XSS detection. Whitebox: targets only `sast_xss_targets`. Blackbox: all endpoints.

#### `wapiti_engine.py` — `WapitiEngine`

Runs `wapiti3` (installed via pip). Used in blackbox mode for XXE, LDAP injection, CRLF injection — vulnerability classes ZAP typically misses.

#### `playwright_spider.py`

Playwright Chromium browser spider for JS-heavy SPAs. Extracts dynamically-loaded endpoint paths.

#### `spec_adapter.py`

- `load_openapi_routes(spec)` — parses OpenAPI 2/3 JSON/YAML, extracts `path + method + parameters`.
- `load_postman_routes(collection)` — parses Postman Collection v2/v2.1, extracts requests.

#### `replay_adapter.py`

- `load_journey_steps(journey_file)` — loads HAR or custom JSON journey files. Used to warm up ZAP's session history with pre-authenticated requests before active scanning.

#### `iast_engine.py`

Receives `IASTEvent` objects from embedded Python/Node.js agents and converts them to `Finding` records with `verified` confidence.

---

### 5.4 Analyzers (`app/analyzers/`)

#### `source_analyzer.py` — `SourceAnalyzer`

Uses **tree-sitter** AST parsing. Framework detection by indicator scoring (scans up to 200 `.py` + 400 JS/TS files):

| Framework | Key Indicators |
|-----------|---------------|
| Flask | `from flask import`, `@app.route`, `Blueprint(` |
| Django | `from django`, `urlpatterns`, `INSTALLED_APPS` |
| FastAPI | `from fastapi import`, `FastAPI()`, `APIRouter` |
| Express | `require('express')`, `express()`, `.get(`, `.post(` |

#### `auth_detector.py`

Detects auth patterns in source: JWT validation, session management, OAuth flows, API key checks. Identifies authentication endpoints for DAST targeting.

#### `sink_detector.py`

Identifies dangerous sinks in AST: `execute()`, `Popen()`, `eval()`, `open()`, template rendering. Provides line number + code snippet.

#### `route_extractor.py`

Extracts route definitions from framework-specific patterns using `framework_parsers/` for per-framework AST traversal.

---

### 5.5 Correlation (`app/correlation/`)

#### `correlation_engine.py` — `CorrelationEngine`

855 lines, 37 KB. Matches SAST findings against DAST findings to assign confidence.

**Confidence assignment logic:**
- `verified` — same endpoint + same vulnerability type in both SAST and DAST
- `probable` — SAST only; code vulnerable, DAST did not trigger
- `observed` — DAST only; runtime finding, no SAST match

**Matching strategy:**
1. **Endpoint normalization** — strips query strings; normalizes path params (`{id}` ↔ `:id` ↔ `*`).
2. **Vulnerability type equivalence** — `VULN_TYPE_EQUIVALENTS` maps aliases to canonical names (e.g., `"sql-injection"` → `"sqli"`, `"cross-site-scripting"` → `"xss"`).
3. **Global scope types** — `config`, `header`, `info_disclosure`, `cors`, `brute_force`, `secret` match without requiring endpoint equality.
4. **Route index** — `file → endpoint` lookup built from extracted routes, enabling SAST file path ↔ DAST endpoint cross-referencing.

#### `deduplicator.py`

Removes duplicate findings. Duplicates get `status = "duplicate"` and `duplicate_of = <primary_finding_id>`.

#### `confidence_scorer.py`

Numeric confidence score (0–100) based on match quality, scanner source reliability, payload evidence.

#### `iast_mapper.py`

Maps `IASTEvent` (proven source→sink traces) to `Finding` records. IAST findings always get `verified` confidence.

#### `risk_ranker.py`

Assigns `risk_score` (int) and `risk_level` string per finding: severity × confidence × endpoint exposure.

---

### 5.6 IAST Agents (`app/iast/`)

#### `python_agent.py`

Importable module that instruments dangerous Python functions at runtime.

**Instrumented sinks:**
| Sink | Vulnerability |
|------|--------------|
| `sqlite3.execute()`, `psycopg2.execute()` | SQL injection |
| `subprocess.Popen()`, `os.system()` | Command injection |
| `jinja2.Template.render()`, `render_template()` | SSTI |
| `open()` with user-controlled path | Path traversal |

**Architecture:**
1. Each sink is wrapped with a decorator that checks if current HTTP request parameters flowed into the call.
2. `threading.local()` holds per-request context (`request_id`, `request_data`).
3. Events are emitted to a `queue.Queue`.
4. A background thread drains the queue and POSTs `IASTEvent` dicts to the TraceON backend.

```python
# Install in your application startup
from app.iast.python_agent import install_hooks, set_request_context
install_hooks()  # Once at startup
# In request middleware:
set_request_context(request_id, {"params": request.args, "body": request.json})
```

#### `nodejs_agent.js`

Equivalent Node.js agent. Monkey-patches `pg.Client.query`, `child_process.exec`, `fs.readFile`. Uses Node.js `async_hooks` for request context tracking across async boundaries.

---

### 5.7 LLM (`app/llm/`)

#### `client.py` — `LLMClient`

Thin async HTTP client supporting five providers.

| Provider | API | Default model |
|----------|-----|---------------|
| `anthropic` | Anthropic Messages API | `claude-3-5-haiku-latest` |
| `openai` | OpenAI Chat Completions | `gpt-4o-mini` |
| `openrouter` | OpenAI-compatible via OpenRouter | `meta-llama/llama-3.1-8b-instruct:free` |
| `google` | Google Generative Language | `gemini-1.5-flash` |
| `github` | GitHub Copilot (OpenAI-compatible) | `gpt-4o` |

Key methods:
- `is_available()` — checks provider + credentials configured.
- `validate_connection()` — minimal chat request to verify credentials.
- `chat(system_prompt, user_prompt, *, json_mode)` — returns parsed JSON or raw text. Retry with exponential backoff up to `LLM_MAX_RETRIES`.

`"copilot"` is normalized to `"github"` internally.

#### `provider_config.py`

`resolve_llm_provider_config_async(db, project, scan_config, user_id)` — priority chain:

```
scan_config overrides (llm_provider, llm_model, llm_api_key)
    → llm_provider_credentials table (user-stored, encrypted)
        → project fields (llm_provider, llm_api_key_encrypted)
            → env vars (LLM_PROVIDER, LLM_MODEL)
                → catalog.py defaults
```

LLM is **auto-enabled** if any provider credential exists in DB (regardless of `LLM_ENABLED` env var).

#### `pre_scan_planner.py` — `PreScanPlanner`

Fires once before scanning when project description ≥ 15 chars. Cached in-memory by SHA-256(description + scan_mode) with 24-hour TTL.

Output:
```json
{
  "focus_areas": ["/api/auth/login", "/api/admin"],
  "skip_hint": ["/api/static", "/api/docs"],
  "risk_hypothesis": "Expected authentication bypass in JWT handling"
}
```

Used by: Nuclei template selection, ZAP scope priority, report risk hypothesis.

#### `post_scan_synthesizer.py`

Called at finalization. Sends correlated findings to LLM. Generates:
- `Scan.llm_summary` — 60-word executive summary
- `Scan.attack_chains` — `[{finding_ids, severity, narrative}]` exploit chains

#### `context_builder.py` + `context_compressor.py`

Assembles finding data within `LLM_MAX_SNIPPET_CHARS` (default 12 000) token budget. Compresses by truncating snippets and dropping low-severity duplicates.

#### `goal_compiler.py`

Converts natural-language `scan_goals` into structured `plan_intent` dict used by the orchestrator to focus scanning.

#### `redaction.py`

Strips secrets, passwords, PII from code snippets before LLM API calls.

#### `prompts.py`

All prompt templates as Python string constants: `pre_scan_prompt`, `post_scan_prompt`, `remediation_prompt`, `goal_prompt`.

---

### 5.8 Remediation (`app/remediation/`)

#### `fix_generator.py` — `FixGenerator`

Template-based fix generation (no LLM required).

| Vuln type | Fix strategy |
|-----------|-------------|
| `sqli` | Converts f-string / `%s` queries to parameterized (`?` with tuple) |
| `xss` | Adds `html.escape()` or `bleach.clean()` |
| `cmdi` | Converts `shell=True` to list-based subprocess |
| `secret` | Replaces hardcoded value with `os.environ.get()` |
| `path_traversal` | Adds `os.path.realpath()` base-directory check |
| `deserialization` | Replaces `pickle.loads` with `json.loads` |
| Generic | Returns remediation description only |

Output: `{original_code, fixed_code, diff, remediation_text}`.

#### `llm_fix_generator.py`

Wrapper that calls `LLMClient` with `remediation_prompt` when template-based generator has no output or LLM fix is explicitly requested.

---

### 5.9 Reports (`app/reports/`)

#### `html_report.py` — `HTMLReportGenerator`

Self-contained HTML via Jinja2. Falls back to built-in inline template if `templates/` directory is missing. Findings sorted by severity (critical first), then confidence (verified first). Dual CSS theme: dark screen + light paginated print/PDF.

#### `pdf_report.py` — `PDFReportGenerator`

WeasyPrint renders the HTML report to PDF via `weasyprint.HTML.write_pdf()`.

#### `sarif_export.py` — `SARIFExporter`

SARIF 2.1.0 JSON. CWE taxonomy for 12 CWE IDs. Populated fields:
- `tool.driver` — name, version, rules
- `results` — location (file, line), message, severity, fix suggestions
- `invocations` — start/end time, success flag
- `artifacts` — source file references

---

### 5.10 Integrations (`app/integrations/`)

#### `gitnexus_client.py` — `GitNexusClient`

MCP-protocol client for **GitNexus** code intelligence server. Fetches data-flow evidence:
- `get_api_impact(endpoint, file_path)` — route handler + call graph query.
- `build_flow_evidence(api_impact, endpoint, file_path)` → `flow_evidence` dict stored on findings.

Helpers: `endpoints_match()` (wildcard-normalized path comparison), `file_paths_match()` (suffix-based, tolerates path prefix differences).

Configure via: `GITNEXUS_ENABLED=true`, `GITNEXUS_MCP_URL`, `GITNEXUS_REPO`, `GITNEXUS_TIMEOUT_SECONDS`.

#### `trustscan_client.py` — `TrustScanClient`

HTTP client for **TrustScan Platform** API using `Authorization: Bearer tm_<token>`.

Methods: `validate_token()`, `list_jobs(limit)`, `get_job_findings(job_id)`, `import_findings(job_id, project_id)`.

---

### 5.11 Auth (`app/auth/`)

#### `api_auth.py` — `RestApiAuthenticator`

Handles authentication for **pure REST API targets** (no HTML login forms).

Discovery sequence:
1. Check OpenAPI `securitySchemes` for login endpoint.
2. Probe 16 common `LOGIN_PROBE_PATHS` in order (e.g., `/api/v1/login`, `/auth/token`, `/oauth/token`).
3. Optionally auto-register a test user via `REGISTER_PROBE_PATHS`.
4. POST credentials, extract token using `TOKEN_RESPONSE_KEYS` (checks `access_token`, `token`, `jwt`, `id_token`, `bearer`, `accessToken`, and more).
5. Returns `Authorization: Bearer <token>` or session cookie header for ZAP context.

Test credentials configurable via `AUTH_TEST_USERNAME`, `AUTH_TEST_PASSWORD`, `AUTH_TEST_EMAIL`.

#### `playwright_runner.py`

Playwright Chromium for HTML form-based logins. Supports form login, MFA/OTP workflows, cookie extraction. Injects cookies into ZAP context.

#### `auth_script_gen.py`

Generates Playwright auth scripts (Python or JS) from config templates.

---

### 5.12 Workflow (`app/workflow/service.py`)

- `ingest_artifact_file(db, project_id, artifact_path, kind)` — parses uploaded artifact, creates `WorkflowGraph` + `WorkflowStep` + `WorkflowAttackPoint` records.
- `ensure_project_artifacts_from_project_config(db, project)` — syncs artifacts from project fields into `project_artifacts` table.
- `collect_project_config_artifacts(project)` → `list[tuple[kind, path]]`

`WorkflowAttackPoint` records injectable parameters (query, path, body) extracted from each HTTP step in a journey.

---

### 5.13 Models (`app/models/`)

| Model | Table | Key fields |
|-------|-------|-----------|
| `Project` | `projects` | `id`, `name`, `scan_mode`, `target_url`, `llm_provider`, `llm_api_key_encrypted`, `owner_id`, `is_active` |
| `Scan` | `scans` | `id`, `project_id`, `status`, `scan_mode`, `progress`, `current_phase`, `modules_enabled`, `scan_goals`, `plan_intent`, `results_summary`, `llm_summary`, `attack_chains`, `plan_result`, `detected_stack`, `cp_job_id`, `cp_callback_url` |
| `Finding` | `findings` | `id`, `scan_id`, `title`, `vulnerability_type`, `severity`, `confidence`, `cwe`, `owasp_category`, `endpoint`, `http_method`, `parameter`, `file_path`, `line_number`, `code_snippet`, `data_flow`, `payload`, `response_evidence`, `auth_role`, `risk_score`, `risk_level`, `scanner_source`, `remediation_text`, `generated_fix_payload`, `fix_available`, `status`, `duplicate_of` |
| `User` | `users` | `id`, `api_key_hash` (SHA-256), `label`, `is_active`, `is_admin` |
| `LLMProviderCredential` | `llm_provider_credentials` | `provider`, `user_id`, `encrypted_token`, `default_model`, `auth_method`, `oauth_username` |
| `ProjectArtifact` | `project_artifacts` | `project_id`, `kind` (openapi/postman/journey/sast/coverage), `file_path`, `content_hash` |
| `WorkflowGraph` | `workflow_graphs` | `project_id`, `name`, `steps[]`, `attack_points[]` |

Scan `status` values: `pending` → `running` → `completed` / `failed` / `cancelled`

---

## 6. Frontend

Built with **React 18 + TypeScript + Vite + Tailwind CSS**.

### Pages

| Route | Component | Description |
|-------|-----------|-------------|
| `/` | `Dashboard.tsx` | Summary stats (projects, scans, findings by severity), last 5 scans |
| `/projects` | `Projects.tsx` | Project CRUD, artifact upload, scan launch, TrustScan connect |
| `/projects/:id/scan` | `ScanConfig.tsx` | Advanced scan configuration (modules, auth, LLM, profile) |
| `/scans/:id` | `ScanProgress.tsx` | Real-time progress, phase indicator, live log via WebSocket |
| `/scans` | `Scans.tsx` | Scan history list |
| `/findings` | `Findings.tsx` | Finding table with severity/confidence/type/status filters |
| `/findings/:id` | `FindingDetail.tsx` | Detail view with Monaco code viewer, data flow diagram, fix diff |
| `/coverage` | `Coverage.tsx` | Code coverage visualization |
| `/reports` | `Reports.tsx` | Report generation and download |
| `/llm` | `LLMProviders.tsx` | Add/update/validate LLM provider credentials |

### Key Components

| Component | Purpose |
|-----------|---------|
| `ApiKeyGate` | Reads `window.__DT_API_KEY__` (server-injected in DEBUG/local) or prompts user to enter API key |
| `CodeViewer` | Monaco editor (read-only) with vulnerable line highlighting |
| `DataFlowDiagram` | Visual source→sink data flow diagram from `data_flow` field |
| `RouteGraph` | Endpoint route graph built from discovered routes |
| `TrustScanConnectModal` | Modal for TrustScan PAT entry and job selection |
| `SeverityBadge` | Color chip: critical/high/medium/low/info |
| `FindingConfidenceBadge` | Color chip: verified/probable/observed |
| `Toast` | Ephemeral notification |

### Frontend Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `react` | ^18.2 | UI framework |
| `react-router-dom` | ^6.30 | Client-side routing |
| `axios` | ^1.18 | HTTP client |
| `@monaco-editor/react` | ^4.6 | Code viewer |
| `lucide-react` | ^0.323 | Icons |
| `dompurify` | ^3.4 | XSS sanitization for rendered HTML |
| `@fontsource-variable/inter` | ^5.2 | Inter variable font |
| `@fontsource-variable/jetbrains-mono` | ^5.2 | Monospace font |

Build tool: `vite ^6.4`, TypeScript `^5.3`.

---

## 7. WebSocket API

### Endpoints

| Path | Auth | Description |
|------|------|-------------|
| `POST /api/v1/auth/ws-token` | API key | Issue one-time WS token (TTL: 120 s) |
| `WS /ws/scan/{scan_id}?token=<token>` | WS token (scope=scan, scan_id) | Real-time scan progress + logs |
| `WS /ws/dashboard?token=<token>` | WS token (scope=dashboard) | Dashboard-wide updates |

### Server → Client Messages

```jsonc
{"type": "progress", "status": "running", "progress": 55, "phase": "spider"}
{"type": "log", "message": "[AUTH] Starting phase..."}
{"type": "error", "message": "ZAP connection refused"}
{"type": "cancelled", "scan_id": "uuid"}
{"type": "ping"}   // keepalive every 30 s
```

### Client → Server Messages

```jsonc
"cancel"   // Cancel the scan
"ping"     // Keepalive
```

### Token Security Model

1. `POST /api/v1/auth/ws-token` (requires API key) returns a short-lived token.
2. Token format: `<payload_b64>.<hmac_sha256_sig>` — payload includes `scope`, `scan_id`, `exp`, `nonce`.
3. Signed with `API_KEY` using HMAC-SHA256.
4. Tokens are **single-use** (consumed on WebSocket connect) — replayed tokens are rejected.
5. Expired tokens (>120 s) are also rejected.

---

## 8. REST API Reference

**Base URL:** `http://localhost:8000/api/v1` (dev) · `https://<domain>/api/v1` (prod)

**Authentication:** `X-API-Key: <api_key>` on all protected endpoints.

### Health (no auth)

```
GET /api/health
GET /api/v1/health
→ {"status": "healthy", "app": "TraceON", "version": "1.0.0"}
```

### Auth

```
GET  /api/v1/auth/key          # Returns current API key
POST /api/v1/auth/ws-token     # Issues one-time WS token
```

### Dashboard Stats

```
GET /api/v1/dashboard/stats
→ {total_projects, total_scans, recent_scans[5], finding_summary{total,critical,high,medium,low,info}}
```
Scoped to current user's projects (admin sees all).

---

## 9. Configuration Reference

Copy `.env.example` → `.env` and set the values.

| Variable | Default | Description |
|----------|---------|-------------|
| `API_KEY` | auto-generated | Master API key. Set explicitly for persistence. |
| `ENCRYPTION_KEY` | auto-generated | Fernet key for credentials at rest. |
| `ENCRYPTION_SALT` | auto-generated | Encryption salt. |
| `DATABASE_URL` | `sqlite+aiosqlite:///./traceon.db` | SQLAlchemy async URL. Use `postgresql+asyncpg://...` for production. |
| `DEBUG` | `false` | Hot reload, stack traces, local API key injection. |
| `TRUST_PROXY` | `false` | Set `true` behind a reverse proxy (trusts `X-Forwarded-For`). |
| `HOST` | `0.0.0.0` | Uvicorn bind address. |
| `PORT` | `8000` | Uvicorn port. |
| **ZAP** | | |
| `ZAP_API_URL` | `http://localhost:8080` | ZAP daemon URL. |
| `ZAP_API_KEY` | _(required)_ | Must match ZAP daemon `api.key`. |
| `DAST_BASE_TIMEOUT` | `2400` | ZAP active scan timeout (s). |
| `DAST_ABSOLUTE_MAX_TIMEOUT` | `2400` | Hard cap (s). |
| `DAST_STALL_TIMEOUT` | `120` | Fail if no new ZAP alerts for this many seconds. |
| `ZAP_NO_WAF_DELAY_MS` | `0` | ZAP request delay when no WAF detected. |
| `ZAP_NO_WAF_THREADS` | `20` | ZAP threads when no WAF detected. |
| **LLM** | | |
| `LLM_ENABLED` | `false` | Master toggle (auto-enabled if DB creds exist). |
| `LLM_PROVIDER` | `anthropic` | `anthropic`, `openai`, `openrouter`, `google`, `github`. |
| `LLM_MODEL` | _(provider default)_ | Model name. |
| `LLM_TIMEOUT_SECONDS` | `40` | Per-request timeout. |
| `LLM_MAX_RETRIES` | `2` | Retry attempts on failure. |
| `LLM_MAX_SNIPPET_CHARS` | `12000` | Max code chars sent to LLM. |
| `ANTHROPIC_API_KEY` | | Anthropic key. |
| `OPENAI_API_KEY` | | OpenAI key. |
| `OPENROUTER_API_KEY` | | OpenRouter key. |
| `GOOGLE_API_KEY` | | Google AI key. |
| `GITHUB_COPILOT_TOKEN` | | GitHub Copilot token. |
| **External Tools** | | |
| `FFUF_ENABLED` | `true` | Enable ffuf path fuzzing. |
| `FEROXBUSTER_ENABLED` | `true` | Enable Feroxbuster. |
| `NIKTO_ENABLED` | `true` | Enable Nikto server audit. |
| `TESTSSL_ENABLED` | `true` | Enable Testssl TLS audit. |
| `WAPITI_ENABLED` | `true` | Enable Wapiti (blackbox mode). |
| `SQLMAP_ENABLED` | `true` | Enable SQLMap. |
| `DALFOX_ENABLED` | `true` | Enable Dalfox XSS. |
| `NUCLEI_DEFAULT_RATE_LIMIT` | `150` | Nuclei req/s (capped to 10 under WAF). |
| `FFUF_WORDLIST_PATH` | `/usr/share/seclists/Discovery/Web-Content/common.txt` | ffuf wordlist. |
| `SEMGREP_RULES` | `local` | `local` = bundled, `auto` = download from semgrep.dev. |
| **GitNexus** | | |
| `GITNEXUS_ENABLED` | `false` | Enable GitNexus MCP integration. |
| `GITNEXUS_MCP_URL` | `http://localhost:4747/api/mcp` | GitNexus MCP endpoint. |
| `GITNEXUS_REPO` | | Indexed repo identifier. |
| `GITNEXUS_TIMEOUT_SECONDS` | `15` | Request timeout. |
| **TrustScan** | | |
| `TRUSTSCAN_ENABLED` | `false` | Enable TrustScan Platform. |
| `TRUSTSCAN_PLATFORM_URL` | `https://trustscan.sc.deeptrustxai.com` | Platform base URL. |
| **CloudGuard CP** | | |
| `CP_SHARED_SECRET` | | HMAC secret for CP callbacks. |
| `CP_APP_LAUNCH_URL` | | SSO entry URL for CP redirect. |
| `CP_EXPECTED_ISSUER` | | CP JWT issuer URL. |
| `CP_JWKS_URL` | | JWKS URL (defaults to `<CP_EXPECTED_ISSUER>/.well-known/jwks.json`). |
| `CP_SCANNER_KEY` | `traceon` | Scanner identity key in CP catalog. |
| **Queue** | | |
| `SCAN_QUEUE_MODE` | `local` | `local`, `sqs`, or `redis`. |
| `SQS_QUEUE_URL` | | AWS SQS URL (required for `sqs` mode). |
| `AWS_REGION` | | AWS region for SQS. |
| `REDIS_URL` | | Redis URL (required for `redis` mode). |
| `REDIS_QUEUE_NAME` | `traceon:scan_jobs` | Redis list key. |
| **Auth Test Credentials** | | |
| `AUTH_TEST_USERNAME` | `scanner_test_user` | Throwaway test user for API auth auto-registration. |
| `AUTH_TEST_PASSWORD` | `ScannerT3st!Pass` | Test user password. |
| `AUTH_TEST_EMAIL` | `scanner@test.local` | Test user email. |

---

## 10. Database

### Supported Backends

| Backend | URL format | Notes |
|---------|-----------|-------|
| SQLite (default) | `sqlite+aiosqlite:///./traceon.db` | WAL mode. Use for dev or single-worker deployments. |
| PostgreSQL | `postgresql+asyncpg://user:pass@host/db` | Recommended for production, multi-worker setups. |

### Migrations

No Alembic. `run_migrations()` in `database.py` runs at every startup (idempotent):
- **SQLite**: `ALTER TABLE ADD COLUMN IF NOT EXISTS` for each column in `_SQLITE_COLUMN_MIGRATIONS`.
- **PostgreSQL**: `ALTER TABLE findings ALTER COLUMN owasp_category TYPE TEXT`.

Add new column definitions to `_SQLITE_COLUMN_MIGRATIONS` when adding model fields.

### Docker Volumes

| Volume | Container path | Content |
|--------|---------------|---------|
| `db_data` | `/data/db` | SQLite database + auto-generated keys |
| `projects_data` | `/data/projects` | Project source uploads |
| `reports_data` | `/data/reports` | Generated reports |
| `uploads_data` | `/data/uploads` | Artifact uploads (specs, journey files) |
| `nuclei_templates` | `/root/.local/share/nuclei-templates` | Nuclei template cache |

---

## 11. Deployment

### Quick Start (Docker Compose)

```bash
# Clone and configure
cp .env.example .env
# Required: set ZAP_API_KEY
# Optional: set ANTHROPIC_API_KEY (or other LLM keys)

docker compose up -d

# Get the auto-generated API key
docker exec traceon-backend cat /data/db/.api_key
```

Access: `http://localhost:8000`

### Resource Limits

| Service | CPU limit | Memory limit |
|---------|----------|-------------|
| `backend` (TraceON) | 2.0 cores | 2 GB |
| `zap` (OWASP ZAP) | 2.0 cores | 4 GB (JVM: `-Xmx3g`) |

ZAP startup health check: `curl http://localhost:8080/JSON/core/view/version/` — backend waits until ZAP passes.

### Multi-Stage Docker Build

| Stage | Base image | Purpose |
|-------|-----------|---------|
| `frontend-build` | `node:20-alpine` | `npm ci && npm run build` |
| `python-builder` | `python:3.11-slim` | Compile Python wheels into `/opt/venv` |
| `go-tools` | `golang:1.22-alpine` | Build `gau` and `ffuf` binaries |
| `runtime` | `python:3.11-slim` | Copy venv + Go bins + download Nuclei + install Nikto + Wapiti |

Playwright Chromium included when `INCLUDE_PLAYWRIGHT=true` (default in docker-compose).

SecLists wordlists downloaded at build time for ffuf: `common.txt`, `api-endpoints.txt`.

### Development Setup

```bash
# Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Frontend (separate terminal)
cd frontend
npm install
npm run dev   # http://localhost:5173
```

`vite.config.ts` proxies `/api` and `/ws` to `http://localhost:8000`.

---

## 12. External Tool Integration

| Tool | Phase | Binary | Install method in Docker |
|------|-------|--------|--------------------------|
| OWASP ZAP | Active DAST | ZAP HTTP API | Separate `zaproxy/zap-stable` container |
| Nuclei | Extended DAST | `nuclei` | Pre-compiled binary downloaded at build |
| ffuf | Path fuzzing | `ffuf` | Built from Go source at build |
| gau | URL discovery | `gau` | Built from Go source at build |
| Feroxbuster | Path fuzzing | `feroxbuster` | Requires manual install or additional build step |
| Nikto | Server audit | `nikto.pl` | Cloned from GitHub at build (`/opt/nikto`) |
| Testssl | TLS audit | `testssl.sh` | Requires manual install or additional build step |
| SQLMap | SQL injection | `sqlmap` | Requires manual install or additional build step |
| Dalfox | XSS | `dalfox` | Requires manual install or additional build step |
| Wapiti | Extended DAST | `wapiti3` | `pip install wapiti3` at build |
| Playwright | Browser spider/auth | Chromium | `playwright install chromium` at build (optional) |

All tools check `*_ENABLED` env var before running. Missing tools are non-fatal — phase is skipped with a warning log.

---

## 13. LLM Providers

### Provider Priority Resolution

```
Per-scan scan_config (llm_provider / llm_model / llm_api_key)
    └── llm_provider_credentials table (user-stored, Fernet-encrypted)
            └── project.llm_provider / project.llm_api_key_encrypted
                    └── env vars (LLM_PROVIDER / LLM_MODEL)
                            └── catalog.py defaults
```

### Adding Credentials via API

```http
POST /api/v1/llm/providers
X-API-Key: <your-key>

{"provider": "anthropic", "api_key": "sk-ant-...", "default_model": "claude-3-5-haiku-latest"}
```

### Validating Credentials

```http
POST /api/v1/llm/providers/anthropic/validate
X-API-Key: <your-key>
```

Sends a minimal `{"ok": true}` chat request to verify key + model.

### GitHub Copilot Provider

Uses the Copilot API at `https://api.githubcopilot.com` (OpenAI-compatible). Requires `GITHUB_COPILOT_TOKEN` or `COPILOT_API_KEY`. `"copilot"` provider name normalizes to `"github"` internally.

---

## 14. Security Design

### API Authentication

- `X-API-Key: <key>` or `Authorization: Bearer <key>` on all protected routes.
- Key is SHA-256 hashed before DB comparison — plain key never persists to DB.
- In `DEBUG=true` + localhost/private IP: key auto-injected into `index.html` as `window.__DT_API_KEY__`.

### Credential Encryption

All third-party credentials (LLM API keys, TrustScan tokens, auth passwords) encrypted with Fernet (`ENCRYPTION_KEY` + `ENCRYPTION_SALT`) before storage. Key lives outside the database.

### WebSocket Security

- Tokens HMAC-SHA256 signed with `API_KEY`, include nonce + expiry.
- **Single-use** — consumed on WS connect; replayed tokens rejected.
- WS token endpoint requires API key auth.
- 120-second TTL.

### Rate Limiting

300 requests/minute per IP (sliding window). Local/private-range IPs exempt. Headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Window`.

### HTTP Security Headers

Applied to all responses:

| Header | Value |
|--------|-------|
| `Content-Security-Policy` | `default-src 'self'`, `script-src 'self'`, `frame-ancestors 'none'`, `upgrade-insecure-requests` (HTTPS only) |
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `X-XSS-Protection` | `1; mode=block` |
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains` (HTTPS, non-localhost) |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `microphone=(), camera=(), geolocation=()` |

### SSRF Protection

`validate_external_target_url()` blocks all private RFC-1918 ranges, loopback, and link-local before any external HTTP call.

### Path Traversal Prevention

The SPA catch-all route (`/app/main.py: serve_spa`) resolves file paths with `Path.resolve()` and validates them against the static directory with `relative_to()` before serving.

---

## 15. Queue Backends

| `SCAN_QUEUE_MODE` | Behavior |
|-------------------|---------|
| `local` (default) | Scans run as asyncio tasks. `_scan_tasks` dict tracks them. No external deps. |
| `sqs` | `boto3` sends to SQS on scan create. Background worker (`SCAN_QUEUE_POLL_ENABLED=true`) polls and executes. |
| `redis` | `redis-py` `LPUSH`/`BRPOP` on `REDIS_QUEUE_NAME`. Multi-node capable without AWS. |

Queue API: `enqueue(payload) → bool`, `poll(wait_seconds, max_messages) → [ScanQueueJob]`, `ack(receipt_handle) → bool`.

---

## 16. Testing

```bash
cd backend
pip install pytest pytest-asyncio
pytest tests/
```

Config: `backend/pytest.ini`.

Coverage collected in `backend/coverage_data/` via the `coverage` package (a listed dependency).

---

## 17. Contributing

### Adding a New Scanner Engine

1. Create `backend/app/scanners/<name>_engine.py` with an async `scan(target_url, **kwargs) → list[dict]` method.
2. Add a `<NAME>_ENABLED: bool` setting in `config.py`.
3. Call the engine from `orchestrator.py` in the appropriate phase method.
4. Document the binary install method in this README's External Tools table.

### Adding a New Vulnerability Type

1. Add canonical name + variants to `VULN_TYPE_EQUIVALENTS` in `correlation_engine.py`.
2. Add a fix strategy to `fix_generator.py`.
3. Add CWE mapping in `sarif_export.py` (`CWE_TAXONOMY`).
4. Add ZAP alert ID → type mapping in `dast_engine.py` (`ZAP_ALERT_MAP`).

### Adding a New LLM Provider

1. Add to `ALLOWED_LLM_PROVIDERS` in `provider_config.py`.
2. Implement `_api_key()` and `_chat_text()` branches in `llm/client.py`.
3. Add default model in `llm/catalog.py`.
4. Add API key env var in `config.py` and `.env.example`.

### Coding Conventions

- All async DB operations use `AsyncSession` from `core/database.py`.
- Never access `AsyncSession` concurrently — acquire `_db_lock` (per-orchestrator `asyncio.Lock`) first.
- API keys and credentials must be encrypted before storage; never log plaintext.
- External tool subprocess calls must check `*_ENABLED` flag before executing.
- New env vars go in `Settings` class **and** `.env.example`.
- Ephemeral scan state (routes found, DAST findings) lives on the `ScanOrchestrator` instance; only finalized data is persisted to DB.

---

*All features documented here are verified against the actual TraceON v1.0.0 source code in this repository.*
