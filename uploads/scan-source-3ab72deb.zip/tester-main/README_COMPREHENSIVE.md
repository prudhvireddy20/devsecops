# TraceON - Multi-Mode Security Scanner

**A comprehensive security scanning platform supporting White-box and Black-box testing with DAST, static finding correlation, and DevSecOps integration.**

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Scanning Modes](#scanning-modes)
- [Quick Start](#quick-start)
- [Project Structure](#project-structure)
- [Technology Stack](#technology-stack)
- [API Reference](#api-reference)
- [Configuration](#configuration)
- [Development](#development)
- [Recent Changes](#recent-changes)
- [Troubleshooting](#troubleshooting)

---

## Overview

### Core Philosophy

> **Static analysis is owned by the DevSecOps platform. TraceON focuses on dynamic testing and correlation.**

TraceON bridges the gap between static and dynamic testing by:

- **Importing** external static findings from DevSecOps platforms or JSON files (SARIF, Semgrep)
- **Running** DAST scans using OWASP ZAP against live targets
- **Discovering** APIs and endpoints through passive and active scanning (gau, ffuf, nikto)
- **Correlating** findings across multiple scanning tools
- **Supporting** multi-role authentication testing
- **Generating** comprehensive security reports

### Key Features

| Feature | White-box | Black-box | Details |
|---------|-----------|-----------|---------|
| **External Import** | ✅ Required | ❌ N/A | Import static findings from DevSecOps |
| **URL Discovery** | ❌ N/A | ✅ | gau + ffuf + nikto enumeration |
| **ZAP DAST** | ✅ | ✅ | Spider + active vulnerability scanning |
| **Nuclei Templates** | ✅ (6000+) | ✅ (All) | Security exposure scanning |
| **WAF Detection** | ✅ | ✅ | Identify & bypass WAF |
| **Multi-Role Auth** | ✅ | ✅ | Test different user roles |
| **Correlation** | ✅ Static ↔ DAST | ✅ DAST only | Match & deduplicate findings |
| **Reporting** | ✅ | ✅ | PDF/HTML/JSON output |

---

## Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         TraceON Scanner                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────┐         ┌──────────────────────────┐     │
│  │   Frontend UI    │◄────────┤   REST API Backend       │     │
│  │  (React/Vite)    │         │   (FastAPI/Uvicorn)     │     │
│  │                  │         │                          │     │
│  │ • Create Project │         │ • Project Management     │     │
│  │ • Configure Scan │         │ • Scan Orchestration     │     │
│  │ • View Progress  │         │ • WebSocket Progress     │     │
│  │ • View Results   │         │ • Finding Storage        │     │
│  └──────────────────┘         └──────────────────────────┘     │
│                                          │                      │
│                                          ▼                      │
│                    ┌──────────────────────────────┐             │
│                    │    Scan Orchestrator         │             │
│                    │  (Core Orchestration Logic)  │             │
│                    └──────────────────────────────┘             │
│                      │        │        │        │              │
│          ┌───────────┘        │        │        └────────┐     │
│          │                    │        │                 │     │
│          ▼                    ▼        ▼                 ▼     │
│    ┌──────────────┐   ┌────────────┐ ┌───────┐   ┌──────────┐│
│    │ External     │   │ OWASP ZAP  │ │Nuclei │   │Discovery ││
│    │ Importer     │   │ DAST Engine│ │Engine │   │ Tools    ││
│    │              │   │            │ │       │   │          ││
│    │ • SARIF      │   │ • Spider   │ │Active │   │ • gau    ││
│    │ • Semgrep    │   │ • Active   │ │Scan   │   │ • ffuf   ││
│    │ • DevSecOps  │   │   Scan     │ │       │   │ • nikto  ││
│    │ • Custom     │   │ • WAF Detect│ │       │   │ • wapiti ││
│    └──────────────┘   └────────────┘ └───────┘   └──────────┘│
│          │                    │        │                 │     │
│          └───────────┬────────┴────────┴─────────────────┘     │
│                      │                                          │
│                      ▼                                          │
│          ┌──────────────────────────┐                          │
│          │  Correlation Engine      │                          │
│          │  (Static ↔ DAST Match)   │                          │
│          └──────────────────────────┘                          │
│                      │                                          │
│                      ▼                                          │
│          ┌──────────────────────────┐                          │
│          │   Report Generator       │                          │
│          │  (PDF, JSON, HTML, etc)  │                          │
│          └──────────────────────────┘                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │   Data Storage   │
                    │  (SQLite/Async)  │
                    └──────────────────┘
```

### Component Responsibilities

```
Frontend (React + Vite)
  ├─ Project creation & management UI
  ├─ Scan configuration form
  ├─ Real-time progress monitoring (WebSocket)
  └─ Finding results visualization

Backend (FastAPI)
  ├─ Project CRUD API
  ├─ Scan lifecycle management
  ├─ WebSocket progress streaming
  └─ Finding storage & retrieval

Scan Orchestrator (Core Logic)
  ├─ Phase pipeline execution
  ├─ Tool coordination (ZAP, Nuclei, etc.)
  ├─ Timeout management
  ├─ Progress tracking
  └─ Error handling & recovery

External Tools
  ├─ OWASP ZAP (DAST engine)
  ├─ Nuclei (Security templates)
  ├─ gau (URL discovery)
  ├─ ffuf (Path fuzzing)
  ├─ nikto (Server audit)
  └─ wapiti (Advanced testing)

Database (SQLite)
  ├─ Projects
  ├─ Scans
  ├─ Findings
  └─ Metadata
```

---

## Scanning Modes

### White-box Mode (10 Phases)

**When to use**: You have source code and external static findings

**Required**: DevSecOps connection OR SARIF/JSON static findings

**Pipeline**:
```
1. Import External Findings
   └─ Fetch static findings from DevSecOps or JSON file
   
2. Endpoint Discovery
   └─ Extract API routes from imported findings
   
3. Fingerprinting
   └─ Detect framework, server, language
   
4. Authentication Setup (Playwright)
   └─ Execute login script, establish session
   
5. ZAP Spider
   └─ Passive crawling of application
   
6. WAF Detection
   └─ Identify WAF presence and bypass strategies
   
7. ZAP Active Scan
   └─ OWASP ZAP active vulnerability scanning
   
8. Nuclei Security Templates
   └─ Run 6000+ security template checks
   
9. Correlation (Static ↔ DAST)
   └─ Match imported findings with DAST results
   
10. Report Generation
    └─ Compile findings into comprehensive report
```

**Benefits**:
- Correlate source code issues with runtime behavior
- Verify fixes are actually deployed
- Reduce false positives with context
- Full coverage (code + runtime)

### Black-box Mode (11 Phases)

**When to use**: Testing live applications without source code

**Requirements**: Live target URL with network access

**Pipeline**:
```
1. URL Discovery (gau + archive.org)
   └─ Passive endpoint enumeration
   
2. Fingerprinting
   └─ Detect framework, server, language
   
3. Nikto Server Audit
   └─ Scan for misconfigs, CVEs, dangerous files
   
4. Authentication Setup (Playwright)
   └─ Execute login script, establish session
   
5. ZAP Spider (seeded)
   └─ Crawling with discovered URLs as seeds
   
6. WAF Detection
   └─ Identify WAF presence and bypass strategies
   
7. ZAP Active Scan
   └─ OWASP ZAP active vulnerability scanning
   
8. Nuclei Security Templates
   └─ Run ALL 6000+ security templates
   
9. Wapiti Advanced Payloads
   └─ Optional: XXE, LDAP, CRLF injection testing
   
10. Correlation (DAST only)
    └─ Deduplicate and verify findings
    
11. Report Generation
    └─ Compile findings into comprehensive report
```

**Benefits**:
- No source code access needed
- Comprehensive endpoint discovery
- Real-world testing conditions
- Fast setup and execution

---

## Quick Start

### Prerequisites

```bash
- Docker & Docker Compose 2.0+
- Python 3.11+ (for local development)
- Node.js 18+ (for frontend dev)
- Git
```

### Docker Compose (Recommended)

```bash
# 1. Clone repository
git clone https://github.com/anishalx/tester.git
cd tester

# 2. Copy environment file
cp .env.example .env
# Edit .env if needed (optional - defaults work for local dev)

# 3. Start services
docker-compose up -d

# 4. Wait for services to be healthy (30-60 seconds)
docker-compose ps

# 5. Access the application
# Frontend: http://localhost:5173
# API Docs: http://localhost:8000/docs
# API Key: Check logs for auto-generated key
```

### Local Development

**Backend:**

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Optional: Install optional dependencies
pip install semgrep  # SAST (heavy install)
playwright install chromium  # Auth automation

cp ../.env.example .env
uvicorn app.main:app --reload --port 8000
```

**Frontend (separate terminal):**

```bash
cd frontend
npm install
npm run dev
# Opens at http://localhost:5173 with proxy to :8000
```

**OWASP ZAP (required for DAST):**

```bash
docker run -d -p 8080:8080 zaproxy/zap-stable \
  zap.sh -daemon -port 8080 -host 0.0.0.0 \
  -config api.key=change-me-zap-api-key \
  -config api.addrs.addr.name=.* \
  -config api.addrs.addr.regex=true
```

### First Scan

1. Open http://localhost:5173
2. Click "New Project"
3. Select scan mode:
   - **White-box**: Enter DevSecOps URL or upload SARIF/JSON
   - **Black-box**: Enter target URL
4. Configure authentication (optional)
   - Auth type: None / Basic / Form / Playwright
   - Username & password
   - Add roles (admin, user, etc.)
5. Click "Create Project"
6. Click "Configure Scan" then "Start Scan"
7. Monitor progress in real-time
8. View findings when complete

---

## Project Structure

```
TraceON/
├── backend/                          # FastAPI backend
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                  # FastAPI app entry
│   │   ├── api/
│   │   │   ├── projects.py          # Project CRUD endpoints
│   │   │   ├── scans.py             # Scan execution endpoints
│   │   │   ├── findings.py          # Finding retrieval
│   │   │   └── websocket.py         # WebSocket progress
│   │   ├── core/
│   │   │   ├── config.py            # Settings (env vars)
│   │   │   ├── database.py          # SQLAlchemy async setup
│   │   │   ├── orchestrator.py      # Main scan orchestration
│   │   │   ├── url_safety.py        # Target URL validation
│   │   │   └── security.py          # Token encryption
│   │   ├── models/
│   │   │   ├── project.py           # SQLAlchemy Project model
│   │   │   ├── scan.py              # SQLAlchemy Scan model
│   │   │   ├── finding.py           # SQLAlchemy Finding model
│   │   │   └── ...other models
│   │   └── scanners/                # Scanning engines
│   │       ├── dast_engine.py       # OWASP ZAP wrapper
│   │       ├── nuclei_engine.py     # Nuclei wrapper
│   │       ├── url_discovery_engine.py  # gau + ffuf
│   │       ├── nikto_engine.py      # Nikto wrapper
│   │       ├── wapiti_engine.py     # Wapiti wrapper
│   │       ├── external_importer.py # Static findings import
│   │       ├── sast_engine.py       # DISABLED (Semgrep)
│   │       ├── secret_scanner.py    # DISABLED (detect-secrets)
│   │       └── dependency_scanner.py # DISABLED (pip-audit)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── entrypoint.sh
│
├── frontend/                        # React + Vite frontend
│   ├── src/
│   │   ├── main.tsx                 # App entry
│   │   ├── App.tsx                  # Root component
│   │   ├── pages/
│   │   │   ├── Projects.tsx         # Create project modal
│   │   │   ├── ScanConfig.tsx       # Configure scan settings
│   │   │   ├── ScanProgress.tsx     # Live scan monitoring
│   │   │   ├── Results.tsx          # Finding results view
│   │   │   └── Dashboard.tsx        # Project overview
│   │   ├── components/
│   │   │   ├── ApiKeyGate.tsx       # Auth gate
│   │   │   ├── Toast.tsx            # Notifications
│   │   │   └── ...other components
│   │   ├── services/
│   │   │   └── api.ts               # API client (axios)
│   │   ├── styles/
│   │   │   └── globals.css          # Global styles
│   │   └── utils/
│   │       └── ...utility functions
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   └── Dockerfile
│
├── docker-compose.yml               # Container orchestration
├── .env                             # Environment variables
│
├── README_COMPREHENSIVE.md          # This file
├── REFACTOR_SUMMARY.md              # Static analysis removal docs
├── TESTING_REPORT.md                # Test results
├── COMPREHENSIVE_TEST_RESULTS.md    # Detailed test summary
└── FINAL_TEST_SUMMARY.md            # Final test status
```

---

## Technology Stack

### Backend

```
Runtime:        Python 3.11
Framework:      FastAPI (modern, async-first)
Web Server:     Uvicorn (ASGI)
Database:       SQLite with SQLAlchemy ORM
Async:          asyncio, aiosqlite
HTTP Client:    httpx, requests
Scanning:       OWASP ZAP, Nuclei, Custom tools
```

### Frontend

```
UI Framework:   React 18+ (TypeScript)
Build Tool:     Vite (fast dev/build)
HTTP Client:    Axios
Icons:          Lucide React
Styling:        Tailwind CSS
State Mgmt:     React Hooks
```

### Infrastructure

```
Containerization: Docker & Docker Compose
Databases:        SQLite (local dev)
DAST Engine:      OWASP ZAP (separate container)
```

---

## API Reference

### Base URL
```
http://localhost:8000/api/v1
```

### Authentication
```
Header: X-API-Key: <api-key>
(Auto-generated on startup, check logs)
```

### Projects API

#### Create Project
```bash
POST /projects

Request:
{
  "name": "My App",
  "description": "Staging environment",
  "scan_mode": "whitebox",  # or "blackbox"
  "target_url": "https://app.example.com",
  "source_type": "url",
  
  # For white-box:
  "devsecops_url": "https://devsecops.example.com",
  "devsecops_token": "token123"
}

Response:
{
  "id": "uuid",
  "name": "My App",
  "scan_mode": "whitebox",
  "target_url": "https://app.example.com",
  "created_at": "2026-06-25T02:11:59Z"
}
```

#### Get Projects
```bash
GET /projects

Response:
{
  "items": [
    {
      "id": "uuid",
      "name": "My App",
      "scan_mode": "whitebox",
      "target_url": "https://app.example.com"
    }
  ]
}
```

### Scans API

#### Start Scan
```bash
POST /scans

Request:
{
  "project_id": "uuid",
  "modules_enabled": {
    "dast": true,
    "nuclei": true,
    "url_discovery": true  # black-box only
  },
  "auth_config": {
    "auth_type": "basic",
    "username": "admin",
    "password": "password",
    "roles": ["admin", "user"]
  },
  "scan_config": {
    "scan_depth": 5,
    "timeout": 1800
  }
}

Response:
{
  "id": "scan-uuid",
  "status": "running",
  "progress": 0
}
```

#### Get Scan Status
```bash
GET /scans/{scan_id}

Response:
{
  "id": "scan-uuid",
  "status": "running",
  "progress": 45,
  "current_phase": "active_scan",
  "results_summary": {
    "total_findings": 8,
    "critical": 1,
    "high": 2,
    "medium": 3,
    "low": 2
  }
}
```

### WebSocket Events

```
ws://localhost:8000/ws/{scan_id}

Progress Update:
{
  "type": "progress",
  "progress": 45,
  "phase": "active_scan",
  "timestamp": "2026-06-25T02:15:30Z"
}

Log Message:
{
  "type": "log",
  "message": "ZAP spider completed: discovered 23 routes"
}

Complete:
{
  "type": "complete",
  "status": "completed",
  "findings_count": 8
}
```

---

## Configuration

### Environment Variables

```bash
# Core
APP_NAME=TraceON
APP_VERSION=1.0.0
DEBUG=False
HOST=0.0.0.0
PORT=8000

# Database
DATABASE_URL=sqlite+aiosqlite:///./traceon.db

# OWASP ZAP (DAST Engine)
ZAP_API_URL=http://localhost:8080
ZAP_API_KEY=change-me-zap-api-key

# DAST Timeouts (seconds)
DAST_BASE_TIMEOUT=1200           # 20 minutes
DAST_ABSOLUTE_MAX_TIMEOUT=1800   # 30 minutes (hard limit)
DAST_STALL_TIMEOUT=180           # 3 minutes no progress = fail
DAST_ADAPTIVE_TIMEOUT=True       # Scale by route count

# Discovery Tools
GAU_ENABLED=True
FFUF_ENABLED=True
NIKTO_ENABLED=True
WAPITI_ENABLED=False
FFUF_WORDLIST_PATH=/usr/share/seclists/Discovery/Web-Content/common.txt

# Nuclei
NUCLEI_DEFAULT_RATE_LIMIT=50

# Security
ENCRYPTION_KEY=<auto-generated>
ENCRYPTION_SALT=<persisted>
```

### Adaptive Timeout Configuration

For **remote targets** (network I/O bound):
- Thread count: 4 (vs 2 for local)
- Attack strength: "Low" (vs "High")
- Result: 40-50% faster scans

For **local targets**:
- Thread count: 2 (conservative)
- Attack strength: "High"

This is automatically detected and applied by the orchestrator.

---

## Development

### Adding a New Scanner

1. Create `backend/app/scanners/new_scanner.py`
2. Implement standard interface:

```python
class NewScanner:
    async def scan(self, target_url: str, options: dict) -> list[dict]:
        """Run scan and return findings list."""
        findings = []
        # Implementation
        return findings
```

3. Register in `backend/app/core/orchestrator.py`
4. Add configuration in `backend/app/core/config.py`

### Frontend Development

```bash
cd frontend
npm install
npm run dev

# Build for production
npm run build

# Type checking
npm run type-check
```

### Backend Development

```bash
cd backend
python -m pip install -r requirements.txt
uvicorn app.main:app --reload

# Run tests
python -m pytest tests/ -v

# Exclude slow tests
python -m pytest tests/ -v -m "not slow"
```

### Commit Message Format

```
<type>: <subject>

<description>

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>
```

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `perf`: Performance improvement
- `refactor`: Code refactoring
- `docs`: Documentation
- `test`: Test addition/modification
- `ui`: User interface changes

### Branch Strategy

```
main              (production-ready)
  ↑
dev               (development branch)
  ↑
feature/*         (feature branches)
bugfix/*          (bug fix branches)
```

---

## Recent Changes

### v1.0.0 - Initial Release (Latest)

**Major Refactoring - Static Analysis Removal**:
- ✅ Removed internal SAST scanner (Semgrep)
- ✅ Removed internal secrets scanner (detect-secrets)
- ✅ Removed internal dependency scanner (pip-audit)
- ✅ Consolidated scanning modes: 3 → 2 (White-box + Black-box only)
- ✅ Static analysis now exclusively owned by DevSecOps platform

**Authentication Configuration**:
- ✅ Moved auth config from ScanConfig to Create Project modal
- ✅ Username & password fields in project creation
- ✅ Multi-role testing support with add/remove
- ✅ Collapsible optional auth section

**Performance Optimizations**:
- ✅ ZAP active scan optimization (commit 6f83d6c)
- ✅ Adaptive threading: 4 threads for remote targets, 2 for local
- ✅ Reduced attack strength for remote targets
- ✅ Expected: 40-50% faster scans (15-20 min vs 28-30 min)

**Bug Fixes**:
- ✅ Timeout hang on complex targets (commit 89a56d9)
- ✅ ZAP active scan timeout logic with hard limits
- ✅ Default source_type handling (commit a75a32a)

**UI Improvements**:
- ✅ Smooth view transitions for mode switching (commit 826ca51)
- ✅ Polished create project modal (commit ed66091)
- ✅ DevSecOps integration defaults to disconnected

---

## Troubleshooting

### Scan Hangs at 75%

**Fixed in**: commit 89a56d9

**Issue**: Scan would hang indefinitely at 75% progress

**Solution**: 
- Implemented hard 30-minute timeout (cannot be exceeded)
- Soft timeout now requires both duration AND stall conditions
- Clear error messaging when timeout occurs

### Slow Active Scans (28-30 minutes)

**Fixed in**: commit 6f83d6c

**Issue**: Active scans taking 28-30 minutes on hosted targets

**Root Cause**: Only 2 threads on remote targets (network I/O bottleneck)

**Solution**:
- Auto-detect remote targets by hostname
- Use 4 threads for remote targets (vs 2 for local)
- Use "Low" attack strength for remote targets
- Expected: 15-20 minutes on hosted Juice Shop

### API Returns 500 Error

**Check**:
1. Backend container logs: `docker logs traceon-backend`
2. API key configured: `docker logs traceon-backend | grep API_KEY`
3. ZAP service running: `docker ps | grep zap`
4. Target URL accessible from container

### Scan Status Stuck at 0%

**Check**:
1. WebSocket connection: Open DevTools → Network tab
2. Backend logs for initialization errors
3. Project configuration (mode, target URL)
4. Auth config if authentication is enabled

---

## Support & Contributing

### Issues
Check GitHub issues or create a new one with:
- Scan mode (white-box/black-box)
- Target details (public/private, framework)
- Full error logs from backend
- Expected vs. actual behavior

### Contributing
1. Fork the repository
2. Create feature branch: `git checkout -b feature/your-feature`
3. Make changes with clear commit messages
4. Push and create a pull request
5. Ensure all tests pass and CI checks succeed

---

## License

Proprietary - Internal Use Only

---

## Resources

- **OWASP ZAP**: https://www.zaproxy.org/
- **Nuclei**: https://nuclei.projectdiscovery.io/
- **FastAPI**: https://fastapi.tiangolo.com/
- **React**: https://react.dev/
- **SQLAlchemy**: https://www.sqlalchemy.org/

---

**Last Updated**: 2026-06-25  
**Status**: ✅ Production Ready  
**Version**: 1.0.0
