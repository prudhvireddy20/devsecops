"""Auth flow detector - identifies authentication patterns in source code."""
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class AuthDetector:
    """Detects authentication flows, decorators, and middleware in source code."""

    AUTH_PATTERNS = {
        "login_route": [
            r"@\w+\.route\(['\"].*login.*['\"]\s*",
            r"def\s+login\s*\(",
            r"path\(['\"].*login.*['\"]",
            r"@\w+\.post\(['\"].*login.*['\"]\s*",
            r"@\w+\.post\(['\"].*auth.*['\"]\s*",
            r"@\w+\.post\(['\"].*token.*['\"]\s*",
        ],
        "jwt": [
            r"import\s+jwt",
            r"from\s+jose\s+import",
            r"from\s+flask_jwt",
            r"jwt\.encode\(",
            r"jwt\.decode\(",
            r"create_access_token\(",
            r"JWTAuthentication",
            r"OAuth2PasswordBearer",
        ],
        "session": [
            r"session\[",
            r"flask\.session",
            r"request\.session",
            r"SessionMiddleware",
            r"SESSION_ENGINE",
        ],
        "csrf": [
            r"csrf_token",
            r"CSRFProtect",
            r"@csrf_protect",
            r"CsrfViewMiddleware",
            r"csrf_exempt",
        ],
        "auth_decorators": [
            r"@login_required",
            r"@auth_required",
            r"@jwt_required",
            r"@token_required",
            r"@permission_required",
            r"@admin_required",
            r"@requires_auth",
            r"@authenticated",
            r"@permission_classes",
            r"Depends\(.*auth.*\)",
            r"Depends\(.*current_user.*\)",
        ],
        "password_hashing": [
            r"bcrypt",
            r"werkzeug\.security",
            r"generate_password_hash",
            r"check_password_hash",
            r"make_password",
            r"pbkdf2_sha256",
            r"passlib",
        ],
        "oauth": [
            r"OAuth",
            r"oauth2",
            r"social_django",
            r"allauth",
            r"authlib",
        ],
    }

    async def detect_auth(self, source_path: str) -> dict:
        """Detect authentication patterns in the source code."""
        source = Path(source_path)
        if not source.exists():
            return {"auth_type": "none", "details": {}}

        results = {
            "auth_type": "none",
            "has_login": False,
            "has_jwt": False,
            "has_session": False,
            "has_csrf": False,
            "has_oauth": False,
            "auth_decorators": [],
            "login_routes": [],
            "protected_routes": [],
            "public_routes": [],
            "details": {},
        }

        python_files = list(source.rglob("*.py"))
        for py_file in python_files[:200]:
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(py_file.relative_to(source))

                for category, patterns in self.AUTH_PATTERNS.items():
                    for pattern in patterns:
                        for i, line in enumerate(lines, 1):
                            if re.search(pattern, line):
                                if category == "login_route":
                                    results["has_login"] = True
                                    results["login_routes"].append({
                                        "file": rel_path,
                                        "line": i,
                                        "code": line.strip(),
                                    })
                                elif category == "jwt":
                                    results["has_jwt"] = True
                                elif category == "session":
                                    results["has_session"] = True
                                elif category == "csrf":
                                    results["has_csrf"] = True
                                elif category == "oauth":
                                    results["has_oauth"] = True
                                elif category == "auth_decorators":
                                    results["auth_decorators"].append({
                                        "file": rel_path,
                                        "line": i,
                                        "decorator": line.strip(),
                                    })

                # Detect protected vs public routes
                self._classify_routes(content, lines, rel_path, results)

            except Exception as e:
                logger.debug(f"Error scanning {py_file}: {e}")
                continue

        # Determine primary auth type
        if results["has_jwt"]:
            results["auth_type"] = "jwt"
        elif results["has_session"]:
            results["auth_type"] = "session"
        elif results["has_oauth"]:
            results["auth_type"] = "oauth"
        elif results["has_login"]:
            results["auth_type"] = "custom"

        return results

    def _classify_routes(
        self, content: str, lines: list[str], file_path: str, results: dict
    ):
        """Classify routes as protected or public based on decorators."""
        auth_decorator_patterns = [
            r"@login_required", r"@auth_required", r"@jwt_required",
            r"@token_required", r"@admin_required", r"@permission_required",
        ]
        route_patterns = [
            r"@\w+\.(route|get|post|put|delete|patch)\(['\"]([^'\"]+)['\"]",
        ]

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Check if this is a route definition
            for rp in route_patterns:
                match = re.search(rp, line)
                if match:
                    route_path = match.group(2)
                    # Look backwards for auth decorators
                    is_protected = False
                    for j in range(max(0, i - 5), i):
                        prev_line = lines[j].strip()
                        for ap in auth_decorator_patterns:
                            if re.search(ap, prev_line):
                                is_protected = True
                                break

                    route_info = {
                        "path": route_path,
                        "file": file_path,
                        "line": i + 1,
                    }
                    if is_protected:
                        results["protected_routes"].append(route_info)
                    else:
                        results["public_routes"].append(route_info)
            i += 1

    async def generate_auth_suggestion(self, auth_info: dict) -> dict:
        """Generate a Playwright login script suggestion based on detected auth patterns."""
        suggestion = {
            "script_type": "playwright",
            "auth_type": auth_info.get("auth_type", "none"),
            "script": "",
            "notes": [],
        }

        if auth_info["auth_type"] == "jwt":
            suggestion["script"] = self._jwt_login_template()
            suggestion["notes"].append("JWT-based auth detected. Script sends credentials to login endpoint and captures the token.")
        elif auth_info["auth_type"] == "session":
            suggestion["script"] = self._session_login_template()
            suggestion["notes"].append("Session-based auth detected. Script fills login form and submits.")
        elif auth_info["auth_type"] == "custom":
            suggestion["script"] = self._generic_login_template()
            suggestion["notes"].append("Custom auth detected. Please modify the script to match your login flow.")

        # Add login route info
        if auth_info.get("login_routes"):
            login_route = auth_info["login_routes"][0]
            suggestion["notes"].append(f"Login route found at: {login_route['file']}:{login_route['line']}")

        return suggestion

    def _jwt_login_template(self) -> str:
        return '''
import asyncio
from playwright.async_api import async_playwright

async def login(target_url: str, username: str, password: str) -> dict:
    """Login and return JWT token."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Navigate to login page
        await page.goto(f"{target_url}/login")

        # Fill in credentials
        await page.fill('input[name="username"], input[type="email"]', username)
        await page.fill('input[name="password"], input[type="password"]', password)

        # Submit form
        await page.click('button[type="submit"]')
        await page.wait_for_load_state("networkidle")

        # Capture token from localStorage or cookies
        token = await page.evaluate("() => localStorage.getItem('token') || localStorage.getItem('access_token')")
        cookies = await context.cookies()

        await browser.close()
        return {"token": token, "cookies": cookies}
'''

    def _session_login_template(self) -> str:
        return '''
import asyncio
from playwright.async_api import async_playwright

async def login(target_url: str, username: str, password: str) -> dict:
    """Login with session-based auth and return cookies."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        await page.goto(f"{target_url}/login")
        await page.fill('input[name="username"], input[type="email"]', username)
        await page.fill('input[name="password"], input[type="password"]', password)
        await page.click('button[type="submit"]')
        await page.wait_for_load_state("networkidle")

        cookies = await context.cookies()
        await browser.close()
        return {"cookies": cookies}
'''

    def _generic_login_template(self) -> str:
        return '''
import asyncio
from playwright.async_api import async_playwright

async def login(target_url: str, username: str, password: str) -> dict:
    """Generic login script - customize for your application."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Step: Customize selectors if needed, or rely on auto-detection
        await page.goto(f"{target_url}/login")
        await page.fill('#username', username)
        await page.fill('#password', password)
        await page.click('#login-button')
        await page.wait_for_load_state("networkidle")

        cookies = await context.cookies()
        token = await page.evaluate("() => localStorage.getItem('token')")
        await browser.close()
        return {"token": token, "cookies": cookies}
'''
