"""Django route parser - extracts URL patterns from Django applications."""
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class DjangoParser:
    """Parses Django applications to extract URL patterns."""

    URL_PATTERNS = [
        # path('url/', view, name='name')
        r"path\s*\(\s*['\"]([^'\"]*)['\"]",
        # re_path(r'^url/$', view)
        r"re_path\s*\(\s*r?['\"]([^'\"]*)['\"]",
        # url(r'^url/$', view) - legacy
        r"url\s*\(\s*r?['\"]([^'\"]*)['\"]",
    ]

    CLASS_BASED_VIEW_METHODS = [
        "get", "post", "put", "patch", "delete", "head", "options"
    ]

    async def extract_routes(self, source_path: str) -> list[dict]:
        """Extract all Django URL patterns from the source code."""
        source = Path(source_path)
        routes = []

        # Find urls.py files
        url_files = list(source.rglob("urls.py"))
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv", "migrations"}

        for url_file in url_files:
            if any(skip in url_file.parts for skip in skip_dirs):
                continue
            try:
                content = url_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(url_file.relative_to(source))

                # Find includes for prefix tracking
                includes = {}
                for line in lines:
                    include_match = re.search(
                        r"path\s*\(\s*['\"]([^'\"]*)['\"].*include\s*\(\s*['\"]([^'\"]+)['\"]",
                        line,
                    )
                    if include_match:
                        includes[include_match.group(2)] = include_match.group(1)

                # Extract URL patterns
                for i, line in enumerate(lines, 1):
                    for pattern in self.URL_PATTERNS:
                        match = re.search(pattern, line)
                        if match:
                            url_path = match.group(1)
                            # Clean regex patterns
                            url_path = url_path.replace("^", "").replace("$", "")
                            if not url_path.startswith("/"):
                                url_path = "/" + url_path

                            # Extract view name/class
                            view_match = re.search(
                                r",\s*(\w+(?:\.\w+)?(?:\.as_view\(\))?)", line
                            )
                            view_name = view_match.group(1) if view_match else ""

                            # Extract URL name
                            name_match = re.search(r"name\s*=\s*['\"](\w+)['\"]", line)
                            url_name = name_match.group(1) if name_match else ""

                            # Extract URL parameters
                            url_params = re.findall(r'<(?:\w+:)?(\w+)>', url_path)
                            # Also regex groups
                            url_params.extend(re.findall(r'\(\?P<(\w+)>', url_path))

                            # Determine methods (need to check the view)
                            methods = self._detect_view_methods(
                                source, view_name, content
                            )

                            for method in methods:
                                routes.append({
                                    "path": url_path,
                                    "method": method,
                                    "function": view_name,
                                    "file": rel_path,
                                    "line": i,
                                    "parameters": url_params,
                                    "url_name": url_name,
                                    "auth_required": False,  # Will be detected separately
                                    "auth_decorators": [],
                                    "framework": "django",
                                })

            except Exception as e:
                logger.debug(f"Error parsing {url_file}: {e}")
                continue

        # Detect auth requirements from views
        await self._detect_auth_for_routes(source, routes)

        return routes

    def _detect_view_methods(
        self, source: Path, view_name: str, urls_content: str
    ) -> list[str]:
        """Detect HTTP methods supported by a Django view."""
        if not view_name:
            return ["GET"]

        # Check if it's a class-based view
        if ".as_view()" in view_name:
            view_class = view_name.replace(".as_view()", "").split(".")[-1]
            # Search for the class definition
            for py_file in source.rglob("*.py"):
                try:
                    content = py_file.read_text(encoding="utf-8", errors="replace")
                    if f"class {view_class}" in content:
                        methods = []
                        for method in self.CLASS_BASED_VIEW_METHODS:
                            if re.search(rf"def\s+{method}\s*\(", content):
                                methods.append(method.upper())
                        return methods if methods else ["GET"]
                except Exception:
                    continue

        # Function-based views - check for request.method checks
        view_func = view_name.split(".")[-1]
        for py_file in source.rglob("*.py"):
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                if f"def {view_func}" in content:
                    methods = []
                    if "request.method" in content:
                        for method in ["GET", "POST", "PUT", "DELETE", "PATCH"]:
                            if f'"{method}"' in content or f"'{method}'" in content:
                                methods.append(method)
                    # Check @require_http_methods
                    method_match = re.search(
                        r'@require_http_methods\s*\(\s*\[([^\]]+)\]',
                        content,
                    )
                    if method_match:
                        methods = [
                            m.strip().strip("'\"")
                            for m in method_match.group(1).split(",")
                        ]
                    return methods if methods else ["GET"]
            except Exception:
                continue

        return ["GET"]

    async def _detect_auth_for_routes(
        self, source: Path, routes: list[dict]
    ):
        """Check Django views for authentication decorators."""
        auth_patterns = [
            r"@login_required",
            r"@permission_required",
            r"@staff_member_required",
            r"@user_passes_test",
            r"permission_classes\s*=",
            r"authentication_classes\s*=",
            r"IsAuthenticated",
            r"IsAdminUser",
        ]

        for py_file in source.rglob("views.py"):
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")

                for route in routes:
                    func_name = route["function"].split(".")[-1].replace(
                        ".as_view()", ""
                    )
                    for i, line in enumerate(lines):
                        if f"def {func_name}" in line or f"class {func_name}" in line:
                            # Check previous lines for auth decorators
                            for k in range(max(0, i - 10), i):
                                for ap in auth_patterns:
                                    if re.search(ap, lines[k]):
                                        route["auth_required"] = True
                                        route["auth_decorators"].append(
                                            lines[k].strip()
                                        )
            except Exception:
                continue
