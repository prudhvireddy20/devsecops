"""Express route parser - extracts routes from Express.js applications."""
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)


class ExpressParser:
    """Parses Express applications to extract route definitions from JS/TS files."""

    ROUTE_CALL_PATTERN = re.compile(
        r"(?P<obj>\w+)\.(?P<method>get|post|put|delete|patch|options|head|all)\s*\(\s*['\"](?P<path>[^'\"]+)['\"]",
        re.IGNORECASE,
    )
    USE_CALL_PATTERN = re.compile(
        r"(?P<obj>\w+)\.use\s*\(\s*['\"](?P<prefix>[^'\"]+)['\"]\s*,\s*(?P<router>\w+)",
        re.IGNORECASE,
    )
    ROUTER_DEF_PATTERN = re.compile(
        r"\b(?:const|let|var)\s+(?P<name>\w+)\s*=\s*(?:express\.)?Router\s*\(",
        re.IGNORECASE,
    )
    APP_DEF_PATTERN = re.compile(
        r"\b(?:const|let|var)\s+(?P<name>\w+)\s*=\s*express\s*\(",
        re.IGNORECASE,
    )

    METHOD_MAP = {
        "get": ["GET"],
        "post": ["POST"],
        "put": ["PUT"],
        "delete": ["DELETE"],
        "patch": ["PATCH"],
        "options": ["OPTIONS"],
        "head": ["HEAD"],
        "all": ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
    }

    async def extract_routes(self, source_path: str) -> list[dict]:
        """Extract Express routes from .js/.ts files."""
        source = Path(source_path)
        routes: list[dict] = []
        skip_dirs = {
            "__pycache__",
            ".git",
            "node_modules",
            ".venv",
            "venv",
            "dist",
            "build",
            ".next",
        }

        source_files = [
            *source.rglob("*.js"),
            *source.rglob("*.ts"),
            *source.rglob("*.mjs"),
            *source.rglob("*.cjs"),
        ]

        # First pass: identify app/router variables and prefix mappings from app.use('/x', router)
        router_names: set[str] = set()
        app_names: set[str] = set()
        router_prefixes: dict[str, list[str]] = {}

        for src_file in source_files:
            if any(skip in src_file.parts for skip in skip_dirs):
                continue
            try:
                content = src_file.read_text(encoding="utf-8", errors="replace")

                for match in self.ROUTER_DEF_PATTERN.finditer(content):
                    router_names.add(match.group("name"))

                for match in self.APP_DEF_PATTERN.finditer(content):
                    app_names.add(match.group("name"))

                for match in self.USE_CALL_PATTERN.finditer(content):
                    router = match.group("router")
                    prefix = match.group("prefix")
                    if router:
                        router_prefixes.setdefault(router, []).append(prefix)
            except Exception as exc:
                logger.debug("Error parsing %s: %s", src_file, exc)

        allowed_route_objects = set(router_names) | set(app_names) | {"router", "app"}

        # Second pass: parse route calls and apply router prefixes when known
        for src_file in source_files:
            if any(skip in src_file.parts for skip in skip_dirs):
                continue
            try:
                content = src_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(src_file.relative_to(source))

                for i, line in enumerate(lines, 1):
                    match = self.ROUTE_CALL_PATTERN.search(line)
                    if not match:
                        continue

                    obj = match.group("obj")
                    raw_method = match.group("method").lower()
                    route_path = match.group("path")

                    if obj not in allowed_route_objects:
                        continue

                    methods = self.METHOD_MAP.get(raw_method, [raw_method.upper()])

                    prefixes = [""]
                    if obj in router_names:
                        mapped = router_prefixes.get(obj) or []
                        if mapped:
                            prefixes = mapped

                    auth_required = any(
                        token in line.lower()
                        for token in (
                            "isauthenticated",
                            "authorize",
                            "auth",
                            "jwt",
                            "passport",
                            "ensureloggedin",
                        )
                    )

                    for prefix in prefixes:
                        full_path = self._join_paths(prefix, route_path)
                        for method in methods:
                            routes.append(
                                {
                                    "path": full_path,
                                    "method": method,
                                    "function": "",
                                    "file": rel_path,
                                    "line": i,
                                    "parameters": self._extract_url_params(full_path),
                                    "auth_required": auth_required,
                                    "auth_decorators": [],
                                    "framework": "express",
                                }
                            )

            except Exception as exc:
                logger.debug("Error parsing %s: %s", src_file, exc)

        return routes

    @staticmethod
    def _join_paths(prefix: str, path: str) -> str:
        """Join Express router prefix and route path safely."""
        if not prefix:
            return path if path.startswith("/") else f"/{path}"
        pfx = prefix.rstrip("/")
        pth = path if path.startswith("/") else f"/{path}"
        return f"{pfx}{pth}" if pfx else pth

    @staticmethod
    def _extract_url_params(path: str) -> list[str]:
        """Extract Express-style URL params from path, e.g. /users/:id."""
        return re.findall(r":([A-Za-z_][A-Za-z0-9_]*)", path)
