"""FastAPI route parser - extracts routes from FastAPI applications."""
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class FastAPIParser:
    """Parses FastAPI applications to extract route definitions."""

    ROUTE_DECORATORS = [
        r'@(\w+)\.(get|post|put|delete|patch|options|head)\s*\(\s*["\']([^"\']+)["\']\s*',
    ]

    ROUTER_PATTERN = r'(\w+)\s*=\s*APIRouter\s*\('
    ROUTER_PREFIX_PATTERN = r'prefix\s*=\s*["\']([^"\']+)["\']'
    INCLUDE_ROUTER_PATTERN = r'(\w+)\.include_router\s*\(\s*(\w+)(?:\.router)?\s*(?:,\s*prefix\s*=\s*["\']([^"\']+)["\'])?\s*'

    async def extract_routes(self, source_path: str) -> list[dict]:
        """Extract all FastAPI routes from the source code."""
        source = Path(source_path)
        routes = []
        routers = {}  # router_var -> {prefix}

        python_files = list(source.rglob("*.py"))
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv"}

        # First pass: find routers and their prefixes
        for py_file in python_files:
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")

                # Find APIRouter definitions
                for match in re.finditer(self.ROUTER_PATTERN, content):
                    var_name = match.group(1)
                    # Look for prefix in the same line or nearby
                    # Get the full APIRouter(...) call
                    start = match.start()
                    paren_count = 0
                    end = start
                    for j in range(start, min(start + 500, len(content))):
                        if content[j] == "(":
                            paren_count += 1
                        elif content[j] == ")":
                            paren_count -= 1
                            if paren_count == 0:
                                end = j + 1
                                break
                    router_call = content[start:end]
                    prefix_match = re.search(self.ROUTER_PREFIX_PATTERN, router_call)
                    prefix = prefix_match.group(1) if prefix_match else ""
                    routers[var_name] = {"prefix": prefix}

                # Find include_router calls
                for match in re.finditer(self.INCLUDE_ROUTER_PATTERN, content):
                    router_var = match.group(2)
                    include_prefix = match.group(3) or ""
                    if router_var in routers:
                        existing = routers[router_var].get("prefix", "")
                        routers[router_var]["prefix"] = include_prefix + existing
                    else:
                        routers[router_var] = {"prefix": include_prefix}

            except Exception:
                continue

        # Second pass: extract routes
        for py_file in python_files:
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(py_file.relative_to(source))

                for i, line in enumerate(lines):
                    stripped = line.strip()

                    for pattern in self.ROUTE_DECORATORS:
                        match = re.search(pattern, stripped)
                        if match:
                            app_or_router = match.group(1)
                            method = match.group(2).upper()
                            route_path = match.group(3)

                            # Apply router prefix
                            prefix = ""
                            if app_or_router in routers:
                                prefix = routers[app_or_router].get("prefix", "")

                            full_path = prefix + route_path

                            # Find the function definition
                            func_name = ""
                            params = []
                            for j in range(i + 1, min(i + 10, len(lines))):
                                func_match = re.match(
                                    r'\s*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)',
                                    lines[j],
                                )
                                if func_match:
                                    func_name = func_match.group(1)
                                    raw_params = func_match.group(2)
                                    # Parse FastAPI parameters
                                    params = self._parse_fastapi_params(raw_params)
                                    break

                            # Detect auth dependencies
                            auth_required = False
                            auth_decorators = []
                            # Check decorator for dependencies
                            full_decorator = stripped
                            # Get multi-line decorator
                            if stripped.count("(") > stripped.count(")"):
                                for j in range(i + 1, min(i + 10, len(lines))):
                                    full_decorator += lines[j].strip()
                                    if ")" in lines[j]:
                                        break

                            auth_deps = [
                                "Depends(get_current_user",
                                "Depends(auth",
                                "Depends(require_auth",
                                "Depends(verify_token",
                                "Security(",
                            ]
                            for dep in auth_deps:
                                if dep in full_decorator:
                                    auth_required = True
                                    auth_decorators.append(dep)

                            # Also check function parameters for Depends
                            if func_name:
                                for j in range(i + 1, min(i + 15, len(lines))):
                                    line_content = lines[j] if j < len(lines) else ""
                                    for dep in auth_deps:
                                        if dep in line_content:
                                            auth_required = True
                                            if dep not in auth_decorators:
                                                auth_decorators.append(dep)

                            # Extract URL parameters
                            url_params = re.findall(r'\{(\w+)\}', full_path)

                            routes.append({
                                "path": full_path,
                                "method": method,
                                "function": func_name,
                                "file": rel_path,
                                "line": i + 1,
                                "parameters": url_params + params,
                                "auth_required": auth_required,
                                "auth_decorators": auth_decorators,
                                "framework": "fastapi",
                            })

            except Exception as e:
                logger.debug(f"Error parsing {py_file}: {e}")
                continue

        return routes

    def _parse_fastapi_params(self, raw_params: str) -> list[str]:
        """Parse FastAPI function parameters to extract query/body params."""
        params = []
        for param in raw_params.split(","):
            param = param.strip()
            if not param or param in ("self", "cls"):
                continue
            # Skip common FastAPI dependencies
            skip_patterns = ["Depends(", "Request", "Response", "BackgroundTasks", "db:"]
            if any(sp in param for sp in skip_patterns):
                continue

            # Extract param name
            name = param.split(":")[0].split("=")[0].strip()
            if name and name not in ("request", "response"):
                params.append(name)

        return params
