"""Flask route parser - extracts routes from Flask applications."""
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class FlaskParser:
    """Parses Flask applications to extract route definitions."""

    ROUTE_DECORATORS = [
        r'@(\w+)\.route\s*\(\s*["\']([^"\']+)["\']\s*(?:,\s*methods\s*=\s*\[([^\]]+)\])?\s*\)',
        r'@(\w+)\.(?:get|post|put|delete|patch)\s*\(\s*["\']([^"\']+)["\']\s*\)',
    ]

    BLUEPRINT_PATTERN = r'(\w+)\s*=\s*Blueprint\s*\(\s*["\'](\w+)["\']\s*'
    REGISTER_PATTERN = r'(\w+)\.register_blueprint\s*\(\s*(\w+)\s*(?:,\s*url_prefix\s*=\s*["\']([^"\']+)["\'])?\s*\)'

    async def extract_routes(self, source_path: str) -> list[dict]:
        """Extract all Flask routes from the source code."""
        source = Path(source_path)
        routes = []
        blueprints = {}  # blueprint_var -> {name, prefix}

        python_files = list(source.rglob("*.py"))
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv"}

        # First pass: find blueprints and their prefixes
        for py_file in python_files:
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")

                # Find blueprint definitions
                for match in re.finditer(self.BLUEPRINT_PATTERN, content):
                    var_name = match.group(1)
                    bp_name = match.group(2)
                    blueprints[var_name] = {"name": bp_name, "prefix": ""}

                # Find blueprint registrations with url_prefix
                for match in re.finditer(self.REGISTER_PATTERN, content):
                    bp_var = match.group(2)
                    prefix = match.group(3) or ""
                    if bp_var in blueprints:
                        blueprints[bp_var]["prefix"] = prefix

            except Exception:
                continue

        # Second pass: extract routes
        for py_file in python_files:
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(py_file.relative_to(source))

                for i, line in enumerate(lines):
                    stripped = line.strip()

                    # Check @app.route or @blueprint.route
                    for pattern in self.ROUTE_DECORATORS:
                        match = re.search(pattern, stripped)
                        if match:
                            groups = match.groups()
                            app_or_bp = groups[0]
                            route_path = groups[1]
                            methods_str = groups[2] if len(groups) > 2 and groups[2] else None

                            # Determine methods
                            if methods_str:
                                methods = [
                                    m.strip().strip("'\"")
                                    for m in methods_str.split(",")
                                ]
                            elif ".get(" in stripped:
                                methods = ["GET"]
                            elif ".post(" in stripped:
                                methods = ["POST"]
                            elif ".put(" in stripped:
                                methods = ["PUT"]
                            elif ".delete(" in stripped:
                                methods = ["DELETE"]
                            elif ".patch(" in stripped:
                                methods = ["PATCH"]
                            else:
                                methods = ["GET"]

                            # Apply blueprint prefix
                            prefix = ""
                            if app_or_bp in blueprints:
                                prefix = blueprints[app_or_bp].get("prefix", "")

                            full_path = prefix + route_path

                            # Find the function name (next def line)
                            func_name = ""
                            params = []
                            for j in range(i + 1, min(i + 5, len(lines))):
                                func_match = re.match(
                                    r'\s*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)',
                                    lines[j],
                                )
                                if func_match:
                                    func_name = func_match.group(1)
                                    raw_params = func_match.group(2)
                                    params = [
                                        p.strip().split(":")[0].strip()
                                        for p in raw_params.split(",")
                                        if p.strip() and p.strip() not in ("self",)
                                    ]
                                    break

                            # Detect auth decorators
                            auth_required = False
                            auth_decorators = []
                            for k in range(max(0, i - 5), i):
                                prev = lines[k].strip()
                                if re.search(
                                    r'@(login_required|auth_required|jwt_required|'
                                    r'token_required|admin_required|roles_required)',
                                    prev,
                                ):
                                    auth_required = True
                                    auth_decorators.append(prev)

                            # Extract URL parameters
                            url_params = re.findall(r'<(?:\w+:)?(\w+)>', full_path)

                            for method in methods:
                                routes.append({
                                    "path": full_path,
                                    "method": method.upper(),
                                    "function": func_name,
                                    "file": rel_path,
                                    "line": i + 1,
                                    "parameters": url_params + params,
                                    "auth_required": auth_required,
                                    "auth_decorators": auth_decorators,
                                    "framework": "flask",
                                })

            except Exception as e:
                logger.debug(f"Error parsing {py_file}: {e}")
                continue

        return routes
