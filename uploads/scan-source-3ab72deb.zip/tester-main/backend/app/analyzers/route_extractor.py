"""Route extractor - dispatches to framework-specific parsers."""
import logging

logger = logging.getLogger(__name__)


class RouteExtractor:
    """Extracts HTTP routes/endpoints from source code using framework-specific parsers."""

    async def extract_routes(self, source_path: str) -> list[dict]:
        """Extract all routes from the source code."""
        from app.analyzers.source_analyzer import SourceAnalyzer

        analyzer = SourceAnalyzer()
        framework = await analyzer.detect_framework(source_path)

        routes = []
        if framework == "flask":
            from app.analyzers.framework_parsers.flask_parser import FlaskParser
            parser = FlaskParser()
            routes = await parser.extract_routes(source_path)
        elif framework == "django":
            from app.analyzers.framework_parsers.django_parser import DjangoParser
            parser = DjangoParser()
            routes = await parser.extract_routes(source_path)
        elif framework == "fastapi":
            from app.analyzers.framework_parsers.fastapi_parser import FastAPIParser
            parser = FastAPIParser()
            routes = await parser.extract_routes(source_path)
        elif framework == "express":
            from app.analyzers.framework_parsers.express_parser import ExpressParser
            parser = ExpressParser()
            routes = await parser.extract_routes(source_path)
        else:
            # Try all parsers and merge results
            from app.analyzers.framework_parsers.flask_parser import FlaskParser
            from app.analyzers.framework_parsers.django_parser import DjangoParser
            from app.analyzers.framework_parsers.fastapi_parser import FastAPIParser
            from app.analyzers.framework_parsers.express_parser import ExpressParser

            for ParserClass in [FlaskParser, DjangoParser, FastAPIParser, ExpressParser]:
                parser = ParserClass()
                try:
                    found = await parser.extract_routes(source_path)
                    routes.extend(found)
                except Exception as e:
                    logger.debug(f"Parser {ParserClass.__name__} failed: {e}")

        logger.info(f"Extracted {len(routes)} routes from {source_path} (framework={framework})")
        return routes
