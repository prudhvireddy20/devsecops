"""Dangerous sink detector - identifies security-sensitive code patterns."""
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class SinkDetector:
    """Detects dangerous sinks (SQL execution, OS commands, template rendering, etc.)."""

    SINK_PATTERNS = {
        "sql_injection": {
            "cwe": "CWE-89",
            "severity": "critical",
            "patterns": [
                r'db\.execute\s*\(\s*f["\']',
                r'cursor\.execute\s*\(\s*f["\']',
                r'\.execute\s*\(\s*["\'].*%s',
                r'\.execute\s*\(\s*["\'].*\+\s*\w+',
                r'\.execute\s*\(\s*["\'].*\.format\s*\(',
                r'\.raw\s*\(\s*f["\']',
                r'\.extra\s*\(\s*.*f["\']',
                r'text\s*\(\s*f["\'].*SELECT',
                r'engine\.execute\s*\(\s*f["\']',
            ],
        },
        "command_injection": {
            "cwe": "CWE-78",
            "severity": "critical",
            "patterns": [
                r'os\.system\s*\(',
                r'os\.popen\s*\(',
                r'subprocess\.call\s*\(\s*["\']',
                r'subprocess\.run\s*\(\s*f["\']',
                r'subprocess\.Popen\s*\(\s*f["\']',
                r'commands\.getoutput\s*\(',
                r'exec\s*\(\s*\w+',
                r'eval\s*\(\s*\w+',
            ],
        },
        "xss": {
            "cwe": "CWE-79",
            "severity": "high",
            "patterns": [
                r'render_template_string\s*\(',
                r'Markup\s*\(\s*\w+',
                r'\|\s*safe\b',
                r'mark_safe\s*\(',
                r'\.format_html\s*\(',
                r'HttpResponse\s*\(\s*\w+',
                r'make_response\s*\(\s*f["\']',
            ],
        },
        "path_traversal": {
            "cwe": "CWE-22",
            "severity": "high",
            "patterns": [
                r'open\s*\(\s*\w+',
                r'send_file\s*\(\s*\w+',
                r'send_from_directory\s*\(',
                r'os\.path\.join\s*\(.*request',
                r'Path\s*\(\s*\w+\s*\)',
                r'shutil\.\w+\s*\(\s*\w+',
            ],
        },
        "ssrf": {
            "cwe": "CWE-918",
            "severity": "high",
            "patterns": [
                r'requests\.\w+\s*\(\s*\w+',
                r'urllib\.request\.urlopen\s*\(\s*\w+',
                r'httpx\.\w+\s*\(\s*\w+',
                r'aiohttp\.ClientSession.*\.\w+\s*\(\s*\w+',
            ],
        },
        "deserialization": {
            "cwe": "CWE-502",
            "severity": "critical",
            "patterns": [
                r'pickle\.loads?\s*\(',
                r'yaml\.load\s*\(\s*\w+\s*\)',
                r'yaml\.unsafe_load\s*\(',
                r'marshal\.loads?\s*\(',
                r'shelve\.open\s*\(',
                r'jsonpickle\.decode\s*\(',
            ],
        },
    }

    async def detect_sinks(self, source_path: str) -> list[dict]:
        """Detect all dangerous sinks in the source code."""
        source = Path(source_path)
        if not source.exists():
            return []

        sinks = []
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv", ".tox"}
        python_files = [
            f for f in source.rglob("*.py")
            if not any(skip in f.parts for skip in skip_dirs)
        ]

        for py_file in python_files:
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                lines = content.split("\n")
                rel_path = str(py_file.relative_to(source))

                for sink_type, config in self.SINK_PATTERNS.items():
                    for pattern in config["patterns"]:
                        for i, line in enumerate(lines, 1):
                            stripped = line.strip()
                            if stripped.startswith("#"):
                                continue
                            match = re.search(pattern, line)
                            if match:
                                # Extract context (surrounding lines)
                                start = max(0, i - 3)
                                end = min(len(lines), i + 2)
                                context = "\n".join(lines[start:end])

                                sinks.append({
                                    "type": sink_type,
                                    "cwe": config["cwe"],
                                    "severity": config["severity"],
                                    "file": rel_path,
                                    "line": i,
                                    "code": stripped,
                                    "context": context,
                                    "pattern": pattern,
                                    "match": match.group(),
                                })
            except Exception as e:
                logger.debug(f"Error scanning {py_file}: {e}")
                continue

        logger.info(f"Detected {len(sinks)} dangerous sinks in {source_path}")
        return sinks

    def get_payload_suggestions(self, sink: dict) -> list[str]:
        """Get targeted payload suggestions based on sink type."""
        payload_map = {
            "sql_injection": [
                "' OR '1'='1",
                "' OR 1=1 --",
                "'; DROP TABLE users; --",
                "' UNION SELECT NULL,NULL,NULL --",
                "1' AND (SELECT SLEEP(5)) --",
            ],
            "command_injection": [
                "; id",
                "| cat /etc/passwd",
                "$(whoami)",
                "`id`",
                "; sleep 5",
            ],
            "xss": [
                '<script>alert("XSS")</script>',
                '"><img src=x onerror=alert(1)>',
                "javascript:alert(1)",
                '<svg onload=alert(1)>',
                "'-alert(1)-'",
            ],
            "path_traversal": [
                "../../etc/passwd",
                "..\\..\\windows\\system.ini",
                "%2e%2e%2f%2e%2e%2fetc%2fpasswd",
                "....//....//etc/passwd",
            ],
            "ssrf": [
                "http://127.0.0.1:80",
                "http://169.254.169.254/latest/meta-data/",
                "http://localhost:8080/admin",
                "file:///etc/passwd",
            ],
        }
        return payload_map.get(sink["type"], [])
