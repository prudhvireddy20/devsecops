"""Source code analyzer using tree-sitter for AST parsing."""
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class SourceAnalyzer:
    """Analyzes source code structure using tree-sitter AST parsing."""

    FRAMEWORK_INDICATORS = {
        "flask": [
            "from flask import",
            "Flask(__name__)",
            "@app.route",
            "Blueprint(",
        ],
        "django": [
            "from django",
            "django.conf",
            "urlpatterns",
            "INSTALLED_APPS",
        ],
        "fastapi": [
            "from fastapi import",
            "FastAPI()",
            "@app.get",
            "@app.post",
            "APIRouter",
        ],
        "express": [
            "require('express')",
            'require("express")',
            "from 'express'",
            'from "express"',
            "express()",
            "express.Router(",
            ".get(",
            ".post(",
            ".put(",
            ".delete(",
            ".patch(",
            "app.use(",
            "router.use(",
        ],
    }

    async def detect_framework(self, source_path: str) -> str:
        """Detect the web framework used in the project."""
        scores = {"flask": 0, "django": 0, "fastapi": 0, "express": 0}
        source = Path(source_path)

        if not source.exists():
            return "unknown"

        python_files = list(source.rglob("*.py"))
        for py_file in python_files[:200]:  # Limit scan scope
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                for framework, indicators in self.FRAMEWORK_INDICATORS.items():
                    for indicator in indicators:
                        if indicator in content:
                            scores[framework] += 1
            except Exception:
                continue

        js_like_files = [
            *source.rglob("*.js"),
            *source.rglob("*.ts"),
            *source.rglob("*.mjs"),
            *source.rglob("*.cjs"),
        ]
        for js_file in js_like_files[:400]:  # Limit scan scope
            try:
                content = js_file.read_text(encoding="utf-8", errors="replace")
                for indicator in self.FRAMEWORK_INDICATORS["express"]:
                    if indicator in content:
                        scores["express"] += 1
            except Exception:
                continue

        # Also check requirements.txt / pyproject.toml
        for req_file in ["requirements.txt", "Pipfile", "pyproject.toml", "setup.py"]:
            req_path = source / req_file
            if req_path.exists():
                try:
                    content = req_path.read_text(encoding="utf-8", errors="replace")
                    for fw in scores:
                        if fw in content.lower():
                            scores[fw] += 5
                except Exception:
                    continue

        package_json = source / "package.json"
        if package_json.exists():
            try:
                content = package_json.read_text(encoding="utf-8", errors="replace").lower()
                if '"express"' in content:
                    scores["express"] += 6
            except Exception:
                pass

        if max(scores.values()) == 0:
            return "unknown"

        return max(scores, key=lambda fw: scores[fw])

    async def parse_file(self, file_path: str) -> Optional[dict]:
        """Parse a Python file and return its AST structure."""
        try:
            path = Path(file_path)
            content = path.read_text(encoding="utf-8", errors="replace")

            # Use tree-sitter if available, fallback to ast module
            try:
                import importlib.util
                if importlib.util.find_spec("tree_sitter") is None:
                    raise ImportError("tree_sitter not installed")
                return self._parse_with_tree_sitter(content, str(path))
            except ImportError:
                return self._parse_with_ast(content, str(path))

        except Exception as e:
            logger.warning(f"Failed to parse {file_path}: {e}")
            return None

    def _parse_with_tree_sitter(self, content: str, file_path: str) -> dict:
        """Parse using tree-sitter for detailed AST."""
        import tree_sitter

        # Initialize Python parser
        try:
            import tree_sitter_python as tspython
            PY_LANGUAGE = tree_sitter.Language(tspython.language())
            parser = tree_sitter.Parser(PY_LANGUAGE)
        except Exception:
            # Fallback if tree-sitter-python not available
            return self._parse_with_ast(content, file_path)

        tree = parser.parse(bytes(content, "utf-8"))
        root = tree.root_node

        result = {
            "file": file_path,
            "imports": [],
            "functions": [],
            "classes": [],
            "decorators": [],
            "calls": [],
            "strings": [],
        }

        self._walk_tree(root, content, result)
        return result

    def _walk_tree(self, node, source: str, result: dict, depth: int = 0):
        """Walk the tree-sitter AST and extract relevant nodes."""
        if depth > 50:  # Prevent infinite recursion
            return

        node_type = node.type

        if node_type == "import_statement" or node_type == "import_from_statement":
            result["imports"].append({
                "text": source[node.start_byte:node.end_byte],
                "line": node.start_point[0] + 1,
            })

        elif node_type == "function_definition":
            func_name = ""
            for child in node.children:
                if child.type == "identifier":
                    func_name = source[child.start_byte:child.end_byte]
                    break
            result["functions"].append({
                "name": func_name,
                "line": node.start_point[0] + 1,
                "end_line": node.end_point[0] + 1,
                "text": source[node.start_byte:node.end_byte][:500],
            })

        elif node_type == "class_definition":
            class_name = ""
            for child in node.children:
                if child.type == "identifier":
                    class_name = source[child.start_byte:child.end_byte]
                    break
            result["classes"].append({
                "name": class_name,
                "line": node.start_point[0] + 1,
            })

        elif node_type == "decorator":
            result["decorators"].append({
                "text": source[node.start_byte:node.end_byte],
                "line": node.start_point[0] + 1,
            })

        elif node_type == "call":
            call_text = source[node.start_byte:node.end_byte]
            if len(call_text) < 200:
                result["calls"].append({
                    "text": call_text,
                    "line": node.start_point[0] + 1,
                })

        for child in node.children:
            self._walk_tree(child, source, result, depth + 1)

    def _parse_with_ast(self, content: str, file_path: str) -> dict:
        """Fallback parser using Python's built-in ast module."""
        import ast

        result = {
            "file": file_path,
            "imports": [],
            "functions": [],
            "classes": [],
            "decorators": [],
            "calls": [],
        }

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return result

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    result["imports"].append({
                        "text": f"import {alias.name}",
                        "line": node.lineno,
                    })
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                names = ", ".join(a.name for a in node.names)
                result["imports"].append({
                    "text": f"from {module} import {names}",
                    "line": node.lineno,
                })
            elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                decorators = []
                for d in node.decorator_list:
                    if isinstance(d, ast.Name):
                        decorators.append(d.id)
                    elif isinstance(d, ast.Attribute):
                        decorators.append(ast.dump(d))
                    elif isinstance(d, ast.Call):
                        if isinstance(d.func, ast.Attribute):
                            decorators.append(f"{ast.dump(d.func)}")
                        elif isinstance(d.func, ast.Name):
                            decorators.append(d.func.id)

                result["functions"].append({
                    "name": node.name,
                    "line": node.lineno,
                    "end_line": node.end_lineno or node.lineno,
                    "decorators": decorators,
                    "args": [a.arg for a in node.args.args],
                })
            elif isinstance(node, ast.ClassDef):
                result["classes"].append({
                    "name": node.name,
                    "line": node.lineno,
                })

        return result

    async def get_all_python_files(self, source_path: str) -> list[str]:
        """Get all Python files in the source directory."""
        source = Path(source_path)
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv", ".tox", "migrations"}
        files = []
        for py_file in source.rglob("*.py"):
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            files.append(str(py_file))
        return files
