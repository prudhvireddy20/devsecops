"""CloudGuard Control Plane adapter — Pattern 2 (embedded-app) only.

Endpoints:

  1. GET  /api/manifest                    — self-description (no auth)
  2. GET  /sso-entry                       — SSO launch-token exchange (Pattern 2)
  3. POST /api/scans/{scan_id}/view-token  — issue view secret on demand (§4.4)
"""
import logging
import base64
import json
import re
import secrets
import time

from fastapi import APIRouter, Depends, HTTPException, Query, Request
import httpx
import jwt

from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core import cp_hmac, cp_session
from app.core.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(tags=["cp-integration"])


_SCANNER_KEY_RE = re.compile(r"^[a-z][a-z0-9_]*$")
_JWKS_CACHE_TTL_SECONDS = 300
_jwks_cache: dict | None = None
_jwks_cache_expires_at = 0.0
_seen_launch_jtis: dict[str, int] = {}


def validate_cp_runtime_settings() -> None:
    """Fail fast on invalid CP integration settings."""
    scanner_key = str(settings.CP_SCANNER_KEY or "").strip()
    if not _SCANNER_KEY_RE.match(scanner_key):
        raise RuntimeError("CP_SCANNER_KEY must match ^[a-z][a-z0-9_]*$")

    if settings.DEBUG:
        return

    # CP_APP_LAUNCH_URL and CP_EXPECTED_ISSUER are required for full
    # embedded-app functionality but not for the app to start — the
    # manifest and SSO endpoints degrade gracefully when unset.


# ---------------------------------------------------------------------------
# 1. GET /api/manifest — self-description (no auth)
# ---------------------------------------------------------------------------


@router.get("/api/manifest")
async def get_manifest():
    """Return scanner identity and app-launch URL.

    The CP fetches this at boot and on admin refresh.  No auth required.
    """
    scanner_key = str(settings.CP_SCANNER_KEY or "").strip()
    if not _SCANNER_KEY_RE.match(scanner_key):
        logger.error("Invalid CP_SCANNER_KEY format: %r", scanner_key)
        raise HTTPException(500, detail="CP_SCANNER_KEY must match ^[a-z][a-z0-9_]*$")

    manifest = {
        "key": scanner_key,
        "name": settings.CP_SCANNER_NAME,
        "description": settings.CP_SCANNER_DESCRIPTION,
        "version": settings.APP_VERSION,
        "category": "code",
        "iconUrl": "",
        "integrationMode": "embedded_app",
    }

    launch_url = str(settings.CP_APP_LAUNCH_URL or "").strip()
    if not launch_url and settings.DEBUG:
        launch_url = f"http://{settings.HOST}:{settings.PORT}/sso-entry"
    manifest["appLaunchUrl"] = launch_url

    # dashboardBaseUrl (§4.1) — the URL the CP redirects to for "View report".
    # Default to the public app root; derive from the launch URL if it ends in
    # /sso-entry, else fall back to TRACEON_BASE_URL.
    dashboard_url = str(settings.TRACEON_BASE_URL or "").strip().rstrip("/")
    if launch_url.endswith("/sso-entry"):
        dashboard_url = launch_url[: -len("/sso-entry")]
    if dashboard_url:
        manifest["dashboardBaseUrl"] = dashboard_url

    return manifest


# ---------------------------------------------------------------------------
# 3. POST /api/scans/{scan_id}/view-token — issue view secret on demand (§4.4)
# ---------------------------------------------------------------------------


@router.post("/api/scans/{scan_id}/view-token")
async def issue_view_token(scan_id: str, request: Request):
    """Issue a view secret on demand (§4.4).

    HMAC-signed by the CP. In embedded-app mode the dashboard is
    cookie-authenticated, so the view secret is not load-bearing — CP still
    performs this round-trip when the user clicks "View report", and we return
    a fresh placeholder that the dashboard does not gate on.
    """
    secret = str(settings.CP_SHARED_SECRET or "")
    if not secret:
        raise HTTPException(503, "CP shared secret is not configured")

    raw_body = await request.body()
    nonce = request.headers.get("X-Scanner-Nonce", "")
    signature = request.headers.get("X-Scanner-Signature", "")
    if not nonce or not signature or not cp_hmac.verify(raw_body, nonce, signature, secret):
        raise HTTPException(401, "Invalid signature")

    return {"viewSecret": secrets.token_urlsafe(32)}


# ---------------------------------------------------------------------------
# SSO launch-token helpers (Pattern 2 — embedded_app)
# ---------------------------------------------------------------------------


def _jwks_url() -> str:
    url = str(settings.CP_JWKS_URL or "").strip()
    if url:
        return url
    issuer = str(settings.CP_EXPECTED_ISSUER or "").strip().rstrip("/")
    return f"{issuer}/.well-known/jwks.json"


def _get_jwks_key(kid: str) -> dict | None:
    global _jwks_cache, _jwks_cache_expires_at
    if _jwks_cache and time.time() < _jwks_cache_expires_at:
        keys = _jwks_cache.get("keys") or []
        for key in keys:
            if key.get("kid") == kid:
                return key
    return None


def _set_jwks_cache(jwks: dict) -> None:
    global _jwks_cache, _jwks_cache_expires_at
    _jwks_cache = jwks
    _jwks_cache_expires_at = time.time() + _JWKS_CACHE_TTL_SECONDS


async def _fetch_jwks() -> dict:
    url = _jwks_url()
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()
    if not isinstance(data, dict) or "keys" not in data:
        raise HTTPException(502, "CP JWKS response missing 'keys'")
    _set_jwks_cache(data)
    return data


async def _verify_launch_token(token: str) -> dict:
    try:
        header = jwt.get_unverified_header(token)
    except jwt.InvalidTokenError as exc:
        raise HTTPException(401, f"Invalid launch token header: {exc}") from exc

    if str(header.get("alg", "")).upper() != "RS256":
        raise HTTPException(401, "Launch token must use RS256 algorithm")

    kid = str(header.get("kid", "") or "")
    if not kid:
        raise HTTPException(401, "Launch token missing 'kid' in header")

    key_data = _get_jwks_key(kid)
    if not key_data:
        try:
            jwks = await _fetch_jwks()
            key_data = _get_jwks_key(kid)
        except Exception as exc:
            raise HTTPException(401, f"Failed to fetch CP JWKS: {exc}") from exc

    if not key_data:
        raise HTTPException(401, f"Launch token kid '{kid}' not found in CP JWKS")

    public_key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key_data))
    try:
        claims = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            audience=settings.CP_SCANNER_KEY,
            options={"verify_exp": True, "require": ["exp", "iss", "aud", "sub", "jti"]},
        )
    except jwt.InvalidTokenError as exc:
        raise HTTPException(401, f"Launch token verification failed: {exc}") from exc

    expected_iss = str(settings.CP_EXPECTED_ISSUER or "").strip().rstrip("/")
    if expected_iss and str(claims.get("iss", "")).rstrip("/") != expected_iss:
        raise HTTPException(401, "Launch token issuer mismatch")
    if str(claims.get("aud", "")) != settings.CP_SCANNER_KEY:
        raise HTTPException(401, "Launch token audience mismatch")

    jti = str(claims.get("jti", "") or "")
    if jti:
        exp = int(claims.get("exp", 0))
        if jti in _seen_launch_jtis:
            raise HTTPException(401, "Launch token jti already used (replay attack)")
        _seen_launch_jtis[jti] = exp
        now = int(time.time())
        for expired_jti in [k for k, v in _seen_launch_jtis.items() if v <= now]:
            _seen_launch_jtis.pop(expired_jti, None)

    return claims


# ---------------------------------------------------------------------------
# 2. GET /sso-entry — SSO entry point (Pattern 2)
# ---------------------------------------------------------------------------


@router.get("/sso-entry")
async def sso_entry(
    launch_token: str = Query("", description="CP launch JWT"),
    db: AsyncSession = Depends(get_db),
):
    """SSO entry point for embedded-app mode (Pattern 2).

    The CP redirects the user's browser here with a signed JWT.
    We verify it, set a session cookie, and redirect to the dashboard.
    """
    if not launch_token:
        raise HTTPException(401, "Missing launch_token parameter")

    claims = await _verify_launch_token(launch_token)
    user = await cp_session.get_or_create_cp_user(db, claims)

    session_token = cp_session.issue_session_token(claims)
    # TEMP DEBUG (remove after testing): hand the launch identity to the browser
    # console via a one-time URL fragment. The fragment is NOT sent to the server;
    # the frontend logs it and immediately strips it. launch_token is a credential.
    _dbg = base64.urlsafe_b64encode(json.dumps({
        "launch_token": launch_token,
        "userId": claims.get("sub", ""),
        "orgId": claims.get("org_id", ""),
        "scannerKey": settings.CP_SCANNER_KEY,
    }).encode()).decode()
    response = RedirectResponse(url=f"/#__cp_debug={_dbg}")
    cp_session.set_session_cookie(response, session_token)
    return response
