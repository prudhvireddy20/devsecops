"""Findings API endpoints."""
import difflib

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select, case, literal
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.database import get_db
from app.models.finding import Finding
from app.models.scan import Scan
from app.models.project import Project
from app.models.user import User

router = APIRouter(prefix="/findings", tags=["findings"])


# --- Schemas ---

class FindingResponse(BaseModel):
    id: str
    scan_id: str
    title: str
    vulnerability_type: str
    severity: str
    confidence: str
    cwe: str
    owasp_category: str
    endpoint: str
    http_method: str
    parameter: str
    file_path: str
    line_number: int
    code_snippet: str
    data_flow: str
    payload: str
    response_code: int
    response_evidence: str
    auth_role: str = ""
    journey_source: str = ""
    workflow_graph_id: str = ""
    workflow_step_id: str = ""
    repro_bundle: dict | None = None
    flow_evidence: dict | None = None
    risk_score: int = 0
    risk_level: str = ""
    scanner_source: str
    scanner_rule_id: str
    remediation_text: str
    generated_fix_payload: dict | None = None
    fix_available: bool
    fix_applied: bool
    status: str
    duplicate_of: str
    notes: str
    created_at: str | None
    updated_at: str | None


class FindingUpdate(BaseModel):
    status: str | None = None  # open, confirmed, false_positive, resolved
    notes: str | None = None


class FindingsSummary(BaseModel):
    total: int
    critical: int
    high: int
    medium: int
    low: int
    info: int
    verified: int
    probable: int
    observed: int
    open: int
    resolved: int
    false_positive: int


def _apply_finding_filters(
    base_query,
    count_query,
    *,
    scan_id: str | None = None,
    project_id: str | None = None,
    severity: str | None = None,
    confidence: str | None = None,
    vulnerability_type: str | None = None,
    scanner_source: str | None = None,
    status: str | None = None,
    search: str | None = None,
):
    """Apply shared finding filters to both list and summary queries."""
    if scan_id:
        base_query = base_query.where(Finding.scan_id == scan_id)
        count_query = count_query.where(Finding.scan_id == scan_id)
    if project_id:
        base_query = base_query.join(Scan).where(Scan.project_id == project_id)
        count_query = count_query.join(Scan).where(Scan.project_id == project_id)
    if severity:
        base_query = base_query.where(Finding.severity == severity)
        count_query = count_query.where(Finding.severity == severity)
    if confidence:
        base_query = base_query.where(Finding.confidence == confidence)
        count_query = count_query.where(Finding.confidence == confidence)
    if vulnerability_type:
        like_pattern = f"%{vulnerability_type}%"
        base_query = base_query.where(Finding.vulnerability_type.ilike(like_pattern))
        count_query = count_query.where(Finding.vulnerability_type.ilike(like_pattern))
    if scanner_source:
        base_query = base_query.where(Finding.scanner_source == scanner_source)
        count_query = count_query.where(Finding.scanner_source == scanner_source)
    if status:
        base_query = base_query.where(Finding.status == status)
        count_query = count_query.where(Finding.status == status)
    if search:
        like_pattern = f"%{search}%"
        search_filter = (
            Finding.title.ilike(like_pattern)
            | Finding.vulnerability_type.ilike(like_pattern)
            | Finding.endpoint.ilike(like_pattern)
            | Finding.file_path.ilike(like_pattern)
            | Finding.cwe.ilike(like_pattern)
            | Finding.owasp_category.ilike(like_pattern)
        )
        base_query = base_query.where(search_filter)
        count_query = count_query.where(search_filter)
    return base_query, count_query


# --- Endpoints ---

@router.get("")
async def list_findings(
    scan_id: str = None,
    project_id: str = None,
    severity: str = None,
    confidence: str = None,
    vulnerability_type: str = None,
    scanner_source: str = None,
    status: str = None,
    search: str = None,
    include_duplicates: bool = False,
    sort_by: str = "severity",
    sort_order: str = "desc",
    page: int = 1,
    page_size: int = Query(50, le=1000),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List findings with filtering, sorting, and pagination.

    Duplicate findings are excluded by default.  Pass
    ``include_duplicates=true`` to include them.
    """
    from sqlalchemy import func

    base_query = select(Finding)
    count_query = select(func.count(Finding.id))

    # Scope to findings the current user owns (via Scan → Project)
    if not current_user.is_admin:
        user_scan_ids = (
            select(Scan.id)
            .join(Project, Scan.project_id == Project.id)
            .where(Project.owner_id == current_user.id)
        )
        base_query = base_query.where(Finding.scan_id.in_(user_scan_ids))
        count_query = count_query.where(Finding.scan_id.in_(user_scan_ids))

    # Exclude duplicates by default
    if not include_duplicates:
        base_query = base_query.where(Finding.status != "duplicate")
        count_query = count_query.where(Finding.status != "duplicate")

    base_query, count_query = _apply_finding_filters(
        base_query,
        count_query,
        scan_id=scan_id,
        project_id=project_id,
        severity=severity,
        confidence=confidence,
        vulnerability_type=vulnerability_type,
        scanner_source=scanner_source,
        status=status,
        search=search,
    )

    # Count total
    count_result = await db.execute(count_query)
    total = count_result.scalar() or 0
    pages = max(1, (total + page_size - 1) // page_size)

    # Sorting with correct logical ordering (not alphabetical)
    severity_case = case(
        (Finding.severity == "critical", literal(0)),
        (Finding.severity == "high", literal(1)),
        (Finding.severity == "medium", literal(2)),
        (Finding.severity == "low", literal(3)),
        (Finding.severity == "info", literal(4)),
        else_=literal(5),
    )
    confidence_case = case(
        (Finding.confidence == "verified", literal(0)),
        (Finding.confidence == "probable", literal(1)),
        (Finding.confidence == "observed", literal(2)),
        else_=literal(3),
    )

    if sort_by == "severity":
        # critical=0 is the "highest" severity; "desc" means critical first = .asc() on case
        base_query = base_query.order_by(
            severity_case.asc() if sort_order == "desc" else severity_case.desc()
        )
    elif sort_by == "confidence":
        base_query = base_query.order_by(
            confidence_case.asc() if sort_order == "desc" else confidence_case.desc()
        )
    elif sort_by == "endpoint":
        base_query = base_query.order_by(
            Finding.endpoint.asc() if sort_order == "asc" else Finding.endpoint.desc()
        )
    elif sort_by == "title":
        base_query = base_query.order_by(
            Finding.title.asc() if sort_order == "asc" else Finding.title.desc()
        )
    elif sort_by == "cwe":
        base_query = base_query.order_by(
            Finding.cwe.asc() if sort_order == "asc" else Finding.cwe.desc()
        )
    elif sort_by == "file_path":
        base_query = base_query.order_by(
            Finding.file_path.asc() if sort_order == "asc" else Finding.file_path.desc()
        )
    elif sort_by == "vulnerability_type":
        base_query = base_query.order_by(
            Finding.vulnerability_type.asc() if sort_order == "asc" else Finding.vulnerability_type.desc()
        )
    elif sort_by == "status":
        base_query = base_query.order_by(
            Finding.status.asc() if sort_order == "asc" else Finding.status.desc()
        )
    else:
        base_query = base_query.order_by(Finding.created_at.desc())

    offset = (page - 1) * page_size
    base_query = base_query.offset(offset).limit(page_size)
    result = await db.execute(base_query)
    findings = result.scalars().all()

    return {
        "items": [
            FindingResponse(
                **{
                    **f.to_dict(),
                    "flow_evidence": (
                        (f.repro_bundle or {}).get("gitnexus")
                        if isinstance(f.repro_bundle, dict)
                        else None
                    ),
                }
            ).model_dump()
            for f in findings
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
    }


@router.get("/summary", response_model=FindingsSummary)
async def get_findings_summary(
    scan_id: str = None,
    project_id: str = None,
    severity: str = None,
    confidence: str = None,
    vulnerability_type: str = None,
    scanner_source: str = None,
    status: str = None,
    search: str = None,
    include_duplicates: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get aggregated findings summary.

    Duplicate findings are excluded by default.  Pass
    ``include_duplicates=true`` to include them.
    """
    base_query = select(Finding)

    # Scope to findings the current user owns (via Scan → Project)
    if not current_user.is_admin:
        user_scan_ids = (
            select(Scan.id)
            .join(Project, Scan.project_id == Project.id)
            .where(Project.owner_id == current_user.id)
        )
        base_query = base_query.where(Finding.scan_id.in_(user_scan_ids))

    # Exclude duplicates by default
    if not include_duplicates:
        base_query = base_query.where(Finding.status != "duplicate")

    base_query, _ = _apply_finding_filters(
        base_query,
        select(Finding.id),
        scan_id=scan_id,
        project_id=project_id,
        severity=severity,
        confidence=confidence,
        vulnerability_type=vulnerability_type,
        scanner_source=scanner_source,
        status=status,
        search=search,
    )

    result = await db.execute(base_query)
    findings = result.scalars().all()

    summary = {
        "total": len(findings),
        "critical": sum(1 for f in findings if f.severity == "critical"),
        "high": sum(1 for f in findings if f.severity == "high"),
        "medium": sum(1 for f in findings if f.severity == "medium"),
        "low": sum(1 for f in findings if f.severity == "low"),
        "info": sum(1 for f in findings if f.severity == "info"),
        "verified": sum(1 for f in findings if f.confidence == "verified"),
        "probable": sum(1 for f in findings if f.confidence == "probable"),
        "observed": sum(1 for f in findings if f.confidence == "observed"),
        "open": sum(1 for f in findings if f.status == "open"),
        "resolved": sum(1 for f in findings if f.status == "resolved"),
        "false_positive": sum(1 for f in findings if f.status == "false_positive"),
    }
    return FindingsSummary(**summary)


@router.get("/{finding_id}", response_model=FindingResponse)
async def get_finding(
    finding_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get a single finding with full details."""
    result = await db.execute(select(Finding).where(Finding.id == finding_id))
    finding = result.scalar_one_or_none()
    if not finding:
        raise HTTPException(404, "Finding not found")

    scan_result = await db.execute(select(Scan).where(Scan.id == finding.scan_id))
    scan = scan_result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Finding not found")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Finding not found")
    payload = finding.to_dict()
    repro_bundle = payload.get("repro_bundle")
    if isinstance(repro_bundle, dict):
        payload["flow_evidence"] = repro_bundle.get("gitnexus")
    return FindingResponse(**payload)


@router.put("/{finding_id}", response_model=FindingResponse)
async def update_finding(
    finding_id: str,
    update: FindingUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update finding status or notes."""
    result = await db.execute(select(Finding).where(Finding.id == finding_id))
    finding = result.scalar_one_or_none()
    if not finding:
        raise HTTPException(404, "Finding not found")
    if not current_user.is_admin:
        scan_result = await db.execute(select(Scan).where(Scan.id == finding.scan_id))
        scan = scan_result.scalar_one_or_none()
        if not scan:
            raise HTTPException(404, "Finding not found")
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Finding not found")

    for field, value in update.model_dump(exclude_unset=True).items():
        setattr(finding, field, value)

    await db.flush()
    await db.commit()
    await db.refresh(finding)
    payload = finding.to_dict()
    repro_bundle = payload.get("repro_bundle")
    if isinstance(repro_bundle, dict):
        payload["flow_evidence"] = repro_bundle.get("gitnexus")
    return FindingResponse(**payload)


@router.post("/{finding_id}/generate-fix")
async def generate_fix(
    finding_id: str,
    strategy: str = Query("auto", pattern="^(auto|template|llm)$"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Generate a code fix for a finding."""
    result = await db.execute(select(Finding).where(Finding.id == finding_id))
    finding = result.scalar_one_or_none()
    if not finding:
        raise HTTPException(404, "Finding not found")

    from app.remediation.fix_generator import FixGenerator
    from app.remediation.llm_fix_generator import LLMFixGenerator
    from app.llm.provider_config import resolve_llm_provider_config_async
    from app.llm.client import LLMClient

    scan_result = await db.execute(select(Scan).where(Scan.id == finding.scan_id))
    scan = scan_result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Finding not found")

    project_result = await db.execute(select(Project).where(Project.id == scan.project_id))
    project = project_result.scalar_one_or_none()
    if not current_user.is_admin and (not project or project.owner_id != current_user.id):
        raise HTTPException(404, "Finding not found")

    fix = None
    if strategy in ("auto", "llm"):
        llm_cfg = await resolve_llm_provider_config_async(
            db,
            project,
            scan_config=scan.scan_config or {},
        )
        client = LLMClient(
            enabled=bool(llm_cfg.get("enabled", False)),
            provider=str(llm_cfg.get("provider", "")),
            model=str(llm_cfg.get("model", "")),
            api_key=str(llm_cfg.get("api_key", "")),
        )
        llm_generator = LLMFixGenerator(client)
        fix = await llm_generator.generate(finding, project=project)

    if not fix and strategy in ("auto", "template"):
        template_generator = FixGenerator()
        fix = template_generator.generate_fix(finding)

    if fix:
        if fix.get("fixed_code") and not fix.get("original_code"):
            fix["original_code"] = finding.code_snippet or ""

        if fix.get("fixed_code") and fix.get("original_code"):
            before_lines = str(fix.get("original_code", "")).splitlines()
            after_lines = str(fix.get("fixed_code", "")).splitlines()
            unified = difflib.unified_diff(
                before_lines,
                after_lines,
                fromfile="before",
                tofile="after",
                lineterm="",
            )
            fix["diff"] = "\n".join(unified)

        if fix.get("remediation_text"):
            finding.remediation_text = fix["remediation_text"]
        finding.generated_fix_payload = fix
        finding.fix_available = True
        await db.flush()
        await db.commit()

    return {
        "finding_id": finding_id,
        "fix_available": fix is not None,
        "strategy_used": (
            "llm" if fix and "triage" in fix else
            "template" if fix else
            "none"
        ),
        "fix": fix,
    }


class ChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    question: str
    thread: list[ChatMessage] = []  # Previous messages (max 2 exchanges = 4 messages)


@router.post("/{finding_id}/chat")
async def chat_about_finding(
    finding_id: str,
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ask a question about a finding. Returns AI-generated answer.

    Thread management is frontend-only (max 2 exchanges).
    Backend is stateless — finding context included in every call.
    """
    result = await db.execute(select(Finding).where(Finding.id == finding_id))
    finding = result.scalar_one_or_none()
    if not finding:
        raise HTTPException(404, "Finding not found")

    scan_result = await db.execute(select(Scan).where(Scan.id == finding.scan_id))
    scan = scan_result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Finding not found")

    project_result = await db.execute(
        select(Project).where(Project.id == scan.project_id)
    )
    project = project_result.scalar_one_or_none()
    if not current_user.is_admin and (not project or project.owner_id != current_user.id):
        raise HTTPException(404, "Finding not found")

    # Get LLM config
    from app.llm.provider_config import resolve_llm_provider_config_async
    from app.llm.client import LLMClient

    llm_cfg = await resolve_llm_provider_config_async(
        db,
        project,
        scan.scan_config or {},
    )

    if not llm_cfg.get("enabled"):
        raise HTTPException(400, "LLM is not enabled for this project")

    client = LLMClient(
        enabled=bool(llm_cfg.get("enabled", False)),
        provider=str(llm_cfg.get("provider", "")),
        model=str(llm_cfg.get("model", "")),
        api_key=str(llm_cfg.get("api_key", "")),
    )

    if not client.is_available():
        raise HTTPException(400, "LLM provider credentials unavailable")

    # Build system prompt with finding context
    system_prompt = (
        "You are a security findings analyst. Answer questions about security vulnerabilities concisely.\n\n"
        f"Finding: {finding.title}\n"
        f"Type: {finding.vulnerability_type}\n"
        f"Severity: {finding.severity}\n"
        f"Endpoint: {finding.endpoint} {finding.http_method} {finding.parameter}\n"
        f"CWE: {finding.cwe}\n"
        f"Description: {finding.owasp_category}\n"
    )

    if finding.code_snippet:
        system_prompt += f"Code:\n{finding.code_snippet}\n"

    # Build user prompt with question and thread history
    messages = []
    if request.thread:
        messages.extend(request.thread)
    messages.append({"role": "user", "content": request.question})

    # Convert thread to prompt format
    thread_text = ""
    for msg in request.thread:
        role_label = "Me" if msg.role == "user" else "Assistant"
        thread_text += f"{role_label}: {msg.content}\n"

    user_prompt = f"{thread_text}Me: {request.question}\n\nAssistant: "

    try:
        # Call LLM with finding context
        response = await client.chat_json(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )

        # Extract text answer
        answer = ""
        if isinstance(response, dict):
            # If LLM returns JSON, try to extract a text field
            answer = response.get("answer") or response.get("text") or str(response)
        else:
            answer = str(response)

        return {
            "finding_id": finding_id,
            "question": request.question,
            "answer": answer,
            "thread_updated": [
                *request.thread,
                {"role": "user", "content": request.question},
                {"role": "assistant", "content": answer},
            ][-4:],  # Keep last 4 messages (2 exchanges)
        }

    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.exception(f"Chat error for finding {finding_id}: {e}")
        raise HTTPException(500, f"LLM query failed: {str(e)}")
