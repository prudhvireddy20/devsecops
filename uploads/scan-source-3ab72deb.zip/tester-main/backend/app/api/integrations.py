"""Integrations management API (Tools → Integrations)."""

from __future__ import annotations

import logging
import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.integrations.email_client import send_email, smtp_configured
from app.models.integration_setting import IntegrationSetting
from app.models.user import User

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/integrations", tags=["integrations"])

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_EMAIL_DESCRIPTION = (
    "Deliver security alerts, report digests, and scan summaries straight to "
    "your team's inbox — no dashboard required."
)


class EmailIntegrationUpdate(BaseModel):
    enabled: bool
    recipients: list[str]


async def _get_email_row(db: AsyncSession) -> IntegrationSetting | None:
    result = await db.execute(
        select(IntegrationSetting).where(IntegrationSetting.key == "email")
    )
    return result.scalar_one_or_none()


def _email_state(row: IntegrationSetting | None) -> tuple[bool, list[str]]:
    if not row:
        return False, []
    recipients = [r for r in (row.config or {}).get("recipients", []) if r]
    return bool(row.enabled), recipients


@router.get("")
async def list_integrations(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Catalog of available integrations with their connection state."""
    enabled, recipients = _email_state(await _get_email_row(db))
    return [
        {
            "key": "email",
            "name": "Email (SMTP)",
            "category": "Communication & Alerts",
            "description": _EMAIL_DESCRIPTION,
            "auth_label": "SMTP",
            "connected": smtp_configured(),
            "enabled": enabled,
            "recipients_count": len(recipients),
        }
    ]


@router.get("/email")
async def get_email_integration(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    enabled, recipients = _email_state(await _get_email_row(db))
    return {
        "enabled": enabled,
        "recipients": recipients,
        "smtp_configured": smtp_configured(),
        "from_email": settings.SMTP_FROM_EMAIL or settings.SMTP_USERNAME,
    }


@router.put("/email")
async def update_email_integration(
    payload: EmailIntegrationUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    recipients = [r.strip() for r in payload.recipients if r and r.strip()]
    invalid = [r for r in recipients if not _EMAIL_RE.match(r)]
    if invalid:
        raise HTTPException(422, f"Invalid email address(es): {', '.join(invalid)}")
    if payload.enabled and not recipients:
        raise HTTPException(422, "Add at least one recipient before enabling")

    row = await _get_email_row(db)
    if not row:
        row = IntegrationSetting(key="email")
        db.add(row)
    row.enabled = payload.enabled
    row.config = {**(row.config or {}), "recipients": recipients}
    await db.commit()

    return {
        "enabled": row.enabled,
        "recipients": recipients,
        "smtp_configured": smtp_configured(),
        "from_email": settings.SMTP_FROM_EMAIL or settings.SMTP_USERNAME,
    }


@router.post("/email/test")
async def test_email_integration(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Send a short test email to the saved recipients."""
    if not smtp_configured():
        raise HTTPException(
            409,
            "SMTP is not configured — set SMTP_HOST, SMTP_USERNAME and "
            "SMTP_PASSWORD environment variables on the backend",
        )
    _, recipients = _email_state(await _get_email_row(db))
    if not recipients:
        raise HTTPException(422, "Add and save at least one recipient first")

    try:
        await send_email(
            recipients,
            "TraceON test email",
            "<p>This is a test email from your TraceON Email (SMTP) integration. "
            "Post-scan reports will be delivered here.</p>",
        )
    except Exception as exc:  # noqa: BLE001 — surface SMTP errors to the UI
        logger.warning("email integration test failed: %s", exc)
        raise HTTPException(502, f"SMTP send failed: {exc}")

    return {"ok": True, "recipients": recipients}
