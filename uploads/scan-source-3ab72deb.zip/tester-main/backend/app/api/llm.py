"""LLM provider management API endpoints."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import logging
import uuid

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.security import decrypt_token, encrypt_token
from app.models.llm_provider_credential import LLMProviderCredential
from app.models.user import User
from app.llm.provider_config import normalize_provider
from app.llm.catalog import (
    get_default_model,
    get_env_api_key,
    get_provider_auth_mode,
    get_provider_label,
    get_provider_models,
    list_providers,
)
from app.llm.client import (
    LLMClient,
    LLMCredentialValidationError,
    LLMProviderConnectivityError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/llm", tags=["llm"])


class ProviderUpdateRequest(BaseModel):
    api_key: str | None = None
    default_model: str | None = None


def _validate_provider(provider: str) -> str:
    normalized = normalize_provider(provider)
    if not normalized:
        raise HTTPException(400, "Unsupported provider")
    return normalized


def _validate_model(provider: str, model: str | None) -> str:
    value = (model or "").strip()
    if not value:
        return ""
    allowed = get_provider_models(provider)
    if value not in allowed:
        raise HTTPException(400, f"Unsupported model '{value}' for provider '{provider}'")
    return value


async def _load_provider_rows(
    db: AsyncSession,
    provider: str,
    user_id: str,
) -> tuple[LLMProviderCredential | None, LLMProviderCredential | None]:
    result = await db.execute(
        select(LLMProviderCredential).where(
            LLMProviderCredential.provider == provider,
            LLMProviderCredential.user_id == user_id,
        )
    )
    row = result.scalar_one_or_none()

    legacy_row: LLMProviderCredential | None = None
    if provider == "github" and row is None:
        legacy_result = await db.execute(
            select(LLMProviderCredential).where(
                LLMProviderCredential.provider == "copilot",
                LLMProviderCredential.user_id == user_id,
            )
        )
        legacy_row = legacy_result.scalar_one_or_none()

    return row, legacy_row


async def _ensure_provider_row(
    db: AsyncSession, provider: str, user_id: str
) -> LLMProviderCredential:
    row, legacy_row = await _load_provider_rows(db, provider, user_id)
    if row is not None:
        return row

    if legacy_row is not None and provider == "github":
        row = LLMProviderCredential(
            provider="github",
            user_id=user_id,
            encrypted_token=legacy_row.encrypted_token,
            default_model=legacy_row.default_model,
        )
        db.add(row)
        await db.flush()
        await db.delete(legacy_row)
        await db.flush()
        return row

    row = LLMProviderCredential(provider=provider, user_id=user_id)
    db.add(row)
    return row


def _provider_connection_payload(provider: str, row: LLMProviderCredential | None) -> dict:
    env_key = get_env_api_key(provider)
    stored_key = ""
    if row and row.encrypted_token:
        stored_key = decrypt_token(row.encrypted_token)

    has_stored = bool(stored_key)
    has_env = bool(env_key)
    reconnect_required = bool(row and row.encrypted_token and not has_stored and not has_env)

    model = ""
    if row and row.default_model:
        model = row.default_model
    else:
        model = get_default_model(provider)
    if model not in get_provider_models(provider):
        model = get_default_model(provider)

    source = "none"
    if has_stored:
        source = "stored"
    elif has_env:
        source = "env"

    payload = {
        "provider": provider,
        "label": get_provider_label(provider),
        "connected": bool(has_stored or has_env),
        "source": source,
        "default_model": model,
        "models": get_provider_models(provider),
        "needs_reconnect": reconnect_required,
        "auth_mode": get_provider_auth_mode(provider),
    }

    return payload


@router.get("/providers")
async def list_llm_providers(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List providers, available models, auth modes, and connection status (per-user)."""
    result = await db.execute(
        select(LLMProviderCredential).where(
            LLMProviderCredential.user_id == current_user.id
        )
    )
    stored_rows = result.scalars().all()
    stored = {row.provider: row for row in stored_rows}

    providers = []
    for provider in list_providers():
        row = stored.get(provider)
        providers.append(_provider_connection_payload(provider, row))

    return {
        "enabled": True,
        "providers": providers,
    }


@router.put("/providers/{provider}")
async def upsert_llm_provider(
    provider: str,
    payload: ProviderUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Connect/update provider API key and optional default model (per-user)."""
    normalized = _validate_provider(provider)
    model = _validate_model(normalized, payload.default_model)
    incoming_key = (payload.api_key or "").strip()

    row, legacy_row = await _load_provider_rows(db, normalized, current_user.id)

    if incoming_key:
        existing_model = (row.default_model or "").strip() if row else ""
        if existing_model and existing_model not in get_provider_models(normalized):
            existing_model = ""
        probe_model = model or existing_model or get_default_model(normalized)
        validator = LLMClient(
            enabled=True,
            provider=normalized,
            model=probe_model,
            api_key=incoming_key,
        )
        try:
            await validator.validate_connection()
        except LLMCredentialValidationError as exc:
            raise HTTPException(400, str(exc)) from exc
        except LLMProviderConnectivityError as exc:
            raise HTTPException(502, str(exc)) from exc

    if row is None:
        if legacy_row is not None and normalized == "github":
            row = LLMProviderCredential(
                provider="github",
                user_id=current_user.id,
                encrypted_token=legacy_row.encrypted_token,
                default_model=legacy_row.default_model,
            )
            db.add(row)
            await db.flush()
            await db.delete(legacy_row)
        else:
            row = LLMProviderCredential(provider=normalized, user_id=current_user.id)
            db.add(row)

    if incoming_key:
        existing_plaintext = ""
        if row.encrypted_token:
            existing_plaintext = decrypt_token(row.encrypted_token)

        if incoming_key != existing_plaintext:
            row.encrypted_token = encrypt_token(incoming_key)
    if model:
        row.default_model = model
    elif payload.default_model is not None:
        row.default_model = ""

    await db.flush()
    await db.commit()
    await db.refresh(row)

    return _provider_connection_payload(normalized, row)


@router.delete("/providers/{provider}")
async def disconnect_llm_provider(
    provider: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Remove stored API key for provider (env key may still exist)."""
    normalized = _validate_provider(provider)

    row, legacy_row = await _load_provider_rows(db, normalized, current_user.id)
    if row:
        row.encrypted_token = ""
        await db.flush()
        await db.commit()
    elif legacy_row and normalized == "github":
        legacy_row.encrypted_token = ""
        await db.flush()
        await db.commit()

    return {
        "provider": normalized,
        "connected": bool(get_env_api_key(normalized)),
        "source": "env" if get_env_api_key(normalized) else "none",
    }
