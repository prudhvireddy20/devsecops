"""Project CRUD API endpoints."""
import json
import logging
import os
import shutil
import uuid
import zipfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.url_safety import validate_external_target_url
from app.models.project import Project
from app.models.user import User
from app.models.project_artifact import ProjectArtifact
from app.models.workflow_graph import WorkflowGraph, WorkflowStep, WorkflowAttackPoint
from app.core.security import encrypt_token
from app.llm.provider_config import normalize_provider
from app.workflow.service import (
    ingest_artifact_file,
    ensure_project_artifacts_from_project_config,
)

router = APIRouter(prefix="/projects", tags=["projects"])
logger = logging.getLogger(__name__)


# --- Pydantic Schemas ---

# Input length validation constants
MAX_PROJECT_NAME_LENGTH = 255
MAX_PROJECT_DESCRIPTION_LENGTH = 5000

class ProjectCreate(BaseModel):
    name: str
    description: str = ""
    source_type: str = Field(default="url", description="whitebox and blackbox use 'url'")
    source_path: str = ""
    scan_mode: str = Field(default="whitebox", description="whitebox or blackbox")
    target_url: str = ""
    llm_provider: str = ""
    llm_model: str = ""
    llm_api_key: str = ""
    openapi_spec_files: str = ""
    postman_collection_files: str = ""
    journey_replay_files: str = ""
    trustscan_url: str = ""
    trustscan_token: str = ""
    trustscan_job_id: str = ""
    auth_config: dict = {}
    git_url: str = ""  # Not required anymore
    git_branch: str = ""  # Not required anymore

    def __init__(self, **data):
        super().__init__(**data)
        # Validate input lengths
        if len(self.name) > MAX_PROJECT_NAME_LENGTH:
            raise ValueError(f"Project name must be at most {MAX_PROJECT_NAME_LENGTH} characters")
        if len(self.description) > MAX_PROJECT_DESCRIPTION_LENGTH:
            raise ValueError(f"Project description must be at most {MAX_PROJECT_DESCRIPTION_LENGTH} characters")


class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    target_url: str | None = None
    git_branch: str | None = None
    llm_provider: str | None = None
    llm_model: str | None = None
    llm_api_key: str | None = None
    openapi_spec_files: str | None = None
    postman_collection_files: str | None = None
    journey_replay_files: str | None = None


class ProjectResponse(BaseModel):
    id: str
    name: str
    description: str
    source_type: str
    source_path: str
    scan_mode: str = "whitebox"
    git_url: str
    git_branch: str
    target_url: str
    framework: str
    language: str
    local_path: str
    trustscan_url: str = ""
    has_trustscan_token: bool = False
    trustscan_job_id: str = ""
    external_findings_path: str = ""
    external_findings_format: str = ""
    llm_provider: str
    llm_model: str
    has_llm_api_key: bool
    openapi_spec_files: str
    postman_collection_files: str
    journey_replay_files: str
    has_auth_config: bool = False
    is_active: bool
    created_at: str | None
    updated_at: str | None


# --- Endpoints ---

@router.post("", response_model=ProjectResponse)
async def create_project(
    project_in: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Create a new project and import source code."""
    # DEBUG: Log incoming request
    logger.info(f"Creating project: name={project_in.name}, scan_mode={project_in.scan_mode}, source_type={project_in.source_type}, git_url='{project_in.git_url}'")

    normalized_target_url = (project_in.target_url or "").strip()
    if normalized_target_url:
        is_valid_url, url_err = validate_external_target_url(normalized_target_url)
        if not is_valid_url:
            raise HTTPException(400, f"Invalid target URL: {url_err}")
        from app.core.url_safety import rewrite_docker_host
        normalized_target_url = rewrite_docker_host(normalized_target_url)

    project = Project(
        id=str(uuid.uuid4()),
        name=project_in.name,
        description=project_in.description,
        source_type=project_in.source_type,
        source_path=project_in.source_path,
        scan_mode=project_in.scan_mode,
        git_url=project_in.git_url,
        git_branch=project_in.git_branch,
        target_url=normalized_target_url,
        llm_provider=normalize_provider(project_in.llm_provider),
        llm_model=(project_in.llm_model or "").strip(),
        openapi_spec_files=(project_in.openapi_spec_files or "").strip(),
        postman_collection_files=(project_in.postman_collection_files or "").strip(),
        journey_replay_files=(project_in.journey_replay_files or "").strip(),
        auth_config=project_in.auth_config or {},
        owner_id=current_user.id,
    )

    # source_available is not used — source code analysis is not part of the pipeline
    project.source_available = False

    # TrustScan platform connection
    if project_in.trustscan_url:
        _ts_valid, _ts_err = validate_external_target_url(project_in.trustscan_url)
        if not _ts_valid:
            raise HTTPException(400, f"Invalid TrustScan URL: {_ts_err}")
    project.trustscan_url = (project_in.trustscan_url or "").strip()
    project.trustscan_job_id = (project_in.trustscan_job_id or "").strip()

    # Encrypt and store tokens if provided
    if project_in.trustscan_token:
        project.trustscan_token_encrypted = encrypt_token(project_in.trustscan_token)
    if project_in.llm_api_key:
        project.llm_api_key_encrypted = encrypt_token(project_in.llm_api_key)

    # Set up local project directory
    project_dir = settings.PROJECTS_DIR / project.id
    project_dir.mkdir(parents=True, exist_ok=True)

    try:
        if project_in.source_type == "git":
            await _clone_git_repo(
                project_in.git_url,
                project_in.git_branch,
                project_dir,
                "",
            )
            project.local_path = str(project_dir)
        elif project_in.source_type == "local":
            # Copy from local path
            src = Path(project_in.source_path)
            if not src.exists():
                raise HTTPException(
                    400,
                    f"Source path does not exist: {src}. "
                    "Note: this path must exist on the server filesystem. "
                    "If running in Docker, ensure the path is mounted as a volume.",
                )
            if not src.is_dir():
                raise HTTPException(
                    400,
                    f"Source path is not a directory: {src}. "
                    "Please provide a path to a directory, not a file.",
                )
            shutil.copytree(src, project_dir / "source", dirs_exist_ok=True)
            project.local_path = str(project_dir / "source")
        elif project_in.source_type == "zip":
            # Will be handled by upload endpoint
            project.local_path = str(project_dir / "source")
        elif project_in.source_type == "url":
            # git_url stored for reference only; no source code cloning needed
            if project_in.scan_mode == "whitebox" and project_in.git_url:
                await _clone_git_repo(
                    project_in.git_url,
                    project_in.git_branch,
                    project_dir,
                    "",
                )
                project.local_path = str(project_dir)
            else:
                project.local_path = str(project_dir)
        else:
            raise HTTPException(400, f"Unsupported source_type: {project_in.source_type}")
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to import source code for project")
        shutil.rmtree(project_dir, ignore_errors=True)
        raise HTTPException(400, f"Failed to import source: {str(e)}")

    db.add(project)
    await db.flush()
    await db.commit()
    await db.refresh(project)
    return ProjectResponse(**project.to_dict())


@router.post("/{project_id}/upload")
async def upload_zip(
    project_id: str,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Upload a ZIP file as the project source."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    # Validate file name
    filename = file.filename or ""
    if not filename.lower().endswith(".zip"):
        raise HTTPException(
            400,
            f"Expected a .zip file, got: {filename}. "
            "Please upload a valid ZIP archive.",
        )

    project_dir = settings.PROJECTS_DIR / project_id
    project_dir.mkdir(parents=True, exist_ok=True)
    zip_path = project_dir / "upload.zip"

    # Save uploaded file with size limit (500 MB)
    max_size = 500 * 1024 * 1024
    content = await file.read()
    if len(content) > max_size:
        raise HTTPException(
            400,
            f"ZIP file too large ({len(content) // (1024 * 1024)} MB). "
            f"Maximum allowed size is {max_size // (1024 * 1024)} MB.",
        )

    with open(zip_path, "wb") as f:
        f.write(content)

    # Validate it's actually a ZIP file
    if not zipfile.is_zipfile(zip_path):
        zip_path.unlink(missing_ok=True)
        raise HTTPException(
            400,
            "The uploaded file is not a valid ZIP archive.",
        )

    # Extract (safe: validate paths against zip slip)
    source_dir = project_dir / "source"
    # Clean existing source if re-uploading
    if source_dir.exists():
        shutil.rmtree(source_dir)
    source_dir.mkdir(exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.namelist():
                member_path = (source_dir / member).resolve()
                if not str(member_path).startswith(str(source_dir.resolve())):
                    raise HTTPException(400, f"Zip slip detected: {member}")
            zf.extractall(source_dir)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to extract zip file")
        zip_path.unlink(missing_ok=True)
        shutil.rmtree(source_dir, ignore_errors=True)
        raise HTTPException(400, f"Failed to extract ZIP: {str(e)}")
    finally:
        # Ensure zip is cleaned up even if extraction fails
        zip_path.unlink(missing_ok=True)

    project.local_path = str(source_dir)
    project.source_type = "zip"
    await db.commit()

    return {"status": "uploaded", "local_path": str(source_dir)}


_MAX_FINDINGS_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB


@router.post("/{project_id}/upload-findings")
async def upload_project_findings(
    project_id: str,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Upload an external findings JSON file and attach it to the project.

    Supports Semgrep, SARIF, Gitleaks, Trivy, and TrustScan/traceon formats.
    The path is stored on the project and automatically copied into scan config
    when a scan is started.
    """
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    raw = await file.read()
    if len(raw) > _MAX_FINDINGS_UPLOAD_BYTES:
        raise HTTPException(413, "File too large (max 50 MB)")

    try:
        data = json.loads(raw)
    except Exception:
        raise HTTPException(400, "File is not valid JSON")

    dest = settings.UPLOADS_DIR / project_id / "external_findings.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)

    from app.scanners.external_importer import ExternalFindingImporter
    importer = ExternalFindingImporter()
    fmt = importer.detect_format(data)
    sample = importer.import_findings(data, format=fmt, auto_detect=False)

    project.external_findings_path = str(dest)
    project.external_findings_format = fmt
    await db.commit()

    logger.info(
        "Uploaded findings for project %s: format=%s count=%d",
        project_id, fmt, len(sample),
    )
    return {
        "path": str(dest),
        "format": fmt,
        "finding_count": len(sample),
    }


@router.post("/{project_id}/artifacts")
async def upload_project_artifact(
    project_id: str,
    kind: str = Form(...),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Upload optional scan artifacts (openapi/postman/journey replay files)."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    kind_norm = (kind or "").strip().lower()
    field_map = {
        "openapi": "openapi_spec_files",
        "postman": "postman_collection_files",
        "journey": "journey_replay_files",
    }
    if kind_norm not in field_map:
        raise HTTPException(400, "kind must be one of: openapi, postman, journey")

    filename = (file.filename or "").strip()
    if not filename:
        raise HTTPException(400, "Missing file name")

    allowed_ext = {
        "openapi": {".json", ".yaml", ".yml"},
        "postman": {".json"},
        "journey": {".json", ".har"},
    }
    ext = Path(filename).suffix.lower()
    if ext not in allowed_ext[kind_norm]:
        raise HTTPException(400, f"Invalid file extension for {kind_norm}: {ext}")

    project_root = Path(project.local_path or (settings.PROJECTS_DIR / project_id / "source"))
    project_root.mkdir(parents=True, exist_ok=True)
    artifact_dir = project_root / ".traceon_artifacts" / kind_norm
    artifact_dir.mkdir(parents=True, exist_ok=True)

    safe_name = f"{uuid.uuid4().hex[:8]}_{Path(filename).name}"
    dest = artifact_dir / safe_name
    data = await file.read()
    
    # File size limits to prevent memory exhaustion DoS attacks
    MAX_ARTIFACT_FILE_SIZE = 50 * 1024 * 1024  # 50 MB for artifacts
    if len(data) > MAX_ARTIFACT_FILE_SIZE:
        logger.warning(f"Artifact file too large: {len(data)} bytes (max: {MAX_ARTIFACT_FILE_SIZE})")
        raise HTTPException(400, f"Artifact too large. Max {MAX_ARTIFACT_FILE_SIZE // (1024 * 1024)} MB")
    dest.write_bytes(data)

    try:
        rel = str(dest.relative_to(project_root))
    except Exception as exc:
        logger.exception("Failed to get relative path for artifact")
        rel = str(dest)

    field = field_map[kind_norm]
    current = str(getattr(project, field, "") or "")
    parts = [p.strip() for p in current.split(",") if p.strip()]
    if rel not in parts:
        parts.append(rel)
    setattr(project, field, ",".join(parts))

    await db.flush()
    await db.refresh(project)

    parse_result = await ingest_artifact_file(
        db,
        project,
        kind=kind_norm,
        source_path=rel,
    )

    await db.commit()

    return {
        "status": "uploaded",
        "kind": kind_norm,
        "file": rel,
        "project_id": project_id,
        "workflow": parse_result.get("graph"),
        "steps": parse_result.get("steps", 0),
    }


@router.get("/{project_id}/artifacts")
async def list_project_artifacts(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List uploaded artifacts and parsed workflow graphs for a project."""
    project_result = await db.execute(select(Project).where(Project.id == project_id))
    project = project_result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    # Backfill legacy project config artifact paths into registry.
    backfill_result = await ensure_project_artifacts_from_project_config(db, project)
    if (backfill_result.get("created", 0) > 0) or (backfill_result.get("parsed", 0) > 0):
        await db.commit()

    artifact_result = await db.execute(
        select(ProjectArtifact).where(ProjectArtifact.project_id == project_id)
    )
    artifacts = artifact_result.scalars().all()

    graph_result = await db.execute(
        select(WorkflowGraph).where(WorkflowGraph.project_id == project_id)
    )
    graphs = graph_result.scalars().all()

    graph_ids = [g.id for g in graphs]
    step_counts: dict[str, int] = {}
    attack_counts: dict[str, int] = {}
    if graph_ids:
        for gid in graph_ids:
            step_result = await db.execute(
                select(WorkflowStep).where(WorkflowStep.graph_id == gid)
            )
            ap_result = await db.execute(
                select(WorkflowAttackPoint).where(WorkflowAttackPoint.graph_id == gid)
            )
            step_counts[gid] = len(step_result.scalars().all())
            attack_counts[gid] = len(ap_result.scalars().all())

    return {
        "project_id": project_id,
        "artifacts": [a.to_dict() for a in artifacts],
        "workflows": [
            {
                **g.to_dict(),
                "step_count": step_counts.get(g.id, 0),
                "attack_point_count": attack_counts.get(g.id, 0),
            }
            for g in graphs
        ],
    }


@router.get("")
async def list_projects(
    page: int = 1,
    page_size: int = 50,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List projects owned by the current user (admin sees all)."""
    from sqlalchemy import func

    base_where = Project.is_active.is_(True)
    if not current_user.is_admin:
        base_where = base_where & (Project.owner_id == current_user.id)

    # Count total
    count_result = await db.execute(
        select(func.count(Project.id)).where(base_where)
    )
    total = count_result.scalar() or 0
    pages = max(1, (total + page_size - 1) // page_size)

    # Fetch page
    offset = (page - 1) * page_size
    result = await db.execute(
        select(Project)
        .where(base_where)
        .order_by(Project.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    projects = result.scalars().all()

    return {
        "items": [ProjectResponse(**p.to_dict()).model_dump() for p in projects],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
    }


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get a single project by ID."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "Project not found")
    if not current_user.is_admin and project.owner_id and project.owner_id != current_user.id:
        raise HTTPException(404, "Project not found")
    return ProjectResponse(**project.to_dict())


@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    update: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update project metadata."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "Project not found")
    if not current_user.is_admin and project.owner_id and project.owner_id != current_user.id:
        raise HTTPException(404, "Project not found")

    for field, value in update.model_dump(exclude_unset=True).items():
        if field == "llm_api_key" and value:
            project.llm_api_key_encrypted = encrypt_token(value)
        elif field == "target_url" and isinstance(value, str):
            normalized_target_url = value.strip()
            if normalized_target_url:
                is_valid_url, url_err = validate_external_target_url(normalized_target_url)
                if not is_valid_url:
                    raise HTTPException(400, f"Invalid target URL: {url_err}")
            setattr(project, field, normalized_target_url)
        elif hasattr(project, field):
            if field == "llm_provider" and isinstance(value, str):
                setattr(project, field, normalize_provider(value))
            elif field == "llm_model" and isinstance(value, str):
                setattr(project, field, value.strip())
            else:
                setattr(project, field, value)

    await db.flush()
    await db.commit()
    await db.refresh(project)
    return ProjectResponse(**project.to_dict())


@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Delete a project and its data."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "Project not found")
    if not current_user.is_admin and project.owner_id and project.owner_id != current_user.id:
        raise HTTPException(404, "Project not found")

    # Remove project files
    project_dir = settings.PROJECTS_DIR / project_id
    if project_dir.exists():
        shutil.rmtree(project_dir)

    await db.delete(project)
    await db.commit()
    return {"status": "deleted", "id": project_id}


@router.get("/{project_id}/routes")
async def get_project_routes(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Extract routes from project source code without requiring a scan."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    if not project.local_path or not Path(project.local_path).exists():
        return {"items": [], "total": 0}

    try:
        from app.analyzers.route_extractor import RouteExtractor
        extractor = RouteExtractor()
        routes = await extractor.extract_routes(project.local_path)
    except Exception:
        logger.exception("Failed to extract routes for project %s", project_id)
        routes = []

    return {
        "items": [
            {
                "path": r.get("path", ""),
                "method": r.get("method", "GET"),
                "handler": r.get("handler", ""),
                "function": r.get("function_name", ""),
                "file_path": r.get("file", ""),
                "line": r.get("line", 0),
                "auth_required": r.get("auth_required", False),
                "parameters": r.get("parameters", []),
            }
            for r in routes
        ],
        "total": len(routes),
    }


@router.get("/{project_id}/files")
async def get_project_files(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get the file tree for a project's source code."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    if not project.local_path or not Path(project.local_path).exists():
        raise HTTPException(400, "Project source not available")

    tree = _build_file_tree(Path(project.local_path))
    return {"tree": tree}


@router.get("/{project_id}/file")
async def get_file_content(
    project_id: str,
    path: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get content of a specific file in the project."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Project not found")

    # Security: ensure the path doesn't escape project directory (check BEFORE accessing)
    file_path = Path(project.local_path) / path
    try:
        file_path.resolve().relative_to(Path(project.local_path).resolve())
    except ValueError:
        raise HTTPException(403, "Path traversal detected")

    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(404, "File not found")

    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        logger.exception(f"Failed to read file {file_path}")
        raise HTTPException(500, f"Failed to read file: {str(e)}")

    return {"path": path, "content": content, "language": _detect_language(path)}


# --- Helper Functions ---

async def _clone_git_repo(
    git_url: str, branch: str, dest: Path, token: str = ""
):
    """Clone a git repository (non-blocking async subprocess).

    If *branch* is empty or the specified branch is not found, falls back
    to the repository's default branch.

    Uses environment variable GIT_ASKPASS for token authentication to avoid
    exposing credentials in process arguments.
    """
    # Safety check: git_url must be non-empty
    if not git_url or not git_url.strip():
        raise ValueError("git_url cannot be empty")

    import asyncio
    import urllib.parse

    # Use environment variable for token authentication instead of URL injection
    env = None
    if token:
        env = os.environ.copy()
        # GIT_ASKPASS allows passing credentials securely without exposing in command line
        env['GIT_ASKPASS_RESULT'] = token
        # Use SSH_ASKPASS-like mechanism for HTTPS auth
        askpass_script = "#!/bin/sh\necho \"$GIT_ASKPASS_RESULT\""
        env['GIT_ASKPASS'] = 'echo'
        # Alternatively, use git credential helper (preferred for HTTPS)
        # Set up a temporary credential helper that returns the token
        env['GIT_TERMINAL_PROMPT'] = '0'  # Disable interactive prompts

    # Build command — omit --branch when empty so git uses the repo default
    cmd = ["git", "clone", "--depth", "1"]
    if branch:
        cmd += ["--branch", branch]
    cmd += [git_url, str(dest)]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
    except asyncio.TimeoutError:
        proc.kill()
        raise Exception("Git clone timed out after 120 seconds")

    if proc.returncode != 0:
        stderr_text = stderr.decode()
        # If the branch wasn't found, retry without --branch (use repo default)
        if branch and ("not found" in stderr_text or "not a valid ref" in stderr_text):
            # Clean up the failed attempt
            import shutil
            shutil.rmtree(dest, ignore_errors=True)
            dest.mkdir(parents=True, exist_ok=True)

            fallback_cmd = ["git", "clone", "--depth", "1", git_url, str(dest)]
            proc2 = await asyncio.create_subprocess_exec(
                *fallback_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            try:
                stdout2, stderr2 = await asyncio.wait_for(proc2.communicate(), timeout=120)
            except asyncio.TimeoutError:
                proc2.kill()
                raise Exception("Git clone timed out after 120 seconds")
            if proc2.returncode != 0:
                raise Exception(f"Git clone failed: {stderr2.decode()}")
            return
        raise Exception(f"Git clone failed: {stderr_text}")


def _build_file_tree(root: Path, prefix: str = "") -> list[dict]:
    """Build a file tree structure for the frontend."""
    entries = []
    try:
        items = sorted(root.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return entries

    skip_dirs = {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox", ".eggs"}
    for item in items:
        # Skip common non-source directories
        if item.is_dir() and item.name in skip_dirs:
            continue
        # Skip hidden files/dirs except .env
        if item.name.startswith(".") and item.name not in (".env",):
            continue
        rel_path = f"{prefix}/{item.name}" if prefix else item.name
        if item.is_dir():
            children = _build_file_tree(item, rel_path)
            entries.append({
                "name": item.name,
                "path": rel_path,
                "type": "directory",
                "children": children,
            })
        else:
            entries.append({
                "name": item.name,
                "path": rel_path,
                "type": "file",
                "language": _detect_language(item.name),
            })
    return entries


def _detect_language(filename: str) -> str:
    """Detect programming language from file extension."""
    ext_map = {
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".tsx": "typescriptreact",
        ".jsx": "javascriptreact",
        ".html": "html",
        ".css": "css",
        ".json": "json",
        ".yaml": "yaml",
        ".yml": "yaml",
        ".md": "markdown",
        ".sql": "sql",
        ".sh": "shell",
        ".dockerfile": "dockerfile",
        ".toml": "toml",
        ".ini": "ini",
        ".cfg": "ini",
        ".txt": "plaintext",
        ".env": "plaintext",
    }
    ext = Path(filename).suffix.lower()
    return ext_map.get(ext, "plaintext")
