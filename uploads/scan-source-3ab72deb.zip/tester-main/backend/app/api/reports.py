"""Report generation API endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.models.scan import Scan
from app.models.finding import Finding
from app.models.project import Project
from app.models.user import User

router = APIRouter(prefix="/reports", tags=["reports"])


class ReportRequest(BaseModel):
    scan_id: str
    format: str = "html"  # html, pdf, sarif, json


class ReportResponse(BaseModel):
    scan_id: str
    format: str
    file_path: str
    download_url: str


@router.post("", response_model=ReportResponse)
async def generate_report(
    report_in: ReportRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Generate a report for a completed scan."""
    # Fetch scan
    result = await db.execute(select(Scan).where(Scan.id == report_in.scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    if scan.status in ("pending", "running"):
        raise HTTPException(409, "Scan is still in progress; generate report after completion")

    # Fetch project + ownership check
    result = await db.execute(select(Project).where(Project.id == scan.project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(404, "Scan not found")

    # Fetch findings (exclude duplicates)
    result = await db.execute(
        select(Finding).where(
            Finding.scan_id == report_in.scan_id,
            Finding.status != "duplicate",
        )
    )
    findings = result.scalars().all()

    # Generate report
    report_dir = settings.REPORTS_DIR / report_in.scan_id
    report_dir.mkdir(parents=True, exist_ok=True)

    findings_data = [f.to_dict() for f in findings]
    scan_data = scan.to_dict()
    project_data = project.to_dict() if project else {}

    if report_in.format == "html":
        from app.reports.html_report import HTMLReportGenerator
        generator = HTMLReportGenerator()
        file_path = await generator.generate(
            scan_data, project_data, findings_data, report_dir
        )
    elif report_in.format == "pdf":
        from app.reports.pdf_report import PDFReportGenerator
        generator = PDFReportGenerator()
        file_path = await generator.generate(
            scan_data, project_data, findings_data, report_dir
        )
    elif report_in.format == "sarif":
        from app.reports.sarif_export import SARIFExporter
        exporter = SARIFExporter()
        file_path = await exporter.export(
            scan_data, project_data, findings_data, report_dir
        )
    elif report_in.format == "json":
        import json
        from datetime import datetime, timezone
        from app.reports.html_report import sort_findings

        sorted_findings = sort_findings(findings_data)
        file_path = report_dir / "report.json"
        with open(file_path, "w") as f:
            json.dump({
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "project": project_data,
                "scan": scan_data,
                "summary": {
                    "total_findings": len(sorted_findings),
                    "by_severity": {
                        s: sum(1 for x in sorted_findings if x.get("severity") == s)
                        for s in ("critical", "high", "medium", "low", "info")
                    },
                    "by_confidence": {
                        c: sum(1 for x in sorted_findings if x.get("confidence") == c)
                        for c in ("verified", "probable", "observed")
                    },
                },
                "findings": sorted_findings,
            }, f, indent=2, ensure_ascii=False, default=str)
    else:
        raise HTTPException(400, f"Unsupported report format: {report_in.format}")

    return ReportResponse(
        scan_id=report_in.scan_id,
        format=report_in.format,
        file_path=str(file_path),
        download_url=f"/api/v1/reports/{report_in.scan_id}/download?format={report_in.format}",
    )


@router.get("/{scan_id}/download")
async def download_report(
    scan_id: str,
    format: str = "html",
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Download a generated report."""
    # Validate scan_id to prevent path traversal
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', scan_id):
        raise HTTPException(400, "Invalid scan ID")

    ext_map = {"html": "report.html", "pdf": "report.pdf", "sarif": "report.sarif", "json": "report.json"}
    if format not in ext_map:
        raise HTTPException(400, f"Unsupported format: {format}")

    # Ownership check
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Report not found.")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Report not found.")

    filename = ext_map[format]
    file_path = settings.REPORTS_DIR / scan_id / filename
    if not file_path.exists():
        raise HTTPException(404, "Report not found. Generate it first.")

    media_type_map = {
        "html": "text/html",
        "pdf": "application/pdf",
        "sarif": "application/json",
        "json": "application/json",
    }

    return FileResponse(
        path=str(file_path),
        filename=filename,
        media_type=media_type_map.get(format, "application/octet-stream"),
    )


@router.get("/{scan_id}/preview")
async def preview_report(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get report data for in-browser preview."""
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    result = await db.execute(select(Project).where(Project.id == scan.project_id))
    project = result.scalar_one_or_none()
    if not current_user.is_admin and (not project or project.owner_id != current_user.id):
        raise HTTPException(404, "Scan not found")

    result = await db.execute(
        select(Finding).where(
            Finding.scan_id == scan_id,
            Finding.status != "duplicate",
        )
    )
    findings = result.scalars().all()

    return {
        "scan": scan.to_dict(),
        "project": project.to_dict() if project else {},
        "findings": [f.to_dict() for f in findings],
    }


class ComplianceRequest(BaseModel):
    scan_id: str
    standards: list[str] = ["pci-dss", "gdpr", "hipaa"]  # Compliance standards to map


@router.post("/{scan_id}/compliance")
async def generate_compliance_report(
    scan_id: str,
    request: ComplianceRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Generate compliance mapping report for a scan.

    Maps findings (by CWE) to compliance standards (PCI-DSS, GDPR, HIPAA, etc).
    Uses LLM to provide reasoning and context for compliance implications.
    """
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    result = await db.execute(select(Project).where(Project.id == scan.project_id))
    project = result.scalar_one_or_none()
    if not current_user.is_admin and (not project or project.owner_id != current_user.id):
        raise HTTPException(404, "Scan not found")

    # Fetch findings
    result = await db.execute(
        select(Finding).where(
            Finding.scan_id == scan_id,
            Finding.status != "duplicate",
        )
    )
    findings = result.scalars().all()

    # Get LLM config
    from app.llm.provider_config import resolve_llm_provider_config_async
    from app.llm.client import LLMClient

    llm_cfg = await resolve_llm_provider_config_async(
        db,
        project,
        scan.scan_config or {},
    )

    if not llm_cfg.get("enabled"):
        raise HTTPException(400, "LLM is not enabled for compliance mapping")

    client = LLMClient(
        enabled=bool(llm_cfg.get("enabled", False)),
        provider=str(llm_cfg.get("provider", "")),
        model=str(llm_cfg.get("model", "")),
        api_key=str(llm_cfg.get("api_key", "")),
    )

    if not client.is_available():
        raise HTTPException(400, "LLM provider credentials unavailable")

    # Build compliance mapping prompt
    findings_list = "\n".join([
        f"- {f.title} (CWE-{f.cwe.replace('CWE-', '')}): {f.severity}"
        for f in findings
    ])

    standards_str = ", ".join(request.standards)

    prompt = (
        f"Map these security findings to compliance standards ({standards_str}):\n\n"
        f"{findings_list}\n\n"
        f"For each finding, provide:\n"
        f"1. Applicable compliance clauses\n"
        f"2. Risk level for compliance\n"
        f"3. Remediation priority\n\n"
        f"Output as JSON with structure: "
        f"{{\"mappings\": [{{\"cwe\": \"CWE-XXX\", \"pci_dss\": [...], \"gdpr\": [...], "
        f"\"hipaa\": [...], \"summary\": \"...\"}}]}}"
    )

    try:
        response = await client.chat_json(
            system_prompt=(
                "You are a compliance expert. Map security vulnerabilities to compliance standards. "
                "Return ONLY valid JSON."
            ),
            user_prompt=prompt,
        )

        return {
            "scan_id": scan_id,
            "standards": request.standards,
            "findings_count": len(findings),
            "mappings": response.get("mappings", []),
            "compliance_summary": {
                "pci_dss": sum(1 for f in findings if f.cwe in ("CWE-89", "CWE-79", "CWE-200")),  # SQL, XSS, Info Disclosure
                "gdpr": sum(1 for f in findings if f.severity in ("critical", "high")),  # High severity = data risk
                "hipaa": sum(1 for f in findings if f.cwe in ("CWE-200", "CWE-307")),  # Info Disclosure, Auth
            },
        }

    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.exception(f"Compliance mapping error for scan {scan_id}: {e}")
        raise HTTPException(500, f"Compliance mapping failed: {str(e)}")
