"""Scan control API endpoints."""
import asyncio
import logging
import contextlib
import json
import secrets
from datetime import UTC, datetime
from pathlib import Path
import threading

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core import cp_bridge
from app.core.database import get_db
from app.core.config import settings
from app.core.security import encrypt_token
from app.core.url_safety import validate_external_target_url
from app.models.project import Project
from app.models.project_artifact import ProjectArtifact
from app.models.scan import Scan
from app.models.user import User
from app.api.websocket import ws_manager
from app.llm.client import LLMClient
from app.llm.provider_config import normalize_provider, resolve_llm_provider_config_async
from app.llm.catalog import get_default_model, get_provider_models
from app.llm.goal_compiler import compile_goals_to_intent
from app.workflow.service import ingest_artifact_file, ensure_project_artifacts_from_project_config
from app.core.scan_queue import ScanQueue

router = APIRouter(prefix="/scans", tags=["scans"])

# Active background scan tasks keyed by scan_id.
# Use a lock to ensure thread-safe access.
_scan_tasks: dict[str, asyncio.Task] = {}
_scan_tasks_lock = threading.Lock()
_queue_worker_task: asyncio.Task | None = None
_queue = ScanQueue()


def _utcnow_naive() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


async def recover_interrupted_scans() -> int:
    """Fail stale in-flight scans after process restart and notify CP.

    This improves production resilience for queue-less deployments: scans that
    were `pending` or `running` when a worker died are explicitly marked failed
    instead of remaining stuck forever.
    """
    from app.core.database import async_session_factory
    from app.core import cp_callback

    recovered = 0
    async with async_session_factory() as db:
        result = await db.execute(
            select(Scan).where(Scan.status.in_(["pending", "running"]))
        )
        stale_scans = list(result.scalars().all())
        if not stale_scans:
            return 0

        now = _utcnow_naive()
        for scan in stale_scans:
            scan.status = "failed"
            scan.completed_at = now
            scan.error_message = (
                "Scan interrupted by service restart before completion. "
                "Please re-run the scan."
            )
            recovered += 1
        await db.commit()

    for scan in stale_scans:
        if scan.cp_callback_url and scan.cp_nonce:
            await cp_callback.post_failed(
                scan.cp_callback_url,
                scan.cp_nonce,
                "Scan interrupted by service restart before completion",
            )

    _logger.warning("Recovered %d interrupted scans at startup", recovered)
    return recovered


async def start_scan_queue_worker() -> None:
    """Start background SQS poll loop when queue mode is enabled."""
    global _queue_worker_task
    if not _queue.enabled:
        return
    if not settings.SCAN_QUEUE_POLL_ENABLED:
        _logger.info("SQS queue mode enabled; poll worker is disabled in this process")
        return
    if _queue_worker_task and not _queue_worker_task.done():
        return
    _queue_worker_task = asyncio.create_task(_scan_queue_worker_loop())
    _logger.info("Started scan queue poll worker")


async def stop_scan_queue_worker() -> None:
    """Stop queue worker on process shutdown."""
    global _queue_worker_task
    task = _queue_worker_task
    _queue_worker_task = None
    if not task:
        return
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task


SCAN_PROFILE_DEFAULTS = {
    "balanced": {
        "scan_depth": 5,
        "timeout": 1800,
        "max_children": 20,
        "context_aware_payloads": True,
        "inscope_only": False,
        "adaptive_timeout": True,
        "ajax_spider": False,
    },
    "api": {
        "scan_depth": 4,
        "timeout": 1200,
        "max_children": 30,
        "context_aware_payloads": True,
        "inscope_only": True,
        "adaptive_timeout": True,
        "ajax_spider": False,
    },
    "spa": {
        "scan_depth": 6,
        "timeout": 2400,
        "max_children": 80,
        "context_aware_payloads": True,
        "inscope_only": False,
        "adaptive_timeout": True,
        "ajax_spider": True,
    },
    "auth_heavy": {
        "scan_depth": 5,
        "timeout": 3000,
        "max_children": 40,
        "context_aware_payloads": True,
        "inscope_only": False,
        "adaptive_timeout": True,
        "ajax_spider": True,
    },
}



def _normalize_string_list(value: object) -> list[str]:
    """Normalize a string-or-list input into a clean string list."""
    items: list[str] = []
    if isinstance(value, str):
        # Allow comma-separated values for UI convenience
        items = [part.strip() for part in value.split(",")]
    elif isinstance(value, list):
        for v in value:
            if isinstance(v, str):
                items.append(v.strip())
    return [x for x in items if x]


def _normalize_scan_config(scan_config: dict | None, scan_type: str, modules_enabled: dict | None) -> dict:
    """Normalize scan config for robust cross-webapp behavior."""
    modules = modules_enabled or {}
    incoming = dict(scan_config or {})

    profile = incoming.get("profile")
    if not profile:
        if modules.get("dast", True) and scan_type in ("full", "dast_only"):
            profile = "balanced"
        else:
            profile = "balanced"

    profile = str(profile).lower()
    base = dict(SCAN_PROFILE_DEFAULTS.get(profile, SCAN_PROFILE_DEFAULTS["balanced"]))
    base["profile"] = profile if profile in SCAN_PROFILE_DEFAULTS else "balanced"
    base.update(incoming)

    base["scan_depth"] = max(1, min(int(base.get("scan_depth", 5)), 20))
    base["timeout"] = max(30, min(int(base.get("timeout", 1800)), 14400))  # Increased from 7200 to 14400 (4 hours)
    base["max_children"] = max(1, min(int(base.get("max_children", 20)), 500))
    base["context_aware_payloads"] = bool(base.get("context_aware_payloads", True))
    base["inscope_only"] = bool(base.get("inscope_only", False))
    base["adaptive_timeout"] = bool(base.get("adaptive_timeout", True))
    base["ajax_spider"] = bool(base.get("ajax_spider", False))

    # Optional file-based adapters/replay inputs
    openapi_files = _normalize_string_list(base.get("openapi_spec_file"))
    postman_files = _normalize_string_list(base.get("postman_collection_file"))
    journey_files = _normalize_string_list(base.get("journey_replay_files"))
    # Backward-compatible singular key
    journey_files.extend(_normalize_string_list(base.get("journey_replay_file")))

    base["openapi_spec_file"] = openapi_files
    base["postman_collection_file"] = postman_files
    base["journey_replay_files"] = sorted(set(journey_files))
    base.pop("journey_replay_file", None)

    # Optional LLM planner controls
    base["llm_planner_enabled"] = bool(base.get("llm_planner_enabled", False))
    base["llm_provider"] = normalize_provider(base.get("llm_provider"))
    base["llm_model"] = str(base.get("llm_model", "") or "").strip()
    # ponytail: LLM key arrives in the POST body unencrypted. On TLS-only
    # deployments this is fine; on plain HTTP the key is exposed in transit.
    # The backend encrypts it before storage, but the wire is the operator's job.
    incoming_llm_key = str(base.get("llm_api_key", "") or "").strip()
    if incoming_llm_key:
        base["llm_api_key_encrypted"] = encrypt_token(incoming_llm_key)
    base.pop("llm_api_key", None)

    # Black-box / white-box mode
    base["black_box_mode"] = bool(base.get("black_box_mode", False))
    base["external_findings_path"] = str(base.get("external_findings_path") or "").strip()
    base["external_findings_format"] = str(base.get("external_findings_format") or "").strip()

    base.setdefault("discovered_routes", [])
    base.setdefault("sast_runtime_focus", True)
    if base.get("sast_runtime_focus"):
        base.setdefault("sast_runtime_excludes", ["**/tests/**"])
    else:
        base.setdefault("sast_runtime_excludes", [])

    return base


# --- Schemas ---

class ScanCreate(BaseModel):
    project_id: str
    scan_type: str = "full"  # full, dast_only
    scan_mode: str | None = None  # None = derive from project
    modules_enabled: dict | None = None  # None = derive from scan_mode
    auth_config: dict = {}
    scan_goals: list[str] = []
    scan_config: dict = {
        "scan_depth": 5,
        "timeout": 3600,
        "max_children": 10,
        "context_aware_payloads": True,
    }


class ScanResponse(BaseModel):
    id: str
    project_id: str
    scan_mode: str = "whitebox"
    status: str
    scan_type: str
    progress: int
    current_phase: str
    modules_enabled: dict
    scan_goals: list = []
    plan_intent: dict = {}
    scan_config: dict
    results_summary: dict
    routes_discovered: int
    coverage_percentage: int
    log: str
    error_message: str
    started_at: str | None
    completed_at: str | None
    created_at: str | None


# --- Endpoints ---

@router.post("", response_model=ScanResponse)
async def start_scan(
    scan_in: ScanCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Start a new security scan for a project."""
    # Verify project exists and is owned by caller
    result = await db.execute(select(Project).where(Project.id == scan_in.project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(404, "Project not found")
    if not current_user.is_admin and project.owner_id and project.owner_id != current_user.id:
        raise HTTPException(404, "Project not found")

    # CP embedded-app claim: if user came through SSO, reserve a scan slot
    cp_claims = getattr(current_user, "cp_sub", None)
    if cp_claims:
        cp_org_id = getattr(current_user, "cp_org_id", "") or ""
        claim_result = await cp_bridge.claim_scan_slot(
            user_id=cp_claims,
            org_id=cp_org_id,
        )
        cp_bridge_job_id = str(claim_result.get("scanJobId", "") or "")
        cp_bridge_callback_url = str(claim_result.get("callbackUrl", "") or "")
        cp_bridge_nonce = str(claim_result.get("callbackNonce", "") or "")
    else:
        cp_bridge_job_id = ""
        cp_bridge_callback_url = ""
        cp_bridge_nonce = ""

    # Determine scan_mode: explicit override → project default → auto-detect from uploads
    scan_mode = scan_in.scan_mode or getattr(project, "scan_mode", "whitebox")
    if scan_mode not in ("whitebox", "blackbox"):
        scan_mode = "whitebox"  # normalise legacy/unknown values
    if not scan_in.scan_mode:
        # Auto-detect: if no explicit mode, check whether an external findings JSON exists
        findings_path = Path(settings.UPLOADS_DIR) / project.id / "external_findings.json"
        if findings_path.exists():
            scan_mode = "whitebox"
        elif not project.target_url:
            scan_mode = "blackbox"

    source_available = False  # source code analysis not used

    # Derive modules from scan_mode if not explicitly provided
    if scan_in.modules_enabled is not None:
        modules_enabled = dict(scan_in.modules_enabled)
    elif scan_mode == "whitebox":
        modules_enabled = {"dast": True, "nuclei": True, "coverage": False}
    else:
        modules_enabled = {
            "dast": True, "nuclei": True, "dast_extended": True,
            "wapiti": True, "sqlmap": True, "dalfox": True, "testssl": True,
            "feroxbuster": True, "coverage": False,
        }

    if modules_enabled.get("dast", True):
        target_url = str(project.target_url or "").strip()
        if not target_url:
            raise HTTPException(
                400,
                "DAST is enabled but project target_url is empty. "
                "Set a public target URL on the project before starting this scan.",
            )
        is_valid_url, url_err = validate_external_target_url(target_url)
        if not is_valid_url:
            raise HTTPException(400, f"Invalid project target URL: {url_err}")

    await ensure_project_artifacts_from_project_config(db, project)

    # Create scan record
    explicit_module_keys = set((scan_in.modules_enabled or {}).keys())
    normalized_scan_config = _normalize_scan_config(
        scan_in.scan_config,
        scan_in.scan_type,
        modules_enabled,
    )

    llm_goal_client = None
    llm_goal_cfg = await resolve_llm_provider_config_async(
        db,
        project=project,
        scan_config=normalized_scan_config,
        user_id=current_user.id,
    )
    if llm_goal_cfg.get("enabled") and str(llm_goal_cfg.get("api_key", "") or "").strip():
        llm_goal_client = LLMClient(
            enabled=True,
            provider=str(llm_goal_cfg.get("provider", "")),
            model=str(llm_goal_cfg.get("model", "")),
            api_key=str(llm_goal_cfg.get("api_key", "")),
        )

    plan_intent_model = await compile_goals_to_intent(
        goals=scan_in.scan_goals,
        scan_context={
            "scan_type": scan_in.scan_type,
            "framework": project.framework,
            "target_url": project.target_url,
            "modules_enabled": modules_enabled,
            "scan_config": normalized_scan_config,
        },
        llm_client=llm_goal_client,
    )
    plan_intent = plan_intent_model.model_dump()

    # Apply plan intent (bounded updates only)
    for mod_key, mod_value in (plan_intent.get("modules_focus") or {}).items():
        if mod_key in modules_enabled and mod_key not in explicit_module_keys:
            modules_enabled[mod_key] = bool(mod_value)

    suggested_cfg = plan_intent.get("suggested_scan_config") or {}
    bounded_updates = {
        k: v
        for k, v in suggested_cfg.items()
        if k in {
            "scan_depth",
            "timeout",
            "max_children",
            "ajax_spider",
            "inscope_only",
            "adaptive_timeout",
            "context_aware_payloads",
        }
    }
    if bounded_updates:
        # Reuse existing normalizer logic by patching and re-normalizing.
        merged = dict(normalized_scan_config)
        merged.update(bounded_updates)
        normalized_scan_config = _normalize_scan_config(
            merged,
            scan_in.scan_type,
            modules_enabled,
        )

    if plan_intent.get("priorities") and not normalized_scan_config.get("llm_prioritized_vuln_types"):
        normalized_scan_config["llm_prioritized_vuln_types"] = list(plan_intent.get("priorities") or [])
    if plan_intent.get("route_keywords"):
        normalized_scan_config["plan_route_keywords"] = list(plan_intent.get("route_keywords") or [])
    if plan_intent.get("role_focus") and scan_in.auth_config:
        auth_cfg = dict(scan_in.auth_config)
        if "roles" not in auth_cfg or not auth_cfg.get("roles"):
            auth_cfg["roles"] = list(plan_intent.get("role_focus") or [])
        scan_auth_config = auth_cfg
    else:
        scan_auth_config = scan_in.auth_config

    if bool(normalized_scan_config.get("llm_planner_enabled", False)):
        # Resolve LLM config from database or environment
        # Auto-enables if any provider is configured in database
        llm_cfg = await resolve_llm_provider_config_async(
            db,
            project=project,
            scan_config=normalized_scan_config,
            user_id=current_user.id,
        )

        # Check if LLM is actually available (either env enabled or DB provider configured)
        if not llm_cfg.get("enabled"):
            raise HTTPException(
                400,
                "LLM planner enabled but no LLM provider is configured. "
                "Go to Dashboard → Settings → LLM Providers and connect a provider (OpenAI, Anthropic, etc).",
            )
        provider = normalize_provider(normalized_scan_config.get("llm_provider")) or str(
            llm_cfg.get("provider", "") or ""
        )
        if not provider:
            raise HTTPException(
                400,
                "LLM planner enabled: please select a provider from connected LLM tools",
            )
        normalized_scan_config["llm_provider"] = provider

        model = (
            str(normalized_scan_config.get("llm_model", "") or "").strip()
            or str(llm_cfg.get("model", "") or "").strip()
            or get_default_model(provider)
        )
        allowed_models = get_provider_models(provider)
        if model not in allowed_models:
            raise HTTPException(
                400,
                f"Unsupported model '{model}' for provider '{provider}'",
            )
        normalized_scan_config["llm_model"] = model

        if not str(llm_cfg.get("api_key", "") or "").strip():
            raise HTTPException(
                400,
                f"Provider '{provider}' is not connected. Connect it in Tools -> LLM.",
            )

        normalized_scan_config["llm_api_key_encrypted"] = encrypt_token(
            str(llm_cfg.get("api_key", ""))
        )

    # Ensure configured workflow artifacts are parsed and normalized.
    artifact_specs = [
        ("openapi", normalized_scan_config.get("openapi_spec_file", [])),
        ("postman", normalized_scan_config.get("postman_collection_file", [])),
        ("journey", normalized_scan_config.get("journey_replay_files", [])),
    ]
    for kind, files in artifact_specs:
        if not isinstance(files, list):
            continue
        for rel_path in files:
            rel_path = str(rel_path).strip()
            if not rel_path:
                continue
            existing = await db.execute(
                select(ProjectArtifact).where(
                    ProjectArtifact.project_id == project.id,
                    ProjectArtifact.kind == kind,
                    ProjectArtifact.source_path == rel_path,
                    ProjectArtifact.parse_status == "ready",
                )
            )
            if existing.scalar_one_or_none():
                continue
            try:
                await ingest_artifact_file(db, project, kind=kind, source_path=rel_path)
            except Exception as exc:
                _logger.exception(f"Failed to parse {kind} artifact '{rel_path}'")
                raise HTTPException(
                    400,
                    f"Failed to parse {kind} artifact '{rel_path}': {exc}",
                ) from exc

    # Inherit project-level findings upload if no explicit scan-level path set
    if (
        not normalized_scan_config.get("external_findings_path")
        and getattr(project, "external_findings_path", "")
    ):
        normalized_scan_config["external_findings_path"] = project.external_findings_path
        normalized_scan_config["external_findings_format"] = project.external_findings_format

    scan = Scan(
        project_id=scan_in.project_id,
        scan_type=scan_in.scan_type,
        scan_mode=scan_mode,
        modules_enabled=modules_enabled,
        auth_config=scan_auth_config,
        scan_goals=[g.strip() for g in scan_in.scan_goals if g and g.strip()],
        plan_intent=plan_intent,
        scan_config=normalized_scan_config,
        status="pending",
        cp_job_id=cp_bridge_job_id,
        cp_callback_url=cp_bridge_callback_url,
        cp_nonce=cp_bridge_nonce,
    )
    db.add(scan)
    await db.flush()
    await db.refresh(scan)

    scan_id = scan.id
    project_id = project.id
    response = ScanResponse(**scan.to_dict())

    # Commit now so the background task can see the scan record
    # in its own independent database session
    await db.commit()

    # Launch scan as a fire-and-forget asyncio task on the running
    # event loop.  FastAPI's BackgroundTasks mechanism silently drops
    # async coroutines in some deployment configurations, so we use
    # asyncio.create_task() which is reliable in all cases.
    enqueued = await _dispatch_scan_job({
        "kind": "scan",
        "scan_id": scan_id,
        "project_id": project_id,
    })
    if not enqueued:
        if _queue.enabled and not settings.SCAN_QUEUE_FAIL_OPEN:
            async with async_session_factory() as qdb:
                qres = await qdb.execute(select(Scan).where(Scan.id == scan_id))
                qscan = qres.scalar_one_or_none()
                if qscan and qscan.status in ("pending", "running"):
                    qscan.status = "failed"
                    qscan.error_message = "Queue dispatch failed in strict queue mode"
                    qscan.completed_at = _utcnow_naive()
                    await qdb.commit()
            raise HTTPException(503, "Scan queue unavailable; please retry")
        task = asyncio.create_task(_run_scan_pipeline(scan_id, project_id))
        with _scan_tasks_lock:
            _scan_tasks[scan_id] = task

    return response


@router.post("/{scan_id}/upload-findings")
async def upload_external_findings(
    scan_id: str,
    file: UploadFile = File(...),
    project_id: str = Form(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Upload external SAST findings JSON for a scan (black-box mode)."""
    if not file.filename:
        raise HTTPException(400, "No file provided")

    # Reject files larger than 50 MB
    MAX_UPLOAD_BYTES = 50 * 1024 * 1024
    content = await file.read()
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            413,
            f"File too large ({len(content) / 1024 / 1024:.1f} MB). "
            f"Maximum is {MAX_UPLOAD_BYTES / 1024 / 1024:.0f} MB.",
        )

    try:
        json.loads(content)
    except json.JSONDecodeError:
        raise HTTPException(400, "Invalid JSON file")

    from app.models.scan import Scan
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Scan not found")

    uploads_dir = Path(settings.UPLOADS_DIR) / scan_id
    uploads_dir.mkdir(parents=True, exist_ok=True)
    dest = uploads_dir / "external_findings.json"
    dest.write_bytes(content)

    from app.scanners.external_importer import ExternalFindingImporter
    importer = ExternalFindingImporter()
    data = json.loads(content)
    fmt = importer.detect_format(data)
    sample = importer.import_findings(data, format=fmt)

    # Persist the path and format back to the scan's config so the
    # orchestrator can find the file when the pipeline runs.
    scan_config = dict(scan.scan_config or {})
    scan_config["external_findings_path"] = str(dest)
    scan_config["external_findings_format"] = fmt
    scan.scan_config = scan_config
    await db.commit()

    return {
        "path": str(dest),
        "format": fmt,
        "finding_count": len(sample),
    }


async def _dispatch_scan_job(payload: dict) -> bool:
    """Dispatch a scan job to queue backend when enabled."""
    if not _queue.enabled:
        return False
    ok = await _queue.enqueue(payload)
    if not ok:
        _logger.error("Queue dispatch failed for payload kind=%s", payload.get("kind"))
    return ok


async def _scan_queue_worker_loop() -> None:
    """Continuously poll SQS and execute scan jobs in this worker."""
    while True:
        jobs = await _queue.poll(wait_seconds=10, max_messages=1)
        if not jobs:
            await asyncio.sleep(0.25)
            continue

        for job in jobs:
            try:
                await _process_queue_job(job.payload)
                await _queue.ack(job.receipt_handle)
            except Exception:
                _logger.exception("Queue job failed (message_id=%s)", job.message_id)


async def _process_queue_job(payload: dict) -> None:
    kind = str((payload or {}).get("kind", "")).strip().lower()
    if kind == "scan":
        scan_id = str(payload.get("scan_id", "") or "").strip()
        project_id = str(payload.get("project_id", "") or "").strip()
        if scan_id and project_id:
            await _run_scan_pipeline(scan_id, project_id)
        return


@router.get("")
async def list_scans(
    project_id: str | None = None,
    status: str | None = None,
    page: int = 1,
    page_size: int = 50,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List scans with pagination, optionally filtered by project or status."""
    from sqlalchemy import func, join

    # Build base filter — always scope to projects the current user owns
    owner_filter = (
        None if current_user.is_admin
        else (Project.owner_id == current_user.id)
    )

    base_filter = select(Scan).join(Project, Scan.project_id == Project.id)
    count_filter = select(func.count(Scan.id)).join(Project, Scan.project_id == Project.id)

    if owner_filter is not None:
        base_filter = base_filter.where(owner_filter)
        count_filter = count_filter.where(owner_filter)

    if project_id:
        base_filter = base_filter.where(Scan.project_id == project_id)
        count_filter = count_filter.where(Scan.project_id == project_id)
    if status:
        base_filter = base_filter.where(Scan.status == status)
        count_filter = count_filter.where(Scan.status == status)

    # Count total
    count_result = await db.execute(count_filter)
    total = count_result.scalar() or 0
    pages = max(1, (total + page_size - 1) // page_size)

    # Fetch page
    offset = (page - 1) * page_size
    result = await db.execute(
        base_filter.order_by(Scan.created_at.desc()).offset(offset).limit(page_size)
    )
    scans = result.scalars().all()

    # Add project_name via lookup
    scan_dicts = []
    project_names: dict[str, str] = {}
    for s in scans:
        d = s.to_dict()
        d.pop("log", None)
        pid = d["project_id"]
        if pid not in project_names:
            p_result = await db.execute(select(Project).where(Project.id == pid))
            p = p_result.scalar_one_or_none()
            project_names[pid] = p.name if p else pid[:8]
        d["project_name"] = project_names[pid]
        scan_dicts.append(d)

    return {
        "items": scan_dicts,
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
    }


@router.get("/{scan_id}", response_model=ScanResponse)
async def get_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get scan details."""
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if proj and proj.owner_id and proj.owner_id != current_user.id:
            raise HTTPException(404, "Scan not found")
    return ScanResponse(**scan.to_dict())


@router.post("/{scan_id}/cancel")
async def cancel_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Cancel a running scan."""
    scan_result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = scan_result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Scan not found")
    result = await _do_cancel_scan(scan_id, db)
    return result


async def _do_cancel_scan(scan_id: str, db: AsyncSession) -> dict:
    """Cancel a running scan (callable from both REST and WebSocket)."""
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    if scan.status not in ("pending", "running"):
        raise HTTPException(400, f"Cannot cancel scan in '{scan.status}' state")

    scan.status = "cancelled"
    scan.completed_at = _utcnow_naive()
    await db.flush()
    await db.commit()

    with _scan_tasks_lock:
        task = _scan_tasks.get(scan_id)
    if task and not task.done():
        task.cancel()

    await ws_manager.send_scan_progress(scan_id, {
        "status": "cancelled",
        "progress": scan.progress,
        "phase": scan.current_phase,
    })

    return {"status": "cancelled", "id": scan_id}


@router.get("/{scan_id}/routes")
async def get_scan_routes(
    scan_id: str,
    page: int = 1,
    page_size: int = 500,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get discovered routes for a scan."""
    result = await db.execute(select(Scan).where(Scan.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")
    if not current_user.is_admin:
        proj_result = await db.execute(select(Project).where(Project.id == scan.project_id))
        proj = proj_result.scalar_one_or_none()
        if not proj or proj.owner_id != current_user.id:
            raise HTTPException(404, "Scan not found")

    # Prefer persisted routes discovered during this scan run.
    scan_cfg = scan.scan_config or {}
    persisted_routes = scan_cfg.get("discovered_routes")

    if isinstance(persisted_routes, list) and persisted_routes:
        routes = persisted_routes
    else:
        routes = []

        # Fallback to source extraction if scan-specific routes are unavailable.
        project_result = await db.execute(
            select(Project).where(Project.id == scan.project_id)
        )
        project = project_result.scalar_one_or_none()
        if not project or not project.local_path:
            return {
                "items": [],
                "total": 0,
                "page": page,
                "page_size": page_size,
                "pages": 1,
            }

        from app.analyzers.route_extractor import RouteExtractor

        extractor = RouteExtractor()
        try:
            routes = await extractor.extract_routes(project.local_path)
        except Exception:
            _logger.exception("Failed to extract routes for project %s", project.id)
            routes = []

        if not routes:
            return {
                "items": [],
                "total": 0,
                "page": page,
                "page_size": page_size,
                "pages": 1,
            }

    if isinstance(scan.scan_config, dict):
        discovered_routes = scan.scan_config.get("discovered_routes", [])
        if routes and routes is not discovered_routes:
            updated_cfg = dict(scan.scan_config)
            updated_cfg["discovered_routes"] = routes
            scan.scan_config = updated_cfg
            await db.flush()
            await db.commit()

    from app.models.finding import Finding
    findings_result = await db.execute(select(Finding).where(Finding.scan_id == scan_id))
    findings = findings_result.scalars().all()
    
    endpoint_counts = {}
    for f in findings:
        if getattr(f, "endpoint", None):
            ep = f.endpoint.split('?')[0].rstrip('/')
            if not ep.startswith('/'):
                ep = '/' + ep
            endpoint_counts[ep] = endpoint_counts.get(ep, 0) + 1

    modules = scan.modules_enabled or {}
    dast_enabled = modules.get("dast", True)
    dast_finished = scan.status in ("completed", "failed", "cancelled")
    dast_ran = dast_enabled and dast_finished

    for r in routes:
        path = r.get("path", "").rstrip('/')
        if not path.startswith('/'):
            path = '/' + path
            
        count = 0
        for ep, cnt in endpoint_counts.items():
            if path == ep or (path and ep.endswith(path)):
                count += cnt

        tested = bool(r.get("tested", False))
        if count > 0:
            tested = True
        elif not dast_ran:
            tested = False

        r["tested"] = tested
        r["finding_count"] = count
        r.setdefault("handler", "")

    total = len(routes)
    pages = max(1, (total + page_size - 1) // page_size)
    offset = (page - 1) * page_size
    page_routes = routes[offset:offset + page_size]

    return {
        "items": page_routes,
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
    }


# --- Background Task ---

_logger = logging.getLogger(__name__)

_SCAN_RETRY_LIMIT = 2
_SCAN_RETRY_BACKOFF_SECONDS = 0.5


async def _run_with_retries(coro_factory, *, scan_id: str, label: str):
    """Run an async operation with bounded retries and backoff."""
    last_exc: Exception | None = None
    for attempt in range(1, _SCAN_RETRY_LIMIT + 1):
        try:
            return await coro_factory()
        except Exception as exc:
            last_exc = exc
            _logger.warning(
                "%s failed for scan %s (attempt %d/%d): %s",
                label,
                scan_id,
                attempt,
                _SCAN_RETRY_LIMIT,
                exc,
            )
            if attempt < _SCAN_RETRY_LIMIT:
                await asyncio.sleep(_SCAN_RETRY_BACKOFF_SECONDS * attempt)
    if last_exc:
        raise last_exc
    return None


async def _run_scan_pipeline(scan_id: str, project_id: str, ephemeral_auth_config: dict | None = None):
    """Execute the full scan pipeline in background.

    Runs in its own asyncio task with an independent DB session so it is
    completely decoupled from the originating HTTP request lifecycle.
    """
    from app.core.database import async_session_factory
    from app.core.orchestrator import ScanOrchestrator

    _logger.info("Scan pipeline started for scan=%s project=%s", scan_id, project_id)

    scan: Scan | None = None
    async with async_session_factory() as db:
        try:
            result = await db.execute(select(Scan).where(Scan.id == scan_id))
            scan = result.scalar_one_or_none()
            if not scan:
                _logger.error("Scan %s not found in database", scan_id)
                await ws_manager.send_scan_progress(scan_id, {
                    "status": "failed",
                    "progress": 0,
                    "error": "Scan record not found in database",
                })
                return

            result = await db.execute(select(Project).where(Project.id == project_id))
            project = result.scalar_one_or_none()
            if not project:
                _logger.error("Project %s not found for scan %s", project_id, scan_id)
                scan.status = "failed"
                scan.error_message = "Associated project not found"
                scan.completed_at = _utcnow_naive()
                await db.commit()
                await ws_manager.send_scan_progress(scan_id, {
                    "status": "failed",
                    "progress": 0,
                    "error": "Associated project not found",
                })
                return

            # Respect cancellation requested before background worker starts.
            if scan.status == "cancelled":
                _logger.info("Scan %s was cancelled before execution started", scan_id)
                return

            scan.status = "running"
            scan.started_at = _utcnow_naive()
            await db.commit()

            # CP embedded-app: tell the CP the scan has started (§13.7).
            if scan.cp_callback_url and scan.cp_nonce:
                from app.core import cp_callback
                asyncio.create_task(
                    cp_callback.post_running(scan.cp_callback_url, scan.cp_nonce)
                )

            await ws_manager.send_scan_progress(scan_id, {
                "status": "running",
                "progress": 0,
                "phase": "initializing",
            })

            _logger.info("Scan %s running — launching orchestrator", scan_id)
            orchestrator = ScanOrchestrator(
                scan, project, db, ws_manager, ephemeral_auth_config=ephemeral_auth_config
            )
            await _run_with_retries(
                lambda: orchestrator.run(),
                scan_id=scan_id,
                label="orchestrator.run",
            )
            _logger.info("Scan %s finished with status=%s", scan_id, scan.status)

        except asyncio.CancelledError:
            _logger.info("Scan %s task cancelled", scan_id)
            progress = getattr(scan, "progress", 0)
            phase = getattr(scan, "current_phase", "")
            try:
                await db.rollback()
            except Exception:
                _logger.debug("Rollback after cancellation failed for scan %s", scan_id, exc_info=True)

            try:
                refreshed_scan = await db.get(Scan, scan_id)
                if refreshed_scan is not None:
                    refreshed_scan.status = "cancelled"
                    refreshed_scan.completed_at = _utcnow_naive()
                    await db.commit()
                    progress = refreshed_scan.progress
                    phase = refreshed_scan.current_phase
            except Exception:
                _logger.exception("Failed to persist cancelled status for scan %s", scan_id)

            await ws_manager.send_scan_progress(scan_id, {
                "status": "cancelled",
                "progress": progress,
                "phase": phase,
            })

        except Exception as e:
            _logger.exception("Scan %s failed with exception", scan_id)
            progress = getattr(scan, "progress", 0)
            try:
                await db.rollback()
            except Exception:
                _logger.debug("Rollback after scan exception failed for scan %s", scan_id, exc_info=True)

            try:
                refreshed_scan = await db.get(Scan, scan_id)
                if refreshed_scan is not None:
                    if refreshed_scan.status == "cancelled":
                        _logger.info("Scan %s exception after cancellation; preserving cancelled status", scan_id)
                        return
                    refreshed_scan.status = "failed"
                    refreshed_scan.error_message = str(e)
                    refreshed_scan.completed_at = _utcnow_naive()
                    await db.commit()
                    progress = refreshed_scan.progress
            except Exception:
                _logger.exception("Failed to update scan %s status after error", scan_id)

            await ws_manager.send_scan_progress(scan_id, {
                "status": "failed",
                "progress": progress,
                "error": str(e),
            })
        finally:
            with _scan_tasks_lock:
                _scan_tasks.pop(scan_id, None)

    # CP bridge callback for embedded-app scans
    if scan and scan.cp_callback_url and scan.cp_nonce:
        from app.core import cp_callback
        final_status = scan.status
        if final_status == "completed":
            summary = scan.results_summary or {}
            async def _cb():
                view_secret = secrets.token_urlsafe(32)
                await cp_callback.post_completed(scan.cp_callback_url, scan.cp_nonce, view_secret, summary)
        else:
            msg = scan.error_message or "Scan failed"
            async def _cb():
                await cp_callback.post_failed(scan.cp_callback_url, scan.cp_nonce, msg)
        asyncio.create_task(_cb())
