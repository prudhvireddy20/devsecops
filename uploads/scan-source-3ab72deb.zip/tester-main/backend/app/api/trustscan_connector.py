"""TrustScan Platform OAuth integration endpoints."""
from __future__ import annotations

import asyncio
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import require_api_key, get_current_user
from app.models.user import User
from app.core.config import settings
from app.core.database import get_db
from app.core.security import decrypt_token, encrypt_token
from app.integrations.trustscan_client import TrustScanClient
from app.models.project import Project
from app.models.scan import Scan
from app.models.finding import Finding
from app.scanners.external_importer import ExternalFindingImporter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/trustscan", tags=["trustscan"])

_OAUTH_STATE_TTL_SECONDS = 300  # 5 minutes
_OAUTH_STATES: dict[str, dict[str, Any]] = {}


class OAuthInitiateRequest(BaseModel):
    pass  # No project_id needed — OAuth happens before project creation


class OAuthStatusResponse(BaseModel):
    status: str  # pending|completed|failed
    error: str | None = None
    token: str | None = None
    base_url: str | None = None


class JobsListResponse(BaseModel):
    jobs: list[dict[str, Any]]


class ImportRequest(BaseModel):
    job_id: str
    target_url: str = ""
    scan_mode: str = "whitebox"


class ImportResponse(BaseModel):
    scan_id: str
    findings_imported: int


def _cleanup_expired_oauth_states() -> None:
    """Remove expired OAuth states (TTL exceeded)."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    expired = [s for s, data in _OAUTH_STATES.items() if data.get("expires_at", now) < now]
    for s in expired:
        del _OAUTH_STATES[s]


@router.post("/oauth/initiate", response_model=dict[str, str])
async def oauth_initiate(
    _: str = Depends(require_api_key),
) -> dict[str, str]:
    """Initiate OAuth flow with TrustScan Platform.

    Does NOT require a project — OAuth happens before project creation.
    Returns a state token and authorization URL to open in a popup.
    """
    _cleanup_expired_oauth_states()

    if not settings.TRUSTSCAN_PLATFORM_URL:
        raise HTTPException(
            status_code=503,
            detail="TrustScan Platform URL not configured. Set TRUSTSCAN_PLATFORM_URL env var.",
        )

    state = str(uuid.uuid4())
    expires_at = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(seconds=_OAUTH_STATE_TTL_SECONDS)

    _OAUTH_STATES[state] = {
        "base_url": settings.TRUSTSCAN_PLATFORM_URL.rstrip("/"),
        "status": "pending",
        "expires_at": expires_at,
    }

    callback_url = f"{settings.TRACEON_BASE_URL.rstrip('/')}/api/v1/trustscan/oauth/callback"
    authorize_url = (
        f"{settings.TRUSTSCAN_PLATFORM_URL.rstrip('/')}/api/auth/traceon-authorize"
        f"?state={state}&redirect_uri={callback_url}"
    )

    return {
        "state": state,
        "authorize_url": authorize_url,
    }


@router.get("/oauth/callback")
async def oauth_callback(
    code: str = Query(...),
    state: str = Query(...),
    error: str | None = Query(None),
) -> HTMLResponse:
    """OAuth callback — exchanges auth code for token and stores it in memory.

    No project needed here. Token is retrieved later via /oauth/status/{state}.
    """
    _cleanup_expired_oauth_states()

    if error:
        logger.warning("TrustScan OAuth error: %s", error)
        return HTMLResponse(
            f"<html><body>Authorization denied: {error}. You can close this window.</body></html>",
            status_code=403,
        )

    oauth_state = _OAUTH_STATES.get(state)
    if not oauth_state:
        logger.warning("Invalid or expired OAuth state: %s", state)
        return HTMLResponse(
            "<html><body>Authorization failed: invalid or expired state. Please try again.</body></html>",
            status_code=400,
        )

    base_url = oauth_state.get("base_url", "").rstrip("/")

    try:
        async with httpx.AsyncClient(timeout=settings.TRUSTSCAN_TIMEOUT_SECONDS) as client:
            token_resp = await client.post(
                f"{base_url}/api/auth/token",
                json={"code": code},
            )
            token_resp.raise_for_status()
            token_data = token_resp.json()

        pat_token = token_data.get("token", "")
        if not pat_token:
            raise ValueError("No token in response from TrustScan")

        # Store token in memory — frontend retrieves via /oauth/status/{state}
        _OAUTH_STATES[state]["status"] = "completed"
        _OAUTH_STATES[state]["token"] = pat_token
        _OAUTH_STATES[state]["base_url"] = base_url

        logger.info("TrustScan OAuth completed, state=%s", state)

        return HTMLResponse(
            "<html><body>Authorization successful! You can close this window.</body>"
            "<script>window.close();</script></html>"
        )

    except Exception as e:
        logger.error("Failed to exchange TrustScan auth code: %s", e)
        _OAUTH_STATES[state]["status"] = "failed"
        _OAUTH_STATES[state]["error"] = str(e)

        return HTMLResponse(
            f"<html><body>Authorization failed: {str(e)}</body></html>",
            status_code=500,
        )


@router.get("/oauth/status/{state}", response_model=OAuthStatusResponse)
async def oauth_status(state: str) -> OAuthStatusResponse:
    """Poll the status of an OAuth flow.

    When status is 'completed', also returns the token and base_url
    so the frontend can list jobs and create the project.
    """
    _cleanup_expired_oauth_states()

    oauth_state = _OAUTH_STATES.get(state)
    if not oauth_state:
        return OAuthStatusResponse(status="failed", error="State not found or expired")

    status = oauth_state.get("status", "pending")
    error = oauth_state.get("error")

    if status == "completed":
        return OAuthStatusResponse(
            status=status,
            token=oauth_state.get("token"),
            base_url=oauth_state.get("base_url"),
        )

    return OAuthStatusResponse(status=status, error=error)


@router.get("/oauth/jobs", response_model=JobsListResponse)
async def list_jobs_by_state(
    state: str = Query(..., description="OAuth state from /oauth/initiate"),
    _: str = Depends(require_api_key),
) -> JobsListResponse:
    """List scan jobs using a temporary OAuth token (before project creation)."""
    _cleanup_expired_oauth_states()

    oauth_state = _OAUTH_STATES.get(state)
    if not oauth_state or oauth_state.get("status") != "completed":
        raise HTTPException(status_code=400, detail="OAuth state not found or not completed")

    token = oauth_state.get("token", "")
    base_url = oauth_state.get("base_url", "")

    if not token or not base_url:
        raise HTTPException(status_code=400, detail="No token available for this state")

    try:
        async with TrustScanClient(base_url, token, settings.TRUSTSCAN_TIMEOUT_SECONDS) as client:
            jobs = await client.list_jobs(limit=50)
        return JobsListResponse(jobs=jobs)
    except Exception as e:
        logger.error("Failed to list TrustScan jobs: %s", e)
        raise HTTPException(status_code=502, detail=f"Failed to fetch jobs: {str(e)}")


@router.get("/projects/{project_id}/jobs", response_model=JobsListResponse)
async def list_trustscan_jobs(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> JobsListResponse:
    """List scan jobs for an existing project that is already connected."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(status_code=404, detail="Project not found")

    if not project.trustscan_token_encrypted or not project.trustscan_url:
        raise HTTPException(
            status_code=400,
            detail="Project not connected to TrustScan Platform",
        )

    try:
        token = decrypt_token(project.trustscan_token_encrypted)
        if not token:
            raise ValueError("Could not decrypt token")

        async with TrustScanClient(project.trustscan_url, token, settings.TRUSTSCAN_TIMEOUT_SECONDS) as client:
            jobs = await client.list_jobs(limit=50)

        return JobsListResponse(jobs=jobs)

    except Exception as e:
        logger.error("Failed to list TrustScan jobs: %s", e)
        raise HTTPException(status_code=502, detail=f"Failed to fetch jobs: {str(e)}")


@router.post("/projects/{project_id}/import", response_model=ImportResponse)
async def import_trustscan_job(
    project_id: str,
    req: ImportRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ImportResponse:
    """Import a scan job from TrustScan Platform into an existing project."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(status_code=404, detail="Project not found")

    if not project.trustscan_token_encrypted or not project.trustscan_url:
        raise HTTPException(
            status_code=400,
            detail="Project not connected to TrustScan Platform",
        )

    try:
        token = decrypt_token(project.trustscan_token_encrypted)
        if not token:
            raise ValueError("Could not decrypt token")

        async with TrustScanClient(
            project.trustscan_url, token, settings.TRUSTSCAN_TIMEOUT_SECONDS
        ) as client:
            job = await client.get_job(req.job_id)
            if not job:
                raise ValueError(f"Job {req.job_id} not found")

            findings_data = await client.get_findings(req.job_id)
            if not findings_data:
                raise ValueError("Could not fetch findings")

        project.scan_mode = req.scan_mode
        if req.target_url:
            project.target_url = req.target_url

        scan = Scan(
            id=str(uuid.uuid4()),
            project_id=project_id,
            status="pending",
            scan_type="full",
            progress=0,
            current_phase="import",
            modules_enabled={
                "dast": req.scan_mode != "blackbox",
                "nuclei": True,
                "coverage": False,
            },
            created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        )

        db.add(scan)
        await db.flush()

        importer = ExternalFindingImporter()
        parsed_findings = importer.import_findings(
            findings_data,
            format="trustscan",
            auto_detect=False,
        )

        findings_created = 0
        for parsed in parsed_findings:
            try:
                finding = Finding(
                    id=str(uuid.uuid4()),
                    scan_id=scan.id,
                    title=parsed.get("title", ""),
                    vulnerability_type=parsed.get("vulnerability_type", "unknown"),
                    severity=parsed.get("severity", "medium"),
                    confidence=parsed.get("confidence", "observed"),
                    cwe=parsed.get("cwe", ""),
                    endpoint=parsed.get("endpoint", ""),
                    http_method="",
                    parameter=parsed.get("parameter", ""),
                    file_path=parsed.get("file_path", ""),
                    line_number=parsed.get("line_number", 0),
                    code_snippet=parsed.get("code_snippet", ""),
                    payload="",
                    response_code=0,
                    response_evidence="",
                    auth_role="",
                    scanner_source="trustscan",
                    scanner_rule_id=parsed.get("rule_id", ""),
                    raw_scanner_output=parsed.get("raw", {}),
                    remediation_text=parsed.get("remediation", ""),
                    status="open",
                    created_at=datetime.now(timezone.utc).replace(tzinfo=None),
                )
                db.add(finding)
                findings_created += 1
            except Exception as e:
                logger.warning("Failed to create finding: %s", e)
                continue

        await db.flush()
        await db.commit()

        logger.info(
            "Imported TrustScan job %s: %d findings",
            req.job_id,
            findings_created,
        )

        return ImportResponse(
            scan_id=scan.id,
            findings_imported=findings_created,
        )

    except Exception as e:
        logger.error("Failed to import TrustScan job: %s", e)
        raise HTTPException(status_code=502, detail=f"Import failed: {str(e)}")


@router.delete("/projects/{project_id}/connect")
async def disconnect_trustscan(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    """Disconnect project from TrustScan Platform."""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project or (not current_user.is_admin and project.owner_id != current_user.id):
        raise HTTPException(status_code=404, detail="Project not found")

    project.trustscan_url = ""
    project.trustscan_token_encrypted = ""
    await db.flush()
    await db.commit()

    logger.info("Disconnected project %s from TrustScan", project_id)

    return {"status": "disconnected"}
