"""User management API endpoints."""
import secrets
import uuid
from hashlib import sha256

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import get_current_user
from app.core.database import get_db
from app.models.user import User

router = APIRouter(prefix="/users", tags=["users"])


class UserCreateRequest(BaseModel):
    label: str


def _hash_key(key: str) -> str:
    return sha256(key.encode()).hexdigest()


@router.get("/me")
async def get_me(user: User = Depends(get_current_user)):
    """Return the current authenticated user's profile (no raw key exposed).

    For CP embedded-app sessions, also surface the CP identity (email, org) so
    the frontend can show the signed-in user in the dashboard.
    """
    data = user.to_dict()
    cp_email = getattr(user, "cp_email", "") or ""
    cp_org_id = getattr(user, "cp_org_id", "") or ""
    cp_sub = getattr(user, "cp_sub", "") or ""
    if cp_sub:
        data["cp_sub"] = cp_sub
        data["cp_email"] = cp_email
        data["cp_org_id"] = cp_org_id
    return data


@router.post("/admin/users")
async def create_user(
    body: UserCreateRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a new user and return their API key (shown once, never again).

    Admin-only. The raw key is returned only at creation time.
    """
    if not user.is_admin:
        raise HTTPException(403, "Admin access required")

    raw_key = secrets.token_urlsafe(32)
    new_user = User(
        id=str(uuid.uuid4()),
        api_key_hash=_hash_key(raw_key),
        label=(body.label or "").strip(),
        is_active=True,
        is_admin=False,
    )
    db.add(new_user)
    await db.flush()
    await db.commit()

    result = new_user.to_dict()
    result["api_key"] = raw_key  # returned once only
    return result


@router.get("/admin/users")
async def list_users(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """List all users (admin only)."""
    if not user.is_admin:
        raise HTTPException(403, "Admin access required")

    result = await db.execute(select(User).order_by(User.created_at))
    users = result.scalars().all()
    return {"items": [u.to_dict() for u in users], "total": len(users)}


@router.delete("/admin/users/{user_id}")
async def deactivate_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Deactivate a user (revokes their API key). Admin only."""
    if not user.is_admin:
        raise HTTPException(403, "Admin access required")
    if user_id == user.id:
        raise HTTPException(400, "Cannot deactivate yourself")

    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(404, "User not found")

    target.is_active = False
    await db.flush()
    await db.commit()
    return {"id": user_id, "is_active": False}
