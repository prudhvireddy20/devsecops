"""WebSocket manager for real-time scan updates."""
import asyncio
import json
import logging
from typing import Dict, Set

from fastapi import WebSocket
from sqlalchemy.exc import OperationalError

from app.core.database import async_session_factory
from app.models.scan import Scan
from sqlalchemy import select

logger = logging.getLogger(__name__)

_SQLITE_LOCK_RETRIES = 5
_SQLITE_LOCK_BACKOFF_SECONDS = 0.1
_LOG_FLUSH_INTERVAL_SECONDS = 0.75
_MAX_LOG_LINES = 1000


def _is_sqlite_locked_error(exc: Exception) -> bool:
    return "database is locked" in str(exc).lower()


class ConnectionManager:
    """Manages WebSocket connections and broadcasts scan progress."""

    def __init__(self):
        # scan_id -> set of connected websockets
        self._connections: Dict[str, Set[WebSocket]] = {}
        # Global connections (dashboard updates)
        self._global_connections: Set[WebSocket] = set()
        # Lock for concurrent access to connection sets
        self._lock = asyncio.Lock()
        # Buffered scan log lines (scan_id -> lines)
        self._scan_log_buffers: Dict[str, list[str]] = {}
        # Pending flush task per scan_id
        self._scan_log_flush_tasks: Dict[str, asyncio.Task] = {}

    async def connect(self, websocket: WebSocket, scan_id: str | None = None):
        """Accept a WebSocket connection and register it."""
        await websocket.accept()
        async with self._lock:
            if scan_id is not None:
                if scan_id not in self._connections:
                    self._connections[scan_id] = set()
                self._connections[scan_id].add(websocket)
            else:
                self._global_connections.add(websocket)

    async def disconnect(self, websocket: WebSocket, scan_id: str | None = None):
        """Remove a WebSocket connection."""
        async with self._lock:
            if scan_id is not None and scan_id in self._connections:
                self._connections[scan_id].discard(websocket)
                if not self._connections[scan_id]:
                    del self._connections[scan_id]
            # Always try to remove from global too, in case scan_id was not
            # provided or the socket was registered globally
            self._global_connections.discard(websocket)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_scan_connections(self, scan_id: str) -> set[WebSocket]:
        """Return a snapshot (copy) of connections for *scan_id*.

        Taking a snapshot under the lock prevents ``RuntimeError: Set
        changed size during iteration`` when a concurrent connect/disconnect
        mutates the underlying set.
        """
        async with self._lock:
            conns = self._connections.get(scan_id)
            return set(conns) if conns else set()

    async def _get_global_connections(self) -> set[WebSocket]:
        """Return a snapshot of global (dashboard) connections."""
        async with self._lock:
            return set(self._global_connections)

    async def _send_to(self, connections: set[WebSocket], message: str, scan_id: str | None = None):
        """Send *message* to a set of websockets, removing dead ones.

        Uses bounded retries to absorb transient send failures.
        """
        dead: set[WebSocket] = set()
        for ws in connections:
            delivered = False
            for attempt in range(1, 4):
                try:
                    await ws.send_text(message)
                    delivered = True
                    break
                except Exception:
                    if attempt < 3:
                        await asyncio.sleep(0.05 * attempt)
                        continue
                    dead.add(ws)
            if not delivered and ws not in dead:
                dead.add(ws)
        if dead:
            async with self._lock:
                for ws in dead:
                    if scan_id is not None and scan_id in self._connections:
                        self._connections[scan_id].discard(ws)
                    self._global_connections.discard(ws)

    # ------------------------------------------------------------------
    # Public send methods
    # ------------------------------------------------------------------

    async def send_scan_progress(self, scan_id: str, data: dict):
        """Send progress update to all connections watching a specific scan."""
        message = json.dumps({"type": "scan_progress", "scan_id": scan_id, **data})
        conns = await self._get_scan_connections(scan_id)
        if conns:
            await self._send_to(conns, message, scan_id=scan_id)

    async def send_scan_log(self, scan_id: str, log_line: str):
        """Stream a log line to scan watchers."""
        await self._buffer_scan_log(scan_id, log_line)
        await self._schedule_scan_log_flush(scan_id)
        message = json.dumps({
            "type": "scan_log",
            "scan_id": scan_id,
            "message": log_line,
        })
        conns = await self._get_scan_connections(scan_id)
        if conns:
            await self._send_to(conns, message, scan_id=scan_id)

    async def _buffer_scan_log(self, scan_id: str, log_line: str) -> None:
        """Append a line to in-memory buffer with retention cap."""
        async with self._lock:
            lines = self._scan_log_buffers.setdefault(scan_id, [])
            lines.append(log_line)
            if len(lines) > _MAX_LOG_LINES:
                self._scan_log_buffers[scan_id] = lines[-_MAX_LOG_LINES:]

    async def _schedule_scan_log_flush(self, scan_id: str) -> None:
        """Schedule a delayed buffer flush if one is not already pending."""
        async with self._lock:
            existing = self._scan_log_flush_tasks.get(scan_id)
            if existing and not existing.done():
                return
            task = asyncio.create_task(self._flush_scan_logs_delayed(scan_id))
            self._scan_log_flush_tasks[scan_id] = task

    async def _flush_scan_logs_delayed(self, scan_id: str) -> None:
        """Flush buffered logs after a short debounce window."""
        try:
            await asyncio.sleep(_LOG_FLUSH_INTERVAL_SECONDS)
            await self._flush_scan_log_buffer(scan_id)
        finally:
            should_reschedule = False
            current = asyncio.current_task()
            async with self._lock:
                if self._scan_log_flush_tasks.get(scan_id) is current:
                    self._scan_log_flush_tasks.pop(scan_id, None)
                should_reschedule = bool(self._scan_log_buffers.get(scan_id))
            if should_reschedule:
                await self._schedule_scan_log_flush(scan_id)

    async def _flush_scan_log_buffer(self, scan_id: str) -> None:
        """Persist buffered lines for scan_id in a single DB write."""
        async with self._lock:
            lines = list(self._scan_log_buffers.get(scan_id, []))
            self._scan_log_buffers[scan_id] = []

        if not lines:
            return

        persisted = await self._persist_scan_log_lines(scan_id, lines)
        if persisted:
            return

        # Re-queue failed lines so they can be retried later.
        async with self._lock:
            pending = self._scan_log_buffers.get(scan_id, [])
            merged = lines + pending
            self._scan_log_buffers[scan_id] = merged[-_MAX_LOG_LINES:]

        await self._schedule_scan_log_flush(scan_id)

    async def _persist_scan_log_lines(self, scan_id: str, lines: list[str]) -> bool:
        """Persist batched scan logs with rolling retention.

        Errors here must never crash scan phases — the DB write is
        best-effort.

        Returns True when persisted successfully, else False.
        """
        try:
            for attempt in range(1, _SQLITE_LOCK_RETRIES + 1):
                try:
                    async with async_session_factory() as db:
                        result = await db.execute(select(Scan).where(Scan.id == scan_id))
                        scan = result.scalar_one_or_none()
                        if not scan:
                            return True

                        existing_lines = scan.log.splitlines() if scan.log else []
                        existing_lines.extend(lines)
                        scan.log = "\n".join(existing_lines[-_MAX_LOG_LINES:])
                        await db.commit()
                    return True
                except OperationalError as exc:
                    if _is_sqlite_locked_error(exc) and attempt < _SQLITE_LOCK_RETRIES:
                        await asyncio.sleep(_SQLITE_LOCK_BACKOFF_SECONDS * attempt)
                        continue
                    if _is_sqlite_locked_error(exc):
                        logger.debug(
                            "SQLite log flush lock persisted for scan %s after %d attempts",
                            scan_id,
                            _SQLITE_LOCK_RETRIES,
                        )
                        return False
                    raise
        except Exception:
            # Never let a log persistence failure kill the scan
            logger.warning(
                "Failed to persist scan log batch for %s (%d lines)",
                scan_id,
                len(lines),
                exc_info=True,
            )
            return False

        return False

    async def send_scan_complete(self, scan_id: str, summary: dict):
        """Notify that a scan has completed."""
        # Best effort flush of any pending buffered logs before completion event.
        await self._flush_scan_log_buffer(scan_id)

        async with self._lock:
            task = self._scan_log_flush_tasks.pop(scan_id, None)
        if task and not task.done():
            task.cancel()

        message = json.dumps({
            "type": "scan_complete",
            "scan_id": scan_id,
            "summary": summary,
        })
        # Send to scan-specific watchers
        conns = await self._get_scan_connections(scan_id)
        if conns:
            await self._send_to(conns, message, scan_id=scan_id)
        # Also notify global watchers (dashboard)
        await self.broadcast_global({
            "type": "scan_complete",
            "scan_id": scan_id,
            "summary": summary,
        })

    async def broadcast_global(self, data: dict):
        """Send a message to all global (dashboard) connections."""
        message = json.dumps(data)
        conns = await self._get_global_connections()
        if conns:
            await self._send_to(conns, message)

    async def send_finding(self, scan_id: str, finding: dict):
        """Stream a newly discovered finding to watchers."""
        message = json.dumps({
            "type": "new_finding",
            "scan_id": scan_id,
            "finding": finding,
        })
        conns = await self._get_scan_connections(scan_id)
        if conns:
            await self._send_to(conns, message, scan_id=scan_id)

    async def send_phase_warning(self, scan_id: str, phase: str, error: str):
        """Send a structured phase-level warning to watchers.

        This is a typed event so the UI can render warnings distinctly
        from regular log lines (e.g. yellow banner instead of grey text).
        """
        message = json.dumps({
            "type": "phase_warning",
            "scan_id": scan_id,
            "phase": phase,
            "error": error,
        })
        conns = await self._get_scan_connections(scan_id)
        if conns:
            await self._send_to(conns, message, scan_id=scan_id)


# Singleton instance
ws_manager = ConnectionManager()
