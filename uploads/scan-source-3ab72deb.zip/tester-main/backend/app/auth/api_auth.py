"""REST API authenticator - direct HTTP login for API-first applications.

Playwright browser-based login does not work for pure REST APIs (no HTML
forms). This module discovers login endpoints (from OpenAPI specs or common
path probing), optionally auto-registers a throwaway test user, POSTs
credentials, and extracts JWT / bearer tokens from the response.
"""
import asyncio
import json
import logging
from http.cookies import SimpleCookie
from typing import Optional
from urllib.parse import urljoin, urlparse

import httpx

from app.core.url_safety import validate_external_target_url
from app.core.config import settings

logger = logging.getLogger(__name__)

# Test credentials for auto-registration — configurable via env vars AUTH_TEST_USERNAME/PASSWORD/EMAIL
DEFAULT_TEST_USER = {
    "username": settings.AUTH_TEST_USERNAME,
    "password": settings.AUTH_TEST_PASSWORD,
    "email": settings.AUTH_TEST_EMAIL,
}

# Common login endpoint paths to probe (ordered by likelihood)
LOGIN_PROBE_PATHS = (
    "/users/v1/login",
    "/api/v1/login",
    "/api/v1/auth/login",
    "/api/login",
    "/auth/login",
    "/api/auth/login",
    "/login",
    "/api/v1/auth/token",
    "/api/auth/token",
    "/auth/token",
    "/oauth/token",
    "/api/token",
    "/api/v1/signin",
    "/api/signin",
    "/signin",
)

# Common registration endpoint paths
REGISTER_PROBE_PATHS = (
    "/users/v1/register",
    "/api/v1/register",
    "/api/register",
    "/auth/register",
    "/api/auth/register",
    "/register",
    "/api/v1/signup",
    "/api/signup",
    "/signup",
)

# Keys to look for in login response that contain auth tokens
TOKEN_RESPONSE_KEYS = (
    "auth_token",
    "access_token",
    "token",
    "jwt",
    "id_token",
    "bearer",
    "accessToken",
    "authToken",
    "session_token",
    "sessionToken",
)

# Max retry attempts for transient HTTP errors
_MAX_RETRIES = 2
_BASE_RETRY_DELAY = 0.5  # seconds (exponential backoff base)


def _validate_target_base_url(target_url: str) -> None:
    """Validate target_url before making outbound requests."""
    ok, err = validate_external_target_url(target_url)
    if not ok:
        raise ValueError(f"Unsafe target URL: {err}")


def _extract_base_url(raw_url: str) -> str:
    parsed = urlparse(raw_url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("URL must include scheme and host")
    return f"{parsed.scheme}://{parsed.netloc}"


def _http_request(
    url: str,
    *,
    method: str = "POST",
    payload: dict | None = None,
    timeout: int = 10,
    retries: int = _MAX_RETRIES,
) -> tuple[int, str, dict]:
    """Perform an HTTP request with retry on transient failures.

    Returns (status_code, body_text, response_headers).
    Raises the underlying exception if all retries are exhausted.

    Implements exponential backoff for retries: delays between attempts are
    _BASE_RETRY_DELAY * 2^(attempt-1) seconds.

    NOTE: This is a *synchronous* function that performs blocking I/O.
    Callers in async contexts must use ``asyncio.to_thread()`` to avoid
    blocking the event loop.
    """
    import time

    _validate_target_base_url(_extract_base_url(url))

    headers = {"Content-Type": "application/json"}

    last_exc: Exception | None = None
    for attempt in range(1, retries + 2):  # retries + 1 total attempts
        try:
            with httpx.Client(timeout=timeout, follow_redirects=False) as client:
                resp = client.request(method, url, json=payload, headers=headers)
            body = resp.text
            resp_headers = {k.lower(): v for k, v in resp.headers.items()}
            return int(resp.status_code), body, resp_headers
        except Exception as exc:
            last_exc = exc
            if attempt <= retries:
                # Exponential backoff: delay = base * 2^(attempt-1)
                delay = _BASE_RETRY_DELAY * (2 ** (attempt - 1))
                logger.debug(
                    "HTTP %s %s attempt %d failed: %s — retrying in %.2fs",
                    method, url, attempt, exc, delay,
                )
                time.sleep(delay)
            else:
                raise

    # Unreachable in normal operation (the loop always either returns or
    # raises), but satisfies the type checker.
    raise last_exc or RuntimeError("_http_request: no attempts executed")


class RestApiAuthenticator:
    """Authenticates against REST APIs by POSTing credentials to login endpoints.

    Designed for API-first apps (VAmPI, etc.) where browser-based login is
    not applicable.
    """

    async def authenticate(
        self,
        target_url: str,
        auth_config: Optional[dict] = None,
    ) -> dict:
        """Try to authenticate via REST API login endpoint.

        Strategy:
        1. If auth_config has login_url, use it directly.
        2. Otherwise discover login endpoint from OpenAPI spec.
        3. Otherwise probe common login paths.
        4. If no credentials provided, try auto-registration + default creds.
        5. POST credentials and extract token.

        Returns dict compatible with PlaywrightRunner output:
            {"success", "token", "headers", "cookies", "error", "login_endpoint"}
        """
        config = auth_config or {}
        _validate_target_base_url(target_url)
        username = config.get("username", "")
        password = config.get("password", "")
        login_url = config.get("login_url", "")

        result: dict = {
            "success": False,
            "token": None,
            "headers": {},
            "cookies": [],
            "error": None,
            "login_endpoint": None,
        }

        # ---- Step 1: Find login endpoint ----
        login_endpoint: Optional[str] = None
        register_endpoint: Optional[str] = None

        if login_url:
            parsed_login = urlparse(login_url)
            if parsed_login.scheme and parsed_login.netloc:
                login_endpoint = login_url
            else:
                login_endpoint = urljoin(target_url, login_url)
            _validate_target_base_url(_extract_base_url(login_endpoint))
        else:
            spec_endpoints = await self._discover_from_openapi(target_url)
            login_endpoint = spec_endpoints.get("login")
            register_endpoint = spec_endpoints.get("register")

            if not login_endpoint:
                login_endpoint = await self._probe_paths(target_url, LOGIN_PROBE_PATHS)
            if not register_endpoint:
                register_endpoint = await self._probe_paths(target_url, REGISTER_PROBE_PATHS)

        if not login_endpoint:
            result["error"] = "No login endpoint found"
            return result

        result["login_endpoint"] = login_endpoint
        logger.info("REST API login endpoint: %s", login_endpoint)

        # ---- Step 2: If no credentials, try auto-registration ----
        if not username or not password:
            if register_endpoint:
                logger.info(
                    "No credentials — auto-registering at %s", register_endpoint
                )
                reg_result = await self._try_register(
                    register_endpoint,
                    DEFAULT_TEST_USER["username"],
                    DEFAULT_TEST_USER["password"],
                    DEFAULT_TEST_USER["email"],
                )
                if reg_result["success"]:
                    username = DEFAULT_TEST_USER["username"]
                    password = DEFAULT_TEST_USER["password"]
                    logger.info("Auto-registration OK for user: %s", username)
                else:
                    # May already exist from a prior scan — try login anyway
                    logger.info(
                        "Auto-registration uncertain (%s) — trying login with defaults",
                        reg_result.get("detail", "unknown"),
                    )
                    username = DEFAULT_TEST_USER["username"]
                    password = DEFAULT_TEST_USER["password"]
            else:
                result["error"] = "No credentials and no registration endpoint found"
                return result

        # ---- Step 3: Login ----
        login_result = await self._try_login(login_endpoint, username, password)
        if login_result.get("token"):
            result["success"] = True
            result["token"] = login_result["token"]
            result["headers"] = {"Authorization": f"Bearer {login_result['token']}"}
            if login_result.get("cookies"):
                result["cookies"] = login_result["cookies"]
            logger.info(
                "REST API login successful — token acquired (%d chars)",
                len(login_result["token"]),
            )
        else:
            result["error"] = login_result.get("error", f"Login failed at {login_endpoint}")

        return result

    # ------------------------------------------------------------------
    # OpenAPI discovery
    # ------------------------------------------------------------------

    async def _discover_from_openapi(self, target_url: str) -> dict:
        """Find login/register endpoints from OpenAPI spec."""
        endpoints: dict[str, Optional[str]] = {"login": None, "register": None}

        _validate_target_base_url(target_url)

        # Re-use the probe list from DASTEngine
        openapi_paths = (
            "/openapi.json",
            "/swagger.json",
            "/api-docs",
            "/swagger/v1/swagger.json",
            "/v1/swagger.json",
            "/v2/api-docs",
            "/v3/api-docs",
            "/api/swagger.json",
            "/api/openapi.json",
        )

        for probe_path in openapi_paths:
            spec_url = urljoin(target_url, probe_path)
            try:
                status, body, _headers = await asyncio.to_thread(
                    _http_request,
                    spec_url,
                    method="GET",
                    payload=None,
                    timeout=10,
                    retries=0,
                )
                if status != 200:
                    continue

                spec = json.loads(body)
                if not (spec.get("openapi") or spec.get("swagger") or spec.get("paths")):
                    continue

                for path, methods_obj in spec.get("paths", {}).items():
                    if not isinstance(methods_obj, dict):
                        continue

                    path_lower = path.lower()
                    has_post = "post" in methods_obj

                    if has_post and not endpoints["login"]:
                        if any(
                            kw in path_lower
                            for kw in ("login", "auth/token", "signin", "/token")
                        ):
                            endpoints["login"] = urljoin(target_url, path)
                            logger.info("OpenAPI: login endpoint -> %s", path)

                    if has_post and not endpoints["register"]:
                        if any(
                            kw in path_lower
                            for kw in ("register", "signup", "create_user")
                        ):
                            endpoints["register"] = urljoin(target_url, path)
                            logger.info("OpenAPI: register endpoint -> %s", path)

                # Also check security schemes for bearer / JWT hint
                security_schemes = (
                    spec.get("components", {}).get("securitySchemes", {})
                    or spec.get("securityDefinitions", {})
                )
                for _name, scheme in security_schemes.items():
                    if scheme.get("type") == "http" and scheme.get("scheme") == "bearer":
                        logger.info("OpenAPI: bearerAuth security scheme detected")
                        break

                if endpoints["login"]:
                    return endpoints

            except Exception:
                continue

        return endpoints

    # ------------------------------------------------------------------
    # Path probing
    # ------------------------------------------------------------------

    async def _probe_paths(
        self, target_url: str, paths: tuple[str, ...]
    ) -> Optional[str]:
        """Probe a list of paths; return the first one that responds (non-404)."""
        _validate_target_base_url(target_url)
        for path in paths:
            url = urljoin(target_url, path)
            try:
                status, _body, _headers = await asyncio.to_thread(
                    _http_request,
                    url,
                    method="POST",
                    payload={"username": "", "password": ""},
                    timeout=5,
                    retries=0,
                )
                if status != 404:
                    return url
            except Exception:
                continue
        return None

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    async def _try_register(
        self,
        register_url: str,
        username: str,
        password: str,
        email: str,
    ) -> dict:
        """Attempt to register a test user at the given URL.

        Returns {"success": bool, "detail": str} with diagnostic info.
        """
        payload_variants = [
            {"username": username, "password": password, "email": email},
            {"username": username, "password": password},
            {"email": email, "password": password, "name": username},
            {"username": username, "password": password, "email": email, "name": username},
        ]

        last_detail = "no response"
        for i, payload in enumerate(payload_variants, 1):
            try:
                status, body, headers = await asyncio.to_thread(
                    _http_request, register_url, payload=payload, timeout=10, retries=1,
                )
                try:
                    result_data = json.loads(body)
                    status_val = str(result_data.get("status", "")).lower()
                    message_val = str(result_data.get("message", "")).lower()
                    if "success" in status_val or "success" in message_val:
                        return {"success": True, "detail": f"variant {i}: {message_val}"}
                except (json.JSONDecodeError, AttributeError):
                    pass
                if status == 409:
                    return {"success": True, "detail": "user already exists (409)"}
                if status >= 400 and any(tok in body.lower() for tok in ("already", "exist")):
                    return {"success": True, "detail": "user already exists"}
                if status in (200, 201):
                    return {"success": True, "detail": f"variant {i}: HTTP {status}"}
                last_detail = f"variant {i}: HTTP {status} — {body[:200]}"

            except httpx.HTTPStatusError as exc:
                resp = getattr(exc, "response", None)
                code = int(resp.status_code) if resp is not None else 0
                if code == 409:
                    return {"success": True, "detail": "user already exists (409)"}
                try:
                    err_body = str(resp.text if resp is not None else "").lower()
                    if "already" in err_body or "exist" in err_body:
                        return {"success": True, "detail": "user already exists"}
                except Exception:
                    pass
                last_detail = f"variant {i}: HTTP {code or 'error'}"
                logger.debug("Register variant %d at %s: HTTP %s", i, register_url, code or "error")
            except Exception as exc:
                last_detail = f"variant {i}: {exc}"
                continue

        return {"success": False, "detail": last_detail}

    # ------------------------------------------------------------------
    # Login
    # ------------------------------------------------------------------

    async def _try_login(
        self, login_url: str, username: str, password: str
    ) -> dict:
        """POST credentials and extract auth token from response.

        Returns {"token": str|None, "cookies": list, "error": str|None}.
        """
        payload_variants = [
            {"username": username, "password": password},
            {"email": username, "password": password},
        ]

        last_error = "no response"
        for i, payload in enumerate(payload_variants, 1):
            try:
                status, body, headers = await asyncio.to_thread(
                    _http_request, login_url, payload=payload, timeout=10, retries=1,
                )
                result_data = json.loads(body)

                # Try extracting token from response body
                token = self._extract_token(result_data)

                # Also check response headers for token
                if not token:
                    token = self._extract_token_from_headers(headers)

                if token:
                    cookies = self._extract_cookies_from_headers(headers)
                    return {"token": token, "cookies": cookies, "error": None}

                last_error = (
                    f"variant {i}: HTTP {status} but no token found in response "
                    f"(keys: {list(result_data.keys()) if isinstance(result_data, dict) else 'non-dict'})"
                )
                logger.debug("Login variant %d: %s", i, last_error)

            except httpx.HTTPError as exc:
                try:
                    resp = getattr(exc, "response", None)
                    code = int(resp.status_code) if resp is not None else 0
                    err_body = resp.text if resp is not None else ""
                    last_error = f"variant {i}: HTTP {code or 'error'} — {err_body[:200]}"
                except Exception:
                    last_error = f"variant {i}: HTTP error"
                logger.debug("Login attempt %d at %s failed: %s", i, login_url, exc)
            except json.JSONDecodeError:
                last_error = f"variant {i}: response is not valid JSON"
            except Exception as exc:
                last_error = f"variant {i}: {exc}"
                logger.debug("Login attempt failed: %s", exc)

        return {"token": None, "cookies": [], "error": last_error}

    @staticmethod
    def _extract_token(response_data: dict) -> Optional[str]:
        """Extract auth token from a login response body."""
        if not isinstance(response_data, dict):
            return None

        # Direct key lookup (case-sensitive first, then case-insensitive)
        for key in TOKEN_RESPONSE_KEYS:
            val = response_data.get(key)
            if val and isinstance(val, str) and len(val) > 10:
                return val

        # Case-insensitive key lookup
        lower_keys = {k.lower(): v for k, v in response_data.items()}
        for key in TOKEN_RESPONSE_KEYS:
            val = lower_keys.get(key.lower())
            if val and isinstance(val, str) and len(val) > 10:
                return val

        # Nested lookup (e.g. {"data": {"token": "..."}})
        for top_key in ("data", "result", "response", "payload", "authentication", "body"):
            nested = response_data.get(top_key)
            if isinstance(nested, dict):
                for key in TOKEN_RESPONSE_KEYS:
                    val = nested.get(key)
                    if val and isinstance(val, str) and len(val) > 10:
                        return val
                # Case-insensitive nested
                nested_lower = {k.lower(): v for k, v in nested.items()}
                for key in TOKEN_RESPONSE_KEYS:
                    val = nested_lower.get(key.lower())
                    if val and isinstance(val, str) and len(val) > 10:
                        return val

        return None

    @staticmethod
    def _extract_token_from_headers(headers: dict) -> Optional[str]:
        """Extract auth token from response headers."""
        # Check Authorization header
        auth = headers.get("authorization", "")
        if auth.lower().startswith("bearer ") and len(auth) > 17:
            return auth[7:]

        # Check custom auth headers
        for header_name in ("x-auth-token", "x-access-token", "x-jwt-token"):
            val = headers.get(header_name, "")
            if val and len(val) > 10:
                return val

        return None

    @staticmethod
    def _extract_cookies_from_headers(headers: dict) -> list[dict]:
        """Extract cookies from Set-Cookie response headers.

        Uses ``http.cookies.SimpleCookie`` to avoid breaking on cookies
        whose ``Expires`` attribute contains commas (e.g.
        ``Expires=Thu, 01 Dec 2025 00:00:00 GMT``).
        """
        cookies: list[dict] = []
        set_cookie = headers.get("set-cookie", "")
        if not set_cookie:
            return cookies

        # SimpleCookie expects individual Set-Cookie values.  The stdlib
        # http.client joins multiple Set-Cookie headers with ", " which is
        # ambiguous.  We split defensively: only on ", " where the next
        # token looks like a cookie name (contains "=" before ";").
        # A simpler safe approach: try SimpleCookie first, fall back to
        # manual extraction.
        try:
            sc = SimpleCookie()
            sc.load(set_cookie)
            for name, morsel in sc.items():
                cookies.append({
                    "name": name,
                    "value": morsel.value,
                    "domain": morsel.get("domain", ""),
                })
            if cookies:
                return cookies
        except Exception:
            pass

        # Fallback: split on "; " boundaries and look for name=value pairs
        # at the start of each segment.  This handles the common single-
        # cookie case without breaking on Expires commas.
        name_val = set_cookie.split(";")[0].strip()
        if "=" in name_val:
            name, _, val = name_val.partition("=")
            cookies.append({"name": name.strip(), "value": val.strip(), "domain": ""})

        return cookies
