"""Auth script generator - auto-generates Playwright login scripts."""
import logging

logger = logging.getLogger(__name__)


class AuthScriptGenerator:
    """Generates Playwright authentication scripts based on detected auth patterns."""

    def generate_config(self, auth_info: dict, target_url: str) -> dict:
        """Build a simplified auth_config dict from detected auth patterns.

        This is a synchronous helper used by the orchestrator to construct
        the config that PlaywrightRunner.run_login() expects.
        """
        login_routes = auth_info.get("login_routes", [])
        login_path = "/login"
        if login_routes:
            import re
            code = login_routes[0].get("code", "")
            path_match = re.search(r"""['"](/[^'"]+)['"]""", code)
            if path_match:
                login_path = path_match.group(1)

        return {
            "auth_type": auth_info.get("auth_type", "session"),
            "login_url": f"{target_url.rstrip('/')}{login_path}",
            "username": auth_info.get("username", ""),
            "password": auth_info.get("password", ""),
        }

    async def generate(self, auth_info: dict, target_url: str) -> dict:
        """Generate a Playwright login script based on detected auth patterns.

        Args:
            auth_info: Output from AuthDetector.detect_auth()
            target_url: Base URL of the target application

        Returns:
            Dict with script content, auth type, and notes.
        """
        auth_type = auth_info.get("auth_type", "none")
        login_routes = auth_info.get("login_routes", [])

        # Determine login URL
        login_path = "/login"
        if login_routes:
            # Extract path from first login route
            code = login_routes[0].get("code", "")
            import re
            path_match = re.search(r"""['"](/[^'"]+)['"]""", code)
            if path_match:
                login_path = path_match.group(1)

        login_url = f"{target_url.rstrip('/')}{login_path}"

        if auth_type == "jwt":
            script = self._generate_jwt_script(login_url, auth_info)
        elif auth_type == "session":
            script = self._generate_session_script(login_url, auth_info)
        elif auth_type == "oauth":
            script = self._generate_oauth_script(login_url, auth_info)
        else:
            script = self._generate_generic_script(login_url, auth_info)

        notes = self._generate_notes(auth_info)

        return {
            "script": script,
            "auth_type": auth_type,
            "login_url": login_url,
            "notes": notes,
        }

    def _generate_jwt_script(self, login_url: str, auth_info: dict) -> str:
        """Generate script for JWT-based authentication."""
        return f'''"""Auto-generated JWT authentication script for TraceON."""
import asyncio
import json
import sys
from playwright.async_api import async_playwright


async def login(target_url: str, username: str, password: str) -> dict:
    """Authenticate using JWT and return token + cookies."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Navigate to login page
        await page.goto("{login_url}", wait_until="networkidle")

        # Fill credentials
        # Try common selectors - customize if needed
        try:
            await page.fill('input[name="username"], input[type="email"], #username, #email', username)
        except Exception:
            await page.fill('input:first-of-type', username)

        try:
            await page.fill('input[name="password"], input[type="password"], #password', password)
        except Exception:
            await page.fill('input[type="password"]', password)

        # Submit form
        await page.click('button[type="submit"], input[type="submit"], .login-btn, #login-button')
        await page.wait_for_load_state("networkidle")

        # Capture JWT from localStorage/sessionStorage
        token = await page.evaluate("""() => {{
            const keys = ['token', 'access_token', 'jwt', 'auth_token', 'id_token'];
            for (const key of keys) {{
                const val = localStorage.getItem(key) || sessionStorage.getItem(key);
                if (val) return val;
            }}
            return null;
        }}""")

        cookies = await context.cookies()
        await browser.close()

        return {{
            "token": token,
            "cookies": [
                {{"name": c["name"], "value": c["value"], "domain": c["domain"]}}
                for c in cookies
            ],
        }}


if __name__ == "__main__":
    import argparse
    import os
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    args = parser.parse_args()
    username = os.environ["AUTH_USERNAME"]
    password = os.environ["AUTH_PASSWORD"]

    result = asyncio.run(login(args.url, username, password))
    print(json.dumps(result))
'''

    def _generate_session_script(self, login_url: str, auth_info: dict) -> str:
        """Generate script for session/cookie-based authentication."""
        has_csrf = auth_info.get("has_csrf", False)
        csrf_handling = ""
        if has_csrf:
            csrf_handling = '''
        # Handle CSRF token
        csrf_token = await page.evaluate("""() => {
            const meta = document.querySelector('meta[name="csrf-token"]');
            if (meta) return meta.getAttribute('content');
            const input = document.querySelector('input[name="csrf_token"], input[name="_csrf"], input[name="csrfmiddlewaretoken"]');
            if (input) return input.value;
            return null;
        }""")
        if csrf_token:
            print(f"CSRF token captured: {csrf_token[:20]}...", file=sys.stderr)
'''

        return f'''"""Auto-generated session authentication script for TraceON."""
import asyncio
import json
import sys
from playwright.async_api import async_playwright


async def login(target_url: str, username: str, password: str) -> dict:
    """Authenticate using session cookies."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        await page.goto("{login_url}", wait_until="networkidle")
{csrf_handling}
        # Fill credentials
        await page.fill('input[name="username"], input[type="email"], #username', username)
        await page.fill('input[name="password"], input[type="password"], #password', password)

        # Submit
        await page.click('button[type="submit"], input[type="submit"]')
        await page.wait_for_load_state("networkidle")

        cookies = await context.cookies()
        await browser.close()

        return {{
            "cookies": [
                {{"name": c["name"], "value": c["value"], "domain": c["domain"]}}
                for c in cookies
            ],
        }}


if __name__ == "__main__":
    import argparse
    import os
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    args = parser.parse_args()
    username = os.environ["AUTH_USERNAME"]
    password = os.environ["AUTH_PASSWORD"]

    result = asyncio.run(login(args.url, username, password))
    print(json.dumps(result))
'''

    def _generate_oauth_script(self, login_url: str, auth_info: dict) -> str:
        """Generate script for OAuth-based authentication."""
        return f'''"""Auto-generated OAuth authentication script for TraceON.

NOTE: OAuth flows often require interactive browser usage.
This script provides a starting point - customize as needed.
"""
import asyncio
import json
import sys
from playwright.async_api import async_playwright


async def login(target_url: str, username: str, password: str) -> dict:
    """Authenticate using OAuth flow."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)  # OAuth may need visible browser
        context = await browser.new_context()
        page = await context.new_page()

        # Start OAuth flow
        await page.goto("{login_url}", wait_until="networkidle")

        # Click OAuth provider button (customize selector)
        # await page.click('a[href*="oauth"], .oauth-button, .social-login')

        # Fill OAuth provider credentials
        await page.fill('input[name="username"], input[type="email"]', username)
        await page.fill('input[name="password"], input[type="password"]', password)
        await page.click('button[type="submit"]')

        # Wait for redirect back to application
        await page.wait_for_url(f"{{target_url}}/**", timeout=30000)
        await page.wait_for_load_state("networkidle")

        cookies = await context.cookies()
        token = await page.evaluate("""() => {{
            return localStorage.getItem('token') || localStorage.getItem('access_token');
        }}""")

        await browser.close()

        return {{
            "token": token,
            "cookies": [
                {{"name": c["name"], "value": c["value"], "domain": c["domain"]}}
                for c in cookies
            ],
        }}


if __name__ == "__main__":
    import argparse
    import os
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    args = parser.parse_args()
    username = os.environ["AUTH_USERNAME"]
    password = os.environ["AUTH_PASSWORD"]

    result = asyncio.run(login(args.url, username, password))
    print(json.dumps(result))
'''

    def _generate_generic_script(self, login_url: str, auth_info: dict) -> str:
        """Generate a generic login script."""
        return f'''"""Auto-generated generic authentication script for TraceON.

Customize this script to match your application's login flow.
"""
import asyncio
import json
import sys
from playwright.async_api import async_playwright


async def login(target_url: str, username: str, password: str) -> dict:
    """Generic login - customize for your application."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        await page.goto("{login_url}", wait_until="networkidle")

        # Step: Adjust these fallback selectors if needed
        await page.fill('#username', username)
        await page.fill('#password', password)
        await page.click('#login-button')
        await page.wait_for_load_state("networkidle")

        cookies = await context.cookies()
        token = await page.evaluate("() => localStorage.getItem('token')")

        await browser.close()

        return {{
            "token": token,
            "cookies": [
                {{"name": c["name"], "value": c["value"], "domain": c["domain"]}}
                for c in cookies
            ],
        }}


if __name__ == "__main__":
    import argparse
    import os
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    args = parser.parse_args()
    username = os.environ["AUTH_USERNAME"]
    password = os.environ["AUTH_PASSWORD"]

    result = asyncio.run(login(args.url, username, password))
    print(json.dumps(result))
'''

    def _generate_notes(self, auth_info: dict) -> list[str]:
        """Generate helpful notes about the detected auth."""
        notes = []

        if auth_info.get("has_jwt"):
            notes.append("JWT authentication detected. The script captures tokens from localStorage/sessionStorage.")
        if auth_info.get("has_session"):
            notes.append("Session-based authentication detected. Cookies will be captured after login.")
        if auth_info.get("has_csrf"):
            notes.append("CSRF protection detected. The script handles CSRF tokens automatically.")
        if auth_info.get("has_oauth"):
            notes.append("OAuth detected. You may need to run the browser in non-headless mode for OAuth provider login.")

        if auth_info.get("login_routes"):
            route = auth_info["login_routes"][0]
            notes.append(f"Login route found at: {route.get('file', '')}:{route.get('line', '')}")

        if auth_info.get("protected_routes"):
            count = len(auth_info["protected_routes"])
            notes.append(f"{count} protected routes detected that require authentication.")

        if auth_info.get("public_routes"):
            count = len(auth_info["public_routes"])
            notes.append(f"{count} public routes detected (no authentication required).")

        return notes
