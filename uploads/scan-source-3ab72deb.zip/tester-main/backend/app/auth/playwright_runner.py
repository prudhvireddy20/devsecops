"""Playwright runner - executes authenticated browsing sessions.

Security hardening:
  - Custom auth scripts are validated via AST analysis before execution.
  - Dangerous imports (os, subprocess, sys, etc.) and builtins (exec, eval)
    are blocked.
  - Scripts run in an isolated subprocess with a restricted environment,
    a dedicated temp directory, and Python's -I (isolated) flag.
  - The entire process group is killed on timeout to prevent orphan processes.
"""
import ast
import asyncio
import json
import logging
import os
import shutil
import signal
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)

# ── Modules that custom auth scripts must never import ──────────────────────
_BLOCKED_MODULES: frozenset[str] = frozenset({
    "os", "subprocess", "sys", "shutil", "socket", "ctypes",
    "importlib", "code", "codeop", "compileall",
    "multiprocessing", "threading", "signal", "resource",
    "builtins", "__builtin__", "gc", "inspect",
    "pickle", "shelve", "marshal",
    "webbrowser", "http.server", "socketserver",
    "ftplib", "smtplib", "telnetlib",
})

# ── Builtin function names that custom scripts must never call ──────────────
_BLOCKED_BUILTINS: frozenset[str] = frozenset({
    "exec", "eval", "compile", "__import__", "breakpoint", "open",
})


class PlaywrightRunner:
    """Executes Playwright scripts for authenticated scanning."""

    # ── public entry point ──────────────────────────────────────────────────

    async def run_login(
        self,
        target_url: str,
        auth_config: dict,
    ) -> dict:
        """Execute a login flow and return authentication credentials.

        Args:
            target_url: Base URL of the target application
            auth_config: Dict containing auth configuration:
                - script: Playwright script content (string)
                - username: Login username
                - password: Login password
                - login_url: URL of the login page
                - auth_type: "jwt" | "session" | "custom"

        Returns:
            Dict with cookies, tokens, and headers for authenticated scanning.
        """
        auth_type = auth_config.get("auth_type", "session")
        script = auth_config.get("script", "")
        username = auth_config.get("username", "")
        password = auth_config.get("password", "")
        login_url = auth_config.get("login_url", f"{target_url}/login")

        result: dict = {
            "success": False,
            "cookies": [],
            "token": None,
            "headers": {},
            "error": None,
        }

        try:
            from playwright.async_api import async_playwright

            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context()
                page = await context.new_page()

                if script:
                    auth_result = await self._run_custom_script(
                        script, page, context, target_url, username, password
                    )
                    result.update(auth_result)
                else:
                    if auth_type == "jwt":
                        auth_result = await self._jwt_login(
                            page, context, login_url, username, password
                        )
                    elif auth_type == "form":
                        auth_result = await self._form_login(
                            page, context, login_url, username, password
                        )
                    else:
                        auth_result = await self._generic_login(
                            page, context, login_url, username, password
                        )
                    result.update(auth_result)

                await browser.close()

        except ImportError:
            result["error"] = (
                "Playwright not installed. "
                "Run: pip install playwright && playwright install chromium"
            )
            logger.error(result["error"])
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Login failed: {type(e).__name__}: {e}", exc_info=True)

        return result

    # ── AST-based script validation ─────────────────────────────────────────

    @staticmethod
    def _validate_script(script: str) -> tuple[bool, str]:
        """Validate a custom auth script using AST analysis.

        Returns ``(is_safe, error_message)``.
        """
        try:
            tree = ast.parse(script)
        except SyntaxError as e:
            return False, f"Script has syntax error: {e}"

        for node in ast.walk(tree):
            # Block dangerous imports
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root_module = alias.name.split(".")[0]
                    if root_module in _BLOCKED_MODULES:
                        return False, f"Blocked import: {alias.name}"
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_module = node.module.split(".")[0]
                    if root_module in _BLOCKED_MODULES:
                        return False, f"Blocked import: {node.module}"
            # Block dangerous builtin calls
            elif isinstance(node, ast.Call):
                func = node.func
                name: str | None = None
                if isinstance(func, ast.Name):
                    name = func.id
                elif isinstance(func, ast.Attribute):
                    name = func.attr
                if name and name in _BLOCKED_BUILTINS:
                    return False, f"Blocked builtin call: {name}"

        return True, ""

    # ── Sandboxed custom script execution ───────────────────────────────────

    async def _run_custom_script(
        self, script: str, page, context, target_url: str,
        username: str, password: str,
    ) -> dict:
        """Execute a user-provided Playwright script with sandboxing.

        Safety layers:
          1. AST validation (blocks dangerous imports/builtins)
          2. Isolated subprocess (``python -I``, restricted env, separate cwd)
          3. New process group for reliable kill-on-timeout
        """
        result: dict = {
            "success": False, "cookies": [], "token": None, "headers": {},
        }

        # ── step 1: validate ────────────────────────────────────────────────
        is_safe, error_msg = self._validate_script(script)
        if not is_safe:
            result["error"] = f"Script rejected: {error_msg}"
            logger.warning("Rejected auth script: %s", error_msg)
            return result

        # ── step 2: write to isolated temp dir ──────────────────────────────
        tmpdir = tempfile.mkdtemp(prefix="dt_auth_")
        script_path = Path(tmpdir) / "auth_script.py"
        script_path.write_text(script)

        try:
            cmd = [
                "python", "-I",          # isolated mode: no user site, no PYTHON* env vars
                str(script_path),
                "--url", target_url,
            ]

            # Minimal environment — deny access to parent env secrets
            # Credentials go via env vars, not CLI args, to avoid /proc/PID/cmdline exposure
            safe_env = {
                "PATH": "/usr/local/bin:/usr/bin:/bin",
                "HOME": tmpdir,
                "TMPDIR": tmpdir,
                "LANG": "C.UTF-8",
                "TARGET_URL": target_url,
                "AUTH_USERNAME": username,
                "AUTH_PASSWORD": password,
                # Playwright needs its browser path
                "PLAYWRIGHT_BROWSERS_PATH": os.environ.get(
                    "PLAYWRIGHT_BROWSERS_PATH", "/opt/pw-browsers"
                ),
            }

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=safe_env,
                cwd=tmpdir,
                start_new_session=True,          # new process group
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=60,
                )
            except asyncio.TimeoutError:
                # Kill the entire process group to prevent orphan processes
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    proc.kill()
                result["error"] = "Auth script timed out after 60 seconds"
                logger.warning("Auth script timed out — killed process group")
                return result

            if stdout:
                try:
                    auth_data = json.loads(stdout.decode())
                    result["cookies"] = auth_data.get("cookies", [])
                    result["token"] = auth_data.get("token")
                    result["success"] = True
                except json.JSONDecodeError:
                    pass

            if stderr:
                logger.warning("Auth script stderr: %s", stderr.decode()[:500])

        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

        return result

    # ── Built-in login flows ────────────────────────────────────────────────

    async def _jwt_login(
        self, page, context, login_url: str, username: str, password: str,
    ) -> dict:
        """Perform JWT-based login."""
        result: dict = {
            "success": False, "cookies": [], "token": None, "headers": {},
        }

        try:
            await page.goto(login_url, wait_until="networkidle", timeout=30000)
            await self._fill_login_form(page, username, password)
            await page.wait_for_load_state("networkidle", timeout=15000)

            token = await page.evaluate("""() => {
                for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    const value = localStorage.getItem(key);
                    if (key.toLowerCase().includes('token') ||
                        key.toLowerCase().includes('jwt') ||
                        key.toLowerCase().includes('auth')) {
                        return value;
                    }
                }
                for (let i = 0; i < sessionStorage.length; i++) {
                    const key = sessionStorage.key(i);
                    const value = sessionStorage.getItem(key);
                    if (key.toLowerCase().includes('token') ||
                        key.toLowerCase().includes('jwt') ||
                        key.toLowerCase().includes('auth')) {
                        return value;
                    }
                }
                return null;
            }""")

            cookies = await context.cookies()

            if token:
                result["token"] = token
                result["headers"] = {"Authorization": f"Bearer {token}"}
                result["success"] = True
            elif cookies:
                result["cookies"] = [
                    {"name": c["name"], "value": c["value"], "domain": c["domain"]}
                    for c in cookies
                ]
                result["success"] = True

        except Exception as e:
            result["error"] = str(e)

        return result

    async def _form_login(
        self, page, context, login_url: str, username: str, password: str,
    ) -> dict:
        """Perform form-based (session) login."""
        result: dict = {
            "success": False, "cookies": [], "token": None, "headers": {},
        }

        try:
            await page.goto(login_url, wait_until="networkidle", timeout=30000)
            await self._fill_login_form(page, username, password)
            await page.wait_for_load_state("networkidle", timeout=15000)

            cookies = await context.cookies()
            if cookies:
                result["cookies"] = [
                    {"name": c["name"], "value": c["value"], "domain": c["domain"]}
                    for c in cookies
                ]
                result["success"] = True

        except Exception as e:
            result["error"] = str(e)

        return result

    async def _generic_login(
        self, page, context, login_url: str, username: str, password: str,
    ) -> dict:
        """Generic login attempt - tries form-based, then JWT."""
        result = await self._form_login(page, context, login_url, username, password)
        if not result["success"]:
            result = await self._jwt_login(page, context, login_url, username, password)
        return result

    # ── Form interaction helpers ────────────────────────────────────────────

    async def _fill_login_form(self, page, username: str, password: str):
        """Find and fill a login form on the page."""
        username_selectors = [
            'input[name="username"]',
            'input[name="email"]',
            'input[type="email"]',
            'input[name="login"]',
            'input[id="username"]',
            'input[id="email"]',
            '#login-username',
            '#login-email',
        ]
        password_selectors = [
            'input[name="password"]',
            'input[type="password"]',
            'input[id="password"]',
            '#login-password',
        ]
        submit_selectors = [
            'button[type="submit"]',
            'input[type="submit"]',
            'button:has-text("Login")',
            'button:has-text("Sign in")',
            'button:has-text("Log in")',
            '#login-button',
            '.login-button',
        ]

        for selector in username_selectors:
            try:
                elem = page.locator(selector).first
                if await elem.is_visible(timeout=2000):
                    await elem.fill(username)
                    break
            except Exception as e:
                logger.debug(f"Failed to fill username field with selector '{selector}': {type(e).__name__}")
                continue

        for selector in password_selectors:
            try:
                elem = page.locator(selector).first
                if await elem.is_visible(timeout=2000):
                    await elem.fill(password)
                    break
            except Exception as e:
                logger.debug(f"Failed to fill password field with selector '{selector}': {type(e).__name__}")
                continue

        for selector in submit_selectors:
            try:
                elem = page.locator(selector).first
                if await elem.is_visible(timeout=2000):
                    await elem.click()
                    break
            except Exception as e:
                logger.debug(f"Failed to click submit button with selector '{selector}': {type(e).__name__}")
                continue

    # ── Utilities ───────────────────────────────────────────────────────────

    async def record_login(self, target_url: str) -> str:
        """Record a manual login flow using Playwright codegen.

        Returns the generated Playwright script.
        """
        cmd = [
            "playwright", "codegen",
            "--target", "python-async",
            target_url,
        ]
        logger.info(f"Launch login recorder: {' '.join(cmd)}")
        return f"# Run this command to record login flow:\n# {' '.join(cmd)}"

    async def test_auth(self, target_url: str, auth_result: dict) -> dict:
        """Test if authentication credentials are valid."""
        try:
            from playwright.async_api import async_playwright

            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context()

                if auth_result.get("cookies"):
                    await context.add_cookies(auth_result["cookies"])

                page = await context.new_page()

                if auth_result.get("token"):
                    await page.set_extra_http_headers({
                        "Authorization": f"Bearer {auth_result['token']}"
                    })

                response = await page.goto(target_url, wait_until="networkidle")
                status = response.status if response else 0

                await browser.close()

                return {
                    "valid": status == 200,
                    "status_code": status,
                    "url": target_url,
                }

        except Exception as e:
            return {"valid": False, "error": str(e)}
