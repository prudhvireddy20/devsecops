"""API key authentication for all endpoints."""
from hashlib import sha256

from fastapi import Depends, Request, Security
from fastapi.exceptions import HTTPException
from fastapi.security import APIKeyHeader
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_403_FORBIDDEN

from app.core.database import get_db
from app.core import cp_session

_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)


def _hash_key(key: str) -> str:
    return sha256(key.encode()).hexdigest()


async def get_current_user(
    request: Request,
    header_key: str | None = Security(_API_KEY_HEADER),
    db: AsyncSession = Depends(get_db),
):
    """Validate API key and return the matching User.

    Supports both the legacy global API_KEY (admin) and per-user keys stored
    in the users table. Always returns a User object so routes can check
    user.id and user.is_admin for data isolation.

    Raises:
        HTTPException 401 if no key is provided.
        HTTPException 403 if the key is invalid or the user is inactive.
    """
    from app.models.user import User  # local import avoids circular deps at module level

    # CP embedded-app session cookie takes precedence over the X-API-Key header
    # so each CP user is scoped to their own data. Without this, an embedded
    # frontend that also sends the global admin API_KEY would authenticate every
    # CP user as the admin (is_admin=True) and leak all users' scans to everyone.
    claims = cp_session.verify_session_token(request.cookies.get(cp_session.COOKIE_NAME, ""))
    if claims:
        cp_session.validate_same_origin_for_cookie_auth(request)
        user = await cp_session.get_or_create_cp_user(db, claims)
        return cp_session.attach_claims(user, claims)

    if header_key:
        key_hash = _hash_key(header_key)
        result = await db.execute(
            select(User).where(User.api_key_hash == key_hash, User.is_active.is_(True))
        )
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN,
                detail="Invalid API key.",
            )
        return user

    raise HTTPException(
        status_code=HTTP_401_UNAUTHORIZED,
        detail="Missing API key or CP session.",
    )


async def require_api_key(
    request: Request,
    header_key: str | None = Security(_API_KEY_HEADER),
    db: AsyncSession = Depends(get_db),
) -> str:
    """Thin shim kept for backward-compat with the global _auth_deps list.

    Validates the key exists in the users table (or is the admin key), then
    returns the raw key string. Routes that need the full User object should
    use ``get_current_user`` directly.
    """
    await get_current_user(request, header_key, db)
    return header_key or "cp-session"
