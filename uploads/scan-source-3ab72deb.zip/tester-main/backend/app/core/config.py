"""Application configuration using Pydantic BaseSettings."""
import secrets
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

# Resolved once at import time — used only for computing defaults
_BASE_DIR = Path(__file__).resolve().parent.parent.parent


def _generate_default_key() -> str:
    """Generate a random encryption key when none is provided via env."""
    return secrets.token_urlsafe(32)


class Settings(BaseSettings):
    """Global application settings loaded from environment variables."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # App
    APP_NAME: str = "TraceON"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    TRUST_PROXY: bool = False  # Set True only when running behind a trusted reverse proxy
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    ENCRYPTION_KEY: str = ""
    ENCRYPTION_SALT: str = ""

    # API Authentication — if empty, a random key is auto-generated (see below).
    # Set API_KEY in your environment for persistence.
    API_KEY: str = ""

    # Database
    DATABASE_URL: str = "sqlite+aiosqlite:///./traceon.db"

    # Paths — all overridable via env vars (e.g. PROJECTS_DIR=/data/projects)
    PROJECTS_DIR: Path = _BASE_DIR / "projects_data"
    UPLOADS_DIR: Path = _BASE_DIR / "uploads"
    REPORTS_DIR: Path = _BASE_DIR / "reports_output"
    COVERAGE_DIR: Path = _BASE_DIR / "coverage_data"

    # ZAP
    ZAP_API_URL: str = "http://localhost:8080"
    ZAP_API_KEY: str = ""  # Must be explicitly configured for security

    # SMTP — outbound email for the Email (SMTP) integration.
    # Leave SMTP_HOST empty to disable email delivery entirely.
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = ""  # falls back to SMTP_USERNAME when empty
    SMTP_USE_TLS: bool = True  # STARTTLS on 587; implicit SSL is used on port 465

    # DAST Active Scan Timeouts (all in seconds)
    # - BASE_TIMEOUT: default timeout for active scan (increased from 1200 to 2400 for complex apps)
    # - ABSOLUTE_MAX_TIMEOUT: hard limit that cannot be exceeded (increased from 600 to 2400)
    # - STALL_TIMEOUT: if no progress for this many seconds, fail the scan (increased from 60 to 120)
    # For complex targets like OWASP Juice Shop, these values are tuned for thorough scanning
    DAST_BASE_TIMEOUT: int = 2400  # 40 minutes
    DAST_ABSOLUTE_MAX_TIMEOUT: int = 2400  # 40 minutes absolute max
    DAST_STALL_TIMEOUT: int = 120   # 120 seconds of no progress = fail
    DAST_ADAPTIVE_TIMEOUT: bool = True  # Enable adaptive timeout based on route count

    # Nuclei — default rate limit; orchestrator overrides per-scan and throttles to 10 under WAF
    NUCLEI_DEFAULT_RATE_LIMIT: int = 150

    # ZAP scan aggression when NO WAF is detected (private targets, no rate limiting)
    ZAP_NO_WAF_DELAY_MS: int = 0    # 0ms delay between ZAP requests
    ZAP_NO_WAF_THREADS: int = 20    # 20 threads per host

    # Docker host hostname for container→host networking.
    # On Docker Desktop (Mac/Win) this works out of the box.
    # On Linux add: --add-host=host.docker.internal:host-gateway
    DOCKER_HOST_HOSTNAME: str = "host.docker.internal"

    # GitHub
    GITHUB_TOKEN: str = ""

    # Black-box discovery tools
    GAU_ENABLED: bool = True
    FFUF_ENABLED: bool = True
    NIKTO_ENABLED: bool = True
    WAPITI_ENABLED: bool = True
    SQLMAP_ENABLED: bool = True
    FEROXBUSTER_ENABLED: bool = True
    DALFOX_ENABLED: bool = True
    TESTSSL_ENABLED: bool = True
    FFUF_WORDLIST_PATH: str = "/usr/share/seclists/Discovery/Web-Content/common.txt"

    # Semgrep — "local" uses bundled rules (no internet); "auto" downloads from semgrep.dev
    SEMGREP_RULES: str = "local"

    # LLM providers
    LLM_ENABLED: bool = False
    LLM_PROVIDER: str = "anthropic"  # anthropic, openai, openrouter, google, github
    LLM_MODEL: str = ""
    LLM_TIMEOUT_SECONDS: int = 40
    LLM_MAX_RETRIES: int = 2
    LLM_MAX_SNIPPET_CHARS: int = 12000

    ANTHROPIC_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    OPENROUTER_API_KEY: str = ""
    GOOGLE_API_KEY: str = ""
    GITHUB_COPILOT_TOKEN: str = ""  # GitHub Copilot API token for "github" provider

    # Legacy/copilot compatibility env vars (kept for existing deployments)
    COPILOT_API_KEY: str = ""

    OPENAI_BASE_URL: str = "https://api.openai.com/v1"
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"
    GOOGLE_BASE_URL: str = "https://generativelanguage.googleapis.com/v1beta"
    GITHUB_COPILOT_BASE_URL: str = "https://api.githubcopilot.com"  # GitHub Copilot endpoint

    # Legacy/copilot compatibility env vars (kept for existing deployments)
    COPILOT_BASE_URL: str = "https://api.githubcopilot.com"

    # CORS
    CORS_ORIGINS: list[str] = ["http://localhost:5173", "http://localhost:3000"]

    # GitNexus (optional)
    GITNEXUS_ENABLED: bool = False
    GITNEXUS_MCP_URL: str = "http://localhost:4747/api/mcp"
    GITNEXUS_REPO: str = ""
    GITNEXUS_TIMEOUT_SECONDS: int = 15

    # CloudGuard Control Plane integration
    CP_SHARED_SECRET: str = ""  # HMAC shared secret with the CP — treat like an API key
    CP_SCANNER_KEY: str = "traceon"
    CP_SCANNER_NAME: str = "TraceON"
    CP_SCANNER_DESCRIPTION: str = "White-box security scanner with SAST/DAST correlation"

    CP_APP_LAUNCH_URL: str = ""  # e.g. https://scanner.example.com/sso-entry
    CP_EXPECTED_ISSUER: str = ""  # CP launch-token issuer, e.g. https://cp.example.com
    CP_JWKS_URL: str = ""  # defaults to <CP_EXPECTED_ISSUER>/.well-known/jwks.json
    CP_BRIDGE_BASE_URL: str = ""  # defaults to CP_EXPECTED_ISSUER for claim requests
    CP_SESSION_TTL_SECONDS: int = 8 * 60 * 60

    # Public base URL of this TraceON instance (used for OAuth callbacks)
    TRACEON_BASE_URL: str = "https://dtest.sc.deeptrustxai.com"

    # TrustScan Platform integration (optional)
    TRUSTSCAN_ENABLED: bool = False
    TRUSTSCAN_PLATFORM_URL: str = "https://trustscan.sc.deeptrustxai.com"
    TRUSTSCAN_TIMEOUT_SECONDS: int = 30

    # Scan execution queue mode: "local" (asyncio task) or "sqs" (AWS SQS)
    SCAN_QUEUE_MODE: str = "local"
    SQS_QUEUE_URL: str = ""
    AWS_REGION: str = ""
    SCAN_QUEUE_POLL_ENABLED: bool = False
    SCAN_QUEUE_FAIL_OPEN: bool = True
    REDIS_URL: str = ""
    REDIS_QUEUE_NAME: str = "traceon:scan_jobs"

    # Throwaway test credentials used by API auth scanner to probe target app login flows.
    # Override via env vars to avoid embedding credentials in source code.
    AUTH_TEST_USERNAME: str = "scanner_test_user"
    AUTH_TEST_PASSWORD: str = "ScannerT3st!Pass"
    AUTH_TEST_EMAIL: str = "scanner@test.local"


settings = Settings()

# Auto-generate ENCRYPTION_KEY if not provided — persist it to the data volume so
# it survives container restarts (same pattern as API_KEY and ENCRYPTION_SALT).
_INSECURE_DEFAULT_ENC_KEY = "change-me-traceon-encryption-key"
if not settings.ENCRYPTION_KEY or settings.ENCRYPTION_KEY == _INSECURE_DEFAULT_ENC_KEY:
    import logging as _logging_enc
    _enc_key_file = Path("/data/db/.encryption_key")
    _persisted_enc_key = ""
    if _enc_key_file.exists():
        try:
            _persisted_enc_key = _enc_key_file.read_text().strip()
        except Exception:
            pass
    if _persisted_enc_key:
        settings.ENCRYPTION_KEY = _persisted_enc_key
        _logging_enc.getLogger(__name__).info(
            "Loaded ENCRYPTION_KEY from %s", _enc_key_file
        )
    else:
        _generated_enc_key = secrets.token_urlsafe(32)
        settings.ENCRYPTION_KEY = _generated_enc_key
        try:
            _enc_key_file.parent.mkdir(parents=True, exist_ok=True)
            _enc_key_file.write_text(_generated_enc_key)
            _logging_enc.getLogger(__name__).info(
                "ENCRYPTION_KEY auto-generated and saved to %s", _enc_key_file
            )
        except Exception:
            _logging_enc.getLogger(__name__).warning(
                "ENCRYPTION_KEY auto-generated but could not be persisted to %s. "
                "Encrypted tokens will NOT survive restarts. "
                "Set ENCRYPTION_KEY in your environment for persistence.",
                _enc_key_file,
            )

if not settings.ENCRYPTION_SALT:
    import logging as _logging_salt
    _salt_file = Path("/data/db/.encryption_salt")
    _persisted_salt = ""
    if _salt_file.exists():
        try:
            _persisted_salt = _salt_file.read_text().strip()
        except Exception:
            pass

    if _persisted_salt:
        settings.ENCRYPTION_SALT = _persisted_salt
        _logging_salt.getLogger(__name__).info(
            "Loaded ENCRYPTION_SALT from %s", _salt_file
        )
    else:
        _generated_salt = secrets.token_urlsafe(24)
        settings.ENCRYPTION_SALT = _generated_salt
        try:
            _salt_file.parent.mkdir(parents=True, exist_ok=True)
            _salt_file.write_text(_generated_salt)
            _logging_salt.getLogger(__name__).info(
                "ENCRYPTION_SALT auto-generated and saved to %s", _salt_file
            )
        except Exception:
            _logging_salt.getLogger(__name__).warning(
                "ENCRYPTION_SALT is not set — generating a random salt. "
                "Encrypted tokens will NOT survive restarts unless you set "
                "ENCRYPTION_SALT or the app can persist it to %s. "
                "Generated salt: %s",
                _salt_file,
                _generated_salt,
            )

if not settings.API_KEY:
    import logging as _logging_api
    # Try to load a previously persisted key from the data volume
    _key_file = Path("/data/db/.api_key")
    _persisted_key = ""
    if _key_file.exists():
        try:
            _persisted_key = _key_file.read_text().strip()
        except Exception:
            pass
    if _persisted_key:
        settings.API_KEY = _persisted_key
        _logging_api.getLogger(__name__).info(
            "Loaded API_KEY from %s", _key_file
        )
    else:
        _generated_api_key = secrets.token_urlsafe(32)
        settings.API_KEY = _generated_api_key
        # Persist so the key survives container restarts
        try:
            _key_file.parent.mkdir(parents=True, exist_ok=True)
            _key_file.write_text(_generated_api_key)
            _logging_api.getLogger(__name__).info(
                "API_KEY auto-generated and saved to %s", _key_file
            )
        except Exception:
            _logging_api.getLogger(__name__).warning(
                "API_KEY auto-generated but could NOT persist to %s. "
                "Key will change on next restart. Set API_KEY in your "
                "environment for persistence.",
                _key_file,
            )

# Ensure directories exist
for dir_path in [settings.PROJECTS_DIR, settings.UPLOADS_DIR, settings.REPORTS_DIR, settings.COVERAGE_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# Warn if ZAP_API_KEY is not configured
if not settings.ZAP_API_KEY:
    import logging as _logging_zap
    _logging_zap.getLogger(__name__).warning(
        "ZAP_API_KEY is not set. DAST scanning will not work. "
        "Set ZAP_API_KEY in your environment for ZAP integration."
    )
