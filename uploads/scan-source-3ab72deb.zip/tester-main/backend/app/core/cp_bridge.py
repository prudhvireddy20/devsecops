"""Calls from embedded-app scanner mode back to the CP bridge."""

from __future__ import annotations

import asyncio
import json

import httpx
from fastapi import HTTPException

from app.core.config import settings
from app.core.cp_hmac import generate_nonce, sign


def _claim_url() -> str:
    base = (settings.CP_BRIDGE_BASE_URL or settings.CP_EXPECTED_ISSUER or "").strip().rstrip("/")
    if not base:
        raise HTTPException(503, "CP bridge base URL is not configured")
    return f"{base}/scanner-bridge/scans/claim"


async def claim_scan_slot(*, user_id: str, org_id: str) -> dict:
    if not settings.CP_SHARED_SECRET:
        raise HTTPException(503, "CP shared secret is not configured")

    raw_body = json.dumps(
        {
            "scannerKey": settings.CP_SCANNER_KEY,
            "userId": user_id,
            "orgId": org_id,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")

    for attempt in range(3):
        nonce = generate_nonce()
        headers = {
            "Content-Type": "application/json",
            "X-Scanner-Nonce": nonce,
            "X-Scanner-Signature": sign(raw_body, nonce, settings.CP_SHARED_SECRET),
        }
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(_claim_url(), content=raw_body, headers=headers)
        except httpx.TimeoutException as exc:
            raise HTTPException(504, "CP claim request timed out") from exc
        except httpx.HTTPError as exc:
            raise HTTPException(502, f"CP claim request failed: {exc}") from exc

        if resp.status_code == 409 and attempt < 2:
            await asyncio.sleep(0.1)
            continue

        if resp.status_code == 200:
            try:
                data = resp.json()
            except ValueError as exc:
                raise HTTPException(502, "CP claim returned invalid JSON") from exc
            required = ("scanJobId", "callbackUrl", "callbackNonce")
            if not all(str(data.get(k, "")).strip() for k in required):
                raise HTTPException(502, "CP claim response is missing required fields")
            return data

        message = "CP claim denied"
        try:
            body = resp.json()
            message = str(body.get("message") or body.get("detail") or message)
        except ValueError:
            if resp.text:
                message = resp.text[:300]
        raise HTTPException(resp.status_code, message)

    raise HTTPException(409, "CP claim conflict; retry later")
