"""Outbound callbacks to the CloudGuard Control Plane.

When a scan's status changes (running → completed / failed), the scanner
POSTs an HMAC-signed status update to the ``callbackUrl`` the CP provided
in the original dispatch.

Wire format matches §4.3 of the scanner integration contract:
  - Reuse the same nonce the CP sent during dispatch
  - Sign ``rawBody + b'.' + nonce`` with the shared secret
  - Send headers: X-Scanner-Nonce, X-Scanner-Signature
"""
import json
import logging
from typing import Optional

import httpx

from app.core.config import settings
from app.core.cp_hmac import sign

logger = logging.getLogger(__name__)

_CALLBACK_TIMEOUT = 15  # seconds


async def post_callback(
    callback_url: str,
    nonce: str,
    payload: dict,
    shared_secret: Optional[str] = None,
) -> bool:
    """POST a signed status update to the CP callback URL.

    Args:
        callback_url: The exact ``callbackUrl`` from the dispatch body.
        nonce: The nonce from the original dispatch — reused on every callback
               for the same jobId (CP checks nonce matches).
        payload: The JSON body to send (e.g. ``{"status": "running"}``).
        shared_secret: Override the default shared secret (for testing).

    Returns:
        True if the CP responded 200, False otherwise.
    """
    secret = shared_secret or settings.CP_SHARED_SECRET
    if not secret:
        logger.error("CP_SHARED_SECRET not set — skipping callback to %s", callback_url)
        return False

    raw_body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    signature = sign(raw_body, nonce, secret)

    headers = {
        "Content-Type": "application/json",
        "X-Scanner-Nonce": nonce,
        "X-Scanner-Signature": signature,
    }

    try:
        async with httpx.AsyncClient(timeout=_CALLBACK_TIMEOUT) as client:
            resp = await client.post(callback_url, content=raw_body, headers=headers)

        if resp.status_code == 200:
            logger.info("Callback to %s succeeded (status=%s)", callback_url, payload.get("status"))
            return True

        logger.warning(
            "Callback to %s returned %d: %s",
            callback_url,
            resp.status_code,
            resp.text[:500],
        )
        return False

    except httpx.TimeoutException:
        logger.error("Callback to %s timed out after %ds", callback_url, _CALLBACK_TIMEOUT)
        return False
    except Exception as exc:
        logger.exception("Callback to %s failed: %s", callback_url, exc)
        return False


async def post_running(callback_url: str, nonce: str) -> bool:
    """Convenience: send ``{ "status": "running" }``."""
    return await post_callback(callback_url, nonce, {"status": "running"})


async def post_completed(
    callback_url: str,
    nonce: str,
    view_secret: str,
    summary: Optional[dict] = None,
) -> bool:
    """Convenience: send completed status with viewSecret and optional summary."""
    payload: dict = {
        "status": "completed",
        "viewSecret": view_secret,
    }
    if summary:
        payload["summary"] = {
            "critical": summary.get("critical", 0),
            "high": summary.get("high", 0),
            "medium": summary.get("medium", 0),
            "low": summary.get("low", 0),
            "info": summary.get("info", 0),
        }
    return await post_callback(callback_url, nonce, payload)


async def post_failed(callback_url: str, nonce: str, error: str) -> bool:
    """Convenience: send ``{ "status": "failed", "error": "..." }``."""
    return await post_callback(callback_url, nonce, {"status": "failed", "error": error})
