"""CloudGuard Control Plane HMAC signature helpers.

Used for signing outbound callbacks to the CP (POST callbackUrl).

Wire format:
    signature = HEX( HMAC-SHA256( sharedSecret, rawBody + b'.' + nonce ) )

Headers on every signed request:
    X-Scanner-Nonce:     <nonce>
    X-Scanner-Signature: <hex signature>
"""
import hashlib
import hmac
import secrets

from app.core.config import settings


def sign(raw_body: bytes, nonce: str, shared_secret: str | None = None) -> str:
    """Compute HMAC-SHA256 signature over ``raw_body + b'.' + nonce``."""
    secret = shared_secret or settings.CP_SHARED_SECRET
    data = raw_body + b"." + nonce.encode("utf-8")
    return hmac.new(secret.encode("utf-8"), data, hashlib.sha256).hexdigest()


def verify(raw_body: bytes, nonce: str, signature: str, shared_secret: str | None = None) -> bool:
    """Constant-time HMAC verification."""
    expected = sign(raw_body, nonce, shared_secret or settings.CP_SHARED_SECRET)
    return hmac.compare_digest(expected, signature)


def generate_nonce() -> str:
    """Generate a cryptographically random nonce (32 hex chars)."""
    return secrets.token_hex(16)
