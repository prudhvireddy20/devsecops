"""Cookie session helpers for CP embedded-app launches."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import uuid
from urllib.parse import urlparse

from fastapi import HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.user import User

COOKIE_NAME = "traceon_cp_session"
_UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}


def _b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode((data + padding).encode("ascii"))


def _session_secret() -> str:
    return settings.CP_SHARED_SECRET or settings.API_KEY


def _sign(payload_b64: str) -> str:
    return hmac.new(
        _session_secret().encode("utf-8"),
        payload_b64.encode("ascii"),
        hashlib.sha256,
    ).hexdigest()


def issue_session_token(claims: dict) -> str:
    now = int(time.time())
    max_age = max(60, int(settings.CP_SESSION_TTL_SECONDS))
    payload = {
        "sub": str(claims.get("sub", "")),
        "email": str(claims.get("email", "")),
        "name": str(claims.get("name", "")),
        "org_id": str(claims.get("org_id", "")),
        "role_key": str(claims.get("role_key", "")),
        "permissions": list(claims.get("permissions") or []),
        "iat": now,
        # Session lifetime is CP_SESSION_TTL_SECONDS from login. The launch
        # token's own (minutes-lived) exp was already enforced at exchange
        # time; inheriting it here would kill the session after ~2 minutes.
        "exp": now + max_age,
        "nonce": uuid.uuid4().hex,
    }
    payload_b64 = _b64encode(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    return f"{payload_b64}.{_sign(payload_b64)}"


def set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        COOKIE_NAME,
        token,
        max_age=max(60, int(settings.CP_SESSION_TTL_SECONDS)),
        httponly=True,
        secure=not settings.DEBUG,
        samesite="strict",
        path="/",
    )


def verify_session_token(token: str) -> dict | None:
    if not token or "." not in token or not _session_secret():
        return None
    payload_b64, provided = token.split(".", 1)
    expected = _sign(payload_b64)
    if not hmac.compare_digest(expected, provided):
        return None
    try:
        payload = json.loads(_b64decode(payload_b64))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    if int(payload.get("exp", 0)) <= int(time.time()):
        return None
    if not payload.get("sub") or not payload.get("org_id"):
        return None
    return payload


def validate_same_origin_for_cookie_auth(request: Request) -> None:
    if request.method.upper() not in _UNSAFE_METHODS:
        return
    host = (request.headers.get("host") or "").split(",", 1)[0].strip().lower()
    origin = (request.headers.get("origin") or "").strip()
    referer = (request.headers.get("referer") or "").strip()
    source = origin or referer
    if not host or not source:
        raise HTTPException(403, "Missing same-origin header for session request")
    parsed = urlparse(source)
    source_host = (parsed.netloc or "").lower()
    if source_host != host:
        raise HTTPException(403, "Cross-site session request rejected")


def cp_user_id(sub: str) -> str:
    try:
        return str(uuid.UUID(str(sub)))
    except Exception:
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"traceon-cp-user:{sub}"))


async def get_or_create_cp_user(db: AsyncSession, claims: dict) -> User:
    user_id = cp_user_id(str(claims.get("sub", "")))
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    label = str(claims.get("email") or claims.get("name") or "CP user").strip()
    if user:
        if not user.is_active:
            raise HTTPException(403, "User is inactive")
        if label and user.label != label:
            user.label = label
            await db.commit()
        return user

    user = User(
        id=user_id,
        api_key_hash=hashlib.sha256(f"cp-session:{user_id}".encode()).hexdigest(),
        label=label,
        is_active=True,
        is_admin=False,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


def attach_claims(user: User, claims: dict) -> User:
    setattr(user, "cp_sub", str(claims.get("sub", "")))
    setattr(user, "cp_org_id", str(claims.get("org_id", "")))
    setattr(user, "cp_email", str(claims.get("email", "")))
    setattr(user, "cp_permissions", list(claims.get("permissions") or []))
    return user
