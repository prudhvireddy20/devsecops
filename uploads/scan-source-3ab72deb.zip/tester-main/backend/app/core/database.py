"""SQLAlchemy async database setup."""
import logging

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.engine import make_url

from app.core.config import settings

logger = logging.getLogger(__name__)

_db_url = make_url(settings.DATABASE_URL)
_engine_kwargs: dict = {
    "echo": settings.DEBUG,
    "future": True,
}

if _db_url.get_backend_name() == "sqlite":
    # ponytail: SQLite under concurrent async write load (parallel SAST phases +
    # WebSocket + ZAP writes) will show "database is locked" errors under real
    # multi-project usage. For production deployments, switch to PostgreSQL via
    # DATABASE_URL.
    # Increase lock wait time for concurrent writes in scan-heavy flows.
    _engine_kwargs["connect_args"] = {"timeout": 30}

engine = create_async_engine(settings.DATABASE_URL, **_engine_kwargs)


if _db_url.get_backend_name() == "sqlite":
    @event.listens_for(engine.sync_engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=5000")
            cursor.execute("PRAGMA foreign_keys=ON")
        finally:
            cursor.close()

async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy models."""
    pass


_SQLITE_COLUMN_MIGRATIONS: dict[str, list[tuple[str, str]]] = {
    "projects": [
        ("source_available", "BOOLEAN DEFAULT 0"),
        ("scan_mode", "VARCHAR(20) DEFAULT 'whitebox'"),
        ("llm_provider", "VARCHAR(50) DEFAULT ''"),
        ("llm_model", "VARCHAR(120) DEFAULT ''"),
        ("llm_api_key_encrypted", "TEXT DEFAULT ''"),
        ("openapi_spec_files", "TEXT DEFAULT ''"),
        ("postman_collection_files", "TEXT DEFAULT ''"),
        ("journey_replay_files", "TEXT DEFAULT ''"),
        ("trustscan_url", "TEXT DEFAULT ''"),
        ("trustscan_token_encrypted", "TEXT DEFAULT ''"),
        ("trustscan_job_id", "TEXT DEFAULT ''"),
        ("external_findings_path", "TEXT DEFAULT ''"),
        ("external_findings_format", "TEXT DEFAULT ''"),
        ("auth_config", "TEXT DEFAULT '{}'"),
        ("owner_id", "VARCHAR(36) DEFAULT ''"),
    ],
    "llm_provider_credentials": [
        ("default_model", "VARCHAR(120) DEFAULT ''"),
        ("api_key_encrypted", "TEXT DEFAULT ''"),
        # GitHub OAuth support
        ("user_id", "VARCHAR(255) DEFAULT ''"),
        ("auth_method", "VARCHAR(50) DEFAULT 'api_key'"),
        ("encrypted_token", "TEXT DEFAULT ''"),
        ("oauth_username", "VARCHAR(255) DEFAULT NULL"),
        ("subscription_verified_at", "TIMESTAMP DEFAULT NULL"),
        ("deleted_at", "TIMESTAMP DEFAULT NULL"),
    ],
    "scans": [
        ("source_available", "BOOLEAN DEFAULT 0"),
        ("scan_mode", "VARCHAR(20) DEFAULT 'whitebox'"),
        ("scan_goals", "JSON DEFAULT '[]'"),
        ("plan_intent", "JSON DEFAULT '{}'"),
        # CloudGuard CP integration fields
        ("cp_job_id", "VARCHAR(36) DEFAULT ''"),
        ("cp_org_id", "VARCHAR(36) DEFAULT ''"),
        ("cp_callback_url", "TEXT DEFAULT ''"),
        ("cp_nonce", "VARCHAR(128) DEFAULT ''"),

    ],
    "findings": [
        ("auth_role", "VARCHAR(80) DEFAULT ''"),
        ("journey_source", "VARCHAR(80) DEFAULT ''"),
        ("generated_fix_payload", "JSON DEFAULT '{}'"),
        ("workflow_graph_id", "VARCHAR(36) DEFAULT ''"),
        ("workflow_step_id", "VARCHAR(36) DEFAULT ''"),
        ("repro_bundle", "JSON DEFAULT '{}'"),
        ("risk_score", "INTEGER DEFAULT 0"),
        ("risk_level", "VARCHAR(20) DEFAULT ''"),
    ],
}


async def get_db():
    """Dependency that yields an async database session."""
    async with async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """Create all database tables."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def run_migrations():
    """Run lightweight schema migrations for existing databases."""
    backend_name = engine.url.get_backend_name()

    if backend_name == "postgresql":
        async with engine.begin() as conn:
            await conn.execute(
                text("ALTER TABLE findings ALTER COLUMN owasp_category TYPE TEXT")
            )
            logger.info(
                "Applied PostgreSQL migration: widened findings.owasp_category to TEXT"
            )
        return

    if backend_name != "sqlite":
        return

    # Validate table names and column names to prevent SQL injection
    _VALID_TABLES = set(_SQLITE_COLUMN_MIGRATIONS.keys())

    async with engine.begin() as conn:
        for table_name, column_defs in _SQLITE_COLUMN_MIGRATIONS.items():
            # Validate table name
            if table_name not in _VALID_TABLES:
                logger.error("Invalid table name in migrations: %s", table_name)
                continue
            
            result = await conn.execute(text(f"PRAGMA table_info({table_name})"))
            rows = result.fetchall()
            if not rows:
                continue
            existing_columns = {row[1] for row in rows}
            for column_name, definition in column_defs:
                # Validate column name (alphanumeric and underscore only)
                if not column_name.replace("_", "").isalnum():
                    logger.error("Invalid column name in migrations: %s", column_name)
                    continue
                if column_name in existing_columns:
                    continue

                await conn.execute(
                    text(
                        f"ALTER TABLE {table_name} "
                        f"ADD COLUMN {column_name} {definition}"
                    )
                )
                logger.info(
                    "Applied SQLite migration: added %s.%s",
                    table_name,
                    column_name,
                )


async def close_db():
    """Dispose of the database engine."""
    await engine.dispose()
