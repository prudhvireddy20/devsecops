"""Structured logging configuration for production observability."""
import logging
import json
import sys
from datetime import datetime, timezone
from typing import Any


class JSONFormatter(logging.Formatter):
    """JSON log formatter for structured logging."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_obj = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Include exception info if present
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)

        # Include extra fields (added via logger.info(..., extra={...}))
        if hasattr(record, "extra_fields"):
            log_obj.update(record.extra_fields)

        return json.dumps(log_obj)


def setup_structured_logging(debug: bool = False):
    """Configure application logging with JSON formatter.

    Args:
        debug: Enable DEBUG level logging if True
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG if debug else logging.INFO)

    # Remove any existing handlers
    root_logger.handlers.clear()

    # JSON handler for structured logs (stdout)
    json_handler = logging.StreamHandler(sys.stdout)
    json_handler.setFormatter(JSONFormatter())
    root_logger.addHandler(json_handler)

    # Suppress verbose third-party loggers in production
    if not debug:
        logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
        logging.getLogger("sqlalchemy.pool").setLevel(logging.WARNING)
        logging.getLogger("playwright").setLevel(logging.WARNING)
        logging.getLogger("asyncio").setLevel(logging.WARNING)


class LogContext:
    """Context manager for adding request-scoped fields to logs."""

    _context: dict[str, Any] = {}

    @classmethod
    def set(cls, **fields):
        """Set context fields for the current request/scope."""
        cls._context.update(fields)

    @classmethod
    def get(cls) -> dict[str, Any]:
        """Get current context fields."""
        return cls._context.copy()

    @classmethod
    def clear(cls):
        """Clear all context fields."""
        cls._context.clear()

    def __enter__(self):
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager."""
        LogContext.clear()


def log_with_context(logger: logging.Logger, level: int, msg: str, **fields):
    """Log a message with additional context fields.

    Args:
        logger: Logger instance
        level: Logging level (e.g., logging.INFO)
        msg: Log message
        **fields: Additional fields to include in JSON output
    """
    context = LogContext.get()
    all_fields = {**context, **fields}

    # Create a custom log record with extra fields
    record = logger.makeRecord(
        logger.name,
        level,
        "()", 0, msg,
        (),
        None,
        func=None,
    )
    record.extra_fields = all_fields
    logger.handle(record)
