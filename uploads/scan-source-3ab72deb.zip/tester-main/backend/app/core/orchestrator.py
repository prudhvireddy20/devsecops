"""Main scan orchestration engine - coordinates all scan phases."""
import asyncio
import logging
import re
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.scan import Scan
from app.models.project import Project
from app.models.finding import Finding
from app.api.websocket import ConnectionManager
from app.scanners.external_importer import ExternalFindingImporter

logger = logging.getLogger(__name__)


def _utcnow_naive() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


# Default maximum wall-clock time for an entire scan (seconds).
_DEFAULT_MAX_DURATION = 14400  # 4 hours (increased from 2 hours for complex targets like OWASP Juice Shop)

# Global semaphore to serialise DAST operations across concurrent scans.
# ZAP's 4 GB container limit is easily exhausted by running multiple active
# scans simultaneously (each holding site trees, scanner states, alerts).
_dast_semaphore = asyncio.Semaphore(1)


class ScanOrchestrator:
    """Orchestrates the full scan pipeline: discovery -> import -> DAST -> correlate."""

    PHASES = [
        ("importing", "Importing external findings", 8),
        ("path_fuzzing", "Fuzzing hidden paths", 12),
        ("server_audit", "Auditing server configuration", 16),
        ("endpoint_discovery", "Discovering endpoints", 20),
        ("fingerprinting", "Fingerprinting target", 24),
        ("attack_surface", "Analyzing attack surface", 28),
        ("auth", "Setting up authentication", 45),
        ("spider", "Spidering application", 55),
        ("waf_detection", "Detecting WAF presence", 60),
        ("active_scan", "Running active scan (ZAP)", 75),
        ("dast_extended", "Running extended DAST scans", 85),
        ("correlation", "Correlating findings", 95),
        ("complete", "Scan complete", 100),
    ]

    def __init__(
        self,
        scan: Scan,
        project: Project,
        db: AsyncSession,
        ws_manager: ConnectionManager,
        ephemeral_auth_config: dict | None = None,
    ):
        self.scan = scan
        self.project = project
        self.db = db
        self.ws = ws_manager
        self._ephemeral_auth_config = ephemeral_auth_config
        self.routes: list[dict] = []
        self.dast_findings: list[dict] = []
        self.all_findings: list[Finding] = []
        self.sinks: list[dict] = []
        self._auth_credentials: dict | None = None
        self._current_auth_role: str = ""
        self._phase_warnings: list[dict] = []
        self._role_scan_stats: list[dict] = []
        self._journey_steps: list[dict] = []
        self._journey_replay_stats: list[dict] = []
        self._workflow_path_map: dict[str, list[dict]] = {}
        self.waf_detected: bool = False
        self.sast_sqli_targets: list[str] = []
        self.sast_xss_targets: list[str] = []
        self.attack_surface: dict[str, list[str]] = {}
        self.high_risk_endpoints: list[str] = []
        self._seed_import_stats: dict = {
            "openapi_file_routes": 0,
            "postman_routes": 0,
            "journey_seed_routes": 0,
            "workflow_routes": 0,
        }
        # Lock to serialize DB writes — AsyncSession is not safe for
        # concurrent use from multiple coroutines.
        self._db_lock = asyncio.Lock()
        self._llm_planner_summary: dict = {
            "enabled": False,
            "provider": "",
            "model": "",
            "decisions": [],
            "errors": [],
        }

    async def run(self):
        """Execute the full scan pipeline with overall timeout."""
        scan_config = self.scan.scan_config or {}
        max_duration = scan_config.get("max_duration", _DEFAULT_MAX_DURATION)

        # Pre-scan LLM planning (optional, if project has description)
        await self._run_pre_scan_planning()

        try:
            await asyncio.wait_for(
                self._run_pipeline(),
                timeout=max_duration,
            )
        except asyncio.CancelledError:
            # Cooperative cancellation: user requested cancel via API/WebSocket.
            self.scan.status = "cancelled"
            self.scan.completed_at = _utcnow_naive()
            await self.db.commit()
            await self.ws.send_scan_progress(self.scan.id, {
                "status": "cancelled",
                "progress": self.scan.progress,
                "phase": self.scan.current_phase,
            })
        except asyncio.TimeoutError:
            logger.error(
                "Scan %s exceeded maximum duration of %ds", self.scan.id, max_duration
            )
            self.scan.status = "failed"
            self.scan.error_message = (
                f"Scan timed out after {max_duration} seconds. "
                "Increase max_duration in scan_config or reduce scope."
            )
            self.scan.completed_at = _utcnow_naive()
            await self.db.commit()
            await self.ws.send_scan_progress(self.scan.id, {
                "status": "failed",
                "progress": self.scan.progress,
                "error": self.scan.error_message,
            })
        except Exception as e:
            logger.exception(f"Scan {self.scan.id} failed: {e}")
            self.scan.status = "failed"
            self.scan.error_message = str(e)
            self.scan.completed_at = _utcnow_naive()
            await self.db.commit()
            await self.ws.send_scan_progress(self.scan.id, {
                "status": "failed",
                "progress": self.scan.progress,
                "error": str(e),
            })

    async def _is_cancel_requested(self) -> bool:
        """Check the latest persisted scan status for cancellation."""
        try:
            result = await self.db.execute(select(Scan.status).where(Scan.id == self.scan.id))
            status = result.scalar_one_or_none()
            if status == "cancelled":
                self.scan.status = "cancelled"
                return True
        except Exception:
            logger.debug("Cancel status check failed", exc_info=True)

        return getattr(self.scan, "status", "") == "cancelled"

    async def _check_cancel_requested(self) -> None:
        """Raise CancelledError if user has cancelled scan."""
        if await self._is_cancel_requested():
            raise asyncio.CancelledError("Scan cancelled by user")

    async def _run_pipeline(self):
        """Internal pipeline — branches by scan_mode.

        whitebox: importing (SAST JSON first) → endpoint_discovery → fingerprinting
                  → attack_surface → DAST (sqlmap/dalfox target SAST-flagged endpoints)
        blackbox: path_fuzzing → server_audit → endpoint_discovery → fingerprinting
                  → attack_surface → pure DAST (no importing — nothing to import)
        """
        modules = self.scan.modules_enabled or {}
        scan_config = self.scan.scan_config or {}
        scan_mode = getattr(self.scan, "scan_mode", "whitebox")

        await self._check_cancel_requested()

        # ── MODE-SPECIFIC PRE-DAST PHASES ──────────────────────────────────
        if scan_mode == "whitebox":
            # Phase: Import SAST findings FIRST (guides all subsequent DAST phases)
            await self._update_phase("importing", 8)
            has_external = await self._import_external_findings()
            if not has_external:
                await self.ws.send_scan_log(
                    self.scan.id,
                    "No external findings file — DAST will run without static correlation.",
                )
            await self._check_cancel_requested()

            # Phase: Endpoint discovery
            await self._update_phase("endpoint_discovery", 20)
            await self._run_endpoint_discovery()
            await self._check_cancel_requested()

            # Phase: Fingerprinting
            await self._update_phase("fingerprinting", 24)
            await self._run_tech_fingerprinting()
            await self._check_cancel_requested()

            # Phase: Attack surface analysis
            await self._update_phase("attack_surface", 28)
            await self._run_attack_surface_analysis()
            await self._check_cancel_requested()

        else:  # blackbox — pure DAST, no SAST JSON to import
            # Phase: Path fuzzing (ffuf + feroxbuster)
            if modules.get("path_fuzzing", True):
                await self._update_phase("path_fuzzing", 12)
                await self._run_ffuf()
                await self._check_cancel_requested()
                if modules.get("feroxbuster", True):
                    await self._run_feroxbuster()
                    await self._check_cancel_requested()

            # Phase: Server audit (nikto + testssl)
            if modules.get("server_audit", True):
                await self._update_phase("server_audit", 16)
                await self._run_nikto()
                await self._check_cancel_requested()
            if modules.get("testssl", True):
                await self._run_testssl()
                await self._check_cancel_requested()

            # Phase: Endpoint discovery
            await self._update_phase("endpoint_discovery", 20)
            await self._run_endpoint_discovery()
            await self._check_cancel_requested()

            # Phase: Fingerprinting
            await self._update_phase("fingerprinting", 24)
            await self._run_tech_fingerprinting()
            await self._check_cancel_requested()

            # Phase: Attack surface analysis
            await self._update_phase("attack_surface", 28)
            await self._run_attack_surface_analysis()
            await self._check_cancel_requested()

        # ── DAST PIPELINE (shared across all modes) ────────────────────────
        if modules.get("dast", True) and self.project.target_url:
            role_profiles = self._build_role_profiles()
            if role_profiles:
                for idx, profile in enumerate(role_profiles, 1):
                    await self._check_cancel_requested()
                    role_name = str(profile.get("role") or f"role_{idx}")
                    self._current_auth_role = role_name
                    before_count = len(self.dast_findings)

                    await self._update_phase("auth", 45)
                    await self._setup_auth_safe(profile)
                    await self._check_cancel_requested()

                    await self._update_phase("spider", 55)
                    await self._run_spider()
                    await self._run_journey_replay_warmup(role_name)
                    await self._check_cancel_requested()

                    await self._update_phase("waf_detection", 60)
                    await self._run_waf_detection()
                    await self._check_cancel_requested()

                    await self._update_phase("active_scan", 75)
                    await self._run_active_scan(auth_role=role_name)
                    await self._run_llm_planner_checkpoint("after_active_scan")
                    await self._run_targeted_retry_if_requested(auth_role=role_name)
                    await self._check_cancel_requested()

                    self._role_scan_stats.append({
                        "role": role_name,
                        "findings_added": len(self.dast_findings) - before_count,
                        "auth_success": bool(self._auth_credentials),
                    })
            else:
                await self._update_phase("auth", 45)
                await self._setup_auth_safe()
                await self._check_cancel_requested()

                await self._update_phase("spider", 55)
                await self._run_spider()
                await self._run_journey_replay_warmup("default")
                await self._check_cancel_requested()

                await self._update_phase("waf_detection", 60)
                await self._run_waf_detection()
                await self._check_cancel_requested()

                await self._update_phase("active_scan", 75)
                await self._run_active_scan()
                await self._run_llm_planner_checkpoint("after_active_scan")
                await self._run_targeted_retry_if_requested()
                await self._check_cancel_requested()

            # Extended DAST (Nuclei, Wapiti for blackbox)
            if modules.get("nuclei", modules.get("dast_extended", False)):
                await self._update_phase("dast_extended", 85)
                await self._run_dast_extended()
                await self._check_cancel_requested()

            # Wapiti for blackbox mode (covers XXE, LDAP injection, CRLF that ZAP misses)
            if scan_mode == "blackbox" and modules.get("wapiti", True):
                await self._update_phase("dast_extended", 87)
                await self._run_wapiti()
                await self._check_cancel_requested()

            # SQLMap — blackbox always; whitebox only when SAST flagged specific SQLi endpoints
            if modules.get("sqlmap", True) and (scan_mode == "blackbox" or self.sast_sqli_targets):
                await self._update_phase("dast_extended", 88)
                await self._run_sqlmap()
                await self._check_cancel_requested()

            # dalfox — blackbox always; whitebox only when SAST flagged specific XSS endpoints
            if modules.get("dalfox", True) and (scan_mode == "blackbox" or self.sast_xss_targets):
                await self._update_phase("dast_extended", 89)
                await self._run_dalfox()
                await self._check_cancel_requested()

            self._current_auth_role = ""

        # ── CORRELATION ──────────────────────────────────────────────────
        await self._check_cancel_requested()
        await self._update_phase("correlation", 90)
        self._infer_file_for_dynamic_routes()
        await self._run_correlation()
        await self._run_llm_planner_checkpoint("after_correlation")
        await self._check_cancel_requested()

        # Coverage (if enabled)
        if modules.get("coverage", False):
            await self._run_coverage_analysis()

        await self._finalize()

    async def _update_phase(self, phase: str, progress: int):
        """Update scan phase and notify via WebSocket."""
        await self._check_cancel_requested()
        self.scan.current_phase = phase
        self.scan.progress = progress
        await self.db.commit()
        await self.ws.send_scan_progress(self.scan.id, {
            "status": "running",
            "progress": progress,
            "phase": phase,
        })
        await self.ws.send_scan_log(self.scan.id, f"[{phase.upper()}] Starting phase...")

    # ── Safe wrappers for parallel phases ──────────────────────────────

    async def _run_ffuf(self):
        """Path fuzzing via ffuf (toggle: FFUF_ENABLED env var)."""
        from app.core.config import settings
        if not settings.FFUF_ENABLED:
            return
        if not (self.scan.modules_enabled or {}).get("path_fuzzing", True):
            logger.info("Path fuzzing disabled for this scan")
            return
        from app.scanners.ffuf_engine import FfufEngine
        engine = FfufEngine()
        depth = (self.scan.scan_config or {}).get("scan_depth", 5)
        paths = await engine.fuzz(self.project.target_url, depth=depth)
        if paths:
            self.routes.extend(paths)
            await self.ws.send_scan_log(
                self.scan.id, f"Path fuzzing discovered {len(paths)} hidden endpoints",
            )

    async def _run_nikto(self):
        """Server audit via Nikto (toggle: NIKTO_ENABLED env var)."""
        from app.core.config import settings
        if not settings.NIKTO_ENABLED:
            return
        if not (self.scan.modules_enabled or {}).get("server_audit", True):
            logger.info("Server audit disabled for this scan")
            return
        from app.scanners.nikto_engine import NiktoEngine
        engine = NiktoEngine()
        findings = await engine.scan(self.project.target_url)
        if findings:
            self.dast_findings.extend(findings)
            await self.ws.send_scan_log(
                self.scan.id, f"Nikto found {len(findings)} server issues",
            )

    async def _run_wapiti(self):
        """Alternative DAST via Wapiti (blackbox mode, optional toggle)."""
        try:
            from app.scanners.wapiti_engine import WapitiEngine
            engine = WapitiEngine()
            findings = await engine.scan(self.project.target_url)
            if findings:
                self.dast_findings.extend(findings)
                await self.ws.send_scan_log(
                    self.scan.id, f"Wapiti found {len(findings)} issues",
                )
        except Exception as exc:
            logger.warning("wapiti scan failed (non-fatal): %s", exc)
            await self.ws.send_scan_log(
                self.scan.id, f"Wapiti error (non-fatal, scan continues): {exc}",
            )

    async def _run_feroxbuster(self):
        """Recursive path fuzzing via feroxbuster (supplements ffuf)."""
        from app.core.config import settings
        if not settings.FEROXBUSTER_ENABLED:
            return
        from app.scanners.feroxbuster_engine import FeroxbusterEngine
        engine = FeroxbusterEngine()
        paths = await engine.fuzz(self.project.target_url)
        if paths:
            self.routes.extend(paths)
            await self.ws.send_scan_log(
                self.scan.id, f"feroxbuster discovered {len(paths)} paths recursively",
            )

    async def _run_testssl(self):
        """TLS/SSL audit via testssl.sh."""
        from app.core.config import settings
        if not settings.TESTSSL_ENABLED:
            return
        from app.scanners.testssl_engine import TestsslEngine
        engine = TestsslEngine()
        findings = await engine.scan(self.project.target_url)
        if findings:
            self.dast_findings.extend(findings)
            await self.ws.send_scan_log(
                self.scan.id, f"testssl found {len(findings)} TLS issue(s)",
            )

    async def _run_sqlmap(self):
        """SQL injection scanning via sqlmap."""
        try:
            from app.core.config import settings
            if not settings.SQLMAP_ENABLED:
                return
            from app.scanners.sqlmap_engine import SqlmapEngine
            engine = SqlmapEngine()
            findings = await engine.scan(self.project.target_url)
            if findings:
                self.dast_findings.extend(findings)
                await self.ws.send_scan_log(
                    self.scan.id, f"sqlmap found {len(findings)} SQL injection point(s)",
                )
            # SAST-guided: target specific endpoints flagged for SQLi
            seen = {self.project.target_url}
            for url in self.sast_sqli_targets:
                if url not in seen:
                    seen.add(url)
                    await self.ws.send_scan_log(self.scan.id, f"SQLMap → SAST-flagged: {url}")
                    targeted = await engine.scan(url)
                    if targeted:
                        self.dast_findings.extend(targeted)
        except Exception as exc:
            logger.warning("sqlmap scan failed (non-fatal): %s", exc)
            await self.ws.send_scan_log(
                self.scan.id, f"SQLMap error (non-fatal, scan continues): {exc}",
            )

    async def _run_dalfox(self):
        """XSS scanning via dalfox."""
        try:
            from app.core.config import settings
            if not settings.DALFOX_ENABLED:
                return
            from app.scanners.dalfox_engine import DalfoxEngine
            engine = DalfoxEngine()
            findings = await engine.scan(self.project.target_url)
            if findings:
                self.dast_findings.extend(findings)
                await self.ws.send_scan_log(
                    self.scan.id, f"dalfox found {len(findings)} XSS vulnerability(s)",
                )
            # SAST-guided: target specific endpoints flagged for XSS
            seen = {self.project.target_url}
            for url in self.sast_xss_targets:
                if url not in seen:
                    seen.add(url)
                    await self.ws.send_scan_log(self.scan.id, f"Dalfox → SAST-flagged: {url}")
                    targeted = await engine.scan(url)
                    if targeted:
                        self.dast_findings.extend(targeted)
        except Exception as exc:
            logger.warning("dalfox scan failed (non-fatal): %s", exc)
            await self.ws.send_scan_log(
                self.scan.id, f"Dalfox error (non-fatal, scan continues): {exc}",
            )

    async def _setup_auth_safe(self, role_profile: dict | None = None):
        """Run auth setup with error isolation — never raises.

        If auth fails the scan continues unauthenticated.
        """
        try:
            await self._setup_auth(role_profile)
        except Exception as exc:
            logger.exception("Auth setup failed: %s", exc)
            self._auth_credentials = None
            await self._add_phase_warning("auth", str(exc))
            await self.ws.send_scan_log(
                self.scan.id,
                f"Auth setup error ({exc}) — DAST will run unauthenticated",
            )

    def _build_role_profiles(self) -> list[dict]:
        """Build normalized role auth profiles from scan auth config.

        Supports:
        - auth_config.role_profiles: list[dict]
        - auth_config.roles: list[str|dict]
        """
        auth_cfg = self._ephemeral_auth_config or self.scan.auth_config or {}
        profiles: list[dict] = []

        role_profiles = auth_cfg.get("role_profiles")
        if isinstance(role_profiles, list):
            for idx, rp in enumerate(role_profiles, 1):
                if not isinstance(rp, dict):
                    continue
                role_name = str(rp.get("role") or rp.get("name") or f"role_{idx}").strip()
                profile = dict(rp)
                profile["role"] = role_name
                profiles.append(profile)

        roles = auth_cfg.get("roles")
        if isinstance(roles, list):
            for idx, entry in enumerate(roles, 1):
                if isinstance(entry, dict):
                    role_name = str(entry.get("role") or entry.get("name") or f"role_{idx}").strip()
                    profile = dict(entry)
                    profile["role"] = role_name
                    profiles.append(profile)
                elif isinstance(entry, str):
                    role_name = entry.strip()
                    if role_name:
                        profiles.append({"role": role_name})

        # De-duplicate by role name while preserving order.
        deduped: list[dict] = []
        seen: set[str] = set()
        for p in profiles:
            role_name = str(p.get("role", "")).strip()
            if not role_name or role_name in seen:
                continue
            seen.add(role_name)
            deduped.append(p)

        return deduped

    async def _run_journey_replay_warmup(self, role_name: str = "") -> None:
        """Replay configured business-journey steps to warm app state/routes."""
        if not self.project.target_url or not self._journey_steps:
            return

        from app.scanners.replay_adapter import replay_steps
        from app.core.config import settings

        scan_cfg = self.scan.scan_config or {}
        max_steps = max(1, min(int(scan_cfg.get("journey_replay_max_steps", 200)), 2000))
        steps = self._journey_steps[:max_steps]
        if not steps:
            return

        await self.ws.send_scan_log(
            self.scan.id,
            f"Replaying {len(steps)} journey step(s) before active scan"
            + (f" for role '{role_name}'" if role_name else ""),
        )

        replay_result = await replay_steps(
            target_url=self.project.target_url,
            steps=steps,
            auth=self._auth_credentials,
            timeout=max(3, min(int(scan_cfg.get("journey_replay_timeout", 12)), 30)),
            proxy_url=str(getattr(settings, "ZAP_API_URL", "") or ""),
        )

        record = {
            "role": role_name or "default",
            "steps_requested": len(steps),
            "executed": int(replay_result.get("executed", 0)),
            "failed": int(replay_result.get("failed", 0)),
            "proxied": int(replay_result.get("proxied", 0)),
        }
        sample_errors = replay_result.get("sample_errors", [])
        if isinstance(sample_errors, list) and sample_errors:
            record["sample_errors"] = sample_errors[:3]
        self._journey_replay_stats.append(record)

        await self.ws.send_scan_log(
            self.scan.id,
            "Journey replay complete: "
            f"executed={record['executed']}, failed={record['failed']}, proxied={record['proxied']}",
        )

    async def _run_targeted_retry_if_requested(self, auth_role: str = "") -> None:
        """Execute bounded targeted retry based on LLM retry hint."""
        scan_cfg = dict(self.scan.scan_config or {})
        hint = scan_cfg.get("llm_retry_hint")
        if not isinstance(hint, dict) or not hint:
            return

        role_key = auth_role or self._current_auth_role or "default"
        executed_roles = scan_cfg.get("llm_retry_executed_roles", [])
        if not isinstance(executed_roles, list):
            executed_roles = []
        if role_key in executed_roles:
            return

        endpoint_candidates = []
        for key in ("endpoints", "paths", "routes"):
            value = hint.get(key)
            if isinstance(value, list):
                endpoint_candidates.extend(str(x) for x in value if str(x).strip())
            elif isinstance(value, str) and value.strip():
                endpoint_candidates.append(value.strip())

        type_hints = hint.get("types")
        if not isinstance(type_hints, list):
            type_hints = []
        type_hints = [str(t).lower() for t in type_hints if str(t).strip()]

        norm_endpoints = {
            (ep if ep.startswith("/") else "/" + ep).rstrip("/").lower() or "/"
            for ep in endpoint_candidates
        }

        retry_routes: list[dict] = []
        if norm_endpoints:
            for route in self.routes:
                path = (str(route.get("path", "")).rstrip("/").lower() or "/")
                if path in norm_endpoints or any(path.startswith(ep + "/") for ep in norm_endpoints):
                    retry_routes.append(route)

        if not retry_routes and type_hints:
            cfg = dict(scan_cfg)
            cfg["llm_prioritized_vuln_types"] = type_hints
            retry_routes = self._select_prioritized_routes(self.routes, cfg)

        if not retry_routes:
            return

        max_retry_routes = max(1, min(int(hint.get("max_routes", 25)), 100))
        retry_routes = retry_routes[:max_retry_routes]

        extra_timeout = int(hint.get("extra_timeout", hint.get("timeout_delta", 300)) or 300)
        retry_cfg = dict(scan_cfg)
        retry_cfg["timeout"] = max(30, min(int(scan_cfg.get("timeout", 1800)) + max(0, extra_timeout), 14400))  # Increased from 7200 to 14400 (4 hours)

        await self.ws.send_scan_log(
            self.scan.id,
            f"[LLM] Running targeted retry for role '{role_key}' on {len(retry_routes)} route(s)",
        )

        await self._run_active_scan(
            auth_role=auth_role,
            routes_override=retry_routes,
            scan_config_override=retry_cfg,
            journey_source="llm_targeted_retry",
        )

        executed_roles.append(role_key)
        scan_cfg["llm_retry_executed_roles"] = sorted(set(executed_roles))
        self.scan.scan_config = scan_cfg
        await self.db.commit()

    async def _add_phase_warning(self, phase: str, error: str):
        """Record a non-fatal phase warning and notify via WebSocket."""
        warning = {"phase": phase, "error": error}
        self._phase_warnings.append(warning)
        await self.ws.send_phase_warning(self.scan.id, phase, error)
        await self.ws.send_scan_log(
            self.scan.id,
            f"WARNING: {phase} phase encountered an error: {error}. "
            "Scan will continue with remaining phases.",
        )

    # ── Core phase implementations ─────────────────────────────────────

    # ── Route artifacts ──────────────────────────────────────────────────

    async def _load_route_artifacts(self) -> None:
        """Load routes from OpenAPI specs, Postman collections, journey replays, workflow graphs."""
        # Optional spec/journey adapters for deeper route seeding
        from app.scanners.spec_adapter import load_spec_seed_routes
        from app.scanners.replay_adapter import load_journey_steps
        from app.workflow.service import load_project_workflow_routes

        source_path = self.project.local_path or ""

        effective_scan_cfg = dict(self.scan.scan_config or {})
        if not effective_scan_cfg.get("openapi_spec_file") and getattr(self.project, "openapi_spec_files", ""):
            effective_scan_cfg["openapi_spec_file"] = str(self.project.openapi_spec_files)
        if not effective_scan_cfg.get("postman_collection_file") and getattr(self.project, "postman_collection_files", ""):
            effective_scan_cfg["postman_collection_file"] = str(self.project.postman_collection_files)
        if not effective_scan_cfg.get("journey_replay_files") and getattr(self.project, "journey_replay_files", ""):
            effective_scan_cfg["journey_replay_files"] = str(self.project.journey_replay_files)

        seed_info = load_spec_seed_routes(source_path, effective_scan_cfg)
        replay_info = load_journey_steps(source_path, effective_scan_cfg)
        workflow_info = await load_project_workflow_routes(self.db, self.project.id)
        self._journey_steps = replay_info.get("steps", [])
        self._workflow_path_map = workflow_info.get("path_map", {})

        seeded_routes = (
            seed_info.get("openapi_routes", [])
            + seed_info.get("postman_routes", [])
            + replay_info.get("routes", [])
            + workflow_info.get("routes", [])
        )
        if seeded_routes:
            existing = {(r.get("path", "").rstrip("/") or "/", r.get("method", "")) for r in self.routes}
            added = 0
            for route in seeded_routes:
                path = (route.get("path", "").rstrip("/") or "/")
                method = route.get("method", "GET").upper()
                key = (path, method)
                if key in existing:
                    continue
                existing.add(key)
                self.routes.append(route)
                added += 1
            await self.ws.send_scan_log(
                self.scan.id,
                f"Loaded {added} additional seeded routes from file adapters",
            )

        self._seed_import_stats["openapi_file_routes"] = len(seed_info.get("openapi_routes", []))
        self._seed_import_stats["postman_routes"] = len(seed_info.get("postman_routes", []))
        self._seed_import_stats["journey_seed_routes"] = len(replay_info.get("routes", []))
        self._seed_import_stats["workflow_routes"] = len(workflow_info.get("routes", []))

        if seed_info.get("openapi_files"):
            await self.ws.send_scan_log(
                self.scan.id,
                f"OpenAPI file adapters loaded: {', '.join(seed_info['openapi_files'])}",
            )
        if seed_info.get("postman_files"):
            await self.ws.send_scan_log(
                self.scan.id,
                f"Postman adapters loaded: {', '.join(seed_info['postman_files'])}",
            )
        if replay_info.get("files"):
            await self.ws.send_scan_log(
                self.scan.id,
                f"Journey replay files loaded: {', '.join(replay_info['files'])}",
            )

    # ── Endpoint discovery (always runs) ─────────────────────────────────

    async def _run_endpoint_discovery(self) -> None:
        """Discover endpoints via spec scraping, directory fuzzing, GraphQL introspection.

        This runs regardless of source availability — it probes /openapi.json,
        /graphql, /.well-known/, and (optionally) fuzzes common API paths.
        Populated routes feed into the correlation engine's route index.
        """
        if not self.project.target_url:
            return

        scan_config = dict(self.scan.scan_config or {})
        enable_dir_fuzz = bool(scan_config.get("enable_dir_fuzz", False))

        # Try common spec paths — lightweight, no external tooling needed
        import httpx
        from urllib.parse import urljoin

        discovered: list[dict] = []
        async with httpx.AsyncClient(timeout=httpx.Timeout(8.0)) as client:
            for path in (
                "/robots.txt", "/sitemap.xml",
                "/openapi.json", "/swagger.json", "/swagger/v1/swagger.json",
                "/api/docs", "/api/v1/docs", "/docs", "/redoc",
                "/graphql", "/graphiql",
                "/.well-known/security.txt",
                "/health", "/healthcheck", "/status",
            ):
                url = urljoin(self.project.target_url.rstrip("/") + "/", path.lstrip("/"))
                try:
                    resp = await client.get(url, timeout=5)
                    if resp.status_code not in (404,):
                        discovered.append({
                            "path": path, "method": "GET",
                            "handler": "", "file": "", "line": 0,
                            "source": "spec_probe",
                        })
                except Exception:
                    continue

            # GraphQL introspection
            if any(r["path"] in ("/graphql", "/graphiql") for r in discovered):
                gql_url = urljoin(self.project.target_url.rstrip("/") + "/", "graphql")
                query = '{"query":"{__schema{types{name}}}"}'
                try:
                    resp = await client.post(gql_url, json=query, timeout=5)
                    if resp.status_code == 200 and "data" in resp.text:
                        await self.ws.send_scan_log(
                            self.scan.id, "GraphQL endpoint detected — introspection available"
                        )
                except Exception:
                    pass

        # Merge into routes (dedup by path+method)
        existing = {(r.get("path", "").rstrip("/") or "/", r.get("method", "")) for r in self.routes}
        added = 0
        for route in discovered:
            key = (route["path"].rstrip("/") or "/", route["method"])
            if key not in existing:
                existing.add(key)
                self.routes.append(route)
                added += 1

        self.scan.routes_discovered = len(self.routes)
        await self.ws.send_scan_log(
            self.scan.id,
            f"Endpoint discovery: found {added} new routes ({len(self.routes)} total)",
        )

        # Also load routes from artifacts (OpenAPI specs, Postman, workflows)
        # — these are available regardless of source availability
        await self._load_route_artifacts()

    # ── Tech fingerprinting ──────────────────────────────────────────────

    async def _run_tech_fingerprinting(self) -> None:
        """Fingerprint target tech stack from response signatures.

        Detects framework (Django/FastAPI/Express/etc.), server (nginx/apache),
        and WAF presence. The fingerprint guides ZAP policy selection in later
        phases.  Lightweight implementation using httpx probes.
        """
        if not self.project.target_url:
            return

        import httpx

        framework = None
        server_type = None
        language = None

        FRAMEWORK_SIGS = {
            "django": ["django", "csrftoken", "csrfmiddlewaretoken"],
            "flask": ["flask", "session"],
            "fastapi": ["openapi", "uvicorn", "starlette"],
            "express": ["express", "x-powered-by: express"],
            "nextjs": ["x-nextjs", "__next_data__"],
            "spring": ["spring", "x-application-context"],
            "rails": ["phusion", "_session"],
            "laravel": ["laravel_session", "livewire"],
        }

        SERVER_SIGS = {
            "nginx": ["nginx"],
            "apache": ["apache"],
            "iis": ["iis", "x-aspnet"],
            "caddy": ["caddy"],
            "gunicorn": ["gunicorn"],
        }

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as client:
                resp = await client.get(self.project.target_url, timeout=10)
                headers_str = str(dict(resp.headers)).lower()
                body_lower = resp.text[:5000].lower()

                for name, patterns in FRAMEWORK_SIGS.items():
                    if any(p in headers_str or p in body_lower for p in patterns):
                        framework = name
                        break

                for name, patterns in SERVER_SIGS.items():
                    if any(p in headers_str for p in patterns):
                        server_type = name
                        break

                lang_map = {
                    "django": "python", "flask": "python", "fastapi": "python",
                    "express": "node", "nextjs": "node",
                    "spring": "java", "rails": "ruby", "laravel": "php",
                }
                if framework:
                    language = lang_map.get(framework)
        except Exception:
            pass

        self._tech_fingerprint = {
            "framework": framework,
            "server": server_type,
            "language": language,
        }
        await self.ws.send_scan_log(
            self.scan.id,
            f"Fingerprinted: framework={framework or 'unknown'}, "
            f"server={server_type or 'unknown'}, language={language or 'unknown'}",
        )

    # ── WAF detection + rate limiting ─────────────────────────────────

    async def _run_waf_detection(self) -> None:
        """Detect WAF presence and apply rate limiting to ZAP.

        ponytail: this is rate limiting, not WAF bypass. A real bypass would
        inject ZAP scripts for header randomization, payload encoding, and IP
        rotation via the ZAP API (Phase 3). For now, slowing down requests
        avoids triggering rate-based WAF blocks — it does NOT evade
        signature-based WAFs (Cloudflare, AWS WAF, Imperva).
        """
        if not self.project.target_url:
            return

        scan_config = dict(self.scan.scan_config or {})
        auto_waf = bool(scan_config.get("waf_bypass_auto", True))

        waf_detected = False
        waf_name = None

        # WAF detection via benign canary probe
        if auto_waf:
            try:
                import httpx
                async with httpx.AsyncClient(timeout=httpx.Timeout(8.0)) as client:
                    # Benign probe — not an attack payload, just a unique
                    # path that WAF response headers will tag regardless of
                    # block/allow decision.
                    probe_url = self.project.target_url.rstrip("/") + "/?_waf_check=1"
                    resp = await client.get(probe_url, timeout=5)
                    body_lower = resp.text.lower()
                    # Generic WAF indicators (present on all responses, not just blocked)
                    waf_indicators = [
                        "cf-ray", "__cf_chl", "cloudflare",  # Cloudflare
                        "x-amzn-requestid", "x-amzn-errortype",  # AWS WAF
                        "modsecurity", "mod_security",
                        "blocked", "challenge", "waf",
                    ]
                    if any(ind in body_lower or ind in str(dict(resp.headers)).lower() for ind in waf_indicators):
                        waf_detected = True
                        waf_name = "detected"
            except Exception:
                pass

        self.waf_detected = waf_detected

        # Apply ZAP rate limiting (always set safe defaults)
        try:
            from app.scanners.dast_engine import get_zap_client
            zap = get_zap_client()
            if waf_detected:
                zap.scanner.set_option_delay_in_ms("2000")
                zap.scanner.set_option_thread_per_host("1")
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"WAF detected — reducing scan rate (delay=2s, threads=1)",
                )
            else:
                from app.core.config import settings as _s
                manual_delay = scan_config.get("waf_delay_ms", _s.ZAP_NO_WAF_DELAY_MS)
                manual_threads = scan_config.get("waf_threads", _s.ZAP_NO_WAF_THREADS)
                zap.scanner.set_option_delay_in_ms(str(manual_delay))
                zap.scanner.set_option_thread_per_host(str(manual_threads))
        except Exception:
            pass

    # ── Extended DAST (Nuclei) ──────────────────────────────────────────

    async def _run_dast_extended(self) -> None:
        """Run optional Nuclei template-based CVE scanning after ZAP active scan.

        Falls back gracefully if nuclei CLI is not installed.
        Results are fed into dast_findings for correlation.
        """
        if not self.project.target_url:
            return

        scan_config = dict(self.scan.scan_config or {})
        enabled = bool(scan_config.get("nuclei_enabled", True))
        if not enabled:
            await self.ws.send_scan_log(self.scan.id, "Nuclei scanning disabled via config")
            return

        from app.scanners.nuclei_engine import run_nuclei
        from app.core.config import settings

        await self.ws.send_scan_log(self.scan.id, "Running Nuclei extended scans...")

        rate_limit = int(scan_config.get("nuclei_rate_limit", settings.NUCLEI_DEFAULT_RATE_LIMIT))
        # Inherit WAF state from detection phase — don't blast the target
        # with the full default rate when ZAP is crawling at 1 thread / 2s delay.
        if getattr(self, "waf_detected", False):
            rate_limit = min(rate_limit, 10)
            await self.ws.send_scan_log(
                self.scan.id,
                f"WAF detected — throttling Nuclei to {rate_limit} req/s",
            )

        nuclei_results = await run_nuclei(
            target_url=self.project.target_url,
            severity=scan_config.get("nuclei_severity", "medium,high,critical"),
            rate_limit=rate_limit,
            timeout=int(scan_config.get("nuclei_timeout", 300)),
        )

        if not nuclei_results:
            await self.ws.send_scan_log(
                self.scan.id,
                "Nuclei returned no results (CLI may not be installed)",
            )
            return

        self.dast_findings.extend(nuclei_results)
        await self.ws.send_scan_log(
            self.scan.id,
            f"Nuclei found {len(nuclei_results)} findings",
        )

    async def _run_attack_surface_analysis(self) -> None:
        """Classify discovered endpoints by risk tier to focus DAST tools.

        Rule-based URL pattern matching — no LLM needed, < 1ms.
        Populates self.attack_surface (tier → URL list) and self.high_risk_endpoints
        (critical + high URLs merged with SAST-flagged targets). Downstream tools
        use high_risk_endpoints for priority scanning.
        """
        if not self.routes:
            await self.ws.send_scan_log(self.scan.id, "Attack surface: no routes to classify yet")
            return

        CRITICAL = ["/login", "/signin", "/auth", "/oauth", "/token", "/password", "/forgot", "/reset", "/api/key", "/secret", "/credential"]
        HIGH = ["/admin", "/manage", "/dashboard", "/upload", "/import", "/file", "/attachment", "/graphql", "/gql", "/api/user", "/api/account", "/api/admin"]
        LOW = ["/static", "/assets", "/css", "/js", "/img", "/fonts", "/favicon", "/_health", "/health", "/ping", "/robots", "/sitemap"]
        UPLOAD = ["/upload", "/file", "/attachment", "/media", "/import", "/export"]

        tiers: dict[str, list[str]] = {"critical": [], "high": [], "medium": [], "low": []}
        base = (self.project.target_url or "").rstrip("/")

        for route in self.routes:
            path = route.get("path", "").lower()
            full_url = base + path if base else path

            if any(p in path for p in CRITICAL):
                tier = "critical"
            elif any(p in path for p in HIGH):
                tier = "high"
            elif any(p in path for p in LOW):
                tier = "low"
            else:
                tier = "medium"

            tiers[tier].append(full_url)

            # File upload endpoints are always at least high risk (potential RCE)
            if any(p in path for p in UPLOAD) and tier not in ("critical",):
                if full_url not in tiers["high"]:
                    tiers["high"].append(full_url)

        # Merge SAST-guided targets into high-risk list
        sast_guided = list(dict.fromkeys(self.sast_sqli_targets + self.sast_xss_targets))

        self.attack_surface = tiers
        self.high_risk_endpoints = list(dict.fromkeys(
            tiers["critical"] + tiers["high"] + sast_guided
        ))

        counts = {k: len(v) for k, v in tiers.items()}
        await self.ws.send_scan_log(
            self.scan.id,
            f"Attack surface: critical={counts['critical']} high={counts['high']} "
            f"medium={counts['medium']} low={counts['low']} | "
            f"high-risk focus: {len(self.high_risk_endpoints)} URLs",
        )
        if sast_guided:
            await self.ws.send_scan_log(
                self.scan.id,
                f"SAST-guided priority targets: {len(sast_guided)} endpoint(s) "
                f"(SQLi: {len(self.sast_sqli_targets)}, XSS: {len(self.sast_xss_targets)})",
            )

    def _extract_sast_guidance(self, finding_data: dict) -> None:
        """Seed self.routes and SAST target lists from a parsed SAST finding.

        Called for every finding imported from TrustScan or external file.
        Ensures DAST tools (ZAP spider, sqlmap, dalfox) know exactly which
        endpoints SAST flagged as risky before they start scanning.
        """
        from urllib.parse import urlparse, urljoin

        endpoint = finding_data.get("endpoint", "")
        if not endpoint:
            return

        # Seed ZAP site tree from SAST endpoint (not just Noir-format routes)
        parsed = urlparse(endpoint)
        path = parsed.path if parsed.netloc else endpoint
        if path and path.startswith("/"):
            method = (finding_data.get("http_method") or "GET").upper()
            existing = {
                (r.get("path", "").rstrip("/") or "/", r.get("method", "GET"))
                for r in self.routes
            }
            if (path.rstrip("/") or "/", method) not in existing:
                self.routes.append({"path": path, "method": method, "from_sast": True})

        # Build targeted vuln lists used by sqlmap and dalfox
        vuln_type = finding_data.get("vulnerability_type", "")
        if vuln_type in ("sqli", "xss"):
            base = self.project.target_url or ""
            full_url = endpoint if endpoint.startswith("http") else urljoin(base, endpoint)
            if vuln_type == "sqli" and full_url not in self.sast_sqli_targets:
                self.sast_sqli_targets.append(full_url)
            elif vuln_type == "xss" and full_url not in self.sast_xss_targets:
                self.sast_xss_targets.append(full_url)

    async def _import_external_findings(self) -> bool:
        """Import findings from TrustScan or an uploaded external JSON file.

        Returns:
            True if findings were loaded, False otherwise.
        """
        scan_config = dict(self.scan.scan_config or {})

        # TrustScan API integration — fetch findings live from TrustScan platform
        if (
            self.project.trustscan_job_id
            and self.project.trustscan_token_encrypted
            and self.project.trustscan_url
        ):
            await self.ws.send_scan_log(
                self.scan.id,
                f"Fetching SAST findings from TrustScan job {self.project.trustscan_job_id} ...",
            )
            try:
                from app.core.security import decrypt_token
                from app.integrations.trustscan_client import TrustScanClient

                token = decrypt_token(self.project.trustscan_token_encrypted)
                async with TrustScanClient(
                    self.project.trustscan_url, token
                ) as client:
                    findings_data = await client.get_findings(self.project.trustscan_job_id)

                if findings_data:
                    importer = ExternalFindingImporter()
                    trustscan_findings = importer.import_findings(
                        findings_data,
                        format="trustscan",
                        auto_detect=False,
                    )
                    if trustscan_findings:
                        async with self._db_lock:
                            for finding_data in trustscan_findings:
                                finding = Finding(
                                    scan_id=self.scan.id,
                                    title=finding_data.get("title", "TrustScan Finding"),
                                    vulnerability_type=finding_data.get("vulnerability_type", "unknown"),
                                    severity=finding_data.get("severity", "medium"),
                                    confidence="probable",
                                    cwe=finding_data.get("cwe", ""),
                                    endpoint=finding_data.get("endpoint", ""),
                                    parameter=finding_data.get("parameter", ""),
                                    file_path=finding_data.get("file_path", ""),
                                    line_number=finding_data.get("line_number", 0),
                                    code_snippet=finding_data.get("code_snippet", ""),
                                    scanner_source="trustscan",
                                    scanner_rule_id=finding_data.get("rule_id", ""),
                                    remediation_text=finding_data.get("remediation", ""),
                                    raw_scanner_output=finding_data.get("raw", {}),
                                )
                                self.db.add(finding)
                                self.all_findings.append(finding)
                                self._extract_sast_guidance(finding_data)
                            await self.db.commit()
                        await self.ws.send_scan_log(
                            self.scan.id,
                            f"Loaded {len(trustscan_findings)} findings from TrustScan.",
                        )
                        return True
            except Exception as e:
                logger.warning("Failed to fetch TrustScan findings: %s", e)
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"TrustScan fetch failed: {e}. Continuing without external findings.",
                )

        findings_path = scan_config.get("external_findings_path", "")

        if not findings_path:
            await self.ws.send_scan_log(
                self.scan.id,
                "No external findings file configured. Skipping import.",
            )
            return False

        path = Path(findings_path)
        if not path.exists():
            await self.ws.send_scan_log(
                self.scan.id,
                f"External findings file not found: {findings_path}. Skipping.",
            )
            return False

        await self.ws.send_scan_log(
            self.scan.id,
            f"Importing external findings from: {path.name}",
        )

        fmt = scan_config.get("external_findings_format") or None
        imported = ExternalFindingImporter.import_from_file(str(path), format=fmt)

        if not imported:
            await self.ws.send_scan_log(
                self.scan.id,
                "No findings could be parsed from the external file (0 findings).",
            )
            return False

        # Separate route-type findings (from Noir) from actual vulnerability findings
        route_findings = [f for f in imported if f.get("_noir_route")]
        vuln_findings = [f for f in imported if not f.get("_noir_route")]

        # Import route findings into orchestrator routes
        for rf in route_findings:
            nr = rf.get("_noir_route", {})
            route_entry = {
                "path": nr.get("path", "/"),
                "method": nr.get("method", "GET").upper(),
                "handler": "",
                "file": nr.get("file", ""),
                "line": 0,
            }
            existing = {
                (r.get("path", "").rstrip("/") or "/", r.get("method", ""))
                for r in self.routes
            }
            route_key = (route_entry["path"].rstrip("/") or "/", route_entry["method"])
            if route_key not in existing:
                self.routes.append(route_entry)

        async with self._db_lock:
            for finding_data in vuln_findings:
                finding = Finding(
                    scan_id=self.scan.id,
                    title=finding_data.get("title", "External Finding"),
                    vulnerability_type=finding_data.get("vulnerability_type", "unknown"),
                    severity=finding_data.get("severity", "medium"),
                    confidence="probable",
                    cwe=finding_data.get("cwe", ""),
                    owasp_category=finding_data.get("owasp_category", ""),
                    endpoint=finding_data.get("endpoint", ""),
                    parameter=finding_data.get("parameter", ""),
                    file_path=finding_data.get("file_path", ""),
                    line_number=finding_data.get("line_number", 0),
                    code_snippet=finding_data.get("code_snippet", ""),
                    data_flow=finding_data.get("data_flow", ""),
                    scanner_source="external",
                    scanner_rule_id=finding_data.get("rule_id", ""),
                    remediation_text=finding_data.get("remediation", ""),
                    raw_scanner_output=finding_data.get("raw", {}),
                )
                self.db.add(finding)
                self.all_findings.append(finding)
                self._extract_sast_guidance(finding_data)
            await self.db.commit()

        # Stream findings to UI
        for finding_data in vuln_findings:
            await self.ws.send_finding(self.scan.id, finding_data)

        self.scan.routes_discovered = len(self.routes)
        await self.ws.send_scan_log(
            self.scan.id,
            f"Imported {len(vuln_findings)} vulnerability findings and "
            f"{len(route_findings)} routes from external file.",
        )
        if self.sast_sqli_targets:
            await self.ws.send_scan_log(
                self.scan.id,
                f"SAST flagged {len(self.sast_sqli_targets)} SQLi endpoint(s) — sqlmap will target these",
            )
        if self.sast_xss_targets:
            await self.ws.send_scan_log(
                self.scan.id,
                f"SAST flagged {len(self.sast_xss_targets)} XSS endpoint(s) — dalfox will target these",
            )
        await self.db.commit()
        return True

    async def _setup_auth(self, role_profile: dict | None = None):
        """Set up authentication for DAST scanning.

        Strategy (in order):
        1. Try REST API login (direct HTTP POST) — works for API-first apps.
        2. Fall back to Playwright browser login — works for HTML-form apps.
        3. If both fail, run unauthenticated.
        """
        await self.ws.send_scan_log(self.scan.id, "Setting up authentication for DAST...")

        auth_config = dict(
            self._ephemeral_auth_config
            or self.scan.auth_config
            or getattr(self.project, "auth_config", None)
            or {}
        )
        if isinstance(role_profile, dict):
            role_name = str(role_profile.get("role", "")).strip()
            if role_name:
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"[ROLE] Applying auth profile for role '{role_name}'",
                )
            # Overlay role-specific auth fields onto scan-level auth config.
            for key in (
                "auth_type",
                "username",
                "password",
                "login_url",
                "playwright_script",
                "script",
                "token",
                "cookies",
            ):
                if key in role_profile and role_profile.get(key) not in (None, ""):
                    auth_config[key] = role_profile.get(key)

        # Frontend uses playwright_script; PlaywrightRunner expects script
        if auth_config.get("playwright_script") and not auth_config.get("script"):
            auth_config["script"] = auth_config.get("playwright_script")

        # HTTP Basic Auth — encode credentials and inject as Authorization: Basic header via ZAP.
        # No login flow needed; bypass the REST probe + Playwright paths entirely.
        if auth_config.get("auth_type") == "basic" and auth_config.get("username"):
            import base64 as _b64
            creds = _b64.b64encode(
                f"{auth_config['username']}:{auth_config.get('password', '')}".encode()
            ).decode()
            self._auth_credentials = {
                "success": True,
                "token": f"Basic {creds}",
                "cookies": [],
            }
            await self.ws.send_scan_log(
                self.scan.id,
                "HTTP Basic Auth configured — ZAP will inject Authorization: Basic header.",
            )
            return

        # Fast path: if caller already provided token/cookies, use them directly.
        if auth_config.get("token") or auth_config.get("cookies"):
            self._auth_credentials = {
                "success": True,
                "token": auth_config.get("token"),
                "cookies": auth_config.get("cookies") or [],
                "headers": (
                    {"Authorization": f"Bearer {auth_config.get('token')}"}
                    if auth_config.get("token")
                    else {}
                ),
            }
            await self.ws.send_scan_log(
                self.scan.id,
                "Auth credentials supplied in config — reusing provided token/cookies",
            )
            return

        # ── Step 1: Try REST API login first ──────────────────────────
        # This is critical for API-first apps (VAmPI, etc.) where there
        # are no HTML forms — Playwright would fail.
        await self.ws.send_scan_log(
            self.scan.id, "Attempting REST API login (direct HTTP)..."
        )
        try:
            from app.auth.api_auth import RestApiAuthenticator

            api_auth = RestApiAuthenticator()
            api_result = await api_auth.authenticate(
                self.project.target_url, auth_config
            )

            if api_result.get("success"):
                self._auth_credentials = api_result
                login_ep = api_result.get("login_endpoint", "?")
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"REST API login successful (endpoint: {login_ep}) "
                    f"— JWT token acquired, DAST will use authenticated session",
                )
                return  # done — skip Playwright
            else:
                api_err = api_result.get("error", "unknown")
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"REST API login not available ({api_err}) — trying browser login...",
                )
        except Exception as exc:
            logger.debug("REST API auth attempt failed: %s", exc, exc_info=True)
            await self.ws.send_scan_log(
                self.scan.id,
                f"REST API auth probe error: {exc} — trying browser login...",
            )

        # ── Step 2: Source-based auth detection → Playwright ──────────
        if not auth_config:
            await self.ws.send_scan_log(
                self.scan.id, "No auth config provided. Auto-detecting from source..."
            )
            from app.analyzers.auth_detector import AuthDetector
            detector = AuthDetector()
            auth_info = await detector.detect_auth(self.project.local_path)
            auth_type = auth_info.get("auth_type", "none")
            await self.ws.send_scan_log(
                self.scan.id, f"Auth detection result: {auth_type}"
            )

            if auth_type != "none" and auth_info.get("login_routes"):
                from app.auth.auth_script_gen import AuthScriptGenerator
                gen = AuthScriptGenerator()
                auth_config = gen.generate_config(auth_info, self.project.target_url)

        # ── Step 3: Playwright browser login ──────────────────────────
        if auth_config and (
            auth_config.get("username")
            or auth_config.get("script")
            or auth_config.get("playwright_script")
        ):
            # Warn about CAPTCHA / MFA that would prevent automation
            try:
                import httpx
                async with httpx.AsyncClient(timeout=httpx.Timeout(8.0)) as _cap_client:
                    login_url = auth_config.get("login_url") or self.project.target_url
                    cap_resp = await _cap_client.get(login_url, timeout=5)
                    cap_body = cap_resp.text.lower()
                    captcha_hints = ["recaptcha", "hcaptcha", "g-recaptcha-response",
                                     "cf-turnstile", "challenge-platform"]
                    if any(h in cap_body for h in captcha_hints):
                        await self.ws.send_scan_log(
                            self.scan.id,
                            "WARNING: CAPTCHA/challenge detected on login page — "
                            "automated login will likely fail. Scan will proceed unauthenticated."
                        )
            except Exception:
                pass

            from app.auth.playwright_runner import PlaywrightRunner
            runner = PlaywrightRunner()
            auth_result = await runner.run_login(self.project.target_url, auth_config)

            if auth_result.get("success"):
                self._auth_credentials = auth_result
                await self.ws.send_scan_log(
                    self.scan.id, "Browser login successful — DAST will use authenticated session"
                )
            else:
                self._auth_credentials = None
                err = auth_result.get("error", "unknown")
                await self.ws.send_scan_log(
                    self.scan.id, f"Browser login failed ({err}) — DAST will run unauthenticated"
                )
        else:
            self._auth_credentials = None
            await self.ws.send_scan_log(
                self.scan.id, "No auth config — DAST will run unauthenticated"
            )

    async def _run_spider(self):
        """Spider the target application using discovered routes."""
        await self._check_cancel_requested()
        await self.ws.send_scan_log(self.scan.id, "Spidering target application...")

        from app.scanners.dast_engine import DASTEngine

        dast = DASTEngine()
        try:
            await self.ws.send_scan_log(
                self.scan.id, "Waiting for ZAP access slot (concurrency semaphore)..."
            )
            async with _dast_semaphore:
                spider_routes = await dast.spider(
                    self.project.target_url,
                    self.routes,
                    self.scan.scan_config,
                    auth=self._auth_credentials,
                    stop_requested=self._is_cancel_requested,
                )

            if spider_routes:
                existing_paths = {
                    (r.get("path") or "").rstrip("/") or "/"
                    for r in self.routes
                }
                new_routes = []
                for route in spider_routes:
                    path = (route.get("path") or "").rstrip("/") or "/"
                    if path not in existing_paths:
                        existing_paths.add(path)
                        new_routes.append(route)
                self.routes.extend(new_routes)

            self.scan.routes_discovered = len(self.routes)
            cfg = dict(self.scan.scan_config or {})
            cfg["discovered_routes"] = self.routes
            self.scan.scan_config = cfg
            await self.db.commit()
            await self._check_cancel_requested()

            await self.ws.send_scan_log(self.scan.id, "Spider completed")
        except Exception as e:
            await self.ws.send_scan_log(self.scan.id, f"Spider warning: {e}")

    async def _run_active_scan(
        self,
        auth_role: str = "",
        routes_override: list[dict] | None = None,
        scan_config_override: dict | None = None,
        journey_source: str = "",
    ):
        """Run ZAP active scan with context-aware payloads."""
        await self.ws.send_scan_log(self.scan.id, "Running active scan...")
        await self.ws.send_scan_log(
            self.scan.id,
            "Active scan can take 20-40 minutes on complex targets — please do not cancel.",
        )

        from app.scanners.dast_engine import DASTEngine

        dast = DASTEngine()
        try:
            # If context-aware payloads enabled, pass sink info
            scan_config = dict(scan_config_override or (self.scan.scan_config or {}))
            if routes_override is not None:
                base_routes = list(routes_override)
            else:
                base_routes = self.routes
            active_routes = self._select_prioritized_routes(base_routes, scan_config)
            if (
                isinstance(scan_config.get("llm_prioritized_vuln_types"), list)
                and active_routes != base_routes
            ):
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"Applying LLM vulnerability prioritization to {len(active_routes)} routes",
                )

            def _norm_path(v: str) -> str:
                raw = (v or "").split("?", 1)[0].rstrip("/").lower()
                return raw or "/"

            journey_paths = {
                _norm_path(str(route.get("path", "")))
                for route in active_routes
                if str(route.get("source", "")).startswith("journey_replay")
            }

            workflow_paths = {
                _norm_path(str(route.get("path", ""))): {
                    "graph_id": str(route.get("workflow_graph_id", "")),
                    "step_id": str(route.get("workflow_step_id", "")),
                }
                for route in active_routes
                if route.get("workflow_graph_id") and route.get("workflow_step_id")
            }

            # Progress callback: maps ZAP's 0-100% to overall 75-85% range
            # so the user sees the progress bar moving during the active scan.
            _last_reported_zap_pct = [-1]

            async def _active_scan_progress(zap_pct: int) -> None:
                if zap_pct <= _last_reported_zap_pct[0]:
                    return
                _last_reported_zap_pct[0] = zap_pct
                overall = 75 + int(zap_pct * 0.10)  # 75% → 85% as ZAP goes 0→100
                self.scan.progress = overall
                await self.db.commit()
                await self.ws.send_scan_progress(self.scan.id, {
                    "status": "running",
                    "progress": overall,
                    "phase": "active_scan",
                    "zap_progress": zap_pct,
                })
                if zap_pct % 10 == 0:
                    await self.ws.send_scan_log(
                        self.scan.id,
                        f"Active scan progress: {zap_pct}% (overall: {overall}%)",
                    )

            await self.ws.send_scan_log(
                self.scan.id, "Waiting for ZAP access slot (concurrency semaphore)..."
            )
            async with _dast_semaphore:
                if scan_config.get("context_aware_payloads", True):
                    from app.analyzers.sink_detector import SinkDetector
                    sink_detector = SinkDetector()
                    sinks = await sink_detector.detect_sinks(self.project.local_path)
                    dast_results = await dast.active_scan(
                        self.project.target_url,
                        active_routes,
                        sinks,
                        auth=self._auth_credentials,
                        scan_config=scan_config,
                        stop_requested=self._is_cancel_requested,
                        on_progress=_active_scan_progress,
                    )
                else:
                    dast_results = await dast.active_scan(
                        self.project.target_url,
                        active_routes,
                        auth=self._auth_credentials,
                        scan_config=scan_config,
                        stop_requested=self._is_cancel_requested,
                        on_progress=_active_scan_progress,
                    )

            # Save partial results FIRST, before checking cancellation.
            # Even if the scan was stopped mid-way, ZAP already found vulnerabilities
            # that are worth keeping. Checking cancellation after preserves them.

            # Keep cumulative DAST results across role scans/retries.
            # PHASE 1: Attach auth_role to each finding for role-aware correlation
            if auth_role or self._current_auth_role:
                role = auth_role or self._current_auth_role
                for finding_data in dast_results:
                    finding_data["_auth_role"] = role
            
            self.dast_findings.extend(dast_results)

            for finding_data in dast_results:
                endpoint_norm = _norm_path(str(finding_data.get("endpoint", "")))
                matched_journey = False
                if endpoint_norm and journey_paths:
                    matched_journey = any(
                        endpoint_norm == jp or endpoint_norm.startswith(jp + "/")
                        for jp in journey_paths
                    )

                workflow_match = None
                if endpoint_norm:
                    if endpoint_norm in workflow_paths:
                        workflow_match = workflow_paths.get(endpoint_norm)
                    elif self._workflow_path_map:
                        for p, candidates in self._workflow_path_map.items():
                            if endpoint_norm == p or endpoint_norm.startswith(p + "/"):
                                if candidates:
                                    workflow_match = candidates[0]
                                    break

                repro_bundle = {
                    "endpoint": finding_data.get("endpoint", ""),
                    "method": finding_data.get("http_method", ""),
                    "parameter": finding_data.get("parameter", ""),
                    "payload": finding_data.get("payload", ""),
                    "response_evidence": finding_data.get("evidence", ""),
                    "source": finding_data.get("source", "zap"),
                }
                if workflow_match:
                    repro_bundle["workflow_graph_id"] = workflow_match.get("graph_id", "")
                    repro_bundle["workflow_step_id"] = workflow_match.get("step_id", "")

                finding = Finding(
                    scan_id=self.scan.id,
                    title=finding_data.get("title", "DAST Finding"),
                    vulnerability_type=finding_data.get("vulnerability_type", "unknown"),
                    severity=finding_data.get("severity", "medium"),
                    confidence=finding_data.get("confidence", "observed"),
                    cwe=finding_data.get("cwe", ""),
                    endpoint=finding_data.get("endpoint", ""),
                    http_method=finding_data.get("http_method", ""),
                    parameter=finding_data.get("parameter", ""),
                    payload=finding_data.get("payload", ""),
                    response_code=finding_data.get("response_code", 0),
                    response_evidence=finding_data.get("evidence", ""),
                    auth_role=auth_role or self._current_auth_role,
                    journey_source=(
                        journey_source
                        or ("journey_replay" if matched_journey else finding_data.get("journey_source", ""))
                    ),
                    workflow_graph_id=(workflow_match or {}).get("graph_id", ""),
                    workflow_step_id=(workflow_match or {}).get("step_id", ""),
                    repro_bundle=repro_bundle,
                    scanner_source="zap",
                    scanner_rule_id=finding_data.get("alert_ref", ""),
                    remediation_text=finding_data.get("remediation", ""),
                    raw_scanner_output=finding_data.get("raw", {}),
                )
                self.db.add(finding)
                self.all_findings.append(finding)
                await self.ws.send_finding(self.scan.id, finding_data)

            await self.db.commit()
            await self.ws.send_scan_log(
                self.scan.id, f"Active scan found {len(dast_results)} issues"
            )
            # Check cancellation AFTER saving results so partial findings are preserved
            await self._check_cancel_requested()
        except asyncio.CancelledError:
            # Partial results were already committed above — just re-raise
            raise
        except Exception as e:
            await self.ws.send_scan_log(self.scan.id, f"Active scan error: {e}")
            raise

    @staticmethod
    def _select_prioritized_routes(routes: list[dict], scan_config: dict) -> list[dict]:
        """Select a focused route subset from planner prioritization hints."""
        priorities = scan_config.get("llm_prioritized_vuln_types")
        route_keywords = scan_config.get("plan_route_keywords")
        if not isinstance(route_keywords, list):
            route_keywords = []
        route_keywords = [str(k).strip().lower() for k in route_keywords if str(k).strip()]

        if route_keywords and not isinstance(priorities, list):
            selected = [
                route
                for route in routes
                if any(k in str(route.get("path", "")).lower() for k in route_keywords)
            ]
            if selected:
                return selected

        if not isinstance(priorities, list) or not priorities:
            return routes

        hints = {str(p).lower() for p in priorities if str(p).strip()}
        if not hints:
            return routes

        keyword_map = {
            "sqli": {"sql", "query", "db", "search", "filter"},
            "sql_injection": {"sql", "query", "db", "search", "filter"},
            "xss": {"comment", "html", "render", "content", "message"},
            "cmdi": {"exec", "cmd", "shell", "run", "system"},
            "command_injection": {"exec", "cmd", "shell", "run", "system"},
            "path_traversal": {"file", "download", "path", "upload"},
            "ssrf": {"url", "fetch", "proxy", "webhook"},
            "secret": {"token", "key", "secret", "credential"},
        }

        keywords = set()
        for hint in hints:
            keywords.update(keyword_map.get(hint, {hint}))

        selected = []
        for route in routes:
            path = str(route.get("path", "")).lower()
            if any(k in path for k in keywords):
                selected.append(route)

        if route_keywords:
            selected = [
                route
                for route in selected
                if any(k in str(route.get("path", "")).lower() for k in route_keywords)
            ] or selected

        # Keep fallback behavior if heuristic yields nothing.
        return selected or routes

    def _has_sink_for_file(self, file_path: str) -> bool:
        """Check whether a file has a detected dangerous sink."""
        if not file_path:
            return False
        normalized = file_path.replace("\\", "/").lower()
        for sink in self.sinks:
            sink_file = str(sink.get("file", "")).replace("\\", "/").lower()
            if sink_file == normalized:
                return True
        return False

    def _infer_file_for_dynamic_routes(self) -> None:
        """Infer 'file' key for dynamically-discovered routes.

        Spider and OpenAPI-imported routes have no 'file' key, making them
        invisible to the correlation engine's route index.  If a static
        route with a known file has the same path, copy the file reference.
        """
        _param_re = re.compile(r'[<{][^>}]+[>}]|:(\w+)')

        # Build path -> file from routes that already have file
        path_to_file: dict[str, str] = {}
        for route in self.routes:
            if route.get("file") and route.get("path"):
                norm = _param_re.sub('*', route["path"].strip().rstrip("/").lower() or "/")
                if norm not in path_to_file:
                    path_to_file[norm] = route["file"]

        inferred = 0
        for route in self.routes:
            if route.get("file"):
                continue
            path = route.get("path", "")
            if not path:
                continue
            norm = _param_re.sub('*', path.strip().rstrip("/").lower() or "/")
            if norm in path_to_file:
                route["file"] = path_to_file[norm]
                inferred += 1

        if inferred:
            logger.info("Inferred 'file' key for %d dynamically-discovered routes", inferred)

    async def _run_correlation(self):
        """Correlate SAST and DAST findings, assign confidence levels.
        
        PHASE 1 ENHANCEMENT: Supports role-aware correlation for IDOR and auth findings.
        If multiple auth roles were tested, groups DAST findings by role for semantic matching.
        """
        await self.ws.send_scan_log(self.scan.id, "Correlating findings...")

        # ponytail: correlation accuracy in black-box mode depends on the
        # external findings format. Noir JSON provides path→route mapping;
        # Semgrep/SARIF lack HTTP route context so hit rates are low.
        # A missed match (false negative) is safe — a false "confirmed" match
        # gives false confidence — so the heuristic errs on the side of
        # not matching when uncertain.

        from app.correlation.correlation_engine import CorrelationEngine
        from app.correlation.confidence_scorer import ConfidenceScorer
        from app.correlation.deduplicator import Deduplicator
        from app.correlation.risk_ranker import score_finding
        from app.core.config import settings
        from app.integrations.gitnexus_client import (
            GitNexusClient,
            GitNexusConfig,
            build_flow_evidence,
        )

        # Correlate
        correlator = CorrelationEngine(routes=self.routes)
        scorer = ConfidenceScorer()
        
        # PHASE 1: NEW - Group DAST findings by role for role-aware correlation (IDOR, auth)
        dast_findings_by_role = self._group_dast_findings_by_role()
        
        # Use role-aware correlation if multiple roles were tested
        if len(dast_findings_by_role) > 1:
            await self.ws.send_scan_log(
                self.scan.id,
                f"Using role-aware correlation for {len(dast_findings_by_role)} roles: "
                f"{', '.join(dast_findings_by_role.keys())}"
            )
            correlated = correlator.correlate_by_role([], dast_findings_by_role)
        else:
            correlated = correlator.correlate([], self.dast_findings)

        # Optional GitNexus context (flow confirmation) for correlation confidence
        gitnexus_enabled = bool(settings.GITNEXUS_ENABLED)
        gitnexus_cfg = GitNexusConfig.from_settings() if gitnexus_enabled else None
        gitnexus_client = GitNexusClient(config=gitnexus_cfg) if gitnexus_cfg else None

        # Update findings with correlation results and score confidence
        try:
            for finding in self.all_findings:
                sast_data = None
                dast_data = None
                match = correlator.find_match(finding, correlated)
                if match:
                    # Use ConfidenceScorer for precise confidence level
                    score_result = scorer.score(
                        sast_finding=match.get("sast_data"),
                        dast_finding=match.get("dast_data"),
                    )
                    finding.confidence = score_result["confidence"]

                    if gitnexus_client:
                        endpoint = None
                        file_path = None
                        if match.get("dast_data"):
                            endpoint = match["dast_data"].get("endpoint", "")
                        if match.get("sast_data"):
                            file_path = match["sast_data"].get("file_path", "")

                        if endpoint or file_path:
                            try:
                                api_impact = None
                                if endpoint:
                                    api_impact = await gitnexus_client.api_impact(
                                        route=endpoint,
                                    )
                                if (not api_impact or api_impact.get("error")) and file_path:
                                    api_impact = await gitnexus_client.api_impact(
                                        file=file_path,
                                    )
                                evidence = build_flow_evidence(
                                    api_impact,
                                    endpoint=endpoint,
                                    file_path=file_path,
                                )
                                finding.repro_bundle = {
                                    **(finding.repro_bundle or {}),
                                    "gitnexus": evidence,
                                }
                            except Exception as exc:
                                logger.warning("GitNexus evidence lookup failed: %s", exc)

                    if match.get("dast_data"):
                        finding.payload = match["dast_data"].get("payload", "")
                        finding.response_evidence = match["dast_data"].get("evidence", "")
                        if not finding.endpoint:
                            finding.endpoint = match["dast_data"].get("endpoint", "")
                        if not finding.http_method:
                            finding.http_method = match["dast_data"].get("http_method", "")
                        if not finding.parameter:
                            finding.parameter = match["dast_data"].get("parameter", "")
                    if match.get("sast_data"):
                        finding.code_snippet = match["sast_data"].get("code_snippet", finding.code_snippet)
                        finding.data_flow = match["sast_data"].get("data_flow", finding.data_flow)
                        if not finding.file_path:
                            finding.file_path = match["sast_data"].get("file_path", "")
                        if not finding.line_number:
                            finding.line_number = match["sast_data"].get("line_number", 0)
                else:
                    # Score standalone findings too
                    if getattr(finding, "scanner_source", "") in ("semgrep",):
                        sast_data = {"vulnerability_type": finding.vulnerability_type}
                    elif getattr(finding, "scanner_source", "") in ("zap",):
                        dast_data = {
                            "vulnerability_type": finding.vulnerability_type,
                            "payload": finding.payload,
                            "response_evidence": finding.response_evidence,
                        }
                    if sast_data or dast_data:
                        extra = None
                        if sast_data and finding.file_path:
                            extra = {"sink_detected": self._has_sink_for_file(finding.file_path)}
                        score_result = scorer.score(
                            sast_finding=sast_data,
                            dast_finding=dast_data,
                            extra=extra,
                        )
                        finding.confidence = score_result["confidence"]

                risk = score_finding(finding)
                finding.risk_score = int(risk["risk_score"])
                finding.risk_level = str(risk["risk_level"])
        finally:
            if gitnexus_client:
                await gitnexus_client.close()

        # Deduplicate
        deduplicator = Deduplicator()
        duplicates = deduplicator.find_duplicates(self.all_findings)
        for dup_finding in duplicates:
            dup_finding.status = "duplicate"

        await self.db.commit()

        verified_count = sum(
            1 for c in correlated if c["confidence"] == "verified"
        )

        # Log and persist correlation diagnostics for debugging
        diag = getattr(correlator, 'diagnostics', {})
        if diag:
            await self.ws.send_scan_log(
                self.scan.id,
                f"Correlation diagnostics: {diag.get('matched', 0)} matched, "
                f"{diag.get('type_mismatch', 0)} type mismatches, "
                f"{diag.get('endpoint_mismatch', 0)} endpoint mismatches, "
                f"{diag.get('guard_rejected', 0)} guard rejected",
            )
        self._correlation_diagnostics = diag

        corr_msg = f"Correlation complete. {verified_count} verified findings, {len(duplicates)} duplicates removed."
        await self.ws.send_scan_log(self.scan.id, corr_msg)

    async def _run_coverage_analysis(self):
        """Analyze scan coverage: route testing, finding distribution, and sink coverage."""
        await self.ws.send_scan_log(self.scan.id, "Analyzing scan coverage...")

        def _norm_path(value: str) -> str:
            raw = (value or "").split("?", 1)[0].strip().lower()
            if not raw:
                return "/"
            if not raw.startswith("/"):
                raw = "/" + raw
            return raw.rstrip("/") or "/"

        total_routes = len(self.routes)
        if total_routes == 0:
            self.scan.coverage_percentage = 0
            await self.ws.send_scan_log(self.scan.id, "No routes discovered — coverage is 0%")
            await self.db.commit()
            return

        # Mark routes as "tested" if any DAST finding references that endpoint
        dast_endpoints = {
            _norm_path(str(f.get("endpoint", "")))
            for f in self.dast_findings
            if f.get("endpoint")
        }
        for route in self.routes:
            route_path = _norm_path(str(route.get("path", "")))
            if route_path in dast_endpoints:
                route["tested"] = True
            # Also check partial matches (e.g. /api/users vs /api/users/1)
            elif route_path != "/" and any(
                ep.startswith(route_path + "/") for ep in dast_endpoints
            ):
                route["tested"] = True

        tested_routes = [r for r in self.routes if r.get("tested", False)]
        tested_count = len(tested_routes)
        coverage_pct = int((tested_count / total_routes) * 100)
        self.scan.coverage_percentage = coverage_pct

        # Build a coverage breakdown for logging
        untested = [r.get("path", "?") for r in self.routes if not r.get("tested", False)]

        await self.ws.send_scan_log(
            self.scan.id,
            f"Route coverage: {tested_count}/{total_routes} ({coverage_pct}%)"
        )
        if untested:
            logger.debug(f"Untested routes: {untested}")

    def _group_dast_findings_by_role(self) -> dict[str, list[dict]]:
        """Group DAST findings by auth role for role-aware correlation.
        
        PHASE 1 ENHANCEMENT: Enables IDOR and auth verification by tracking
        which role discovered each finding.
        
        Returns: {"admin": [...findings...], "user": [...findings...], ...}
        """
        by_role = {}
        for finding in self.dast_findings:
            role = finding.get("_auth_role", finding.get("auth_role", "default"))
            if role not in by_role:
                by_role[role] = []
            by_role[role].append(finding)
        
        if not by_role:
            by_role["default"] = self.dast_findings
        
        return by_role

    async def _verify_idor(self, sast_finding: dict, dast_findings_by_role: dict[str, list[dict]]) -> bool:
        """Verify IDOR vulnerability by checking if multiple roles access same endpoint.
        
        PHASE 1 ENHANCEMENT: IDOR is only verified when 2+ roles have findings for the
        same endpoint with matching parameters.
        """
        if sast_finding.get("type") not in {"idor", "auth", "privilege_escalation"}:
            return False
        
        endpoint = sast_finding.get("endpoint")
        parameter = sast_finding.get("parameter")
        
        if not endpoint or not parameter:
            return False
        
        # Check if multiple roles have findings for this endpoint
        roles_with_findings = []
        for role, findings in dast_findings_by_role.items():
            for dast_finding in findings:
                if dast_finding.get("endpoint") == endpoint:
                    roles_with_findings.append(role)
                    break
        
        # IDOR verified if 2+ roles accessed same endpoint with same parameter
        return len(roles_with_findings) >= 2

    async def _verify_auth_logic(self, sast_finding: dict, dast_findings_by_role: dict[str, list[dict]]) -> bool:
        """Verify authentication/privilege issues via role-level access differences.
        
        PHASE 1 ENHANCEMENT: Authentication logic flaws are verified when different
        roles have inconsistent access to endpoints (e.g., admin can access but user cannot).
        """
        if sast_finding.get("type") not in {"auth", "privilege_escalation", "idor"}:
            return False
        
        endpoint = sast_finding.get("endpoint")
        if not endpoint:
            return False
        
        # Collect which roles have access
        roles_with_access = set()
        roles_without_access = set()
        
        for role, findings in dast_findings_by_role.items():
            has_access = any(f.get("endpoint") == endpoint for f in findings)
            if has_access:
                roles_with_access.add(role)
            else:
                roles_without_access.add(role)
        
        # Auth logic issue is verified if some roles have access and others don't
        return len(roles_with_access) > 0 and len(roles_without_access) > 0

    async def _finalize(self):
        """Finalize the scan and update summary."""
        if await self._is_cancel_requested():
            self.scan.status = "cancelled"
            self.scan.completed_at = _utcnow_naive()
            await self.db.commit()
            await self.ws.send_scan_progress(self.scan.id, {
                "status": "cancelled",
                "progress": self.scan.progress,
                "phase": self.scan.current_phase,
            })
            return

        self.scan.status = "completed"
        self.scan.completed_at = _utcnow_naive()
        self.scan.progress = 100
        self.scan.current_phase = "complete"

        # Build summary (exclude duplicates from counts)
        active_findings = [
            f for f in self.all_findings if getattr(f, "status", "") != "duplicate"
        ]
        duplicate_count = len(self.all_findings) - len(active_findings)

        # Some scanners are static-only by design and should remain probable,
        # independent of dynamic correlation outcomes.
        static_probable_sources = {"semgrep", "detect-secrets"}
        probable_count = sum(
            1
            for f in active_findings
            if f.confidence == "probable"
            or (f.scanner_source in static_probable_sources and f.confidence != "verified")
        )

        observed_count = sum(
            1
            for f in active_findings
            if f.confidence == "observed" and f.scanner_source not in static_probable_sources
        )

        summary = {
            "total_findings": len(active_findings),
            "duplicates_removed": duplicate_count,
            "critical": sum(1 for f in active_findings if f.severity == "critical"),
            "high": sum(1 for f in active_findings if f.severity == "high"),
            "medium": sum(1 for f in active_findings if f.severity == "medium"),
            "low": sum(1 for f in active_findings if f.severity == "low"),
            "info": sum(1 for f in active_findings if f.severity == "info"),
            "verified": sum(1 for f in active_findings if f.confidence == "verified"),
            "probable": probable_count,
            "observed": observed_count,
            "risk_critical": sum(1 for f in active_findings if getattr(f, "risk_level", "") == "critical"),
            "risk_high": sum(1 for f in active_findings if getattr(f, "risk_level", "") == "high"),
            "risk_medium": sum(1 for f in active_findings if getattr(f, "risk_level", "") == "medium"),
            "risk_low": sum(1 for f in active_findings if getattr(f, "risk_level", "") == "low"),
        }
        # Include correlation diagnostics for API/UI debugging
        summary["correlation_diagnostics"] = getattr(self, '_correlation_diagnostics', {})
        # Include phase warnings so the UI can display non-fatal issues
        if self._phase_warnings:
            summary["phase_warnings"] = self._phase_warnings
        if self._seed_import_stats:
            summary["seed_imports"] = self._seed_import_stats
        if self._journey_replay_stats:
            summary["journey_replay"] = self._journey_replay_stats
        if self._role_scan_stats:
            summary["role_scan_stats"] = self._role_scan_stats
        if self._llm_planner_summary.get("enabled"):
            summary["llm_planner"] = self._llm_planner_summary
        if self.scan.plan_intent:
            summary["plan_intent"] = self.scan.plan_intent
        self.scan.results_summary = summary

        # Post-scan LLM synthesis (chains + FP flags + summary)
        # Never fails the scan — gracefully handles errors
        await self._run_post_scan_synthesis(active_findings)

        await self.db.commit()
        await self.ws.send_scan_complete(self.scan.id, summary)
        await self.ws.send_scan_log(self.scan.id, "Scan completed successfully!")

        # Email integration: fire-and-forget report delivery — never blocks
        # or fails the scan (send_scan_report_email swallows all errors).
        try:
            from app.integrations.email_client import send_scan_report_email

            asyncio.create_task(send_scan_report_email(self.scan.id, ws=self.ws))
        except Exception:  # noqa: BLE001
            logger.warning("email integration: failed to schedule report email")

    async def _run_llm_planner_checkpoint(self, checkpoint: str) -> None:
        """Run guarded LLM planner checkpoint, applying safe config updates only."""
        scan_cfg = self.scan.scan_config or {}
        if not bool(scan_cfg.get("llm_planner_enabled", False)):
            return

        try:
            from app.llm.provider_config import resolve_llm_provider_config_async
            from app.llm.client import LLMClient
            from app.llm.planner import LLMPlanner
            from app.llm.context_builder import build_planner_context

            llm_cfg = await resolve_llm_provider_config_async(
                self.db,
                self.project,
                scan_cfg,
            )
            self._llm_planner_summary["enabled"] = bool(llm_cfg.get("enabled"))
            self._llm_planner_summary["provider"] = llm_cfg.get("provider", "")
            self._llm_planner_summary["model"] = llm_cfg.get("model", "")

            client = LLMClient(
                enabled=bool(llm_cfg.get("enabled", False)),
                provider=str(llm_cfg.get("provider", "")),
                model=str(llm_cfg.get("model", "")),
                api_key=str(llm_cfg.get("api_key", "")),
            )
            if not client.is_available():
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"[LLM] Planner skipped at {checkpoint}: provider credentials unavailable",
                )
                return

            _SAST_SOURCES = {
                "trustscan", "semgrep", "sarif", "gitleaks",
                "trivy", "noir", "generic", "external",
            }
            context = build_planner_context(
                checkpoint=checkpoint,
                project=self.project,
                scan=self.scan,
                routes=self.routes,
                sinks=self.sinks,
                sast_findings=[
                    {"vulnerability_type": getattr(f, "vulnerability_type", "unknown")}
                    for f in self.all_findings
                    if getattr(f, "scanner_source", "") in _SAST_SOURCES
                ],
                dast_findings=self.dast_findings,
            )

            planner = LLMPlanner(client)
            decision = await planner.decide(checkpoint=checkpoint, context=context)

            applied_updates = {}
            priorities = []
            retry_hint = {}
            config_changed = False
            for action in decision.actions:
                if action.action == "update_scan_config":
                    applied_updates = planner.apply_scan_config_updates(
                        self.scan.scan_config or {}, action.params
                    )
                    self.scan.scan_config = applied_updates
                    config_changed = True
                elif action.action == "prioritize_vuln_types":
                    vt = action.params.get("types", []) if isinstance(action.params, dict) else []
                    if isinstance(vt, list):
                        priorities = [str(x) for x in vt[:12]]
                elif action.action == "recommend_targeted_retry":
                    retry_hint = action.params if isinstance(action.params, dict) else {}

            if priorities:
                cfg = dict(self.scan.scan_config or {})
                cfg["llm_prioritized_vuln_types"] = priorities
                self.scan.scan_config = cfg
                config_changed = True

            if retry_hint:
                cfg = dict(self.scan.scan_config or {})
                cfg["llm_retry_hint"] = retry_hint
                self.scan.scan_config = cfg
                config_changed = True

            if config_changed:
                await self.db.commit()

            self._llm_planner_summary["decisions"].append({
                "checkpoint": checkpoint,
                "summary": decision.summary,
                "actions": [a.model_dump() for a in decision.actions],
            })
            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Planner decision at {checkpoint}: {decision.summary or 'no summary'}",
            )
        except Exception as exc:
            msg = str(exc)
            self._llm_planner_summary["errors"].append({
                "checkpoint": checkpoint,
                "error": msg,
            })
            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Planner warning at {checkpoint}: {msg}",
            )

    async def _run_pre_scan_planning(self) -> None:
        """Run pre-scan LLM planning to guide scan focus areas.

        Optional — skipped if no project description or LLM disabled.
        Never fails the scan.
        """
        try:
            project_desc = self.project.description or ""
            if not project_desc or len(project_desc.strip()) < 15:
                return  # Skip silently

            from app.llm.pre_scan_planner import plan_scan
            from app.llm.context_compressor import compress_finding_types
            from app.llm.provider_config import resolve_llm_provider_config_async

            # Check if LLM is available
            scan_cfg = self.scan.scan_config or {}
            llm_cfg = await resolve_llm_provider_config_async(
                self.db,
                self.project,
                scan_cfg,
            )

            if not llm_cfg.get("enabled") or not llm_cfg.get("api_key"):
                return  # Skip silently

            await self.ws.send_scan_log(self.scan.id, "[LLM] Planning scan from project description...")

            finding_types = ""

            # Call planner
            plan = await plan_scan(
                project_description=project_desc,
                scan_mode=self.scan.scan_mode or "whitebox",
                target_domain=self.project.target_url.split("//")[-1].split("/")[0] if self.project.target_url else "",
                finding_types=finding_types,
                api_key=llm_cfg.get("api_key"),
                provider=str(llm_cfg.get("provider") or "anthropic"),
                model=str(llm_cfg.get("model") or ""),
            )

            if not plan:
                return  # Skipped or error

            # Store plan result
            self.scan.plan_result = plan
            await self.db.commit()

            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Plan: focus={plan.get('focus_areas', [])}, skip={plan.get('skip_hint', [])}"
            )

        except Exception as exc:
            logger.exception("Pre-scan planning error: %s", exc)
            # Never fail the scan — log and continue
            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Planning warning: {exc}"
            )

    async def _run_post_scan_synthesis(self, findings: list) -> None:
        """Run post-scan LLM synthesis (chains + FP flags + summary).

        Fires once after all tools complete. Never fails the scan.
        """
        try:
            from app.llm.post_scan_synthesizer import synthesize_scan_findings

            # Get LLM API key from config
            scan_cfg = self.scan.scan_config or {}
            from app.llm.provider_config import resolve_llm_provider_config_async
            llm_cfg = await resolve_llm_provider_config_async(
                self.db,
                self.project,
                scan_cfg,
            )

            # Skip if LLM not available
            if not llm_cfg.get("enabled") or not llm_cfg.get("api_key"):
                self.scan.llm_status = "skipped"
                return

            await self.ws.send_scan_log(self.scan.id, "[LLM] Running post-scan synthesis...")

            # Call synthesizer
            result = await synthesize_scan_findings(
                findings=findings,
                scan_mode=self.scan.scan_mode or "whitebox",
                detected_stack=self.scan.detected_stack,
                auth_config=self.scan.auth_config,
                api_key=llm_cfg.get("api_key"),
                provider=str(llm_cfg.get("provider") or "anthropic"),
                model=str(llm_cfg.get("model") or ""),
            )

            # Extract results
            if result.get("skipped"):
                self.scan.llm_status = "skipped"
                self.scan.llm_error = result.get("skipped_reason", "")
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"[LLM] Synthesis skipped: {result.get('skipped_reason', 'insufficient findings')}"
                )
                return

            if result.get("error"):
                self.scan.llm_status = "failed"
                self.scan.llm_error = result.get("error", "unknown error")
                await self.ws.send_scan_log(
                    self.scan.id,
                    f"[LLM] Synthesis failed: {result.get('error')}"
                )
                return

            # Store results
            self.scan.llm_status = "ok"
            self.scan.attack_chains = result.get("attack_chains", [])
            self.scan.llm_summary = result.get("summary", "")

            # Add chains and summary to results
            summary = self.scan.results_summary or {}
            if result.get("attack_chains"):
                summary["attack_chains"] = result.get("attack_chains", [])
            if result.get("summary"):
                summary["llm_summary"] = result.get("summary", "")
            self.scan.results_summary = summary

            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Synthesis complete: {len(result.get('attack_chains', []))} chains, summary generated"
            )

        except Exception as exc:
            logger.exception("Post-scan LLM synthesis error: %s", exc)
            self.scan.llm_status = "failed"
            self.scan.llm_error = str(exc)
            await self.ws.send_scan_log(
                self.scan.id,
                f"[LLM] Synthesis error: {exc}"
            )
