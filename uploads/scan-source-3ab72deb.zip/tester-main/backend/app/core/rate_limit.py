"""Rate limiting middleware for DDoS protection."""
import asyncio
import logging
from datetime import datetime, timedelta, timezone
from collections import defaultdict

logger = logging.getLogger(__name__)


class RateLimiter:
    """In-memory sliding window rate limiter for per-IP request throttling."""

    def __init__(self, requests_per_minute: int = 60, cleanup_interval: int = 300):
        """Initialize rate limiter.

        Args:
            requests_per_minute: Max requests per IP per minute
            cleanup_interval: Seconds between cleaning up expired entries
        """
        self.requests_per_minute = requests_per_minute
        self.window_seconds = 60
        self.cleanup_interval = cleanup_interval
        # Track request timestamps per IP: {ip: [timestamp1, timestamp2, ...]}
        self._ip_requests: dict[str, list[datetime]] = defaultdict(list)
        self._cleanup_task: asyncio.Task | None = None

    async def start(self):
        """Start background cleanup task."""
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
            logger.info("Rate limiter cleanup task started")

    async def stop(self):
        """Stop background cleanup task."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
            logger.info("Rate limiter cleanup task stopped")

    async def _cleanup_loop(self):
        """Periodically remove old entries to prevent memory leaks."""
        try:
            while True:
                await asyncio.sleep(self.cleanup_interval)
                self._cleanup_expired_entries()
        except asyncio.CancelledError:
            pass

    def _cleanup_expired_entries(self):
        """Remove request entries older than 2 minutes."""
        now = datetime.now(timezone.utc)
        expired_threshold = now - timedelta(seconds=self.window_seconds * 2)

        for ip in list(self._ip_requests.keys()):
            # Keep only recent requests
            self._ip_requests[ip] = [
                ts for ts in self._ip_requests[ip] if ts > expired_threshold
            ]
            # Remove IP if no requests left
            if not self._ip_requests[ip]:
                del self._ip_requests[ip]

    def is_allowed(self, client_ip: str) -> bool:
        """Check if request from client_ip is allowed.

        Args:
            client_ip: Client IP address

        Returns:
            True if within rate limit, False if exceeded
        """
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(seconds=self.window_seconds)

        # Get requests in current window
        requests_in_window = [
            ts for ts in self._ip_requests[client_ip] if ts > window_start
        ]

        # Update list (clean old entries)
        self._ip_requests[client_ip] = requests_in_window

        # Check limit
        if len(requests_in_window) >= self.requests_per_minute:
            logger.warning(
                f"Rate limit exceeded for {client_ip}: "
                f"{len(requests_in_window)} requests in 60s"
            )
            return False

        # Record this request
        self._ip_requests[client_ip].append(now)
        return True

    def get_remaining(self, client_ip: str) -> int:
        """Get remaining requests for client IP in current window."""
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(seconds=self.window_seconds)

        requests_in_window = [
            ts for ts in self._ip_requests[client_ip] if ts > window_start
        ]

        return max(0, self.requests_per_minute - len(requests_in_window))


# Global rate limiter instance
_rate_limiter = RateLimiter(requests_per_minute=300)


def get_rate_limiter() -> RateLimiter:
    """Get the global rate limiter instance."""
    return _rate_limiter
