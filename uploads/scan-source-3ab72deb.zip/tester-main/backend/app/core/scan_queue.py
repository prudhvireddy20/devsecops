"""Scan job queue abstraction with SQS and Redis backends."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class ScanQueueJob:
    message_id: str
    receipt_handle: str
    payload: dict[str, Any]


class ScanQueue:
    def __init__(self) -> None:
        self.mode = (getattr(settings, "SCAN_QUEUE_MODE", "local") or "local").strip().lower()
        self.queue_url = str(getattr(settings, "SQS_QUEUE_URL", "") or "").strip()
        self.region = str(getattr(settings, "AWS_REGION", "") or "").strip() or None
        self.redis_url = str(getattr(settings, "REDIS_URL", "") or "").strip()
        self.redis_queue_name = str(getattr(settings, "REDIS_QUEUE_NAME", "traceon:scan_jobs") or "traceon:scan_jobs").strip()
        self._client = None
        self._redis = None

    @property
    def enabled(self) -> bool:
        return self.mode in {"sqs", "redis"}

    def _client_or_none(self):
        if self.mode != "sqs":
            return None
        if not self.queue_url:
            logger.error("SCAN_QUEUE_MODE=sqs but SQS_QUEUE_URL is not configured")
            return None
        if self._client is not None:
            return self._client
        try:
            import boto3
        except Exception:
            logger.exception("boto3 is required for SQS queue mode")
            return None
        self._client = boto3.client("sqs", region_name=self.region)
        return self._client

    def _redis_or_none(self):
        if self.mode != "redis":
            return None
        if not self.redis_url:
            logger.error("SCAN_QUEUE_MODE=redis but REDIS_URL is not configured")
            return None
        if self._redis is not None:
            return self._redis
        try:
            import redis
            self._redis = redis.from_url(self.redis_url, decode_responses=True)
            return self._redis
        except Exception:
            logger.exception("Failed to initialize Redis queue client")
            return None

    async def enqueue(self, payload: dict[str, Any]) -> bool:
        body = json.dumps(payload, separators=(",", ":"), sort_keys=True)
        if self.mode == "sqs":
            client = self._client_or_none()
            if client is None:
                return False
            try:
                client.send_message(QueueUrl=self.queue_url, MessageBody=body)
                return True
            except Exception:
                logger.exception("Failed to enqueue scan job to SQS")
                return False
        if self.mode == "redis":
            redis_client = self._redis_or_none()
            if redis_client is None:
                return False
            try:
                redis_client.lpush(self.redis_queue_name, body)
                return True
            except Exception:
                logger.exception("Failed to enqueue scan job to Redis")
                return False
        return False

    async def poll(self, wait_seconds: int = 10, max_messages: int = 1) -> list[ScanQueueJob]:
        if self.mode == "sqs":
            client = self._client_or_none()
            if client is None:
                return []
            try:
                resp = client.receive_message(
                    QueueUrl=self.queue_url,
                    MaxNumberOfMessages=max(1, min(int(max_messages), 10)),
                    WaitTimeSeconds=max(0, min(int(wait_seconds), 20)),
                    MessageAttributeNames=["All"],
                )
            except Exception:
                logger.exception("Failed to poll SQS queue")
                return []

            out: list[ScanQueueJob] = []
            for item in resp.get("Messages", []) or []:
                body = str(item.get("Body", "") or "")
                if not body:
                    continue
                try:
                    payload = json.loads(body)
                except Exception:
                    logger.warning("Dropping malformed queue message id=%s", item.get("MessageId"))
                    await self.ack(str(item.get("ReceiptHandle", "") or ""))
                    continue
                out.append(
                    ScanQueueJob(
                        message_id=str(item.get("MessageId", "") or ""),
                        receipt_handle=str(item.get("ReceiptHandle", "") or ""),
                        payload=payload,
                    )
                )
            return out

        if self.mode == "redis":
            redis_client = self._redis_or_none()
            if redis_client is None:
                return []
            out: list[ScanQueueJob] = []
            limit = max(1, min(int(max_messages), 100))
            timeout = max(1, min(int(wait_seconds), 30))
            try:
                for _ in range(limit):
                    item = redis_client.brpop(self.redis_queue_name, timeout=timeout)
                    if not item:
                        break
                    _, body = item
                    try:
                        payload = json.loads(body)
                    except Exception:
                        logger.warning("Dropping malformed Redis queue payload")
                        continue
                    out.append(
                        ScanQueueJob(
                            message_id="redis",
                            receipt_handle="",
                            payload=payload,
                        )
                    )
                return out
            except Exception:
                logger.exception("Failed to poll Redis queue")
                return []

        return []

    async def ack(self, receipt_handle: str) -> bool:
        if self.mode == "sqs":
            client = self._client_or_none()
            if client is None:
                return False
            if not receipt_handle:
                return False
            try:
                client.delete_message(QueueUrl=self.queue_url, ReceiptHandle=receipt_handle)
                return True
            except Exception:
                logger.exception("Failed to ack SQS message")
                return False
        if self.mode == "redis":
            return True
        return False
