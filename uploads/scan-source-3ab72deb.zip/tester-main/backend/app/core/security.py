"""Token encryption/decryption using Fernet with configurable PBKDF2 salt."""
import base64
import logging

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from app.core.config import settings

logger = logging.getLogger(__name__)

# Legacy static salt — kept for backward-compatible decryption of tokens
# that were encrypted before the salt was made configurable.
_LEGACY_SALT = b"traceon-static-salt"


def _derive_fernet(salt: bytes) -> Fernet:
    """Derive a Fernet key from the encryption key and given salt."""
    key_material = settings.ENCRYPTION_KEY.encode()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100_000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(key_material))
    return Fernet(key)


def _get_fernet() -> Fernet:
    """Get Fernet instance using the configured (or legacy) salt."""
    salt = (
        settings.ENCRYPTION_SALT.encode()
        if settings.ENCRYPTION_SALT
        else _LEGACY_SALT
    )
    return _derive_fernet(salt)


def encrypt_token(token: str) -> str:
    """Encrypt a token string. Returns empty string for empty input."""
    if not token:
        return ""
    f = _get_fernet()
    return f.encrypt(token.encode()).decode()


def decrypt_token(encrypted_token: str) -> str:
    """Decrypt a token string with automatic legacy-salt fallback.

    - Tries the current configured salt first.
    - Falls back to the legacy static salt for tokens encrypted before the
      salt was made configurable.
    - Returns empty string for undecryptable Fernet ciphertexts (key changed).
    - Returns the raw value for legacy plaintext tokens stored before
      encryption was added.
    """
    if not encrypted_token:
        return ""
    try:
        f = _get_fernet()
        return f.decrypt(encrypted_token.encode()).decode()
    except (Exception, InvalidToken):
        # Try legacy salt if current salt differs
        current_salt = (
            settings.ENCRYPTION_SALT.encode()
            if settings.ENCRYPTION_SALT
            else _LEGACY_SALT
        )
        if current_salt != _LEGACY_SALT:
            try:
                legacy_f = _derive_fernet(_LEGACY_SALT)
                plaintext = legacy_f.decrypt(encrypted_token.encode()).decode()
                logger.info(
                    "Decrypted token using legacy salt — "
                    "consider re-encrypting with the current salt"
                )
                return plaintext
            except Exception:
                pass
        # Fernet ciphertext that we can't decrypt — key likely changed
        if encrypted_token.startswith("gAAAA"):
            return ""
        # Fallback for legacy plaintext tokens stored before encryption.
        return encrypted_token
