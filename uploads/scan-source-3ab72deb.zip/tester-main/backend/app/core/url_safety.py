"""URL safety helpers for outbound scan/auth requests.

These checks reduce SSRF risk by allowing normal local/public targets while
still blocking metadata-service and clearly unsafe destinations.

Also auto-rewrites ``localhost`` / ``127.0.0.1`` to ``host.docker.internal``
so scanner containers reach the Docker host without manual URL changes.
"""

from __future__ import annotations

import ipaddress
from urllib.parse import urlparse, urlunparse

from app.core.config import settings

_BLOCKED_HOSTNAMES = {
    "metadata",
    "metadata.google.internal",
}

_BLOCKED_IPS = {
    ipaddress.ip_address("169.254.169.254"),  # AWS/GCP/Azure metadata IPv4
    ipaddress.ip_address("fd00:ec2::254"),    # AWS metadata IPv6
}


def _is_blocked_ip(ip: ipaddress._BaseAddress) -> bool:
    """Return True when *ip* is not allowed for outbound target URLs."""
    if ip in _BLOCKED_IPS:
        return True
    if ip.is_multicast:
        return True
    if ip.is_unspecified or ip.is_reserved:
        return True
    return False


def rewrite_docker_host(url: str) -> str:
    """Rewrite ``localhost`` / ``127.0.0.1`` → configured Docker host hostname.

    The scanner runs inside a Docker container, so ``localhost`` resolves
    to the container, not the host.  This rewrite lets users enter URLs
    like ``http://localhost:5000`` and have them automatically reach the
    Docker host machine.

    The target hostname is configurable via ``DOCKER_HOST_HOSTNAME`` env var
    (default: ``host.docker.internal``).  On Linux Docker, you may need:

        --add-host=host.docker.internal:host-gateway

    or set DOCKER_HOST_HOSTNAME to the Docker bridge gateway IP (e.g. 172.17.0.1).
    """
    try:
        parsed = urlparse(url)
        hostname = (parsed.hostname or "").strip().lower()
    except ValueError:
        # e.g. "http://[bad" — .hostname raises "Invalid IPv6 URL"
        return url
    if hostname in ("localhost", "127.0.0.1"):
        new_netloc = parsed.netloc.replace(parsed.hostname, settings.DOCKER_HOST_HOSTNAME, 1)
        return urlunparse(parsed._replace(netloc=new_netloc))
    return url


def validate_external_target_url(url: str) -> tuple[bool, str]:
    """Validate that URL is safe for outbound scanner/auth requests.

    Returns ``(is_valid, error_message)``.  The returned URL is the
    (possibly rewritten) version.
    """
    raw = (url or "").strip()
    if not raw:
        return False, "Target URL is required"

    # Auto-rewrite localhost for Docker networking
    raw = rewrite_docker_host(raw)

    try:
        parsed = urlparse(raw)
        if parsed.scheme not in ("http", "https"):
            return False, "Only http:// and https:// target URLs are allowed"
        hostname = (parsed.hostname or "").strip().lower()
    except ValueError:
        return False, "Target URL is malformed"
    if not hostname:
        return False, "Target URL must include a valid host"

    if hostname in _BLOCKED_HOSTNAMES:
        return False, "Target metadata host is blocked for security reasons"

    # Direct IP host
    try:
        ip = ipaddress.ip_address(hostname)
    except ValueError:
        ip = None

    if ip is not None:
        if _is_blocked_ip(ip):
            return False, f"Target host IP {ip} is not allowed"
        return True, ""

    # For DNS hostnames, allow here and rely on runtime network controls.
    return True, ""


def normalize_target_url(url: str) -> str:
    """Strip, validate, and rewrite *url* for Docker networking.

    Returns the cleaned (possibly rewritten) URL, or empty string on
    validation failure.  Intended for use at project/scan creation before
    persisting the target URL.
    """
    raw = (url or "").strip()
    if not raw:
        return ""
    valid, _ = validate_external_target_url(raw)
    return rewrite_docker_host(raw) if valid else ""
