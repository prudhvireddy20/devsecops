"""Confidence scorer - assigns confidence levels to correlated findings."""
import logging
import re

logger = logging.getLogger(__name__)

_CWE_RE = re.compile(r"(CWE-\d+)")
_PARAM_RE = re.compile(r"[<{][^>}]+[>}]|:(\w+)")


class ConfidenceScorer:
    """Assigns and adjusts confidence levels for security findings.

    Confidence Levels:
    - verified: SAST + DAST both confirm (highest priority)
    - probable: SAST only (vulnerable code but not dynamically exploited)
    - observed: DAST only (runtime finding without source code match)
    """

    # Weights for confidence calculation
    WEIGHTS = {
        "sast_match": 40,
        "dast_match": 40,
        "parameter_match": 10,
        "endpoint_match": 10,
        "cwe_match": 5,
        "sink_detected": 5,
    }

    CONFIDENCE_THRESHOLDS = {
        "verified": 70,
        "probable": 30,
        "observed": 0,
    }

    def score(
        self,
        sast_finding: dict | None = None,
        dast_finding: dict | None = None,
        extra: dict | None = None,
    ) -> dict:
        """Calculate confidence score for a finding pair."""
        score = 0
        factors = []

        if sast_finding and dast_finding:
            # Both scanners found it
            score += self.WEIGHTS["sast_match"]
            score += self.WEIGHTS["dast_match"]
            factors.append("Static analysis confirmed")
            factors.append("Dynamic analysis confirmed")

            # Parameter match bonus
            sast_param = sast_finding.get("parameter", "")
            dast_param = dast_finding.get("parameter", "")
            if sast_param and dast_param and sast_param.lower() == dast_param.lower():
                score += self.WEIGHTS["parameter_match"]
                factors.append(f"Parameter match: {sast_param}")

            # Endpoint match bonus
            sast_endpoint = sast_finding.get("endpoint", "")
            dast_endpoint = dast_finding.get("endpoint", "")
            if self._endpoints_match(sast_endpoint, dast_endpoint):
                score += self.WEIGHTS["endpoint_match"]
                factors.append(f"Endpoint match: {dast_endpoint}")

            # CWE match bonus
            sast_cwe = sast_finding.get("cwe", "")
            dast_cwe = dast_finding.get("cwe", "")
            if self._cwes_match(sast_cwe, dast_cwe):
                score += self.WEIGHTS["cwe_match"]
                factors.append(f"CWE match: {sast_cwe}")

        elif sast_finding:
            score += self.WEIGHTS["sast_match"]
            factors.append("Static analysis only")

            # Boost if a dangerous sink was detected
            if extra and extra.get("sink_detected"):
                score += self.WEIGHTS["sink_detected"]
                factors.append("Dangerous sink detected in code path")

        elif dast_finding:
            # DAST-only findings should remain "observed" unless correlation with
            # source evidence exists. We keep score below the probable threshold,
            # but still differentiate stronger runtime evidence.
            score += 20
            factors.append("Dynamic analysis only")

            if dast_finding.get("payload") and dast_finding.get("response_evidence"):
                score += 9
                factors.append("Exploit evidence present")

        # Determine confidence level
        if score >= self.CONFIDENCE_THRESHOLDS["verified"]:
            confidence = "verified"
        elif score >= self.CONFIDENCE_THRESHOLDS["probable"]:
            confidence = "probable"
        else:
            confidence = "observed"

        return {
            "confidence": confidence,
            "score": min(score, 100),
            "factors": factors,
            "description": self._confidence_description(confidence),
        }

    @staticmethod
    def _endpoints_match(sast_endpoint: str, dast_endpoint: str) -> bool:
        """Return True when two endpoint strings refer to the same route shape."""
        if not sast_endpoint or not dast_endpoint:
            return False

        ep1_clean = _PARAM_RE.sub("*", str(sast_endpoint).strip().rstrip("/").lower() or "/")
        ep2_clean = _PARAM_RE.sub("*", str(dast_endpoint).strip().rstrip("/").lower() or "/")

        if ep1_clean == ep2_clean:
            return True

        parts1 = ep1_clean.split("/")
        parts2 = ep2_clean.split("/")
        if len(parts1) != len(parts2):
            return False

        for p1, p2 in zip(parts1, parts2):
            if p1 == "*" or p2 == "*":
                continue
            if p1 != p2:
                return False

        return True

    @staticmethod
    def _cwes_match(sast_cwe: str, dast_cwe: str) -> bool:
        """Return True when CWE values normalize to the same base identifier."""
        if not sast_cwe or not dast_cwe:
            return False

        sast_raw = str(sast_cwe).strip().upper()
        dast_raw = str(dast_cwe).strip().upper()
        sast_match = _CWE_RE.match(sast_raw)
        dast_match = _CWE_RE.match(dast_raw)
        sast_norm = sast_match.group(1) if sast_match else sast_raw
        dast_norm = dast_match.group(1) if dast_match else dast_raw
        return bool(sast_norm and dast_norm and sast_norm == dast_norm)

    def _confidence_description(self, confidence: str) -> str:
        """Get human-readable description for confidence level."""
        descriptions = {
            "verified": "Both static and dynamic analysis confirmed this vulnerability. High confidence - immediate remediation recommended.",
            "probable": "Static analysis identified vulnerable code, but dynamic testing did not confirm exploitation. Code review recommended.",
            "observed": "Dynamic testing detected a potential issue, but no matching source code vulnerability was found. Further investigation needed.",
        }
        return descriptions.get(confidence, "Unknown confidence level")

    def adjust_for_severity(self, confidence: str, severity: str) -> int:
        """Calculate a priority score based on confidence and severity."""
        confidence_weights = {"verified": 100, "probable": 60, "observed": 30}
        severity_weights = {"critical": 100, "high": 75, "medium": 50, "low": 25, "info": 10}

        c_weight = confidence_weights.get(confidence, 30)
        s_weight = severity_weights.get(severity, 25)

        return int((c_weight * 0.6) + (s_weight * 0.4))
