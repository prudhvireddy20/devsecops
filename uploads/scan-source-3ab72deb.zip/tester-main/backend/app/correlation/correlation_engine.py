"""Correlation engine - matches SAST and DAST findings to determine confidence."""
import logging
import re
from pathlib import PurePosixPath
from typing import Optional

from app.utils.normalizers import (
    clear_caches as normalizer_clear_caches,
    get_cache_stats as normalizer_get_cache_stats,
    normalize_endpoint_value,
    normalize_file_path,
    normalize_parameter_name,
    parameters_match,
)

logger = logging.getLogger(__name__)

# Pre-compiled regexes used in hot-loop matching methods.
_CWE_RE = re.compile(r'(CWE-\d+)')
_PARAM_RE = re.compile(r'[<{][^>}]+[>}]|:(\w+)')


# Mapping between vulnerability types for SAST <-> DAST correlation
VULN_TYPE_EQUIVALENTS = {
    "sqli": ["sqli", "sql_injection", "sql-injection"],
    "xss": ["xss", "cross-site-scripting"],
    "cmdi": ["cmdi", "command_injection", "command-injection", "os-command-injection"],
    "path_traversal": ["path_traversal", "path-traversal", "directory-traversal"],
    "ssrf": ["ssrf", "server-side-request-forgery"],
    "deserialization": ["deserialization", "insecure-deserialization"],
    "secret": ["secret", "hardcoded-secret", "hardcoded-password"],
    "config": ["config", "security_misconfiguration", "misconfiguration"],
    "info_disclosure": ["info_disclosure", "information_disclosure", "info-disclosure"],
    # Access Control (PHASE 1 EXPANSION)
    "idor": ["idor", "insecure_direct_object_reference", "insecure-direct-object-reference"],
    "auth": ["auth", "authentication", "jwt", "jwt-none", "jwt_none"],
    "mass_assignment": ["mass_assignment", "mass-assignment", "parameter-pollution"],
    # Cryptography (PHASE 1 EXPANSION)
    "weak_crypto": ["weak_crypto", "weak-crypto", "insecure_crypto", "insecure-crypto", "weak_cipher", "weak-cipher"],
    # API & Configuration Issues (PHASE 1 EXPANSION)
    "brute_force": ["brute_force", "rate_limit", "rate-limit", "cwe-307"],
    "cors": ["cors", "cors-misconfiguration", "cross-origin-resource-sharing"],
}

_VULN_CANONICAL: dict[str, str] = {}
for _canonical, _variants in VULN_TYPE_EQUIVALENTS.items():
    for _variant in _variants:
        _VULN_CANONICAL[_variant] = _canonical


class CorrelationEngine:
    """Correlates SAST and DAST findings to assign confidence levels.

    - Verified: Both SAST and DAST found the same vulnerability
    - Probable: Only SAST found it (code is vulnerable but not exploited dynamically)
    - Observed: Only DAST found it (runtime finding without source code match)
    """

    def __init__(self, routes: Optional[list[dict]] = None):
        self.correlated_findings: list[dict] = []
        self.diagnostics: dict = {}
        self._file_to_endpoints: dict[str, set[str]] = {}
        self._dast_findings_by_role: dict[str, list[dict]] = {}  # Track DAST findings per role
        self._build_route_index(routes or [])

    GLOBAL_SCOPE_TYPES = {
        "config",
        "header",
        "info_disclosure",
        "timestamp",
        "absence",
        # CORS and brute-force are app-wide / middleware-level concerns that
        # don't map to a single endpoint, so allow global-scope matching.
        "cors",
        "brute_force",
        # Hardcoded secrets are a static code finding; the DAST evidence is
        # a side-effect (credential works) rather than a specific endpoint hit.
        "secret",
    }

    def _build_route_index(self, routes: list[dict]) -> None:
        """Build file->endpoint lookup from extracted route metadata."""
        for route in routes:
            file_path = route.get("file", "")
            endpoint = route.get("path", "")
            if not file_path or not endpoint:
                continue
            norm_file = self._normalize_file_path(file_path)
            self._file_to_endpoints.setdefault(norm_file, set()).add(
                self._normalize_endpoint_value(endpoint)
            )

            # Add basename alias to tolerate path prefix differences.
            basename = PurePosixPath(norm_file).name
            if basename:
                self._file_to_endpoints.setdefault(basename, set()).add(
                    self._normalize_endpoint_value(endpoint)
                )

    @staticmethod
    def _normalize_file_path(file_path: str) -> str:
        return normalize_file_path(file_path)

    @staticmethod
    def _normalize_endpoint_value(endpoint: str) -> str:
        return normalize_endpoint_value(endpoint)

    def _bucket_findings_by_type(self, findings: list[dict]) -> dict[str, list[tuple[int, dict]]]:
        """Group findings by canonical vulnerability type with index tracking."""
        buckets: dict[str, list[tuple[int, dict]]] = {}
        for idx, finding in enumerate(findings):
            vuln_type = finding.get("vulnerability_type", "").lower()
            canonical_type = self._canonical_vuln_type(vuln_type)
            buckets.setdefault(canonical_type, []).append((idx, finding))
        return buckets

    def correlate(
        self, sast_findings: list[dict], dast_findings: list[dict]
    ) -> list[dict]:
        """Correlate SAST and DAST findings with type-based optimization."""
        self.correlated_findings = []
        matched_sast = set()
        matched_dast = set()
        diagnostics = {
            "type_mismatch": 0,
            "endpoint_mismatch": 0,
            "guard_rejected": 0,
            "matched": 0,
        }

        # OPTIMIZATION P0: Bucket findings by type before correlation
        sast_buckets = self._bucket_findings_by_type(sast_findings)
        dast_buckets = self._bucket_findings_by_type(dast_findings)

        logger.debug(
            "SAST buckets: %d, DAST buckets: %d",
            len(sast_buckets),
            len(dast_buckets),
        )

        # Only correlate within matching type buckets
        for vuln_type, sast_in_bucket in sast_buckets.items():
            dast_in_bucket = dast_buckets.get(vuln_type)
            if not dast_in_bucket:
                continue

            for sast_orig_idx, sast in sast_in_bucket:
                if sast_orig_idx in matched_sast:
                    continue
                for dast_orig_idx, dast in dast_in_bucket:
                    if dast_orig_idx in matched_dast:
                        continue
                    if self._is_match(sast, dast, diagnostics):
                        self.correlated_findings.append({
                            "confidence": "verified",
                            "sast_data": sast,
                            "dast_data": dast,
                            "sast_index": sast_orig_idx,
                            "dast_index": dast_orig_idx,
                            "match_reason": self._match_reason(sast, dast),
                        })
                        matched_sast.add(sast_orig_idx)
                        matched_dast.add(dast_orig_idx)
                        diagnostics["matched"] += 1
                        break

        # CWE-based fallback when types don't match but CWE does
        for si, sast in enumerate(sast_findings):
            if si in matched_sast:
                continue
            for di, dast in enumerate(dast_findings):
                if di in matched_dast:
                    continue
                sast_type = sast.get("vulnerability_type", "").lower()
                dast_type = dast.get("vulnerability_type", "").lower()
                if self._canonical_vuln_type(sast_type) == self._canonical_vuln_type(dast_type):
                    continue
                if self._cwes_match(sast.get("cwe", ""), dast.get("cwe", "")):
                    if self._is_match(sast, dast, diagnostics):
                        self.correlated_findings.append({
                            "confidence": "verified",
                            "sast_data": sast,
                            "dast_data": dast,
                            "sast_index": si,
                            "dast_index": di,
                            "match_reason": self._match_reason(sast, dast),
                        })
                        matched_sast.add(si)
                        matched_dast.add(di)
                        diagnostics["matched"] += 1
                        break

        # Remaining SAST findings -> probable
        for si, sast in enumerate(sast_findings):
            if si not in matched_sast:
                self.correlated_findings.append({
                    "confidence": "probable",
                    "sast_data": sast,
                    "dast_data": None,
                    "sast_index": si,
                    "dast_index": None,
                    "match_reason": "SAST only - code is vulnerable but not confirmed dynamically",
                })

        # Remaining DAST findings -> observed
        for di, dast in enumerate(dast_findings):
            if di not in matched_dast:
                self.correlated_findings.append({
                    "confidence": "observed",
                    "sast_data": None,
                    "dast_data": dast,
                    "sast_index": None,
                    "dast_index": di,
                    "match_reason": "DAST only - runtime finding without source code match",
                })

        verified_count = sum(
            1 for c in self.correlated_findings if c["confidence"] == "verified"
        )
        logger.info(
            f"Correlation complete: {verified_count} verified, "
            f"{len(sast_findings) - len(matched_sast)} probable, "
            f"{len(dast_findings) - len(matched_dast)} observed"
        )
        logger.info(
            "Correlation diagnostics: matched=%d, type_mismatch=%d, endpoint_mismatch=%d, guard_rejected=%d",
            diagnostics["matched"],
            diagnostics["type_mismatch"],
            diagnostics["endpoint_mismatch"],
            diagnostics["guard_rejected"],
        )

        self.diagnostics = diagnostics
        return self.correlated_findings

    def _is_match(self, sast: dict, dast: dict, diagnostics: Optional[dict] = None) -> bool:
        """Determine if a SAST finding matches a DAST finding."""
        # Match by vulnerability type
        sast_type = sast.get("vulnerability_type", "").lower()
        dast_type = dast.get("vulnerability_type", "").lower()

        sast_canonical = self._canonical_vuln_type(sast_type)
        dast_canonical = self._canonical_vuln_type(dast_type)
        type_match = sast_canonical == dast_canonical

        if not type_match:
            # Allow tightly constrained fallback when taxonomies differ but
            # CWE agrees (e.g. scanner-specific label names).
            if not self._cwes_match(sast.get("cwe", ""), dast.get("cwe", "")):
                if diagnostics is not None:
                    diagnostics["type_mismatch"] += 1
                return False

        # Match by endpoint (if available)
        sast_endpoints = self._extract_endpoints(sast)
        dast_endpoints = self._extract_endpoints(dast)
        allow_global_scope = self._allows_global_scope_matching(sast_type, dast_type)

        endpoint_match = any(
            self._endpoints_match(sep, dep, allow_global_scope=allow_global_scope)
            for sep in sast_endpoints
            for dep in dast_endpoints
        )

        # PHASE 1 ENHANCEMENT: Smarter endpoint matching for multi-route files
        # If endpoint mismatch, allow CWE or parameter to carry verification
        # This handles case where SAST has file but no endpoint, and multiple
        # endpoints exist for that file - we can still verify if CWE/param matches
        endpoint_context_required = bool(
            dast_endpoints and sast_endpoints and not endpoint_match
        )

        if endpoint_context_required and not allow_global_scope:
            if diagnostics is not None:
                diagnostics["endpoint_mismatch"] += 1
            # PHASE 1: Allow fallback to CWE/parameter matching instead of hard fail
            # This helps multi-route files still achieve verification
            endpoint_match = False
        elif not endpoint_context_required:
            # Either no endpoint context from DAST, or already matching
            endpoint_match = True

        # Match by parameter (if available)
        sast_param = sast.get("parameter", "").lower()
        dast_param = dast.get("parameter", "").lower()

        if sast_param and dast_param:
            if not self._parameters_match(sast_param, dast_param):
                return False

        if not self._passes_verified_guards(sast, dast, endpoint_match):
            if diagnostics is not None:
                diagnostics["guard_rejected"] += 1
            return False

        # PHASE 1: NEW - Type-specific semantic matching for enhanced correlation
        # For certain vulnerability types, apply additional context-aware logic
        sast_can_verify_type = self._is_type_verifiable(sast_canonical)
        dast_can_verify_type = self._is_type_verifiable(dast_canonical)
        
        if sast_can_verify_type and dast_can_verify_type:
            # Type-specific verification rules apply
            pass  # Already validated by guards above

        return True

    @staticmethod
    def _cwes_match(sast_cwe: str, dast_cwe: str) -> bool:
        """Return True when CWE values normalize to the same base identifier."""
        if not sast_cwe or not dast_cwe:
            return False
        sast_raw = str(sast_cwe).strip().upper()
        dast_raw = str(dast_cwe).strip().upper()
        sast_m = _CWE_RE.match(sast_raw)
        dast_m = _CWE_RE.match(dast_raw)
        sast_norm = sast_m.group(1) if sast_m else sast_raw
        dast_norm = dast_m.group(1) if dast_m else dast_raw
        return bool(sast_norm and dast_norm and sast_norm == dast_norm)

    @staticmethod
    def _passes_verified_guards(sast: dict, dast: dict, endpoint_match: bool) -> bool:
        """Apply strict guards to avoid false-positive verified correlations.
        
        PHASE 3 FIX: Enhanced parameter matching for better accuracy.
        Keeps permissive fallback when both sides lack CWE/parameter data
        (type+endpoint match is sufficient).
        """
        if not endpoint_match:
            return False

        sast_param = str(sast.get("parameter", "")).strip().lower()
        dast_param = str(dast.get("parameter", "")).strip().lower()
        parameter_match = bool(
            sast_param
            and dast_param
            and CorrelationEngine._parameters_match(sast_param, dast_param)
        )

        # Normalize CWE to just the numeric ID for comparison.
        # Handles format mismatches like "CWE-89" vs "CWE-89: Improper Neutralization..."
        sast_cwe_raw = str(sast.get("cwe", "")).strip().upper()
        dast_cwe_raw = str(dast.get("cwe", "")).strip().upper()
        sast_cwe_m = _CWE_RE.match(sast_cwe_raw)
        dast_cwe_m = _CWE_RE.match(dast_cwe_raw)
        sast_cwe = sast_cwe_m.group(1) if sast_cwe_m else sast_cwe_raw
        dast_cwe = dast_cwe_m.group(1) if dast_cwe_m else dast_cwe_raw
        cwe_match = bool(sast_cwe and dast_cwe and sast_cwe == dast_cwe)

        if parameter_match or cwe_match:
            return True

        # When neither side provides CWE or parameter data, the type +
        # endpoint match alone is sufficient — there is no contradictory
        # evidence to reject. This keeps verified rates reasonable.
        no_cwe_data = not sast_cwe and not dast_cwe
        no_param_data = not sast_param and not dast_param
        if no_cwe_data and no_param_data:
            return True

        mapping_tier = str(dast.get("mapping_tier", "none")).strip().lower()
        strong_evidence = bool(dast.get("strong_evidence", False))

        # Only high-trust dynamic evidence may verify without param/CWE.
        return strong_evidence and mapping_tier in {"high", "builtin"}

    @staticmethod
    def _normalize_parameter_name(value: str) -> str:
        return normalize_parameter_name(value)

    @staticmethod
    def _parameters_match(sast_param: str, dast_param: str) -> bool:
        return parameters_match(sast_param, dast_param, fuzzy_threshold=0.80)

    @staticmethod
    def clear_caches() -> None:
        """Clear all normalization caches for testing."""
        normalizer_clear_caches()

    @staticmethod
    def get_cache_stats() -> dict:
        """Expose shared normalizer cache stats for performance tests."""
        stats = normalizer_get_cache_stats()
        fuzzy_stats = stats.get("_fuzzy_param_similarity", {})
        return {
            "hits": fuzzy_stats.get("hits", 0),
            "misses": fuzzy_stats.get("misses", 0),
            "maxsize": fuzzy_stats.get("maxsize", 0),
        }

    def _extract_endpoints(self, finding: dict) -> list[str]:
        """Extract endpoint candidates from finding endpoint and file path.

        Keep explicit endpoint context, but also include route-index candidates
        from file path when available. This avoids losing valid correlations
        when a pre-enriched endpoint is stale/inexact for multi-route files.
        
        PHASE 1 ENHANCEMENT: Returns ALL candidate endpoints for multi-route files,
        allowing correlation engine to match against any of them. This fixes failures
        when a file has multiple endpoints but enrichment only picked one.
        """
        matches: set[str] = set()

        # Primary: explicit endpoint from finding
        endpoint = finding.get("endpoint", "")
        if endpoint:
            matches.add(self._normalize_endpoint_value(endpoint))

        # Secondary: all endpoints from route index for this file
        # PHASE 1: Instead of picking "best by line", return ALL candidates
        # Correlation will try matching against each candidate
        file_path = finding.get("file_path", "")
        if file_path:
            norm_file = self._normalize_file_path(file_path)
            # Get all endpoints for this file (even if multiple routes)
            all_endpoints = self._file_to_endpoints.get(norm_file, set())
            if all_endpoints:
                matches.update(all_endpoints)
            
            # Also check by basename for tolerance
            basename = PurePosixPath(norm_file).name
            if basename:
                basename_endpoints = self._file_to_endpoints.get(basename, set())
                if basename_endpoints:
                    matches.update(basename_endpoints)

        return sorted(matches)

    @staticmethod
    def _canonical_vuln_type(vuln_type: str) -> str:
        raw = str(vuln_type or "").strip().lower()
        return _VULN_CANONICAL.get(raw, raw)
    
    @staticmethod
    def _is_type_verifiable(canonical_type: str) -> bool:
        """Check if this vulnerability type can be verified via SAST+DAST correlation.
        
        PHASE 1 EXPANSION: More types now support verification (auth, idor, mass_assignment, etc.)
        """
        return canonical_type in VULN_TYPE_EQUIVALENTS

    @classmethod
    def _allows_global_scope_matching(cls, left_type: str, right_type: str) -> bool:
        left = cls._canonical_vuln_type(left_type)
        right = cls._canonical_vuln_type(right_type)
        return left in cls.GLOBAL_SCOPE_TYPES and right in cls.GLOBAL_SCOPE_TYPES

    @staticmethod
    def _is_global_scope_endpoint(endpoint: str) -> bool:
        raw = str(endpoint or "").strip().lower()
        return raw in {"*", "/*"}

    def _endpoints_match(self, ep1: str, ep2: str, allow_global_scope: bool = False) -> bool:
        """Check if two endpoints match, accounting for URL parameters."""
        if allow_global_scope and (
            self._is_global_scope_endpoint(ep1)
            or self._is_global_scope_endpoint(ep2)
        ):
            return True

        # Normalize URL parameters: {id}, <int:id>, and Express :id -> *
        ep1_clean = _PARAM_RE.sub('*', ep1)
        ep2_clean = _PARAM_RE.sub('*', ep2)

        if ep1_clean == ep2_clean:
            return True

        # Check if one is a prefix of the other
        parts1 = ep1_clean.split("/")
        parts2 = ep2_clean.split("/")

        if len(parts1) != len(parts2):
            return False

        for p1, p2 in zip(parts1, parts2):
            if p1 == "*" or p2 == "*":
                continue
            if p1 != p2:
                return False

        return True

    def _match_reason(self, sast: dict, dast: dict) -> str:
        """Generate a human-readable reason for the match."""
        reasons = ["Vulnerability type match"]
        sast_endpoints = self._extract_endpoints(sast)
        dast_endpoints = self._extract_endpoints(dast)
        endpoint_match = next(
            (
                dep
                for sep in sast_endpoints
                for dep in dast_endpoints
                if self._endpoints_match(sep, dep)
            ),
            None,
        )
        if endpoint_match:
            reasons.append(f"Endpoint match: {endpoint_match}")
        if sast.get("parameter") and dast.get("parameter"):
            reasons.append(f"Parameter match: {dast['parameter']}")
        return "; ".join(reasons)

    def correlate_by_role(
        self, sast_findings: list[dict], dast_findings_by_role: dict[str, list[dict]]
    ) -> list[dict]:
        """Correlate SAST with DAST findings grouped by role.
        
        This enables role-aware verification, especially for access control issues like IDOR.
        
        Args:
            sast_findings: List of SAST findings from static analysis
            dast_findings_by_role: Dict mapping role name -> list of DAST findings for that role
                Example: {"user": [...], "admin": [...], "guest": [...]}
        
        Returns:
            List of correlated findings with role awareness
        """
        self._dast_findings_by_role = dast_findings_by_role
        
        # Flatten all DAST findings while preserving role context
        all_dast_findings = []
        for role_name, findings in dast_findings_by_role.items():
            for finding in findings:
                finding_copy = dict(finding)
                finding_copy["_auth_role"] = role_name
                all_dast_findings.append(finding_copy)
        
        # Run normal correlation with annotated findings
        return self.correlate(sast_findings, all_dast_findings)
     
    def _verify_idor(self, sast: dict, dast_findings_by_role: dict[str, list[dict]]) -> bool:
        """Verify IDOR vulnerability using role-based correlation.
        
        IDOR is verified if:
        - SAST detected an object reference vulnerability
        - DAST with lower-privilege role successfully accessed endpoints
          that should be restricted to higher-privilege roles
        
        Returns: True if IDOR is verified across roles
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "idor":
            return False
        
        sast_endpoints = self._extract_endpoints(sast)
        if not sast_endpoints:
            return False
        
        sast_param = sast.get("parameter", "")
        if not sast_param:
            return False
        
        # Check if different roles found anomalies on same endpoint
        roles_with_findings = {}
        for role_name, findings in dast_findings_by_role.items():
            for dast_finding in findings:
                dast_endpoints = self._extract_endpoints(dast_finding)
                dast_param = dast_finding.get("parameter", "")
                
                # Check endpoint match
                endpoint_match = any(
                    self._endpoints_match(sep, dep)
                    for sep in sast_endpoints
                    for dep in dast_endpoints
                )
                
                if endpoint_match and dast_param and self._parameters_match(sast_param, dast_param):
                    roles_with_findings.setdefault(dast_finding.get("endpoint", ""), []).append(role_name)
        
        # IDOR verified if 2+ different roles accessed the same parameterized endpoint
        for endpoint, roles in roles_with_findings.items():
            if len(set(roles)) >= 2:
                logger.info(f"IDOR verified on {endpoint}: roles {roles} have access")
                return True

        
        return False
    
    def _verify_auth_logic(self, sast: dict, dast_findings_by_role: dict[str, list[dict]]) -> bool:
        """Verify authentication/authorization logic issues using DAST behavior.
        
        Auth issues are verified if:
        - SAST detected JWT-none, hardcoded auth, or similar issues
        - DAST shows inconsistent authorization behavior across roles
          (e.g., guest can access admin endpoints)
        
        Returns: True if auth issue is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "auth":
            return False
        
        # Count how many endpoints are accessible across different privilege levels
        endpoints_by_role = {}
        for role_name, findings in dast_findings_by_role.items():
            for dast_finding in findings:
                endpoint = dast_finding.get("endpoint", "")
                if endpoint:
                    endpoints_by_role.setdefault(endpoint, set()).add(role_name)
        
        # Auth issue verified if low-priv role accessed high-priv endpoints
        privilege_levels = {"guest": 0, "user": 1, "admin": 2}
        for endpoint, roles in endpoints_by_role.items():
            role_levels = [privilege_levels.get(r, 1) for r in roles]
            # If min privilege < 2 (admin) but we have high-priv routes, auth is broken
            if min(role_levels) < 2 and max(role_levels) >= 2:
                logger.info(f"Auth logic issue verified: lower-priv role accessed {endpoint}")
                return True
         
        return False

    def _verify_mass_assignment(self, sast: dict, dast_findings: list[dict]) -> bool:
        """Verify mass assignment vulnerabilities using parameter enumeration.
        
        Mass assignment is verified if:
        - SAST detected parameter binding without filtering
        - DAST found unexpected parameters accepted by endpoint
        
        Returns: True if mass assignment is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "mass_assignment":
            return False
        
        sast_endpoints = self._extract_endpoints(sast)
        if not sast_endpoints:
            return False
        
        # Check if DAST found endpoint with unexpected parameters
        for dast_finding in dast_findings:
            dast_endpoints = self._extract_endpoints(dast_finding)
            dast_type = self._canonical_vuln_type(dast_finding.get("vulnerability_type", ""))
            
            # Only correlate mass assignment findings
            if dast_type != "mass_assignment":
                continue
            
            endpoint_match = any(
                self._endpoints_match(sep, dep)
                for sep in sast_endpoints
                for dep in dast_endpoints
            )
            
            if endpoint_match:
                logger.info(f"Mass assignment verified on {dast_finding.get('endpoint', '')}: unexpected parameters accepted")
                return True
        
        return False

    def _verify_config_issue(self, sast: dict, dast_findings: list[dict]) -> bool:
        """Verify configuration/misconfiguration issues using DAST evidence.
        
        Config issues are verified if:
        - SAST detected insecure configuration (debug mode, weak headers, etc)
        - DAST found evidence of the misconfiguration
        
        Returns: True if config issue is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "config":
            return False
        
        # Config issues often have global scope, so check if ANY DAST finding
        # matches the configuration problem
        for dast_finding in dast_findings:
            dast_type = self._canonical_vuln_type(dast_finding.get("vulnerability_type", ""))
            
            # Config issues can correlate across different DAST type names
            if dast_type not in ("config", "info_disclosure", "header"):
                continue
            
            # Match by CWE if available
            sast_cwe = sast.get("cwe", "")
            dast_cwe = dast_finding.get("cwe", "")
            
            if sast_cwe and dast_cwe and self._cwes_match(sast_cwe, dast_cwe):
                logger.info(f"Config issue verified: {dast_finding.get('description', 'misconfiguration detected')}")
                return True
            
            # Match by description keywords
            sast_desc = (sast.get("description", "") or "").lower()
            dast_desc = (dast_finding.get("description", "") or "").lower()
            
            config_keywords = ["debug", "cache-control", "cors", "header", "tls", "ssl", "security"]
            if any(kw in sast_desc and kw in dast_desc for kw in config_keywords):
                logger.info(f"Config issue verified by keyword match: {dast_desc}")
                return True
        
        return False

    def _verify_info_disclosure(self, sast: dict, dast_findings: list[dict]) -> bool:
        """Verify information disclosure using DAST evidence.
        
        Info disclosure is verified if:
        - SAST detected information exposure (error messages, paths, versions)
        - DAST found similar information in responses
        
        Returns: True if info disclosure is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "info_disclosure":
            return False
        
        sast_endpoints = self._extract_endpoints(sast)
        sast_desc = (sast.get("description", "") or "").lower()
        
        # Info disclosure keywords that SAST might detect
        disclosure_keywords = ["error", "stack trace", "path", "version", "debug", "environment", "api", "url"]
        
        for dast_finding in dast_findings:
            dast_type = self._canonical_vuln_type(dast_finding.get("vulnerability_type", ""))
            dast_desc = (dast_finding.get("description", "") or "").lower()
            dast_evidence = (dast_finding.get("evidence", "") or "").lower()
            
            # Info disclosure, errors, and headers can all reveal information
            if dast_type not in ("info_disclosure", "error", "header"):
                continue
            
            # Check if endpoints match (if SAST has endpoint context)
            if sast_endpoints:
                dast_endpoints = self._extract_endpoints(dast_finding)
                endpoint_match = any(
                    self._endpoints_match(sep, dep)
                    for sep in sast_endpoints
                    for dep in dast_endpoints
                )
                if not endpoint_match:
                    continue
            
            # Check if keyword from SAST description appears in DAST response
            sast_keywords = [kw for kw in disclosure_keywords if kw in sast_desc]
            if sast_keywords:
                if any(kw in dast_desc or kw in dast_evidence for kw in sast_keywords):
                    logger.info(f"Info disclosure verified: {dast_desc}")
                    return True
            
            # Generic match if CWE matches
            sast_cwe = sast.get("cwe", "")
            dast_cwe = dast_finding.get("cwe", "")
            if sast_cwe and dast_cwe and self._cwes_match(sast_cwe, dast_cwe):
                logger.info(f"Info disclosure verified by CWE match")
                return True
        
        return False
    
    def _verify_brute_force(self, sast: dict, dast_findings: list[dict]) -> bool:
        """Verify brute force / rate limiting vulnerability.
        
        Rate limiting vulnerabilities are verified if:
        - SAST detected missing rate limiting or weak rate limiting
        - DAST shows repeated failed authentication attempts or suspicious patterns
        
        Returns: True if rate limiting issue is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "brute_force":
            return False
        
        sast_endpoints = self._extract_endpoints(sast)
        sast_cwe = sast.get("cwe", "")
        
        for dast_finding in dast_findings:
            dast_type = self._canonical_vuln_type(dast_finding.get("vulnerability_type", ""))
            if dast_type not in ("brute_force", "auth"):
                continue
            
            # Check endpoints match (rate limiting is typically on auth endpoints)
            if sast_endpoints:
                dast_endpoints = self._extract_endpoints(dast_finding)
                endpoint_match = any(
                    self._endpoints_match(sep, dep)
                    for sep in sast_endpoints
                    for dep in dast_endpoints
                )
                if not endpoint_match:
                    continue
            
            # Check CWE match (CWE-307, CWE-359)
            dast_cwe = dast_finding.get("cwe", "")
            if sast_cwe and dast_cwe:
                if self._cwes_match(sast_cwe, dast_cwe):
                    logger.info(f"Brute force/rate limit verified via CWE match")
                    return True
            
            # Check evidence for rate-limit-related keywords
            evidence = (dast_finding.get("evidence", "") or "").lower()
            description = (dast_finding.get("description", "") or "").lower()
            rate_keywords = ["rate limit", "retry", "timeout", "throttle", "429", "too many"]
            if any(kw in evidence or kw in description for kw in rate_keywords):
                logger.info(f"Brute force/rate limit verified via evidence")
                return True
        
        return False
    
    def _verify_cors(self, sast: dict, dast_findings: list[dict]) -> bool:
        """Verify CORS misconfiguration vulnerability.
        
        CORS issues are verified if:
        - SAST detected overly permissive CORS configuration
        - DAST shows wildcard or overly broad CORS headers
        
        Returns: True if CORS issue is verified
        """
        sast_type = self._canonical_vuln_type(sast.get("vulnerability_type", ""))
        if sast_type != "cors":
            return False
        
        for dast_finding in dast_findings:
            dast_type = self._canonical_vuln_type(dast_finding.get("vulnerability_type", ""))
            if dast_type != "cors":
                continue
            
            # Check if evidence mentions CORS wildcard or permissive headers
            evidence = (dast_finding.get("evidence", "") or "").lower()
            description = (dast_finding.get("description", "") or "").lower()
            response_headers = (dast_finding.get("response_headers", "") or "").lower()
            
            cors_keywords = ["access-control", "wildcard", "*", "origin"]
            if any(kw in evidence or kw in description or kw in response_headers for kw in cors_keywords):
                logger.info(f"CORS misconfiguration verified")
                return True
            
            # Check CWE match (CWE-942)
            sast_cwe = sast.get("cwe", "")
            dast_cwe = dast_finding.get("cwe", "")
            if sast_cwe and dast_cwe and self._cwes_match(sast_cwe, dast_cwe):
                logger.info(f"CORS verified via CWE match")
                return True
        
        return False

    def find_match(self, finding, correlated: list[dict]) -> Optional[dict]:
        """Find a correlation match for a specific finding (Finding model instance)."""
        finding_type = getattr(finding, "vulnerability_type", "")
        finding_endpoint = getattr(finding, "endpoint", "")
        finding_file = getattr(finding, "file_path", "")
        finding_source = getattr(finding, "scanner_source", "")

        for corr in correlated:
            if corr["confidence"] != "verified":
                continue

            sast_data = corr.get("sast_data", {})
            dast_data = corr.get("dast_data", {})

            if finding_source in ("semgrep",) and sast_data:
                if (sast_data.get("file_path") == finding_file and
                        sast_data.get("vulnerability_type") == finding_type):
                    return corr
            elif finding_source in ("zap",) and dast_data:
                if (dast_data.get("endpoint") == finding_endpoint and
                        dast_data.get("vulnerability_type") == finding_type):
                    return corr

        return None
