"""Finding deduplicator - collapses duplicate findings from multiple scanners."""
import logging

from app.utils.normalizers import normalize_endpoint_key

logger = logging.getLogger(__name__)

# Canonical mapping so different scanners' names for the same vuln class
# collapse into one group.  Mirrors the table in correlation_engine.py.
VULN_TYPE_EQUIVALENTS = {
    "sqli": {"sqli", "sql_injection", "sql-injection"},
    "xss": {"xss", "cross-site-scripting"},
    "cmdi": {"cmdi", "command_injection", "command-injection", "os-command-injection"},
    "path_traversal": {"path_traversal", "path-traversal", "directory-traversal"},
    "ssrf": {"ssrf", "server-side-request-forgery"},
    "deserialization": {"deserialization", "insecure-deserialization"},
    "secret": {"secret", "hardcoded-secret", "hardcoded-password"},
    "config": {"config", "security_misconfiguration", "misconfiguration"},
    "info_disclosure": {"info_disclosure", "information_disclosure", "info-disclosure"},
}

# Build a fast reverse-lookup: variant -> canonical
_VULN_CANONICAL: dict[str, str] = {}
for _canonical, _variants in VULN_TYPE_EQUIVALENTS.items():
    for _v in _variants:
        _VULN_CANONICAL[_v] = _canonical


class Deduplicator:
    """Deduplicates security findings when the same vulnerability is found by multiple scanners."""

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def find_duplicates(self, findings: list) -> list:
        """Identify and mark duplicate findings.

        Returns list of findings that should be marked as duplicates.
        The 'primary' finding is kept; duplicates reference the primary
        via their ``duplicate_of`` attribute.
        """
        if not findings:
            return []

        duplicates = []
        groups = self._group_findings(findings)

        for key, group in groups.items():
            if len(group) <= 1:
                continue

            # Sort by priority: verified > probable > observed, then by scanner reliability
            sorted_group = sorted(
                group,
                key=lambda f: (
                    self._confidence_priority(getattr(f, "confidence", "")),
                    self._scanner_priority(getattr(f, "scanner_source", "")),
                ),
            )

            # Keep the first (highest priority) as primary, rest are duplicates
            primary = sorted_group[0]
            for dup in sorted_group[1:]:
                # Merge useful data from duplicate into primary
                self._merge_finding(primary, dup)
                # Track which primary this duplicate belongs to
                primary_id = getattr(primary, "id", "")
                if hasattr(dup, "duplicate_of"):
                    dup.duplicate_of = primary_id
                duplicates.append(dup)

        logger.info(f"Found {len(duplicates)} duplicate findings to collapse")
        return duplicates

    # ------------------------------------------------------------------
    # Grouping logic
    # ------------------------------------------------------------------

    def _normalize_vuln_type(self, vuln_type: str) -> str:
        """Map a vulnerability type to its canonical form.

        ``sql_injection`` and ``sqli`` both map to ``sqli``, etc.
        If the type is not in the equivalence map it is returned as-is.
        """
        return _VULN_CANONICAL.get(vuln_type.lower(), vuln_type.lower())

    def _normalize_endpoint(self, endpoint: str) -> str:
        """Normalize an endpoint for comparison.
        """
        return normalize_endpoint_key(endpoint)

    def _endpoints_match(self, ep1: str, ep2: str) -> bool:
        """Check if two (already-normalized) endpoints match.

        Supports wildcard segments so ``api/users/*`` matches
        ``api/users/*``.
        """
        parts1 = ep1.split("/")
        parts2 = ep2.split("/")

        if len(parts1) != len(parts2):
            return False

        for p1, p2 in zip(parts1, parts2):
            if p1 == "*" or p2 == "*":
                continue
            if p1 != p2:
                return False
        return True

    def _group_findings(self, findings: list) -> dict:
        """Group findings that are likely duplicates.

        Improvements over the original implementation:
        * Uses canonical vulnerability types so ``sqli`` and
          ``sql_injection`` end up in the same group.
        * Normalizes endpoints (strips slashes, replaces path params
          with ``*``) so ``/users/{id}`` and ``/users/<int:id>`` group
          together.
        * Findings with an endpoint but no file_path are matched against
          existing endpoint-based groups using fuzzy matching.
        """
        groups: dict[str, list] = {}
        # Secondary index: maps canonical endpoint keys already seen so we
        # can fuzzy-match new findings against them.
        endpoint_keys: dict[str, str] = {}  # normalized_ep -> group_key

        for finding in findings:
            vuln_type = self._normalize_vuln_type(
                getattr(finding, "vulnerability_type", "unknown")
            )
            endpoint = getattr(finding, "endpoint", "")
            file_path = getattr(finding, "file_path", "")
            line_number = getattr(finding, "line_number", 0)
            parameter = getattr(finding, "parameter", "")

            key = None

            # Primary grouping: by file + line (same code location)
            if file_path and line_number:
                key = f"{vuln_type}:{file_path}:{line_number}"

            # Secondary grouping: by endpoint + parameter (same attack surface)
            elif endpoint and parameter:
                norm_ep = self._normalize_endpoint(endpoint)
                # Try to find fuzzy match with existing endpoint keys
                matched_ep = self._find_matching_endpoint(norm_ep, endpoint_keys)
                if matched_ep:
                    key = f"{vuln_type}:{matched_ep}:{parameter.lower()}"
                else:
                    key = f"{vuln_type}:{norm_ep}:{parameter.lower()}"
                    endpoint_keys[norm_ep] = key

            # Tertiary grouping: by endpoint + type
            elif endpoint:
                norm_ep = self._normalize_endpoint(endpoint)
                matched_ep = self._find_matching_endpoint(norm_ep, endpoint_keys)
                if matched_ep:
                    key = f"{vuln_type}:{matched_ep}"
                else:
                    key = f"{vuln_type}:{norm_ep}"
                    endpoint_keys[norm_ep] = key

            else:
                # No good grouping key, keep as unique
                key = f"{vuln_type}:{id(finding)}"

            if key not in groups:
                groups[key] = []
            groups[key].append(finding)

        return groups

    def _find_matching_endpoint(
        self, norm_ep: str, endpoint_keys: dict[str, str]
    ) -> str | None:
        """Return the first already-seen normalized endpoint that fuzzy-matches *norm_ep*."""
        for existing_ep in endpoint_keys:
            if self._endpoints_match(norm_ep, existing_ep):
                return existing_ep
        return None

    # ------------------------------------------------------------------
    # Priority helpers
    # ------------------------------------------------------------------

    def _confidence_priority(self, confidence: str) -> int:
        """Lower number = higher priority."""
        priorities = {"verified": 0, "probable": 1, "observed": 2}
        return priorities.get(confidence, 3)

    def _scanner_priority(self, scanner: str) -> int:
        """Lower number = higher priority (more reliable scanner gets priority)."""
        priorities = {
            "correlation": 0,  # Correlated findings are highest priority
            "semgrep": 1,      # SAST with code context
            "zap": 2,          # DAST with exploit proof
            "detect-secrets": 3,
            "pip-audit": 4,
            "safety": 5,
        }
        return priorities.get(scanner, 10)

    # ------------------------------------------------------------------
    # Merge helpers
    # ------------------------------------------------------------------

    def _merge_finding(self, primary, duplicate):
        """Merge useful information from a duplicate into the primary finding."""
        # If duplicate has code context that primary lacks
        if not getattr(primary, "code_snippet", "") and getattr(duplicate, "code_snippet", ""):
            primary.code_snippet = duplicate.code_snippet
            primary.file_path = duplicate.file_path
            primary.line_number = duplicate.line_number

        # If duplicate has dynamic proof that primary lacks
        if not getattr(primary, "payload", "") and getattr(duplicate, "payload", ""):
            primary.payload = duplicate.payload
            primary.response_evidence = getattr(duplicate, "response_evidence", "")
            primary.response_code = getattr(duplicate, "response_code", 0)

        # If duplicate has data flow that primary lacks
        if not getattr(primary, "data_flow", "") and getattr(duplicate, "data_flow", ""):
            primary.data_flow = duplicate.data_flow

        # If duplicate has endpoint info that primary lacks
        if not getattr(primary, "endpoint", "") and getattr(duplicate, "endpoint", ""):
            primary.endpoint = duplicate.endpoint
            primary.http_method = getattr(duplicate, "http_method", "")

        # If duplicate is verified, upgrade primary
        if getattr(duplicate, "confidence", "") == "verified":
            primary.confidence = "verified"

        # Merge notes
        dup_source = getattr(duplicate, "scanner_source", "")
        if dup_source:
            existing_notes = getattr(primary, "notes", "")
            primary.notes = f"{existing_notes}\nAlso found by: {dup_source}".strip()
