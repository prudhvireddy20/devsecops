"""
IAST Mapper - Correlates IAST events to SAST and DAST findings

Maps IAST events (source → sink evidence) to vulnerabilities by:
1. Matching sink types (sql, subprocess, template) to vuln types (sqli, cmdi, ssti)
2. Matching request IDs to DAST findings
3. Matching source/sink patterns to SAST findings
"""

import logging
from typing import Dict, List, Optional, Any, Tuple

logger = logging.getLogger(__name__)


class IASTMapper:
    """Maps IAST events to SAST/DAST findings."""

    # Mapping from IAST sink types to vulnerability types
    SINK_TO_VULN_TYPE = {
        "sql": "sqli",
        "sqlite3": "sqli",
        "psycopg2": "sqli",
        "pg": "sqli",
        "mysql": "sqli",
        "mysql2": "sqli",
        "subprocess": "cmdi",
        "template": "ssti",
        "path": "path_traversal",
        "xpath": "xpath_injection",
        "ldap": "ldap_injection",
        "os": "cmdi",
    }

    def __init__(self):
        self.event_to_findings: Dict[str, List[str]] = {}

    def map_events_to_findings(
        self,
        events: List[Dict[str, Any]],
        sast_findings: List[Dict[str, Any]],
        dast_findings: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Map IAST events to SAST and DAST findings.
        
        Returns list of correlations with IAST evidence.
        """
        correlations = []
        
        for event in events:
            # Skip sanitized events (no vulnerability evidence)
            if event.get("sanitized", True):
                continue
            
            # Map event sink type to vulnerability type
            vuln_type = self._map_sink_to_vuln_type(event.get("sink_type"))
            if not vuln_type:
                continue
            
            # Find matching SAST finding
            sast_match = self._find_sast_finding(
                event, vuln_type, sast_findings
            )
            
            # Find matching DAST finding
            dast_match = self._find_dast_finding(
                event, vuln_type, dast_findings
            )
            
            # Create correlation if matches found
            if sast_match and dast_match:
                correlation = {
                    "type": "iast_verified",
                    "sast_finding": sast_match,
                    "dast_finding": dast_match,
                    "iast_event": event,
                    "confidence": "verified_by_iast",
                    "evidence": {
                        "sink_type": event.get("sink_type"),
                        "input_value": event.get("input_value"),
                        "sink_location": event.get("sink_location"),
                        "unsanitized": not event.get("sanitized", True),
                        "evidence": event.get("evidence", {}),
                    },
                }
                correlations.append(correlation)
                logger.info(
                    f"IAST verified: {vuln_type} at {event.get('sink_location')}"
                )
        
        return correlations

    def _map_sink_to_vuln_type(self, sink_type: str) -> Optional[str]:
        """Map IAST sink type to vulnerability type."""
        return self.SINK_TO_VULN_TYPE.get(sink_type)

    def _find_sast_finding(
        self,
        event: Dict[str, Any],
        vuln_type: str,
        sast_findings: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """
        Find SAST finding matching IAST event.
        
        Matches based on:
        1. Vulnerability type
        2. File/location proximity
        3. CWE matching
        """
        best_match = None
        best_score = 0
        
        for finding in sast_findings:
            score = 0
            
            # Type match (highest priority)
            if finding.get("type") == vuln_type:
                score += 100
            elif self._types_equivalent(finding.get("type"), vuln_type):
                score += 50
            else:
                continue  # Skip if type doesn't match
            
            # CWE match (if available)
            event_cwe = self._infer_cwe_from_sink(event.get("sink_type"))
            finding_cwe = finding.get("cwe", "")
            if event_cwe and event_cwe in finding_cwe:
                score += 30
            
            # Keep best match
            if score > best_score:
                best_score = score
                best_match = finding
        
        return best_match if best_score >= 50 else None

    def _find_dast_finding(
        self,
        event: Dict[str, Any],
        vuln_type: str,
        dast_findings: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """
        Find DAST finding matching IAST event.
        
        Matches based on:
        1. Request ID (primary)
        2. Vulnerability type
        3. Endpoint matching
        """
        request_id = event.get("request_id")
        best_match = None
        best_score = 0
        
        for finding in dast_findings:
            score = 0
            
            # Request ID match (highest priority)
            if finding.get("_request_id") == request_id:
                score += 100
            
            # Type match
            if finding.get("type") == vuln_type:
                score += 50
            elif self._types_equivalent(finding.get("type"), vuln_type):
                score += 25
            else:
                continue  # Skip if type doesn't match
            
            # Keep best match
            if score > best_score:
                best_score = score
                best_match = finding
        
        return best_match if best_score >= 50 else None

    def _types_equivalent(self, type1: str, type2: str) -> bool:
        """Check if two vulnerability types are equivalent."""
        equivalents = {
            "sqli": ["sql_injection", "db_injection"],
            "cmdi": ["command_injection", "os_injection", "shell_injection"],
            "ssti": ["template_injection", "server_side_template"],
            "path_traversal": ["directory_traversal", "path_injection"],
        }
        
        for primary, alts in equivalents.items():
            if type1 == primary and type2 in alts:
                return True
            if type2 == primary and type1 in alts:
                return True
        
        return False

    def _infer_cwe_from_sink(self, sink_type: str) -> Optional[str]:
        """Infer CWE from IAST sink type."""
        cwe_mapping = {
            "sql": "CWE-89",
            "subprocess": "CWE-78",
            "template": "CWE-1336",
            "path": "CWE-22",
            "xpath": "CWE-643",
            "ldap": "CWE-90",
        }
        return cwe_mapping.get(sink_type)

    def get_iast_coverage_stats(
        self, events: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Get coverage statistics from IAST events."""
        by_sink_type = {}
        unsanitized_count = 0
        
        for event in events:
            sink = event.get("sink_type", "unknown")
            by_sink_type[sink] = by_sink_type.get(sink, 0) + 1
            
            if not event.get("sanitized", True):
                unsanitized_count += 1
        
        return {
            "total_events": len(events),
            "unsanitized_events": unsanitized_count,
            "by_sink_type": by_sink_type,
            "coverage_percentage": (
                unsanitized_count / len(events) * 100
                if events
                else 0
            ),
        }


class IASTCorrelationResult:
    """Result of IAST-based correlation."""

    def __init__(self, iast_events: List[Dict[str, Any]]):
        self.iast_events = iast_events
        self.mapper = IASTMapper()
        self.correlations: List[Dict[str, Any]] = []

    def correlate(
        self,
        sast_findings: List[Dict[str, Any]],
        dast_findings: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Perform IAST-based correlation."""
        self.correlations = self.mapper.map_events_to_findings(
            self.iast_events, sast_findings, dast_findings
        )
        return self.correlations

    def get_verified_count(self) -> int:
        """Get count of IAST-verified findings."""
        return len(
            [
                c for c in self.correlations
                if c.get("confidence") == "verified_by_iast"
            ]
        )

    def get_statistics(self) -> Dict[str, Any]:
        """Get correlation statistics."""
        verified = self.get_verified_count()
        
        return {
            "total_correlations": len(self.correlations),
            "iast_verified": verified,
            "verification_rate": (
                verified / len(self.correlations) * 100
                if self.correlations
                else 0
            ),
            "event_statistics": self.mapper.get_iast_coverage_stats(
                self.iast_events
            ),
        }


def demo_iast_mapper():
    """Demo IAST mapper functionality."""
    print("\n" + "="*80)
    print("IAST MAPPER DEMO - Event to Finding Correlation")
    print("="*80)
    
    # Create demo IAST events
    demo_events = [
        {
            "event_id": "evt-001",
            "request_id": "req-001",
            "source_type": "http_parameter",
            "sink_type": "sql",
            "sink_location": "app.py:45",
            "input_value": "1' or '1'='1",
            "sanitized": False,
            "evidence": {"sql_query": "SELECT * FROM users WHERE id = 1' or '1'='1"},
        },
        {
            "event_id": "evt-002",
            "request_id": "req-002",
            "source_type": "http_parameter",
            "sink_type": "subprocess",
            "sink_location": "shell.py:120",
            "input_value": "test; cat /etc/passwd",
            "sanitized": False,
            "evidence": {"command": "/bin/sh -c test; cat /etc/passwd"},
        },
        {
            "event_id": "evt-003",
            "request_id": "req-003",
            "source_type": "http_parameter",
            "sink_type": "sql",
            "sink_location": "db.py:60",
            "input_value": "normal_input",
            "sanitized": True,
            "evidence": {"sql_query": "SELECT * FROM users WHERE email = ?"},
        },
    ]
    
    # Create demo SAST findings
    demo_sast = [
        {
            "id": "sast-001",
            "type": "sqli",
            "file": "app.py",
            "line": 45,
            "parameter": "id",
            "cwe": "CWE-89",
        },
        {
            "id": "sast-002",
            "type": "cmdi",
            "file": "shell.py",
            "line": 120,
            "parameter": "cmd",
            "cwe": "CWE-78",
        },
    ]
    
    # Create demo DAST findings
    demo_dast = [
        {
            "id": "dast-001",
            "type": "sqli",
            "endpoint": "/api/users",
            "parameter": "id",
            "_request_id": "req-001",
        },
        {
            "id": "dast-002",
            "type": "cmdi",
            "endpoint": "/api/shell",
            "parameter": "cmd",
            "_request_id": "req-002",
        },
    ]
    
    # Run correlation
    result = IASTCorrelationResult(demo_events)
    correlations = result.correlate(demo_sast, demo_dast)
    
    print(f"\nEvents: {len(demo_events)}")
    print(f"SAST Findings: {len(demo_sast)}")
    print(f"DAST Findings: {len(demo_dast)}")
    print(f"\nIAST-based Correlations: {len(correlations)}")
    
    for i, corr in enumerate(correlations, 1):
        print(f"\n  {i}. {corr.get('confidence')}")
        print(f"     SAST: {corr['sast_finding'].get('type')} ({corr['sast_finding'].get('id')})")
        print(f"     DAST: {corr['dast_finding'].get('type')} ({corr['dast_finding'].get('id')})")
        print(f"     Event: {corr['iast_event'].get('sink_type')} - {corr['iast_event'].get('input_value')}")
    
    stats = result.get_statistics()
    print(f"\n{'─'*80}")
    print(f"Statistics:")
    print(f"  Total Correlations: {stats['total_correlations']}")
    print(f"  IAST Verified: {stats['iast_verified']}")
    print(f"  Verification Rate: {stats['verification_rate']:.1f}%")
    print(f"  Unsanitized Events: {stats['event_statistics']['unsanitized_events']}")
    print("="*80 + "\n")


if __name__ == "__main__":
    demo_iast_mapper()
