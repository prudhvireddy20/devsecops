"""Risk ranking utility for findings."""

from __future__ import annotations


SEVERITY_SCORE = {
    "critical": 90,
    "high": 70,
    "medium": 50,
    "low": 30,
    "info": 10,
}

CONFIDENCE_BONUS = {
    "verified": 15,
    "probable": 8,
    "observed": 3,
}


def score_finding(finding) -> dict:
    """Compute normalized risk score and level for a finding model instance."""
    severity = str(getattr(finding, "severity", "medium") or "medium").lower()
    confidence = str(getattr(finding, "confidence", "probable") or "probable").lower()

    score = int(SEVERITY_SCORE.get(severity, 50))
    score += int(CONFIDENCE_BONUS.get(confidence, 0))

    if getattr(finding, "payload", ""):
        score += 6
    if getattr(finding, "response_evidence", ""):
        score += 6

    role = str(getattr(finding, "auth_role", "") or "").lower()
    if role in {"guest", "anonymous", "default", ""}:
        score += 6
    elif role in {"user", "member"}:
        score += 4
    elif role in {"admin", "superadmin"}:
        score += 2

    if getattr(finding, "workflow_step_id", ""):
        score += 4

    score = max(0, min(score, 100))

    if score >= 85:
        level = "critical"
    elif score >= 65:
        level = "high"
    elif score >= 40:
        level = "medium"
    else:
        level = "low"

    return {"risk_score": score, "risk_level": level}
