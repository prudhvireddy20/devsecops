"""
IAST (Interactive Application Security Testing) Integration

Provides runtime instrumentation to verify that untrusted input reaches
vulnerable sinks without proper sanitization.

Modules:
- python_agent: Python function hooks for vulnerability detection
- nodejs_agent: Node.js function hooks for vulnerability detection
"""
