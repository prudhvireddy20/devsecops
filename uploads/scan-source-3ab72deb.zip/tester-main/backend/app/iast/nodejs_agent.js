/**
 * Node.js IAST Agent - Runtime Instrumentation for Vulnerability Detection
 * 
 * This agent hooks into dangerous Node.js functions to track:
 * - Untrusted input sources (HTTP request parameters)
 * - Sensitive sinks (database queries, subprocess execution, etc.)
 * - Proof that untrusted input reached vulnerable sinks
 * 
 * Instrumented modules:
 * - sqlite3, pg, mysql/mysql2 - SQL injection
 * - child_process - Command injection
 * - ejs, pug, handlebars - Server-side template injection
 * - fs - Path traversal
 */

const fs = require('fs');
const path = require('path');
const uuid = require('crypto').randomUUID || (() => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => (c === 'x' ? Math.random() * 16 | 0 : 'y' ^ Math.random() * 16 | 0).toString(16)));

// Request context storage (using WeakMap for automatic cleanup)
const requestContextMap = new WeakMap();
let currentRequestId = null;
let currentRequestData = null;

// Event queue for sending to IAST engine
const eventQueue = [];
const MAX_QUEUE_SIZE = 10000;

/**
 * IAST Event class
 */
class IASTEvent {
  constructor({
    eventId,
    requestId,
    sourceType,
    sinkType,
    sinkLocation,
    inputValue,
    sanitized = false,
    evidence = {},
  }) {
    this.eventId = eventId;
    this.requestId = requestId;
    this.sourceType = sourceType;
    this.sinkType = sinkType;
    this.sinkLocation = sinkLocation;
    this.inputValue = inputValue.substring(0, 200);
    this.sanitized = sanitized;
    this.evidence = evidence;
    this.timestamp = new Date().toISOString();
  }

  toJSON() {
    return {
      event_id: this.eventId,
      request_id: this.requestId,
      source_type: this.sourceType,
      sink_type: this.sinkType,
      sink_location: this.sinkLocation,
      input_value: this.inputValue,
      sanitized: this.sanitized,
      evidence: this.evidence,
      timestamp: this.timestamp,
    };
  }
}

/**
 * Set current HTTP request context
 */
function setRequestContext(requestId, requestData) {
  currentRequestId = requestId;
  currentRequestData = requestData || {};
}

/**
 * Get current request context
 */
function getRequestContext() {
  if (currentRequestId && currentRequestData) {
    return {
      request_id: currentRequestId,
      request_data: currentRequestData,
    };
  }
  return null;
}

/**
 * Clear request context
 */
function clearRequestContext() {
  currentRequestId = null;
  currentRequestData = null;
}

/**
 * Get the first parameter value from request data for evidence
 */
function getSourceValue(requestData) {
  const commonParams = ['query', 'q', 'search', 'id', 'user_id', 'username', 'email'];
  
  for (const key of commonParams) {
    if (key in requestData) {
      return String(requestData[key]).substring(0, 100);
    }
  }
  
  for (const value of Object.values(requestData)) {
    if (typeof value === 'string' || typeof value === 'number') {
      return String(value).substring(0, 100);
    }
  }
  
  return 'unknown';
}

/**
 * Get stack location for debugging
 */
function getStackLocation() {
  const stack = new Error().stack.split('\n');
  // Skip first few frames
  for (let i = 3; i < stack.length; i++) {
    if (!stack[i].includes('iast_agent') && !stack[i].includes('node_modules')) {
      return stack[i].trim().substring(0, 150);
    }
  }
  return 'unknown';
}

/**
 * Emit an IAST event
 */
function emitEvent(event) {
  if (eventQueue.length < MAX_QUEUE_SIZE) {
    eventQueue.push(event.toJSON());
  }
}

/**
 * Hook for SQL execution functions
 */
function hookSQLExecution(func, sinkType) {
  return function(...args) {
    const context = getRequestContext();
    
    // Extract SQL query
    let sqlQuery = null;
    if (args[0]) {
      sqlQuery = String(args[0]).substring(0, 200);
    }
    
    // Check if sanitized
    const sanitized = sqlQuery ? checkSQLSanitization(sqlQuery) : true;
    
    if (context && sqlQuery) {
      const event = new IASTEvent({
        eventId: uuid(),
        requestId: context.request_id,
        sourceType: 'http_parameter',
        sinkType,
        sinkLocation: getStackLocation(),
        inputValue: getSourceValue(context.request_data),
        sanitized,
        evidence: {
          sql_query: sqlQuery,
          query_length: sqlQuery.length,
          suspicious_keywords: findSQLKeywords(sqlQuery),
        },
      });
      emitEvent(event);
    }
    
    return func.apply(this, args);
  };
}

/**
 * Hook for subprocess execution
 */
function hookSubprocessExecution(func) {
  return function(...args) {
    const context = getRequestContext();
    
    // Extract command
    let command = null;
    if (args[0]) {
      command = String(args[0]).substring(0, 200);
    }
    
    const sanitized = command ? checkCommandSanitization(command) : true;
    
    if (context && command) {
      const event = new IASTEvent({
        eventId: uuid(),
        requestId: context.request_id,
        sourceType: 'http_parameter',
        sinkType: 'subprocess',
        sinkLocation: getStackLocation(),
        inputValue: getSourceValue(context.request_data),
        sanitized,
        evidence: {
          command,
          has_shell_operators: ['|', '&', ';', '`', '$'].some(op => command.includes(op)),
        },
      });
      emitEvent(event);
    }
    
    return func.apply(this, args);
  };
}

/**
 * Hook for template rendering
 */
function hookTemplateRendering(func, templateEngine) {
  return function(...args) {
    const context = getRequestContext();
    
    let templateContent = null;
    if (args[0]) {
      templateContent = String(args[0]).substring(0, 200);
    }
    
    const sanitized = templateContent ? checkSSTISanitization(templateContent) : true;
    
    if (context && templateContent) {
      const event = new IASTEvent({
        eventId: uuid(),
        requestId: context.request_id,
        sourceType: 'http_parameter',
        sinkType: 'template',
        sinkLocation: getStackLocation(),
        inputValue: getSourceValue(context.request_data),
        sanitized,
        evidence: {
          template_engine: templateEngine,
          template_preview: templateContent.substring(0, 100),
          ssti_indicators: findSSTIPatterns(templateContent),
        },
      });
      emitEvent(event);
    }
    
    return func.apply(this, args);
  };
}

/**
 * Check if SQL query appears sanitized
 */
function checkSQLSanitization(query) {
  const suspicious = [
    "' or '",
    "' or 1=1",
    'union',
    'select',
    ';',
    '--',
    '/*',
  ];
  const queryLower = query.toLowerCase();
  return !suspicious.some(pattern => queryLower.includes(pattern));
}

/**
 * Find SQL keywords in query
 */
function findSQLKeywords(query) {
  const keywords = ['union', 'select', 'insert', 'update', 'delete', 'drop', 'where'];
  const queryLower = query.toLowerCase();
  return keywords.filter(kw => queryLower.includes(kw));
}

/**
 * Check if command appears sanitized
 */
function checkCommandSanitization(command) {
  const shellOperators = ['|', '&', ';', '`', '$', '$(', '${'];
  return !shellOperators.some(op => command.includes(op));
}

/**
 * Check for SSTI sanitization
 */
function checkSSTISanitization(template) {
  const ssti_patterns = ['{{', '{%', '${', '<%', '[['];
  return !ssti_patterns.some(pattern => template.includes(pattern));
}

/**
 * Find SSTI patterns
 */
function findSSTIPatterns(template) {
  const patterns = [];
  if (template.includes('{{')) patterns.push('ejs_tag');
  if (template.includes('<%')) patterns.push('ejs_scriptlet');
  if (template.includes('#{')) patterns.push('erb_tag');
  if (template.includes('{{')) patterns.push('handlebars_tag');
  return patterns;
}

/**
 * Install all IAST hooks
 */
function installHooks() {
  try {
    // Hook sqlite3
    const sqlite3 = require('sqlite3');
    const Database = sqlite3.Database;
    const originalRun = Database.prototype.run;
    Database.prototype.run = hookSQLExecution(originalRun, 'sqlite3');
  } catch (e) {
    // sqlite3 not installed
  }

  try {
    // Hook pg (PostgreSQL)
    const pg = require('pg');
    const Client = pg.Client;
    const originalQuery = Client.prototype.query;
    Client.prototype.query = hookSQLExecution(originalQuery, 'pg');
  } catch (e) {
    // pg not installed
  }

  try {
    // Hook mysql2
    const mysql2 = require('mysql2');
    const Connection = mysql2.Connection;
    const originalQuery = Connection.prototype.query;
    Connection.prototype.query = hookSQLExecution(originalQuery, 'mysql2');
  } catch (e) {
    // mysql2 not installed
  }

  try {
    // Hook child_process
    const childProcess = require('child_process');
    childProcess.exec = hookSubprocessExecution(childProcess.exec);
    childProcess.execSync = hookSubprocessExecution(childProcess.execSync);
    childProcess.spawn = hookSubprocessExecution(childProcess.spawn);
  } catch (e) {
    // child_process unavailable
  }

  try {
    // Hook EJS
    const ejs = require('ejs');
    ejs.render = hookTemplateRendering(ejs.render, 'ejs');
  } catch (e) {
    // EJS not installed
  }

  try {
    // Hook Pug
    const pug = require('pug');
    pug.render = hookTemplateRendering(pug.render, 'pug');
  } catch (e) {
    // Pug not installed
  }

  try {
    // Hook Handlebars
    const handlebars = require('handlebars');
    const originalCompile = handlebars.compile;
    handlebars.compile = function(source, options) {
      const context = getRequestContext();
      if (context) {
        const event = new IASTEvent({
          eventId: uuid(),
          requestId: context.request_id,
          sourceType: 'http_parameter',
          sinkType: 'template',
          sinkLocation: getStackLocation(),
          inputValue: getSourceValue(context.request_data),
          sanitized: checkSSTISanitization(source),
          evidence: {
            template_engine: 'handlebars',
            template_preview: source.substring(0, 100),
          },
        });
        emitEvent(event);
      }
      return originalCompile.call(this, source, options);
    };
  } catch (e) {
    // Handlebars not installed
  }
}

/**
 * Get all events from queue
 */
function getEvents() {
  const events = [...eventQueue];
  eventQueue.length = 0;
  return events;
}

/**
 * Export events to file
 */
function exportEvents(filepath) {
  const events = getEvents();
  fs.writeFileSync(filepath, JSON.stringify(events, null, 2));
  return events.length;
}

/**
 * Clear event queue
 */
function clearEvents() {
  eventQueue.length = 0;
}

// Auto-install hooks unless disabled
if (process.env.DISABLE_IAST_AGENT !== 'true') {
  installHooks();
}

module.exports = {
  setRequestContext,
  getRequestContext,
  clearRequestContext,
  getEvents,
  exportEvents,
  clearEvents,
  IASTEvent,
};
