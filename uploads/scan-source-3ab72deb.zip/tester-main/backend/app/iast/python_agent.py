"""
Python IAST Agent - Runtime Instrumentation for Vulnerability Detection

This agent hooks into dangerous Python functions to track:
- Untrusted input sources (HTTP request parameters)
- Sensitive sinks (database queries, subprocess execution, etc.)
- Proof that untrusted input reached vulnerable sinks

Instrumented functions:
- sqlite3.execute() / psycopg2.execute() - SQL injection
- subprocess.Popen() / os.system() - Command injection
- Template rendering - Server-side template injection
- File operations - Path traversal
"""

import sys
import os
import json
import uuid
import time
import functools
import inspect
from typing import Any, Callable, Dict, List, Optional
from datetime import datetime, timezone
from pathlib import Path
import threading
import queue

# Thread-local storage for request context
_request_context = threading.local()

# Global event queue for sending to IAST engine
_event_queue = queue.Queue()


class IASTEvent:
    """Represents a single IAST event (source → sink)."""

    def __init__(
        self,
        event_id: str,
        request_id: str,
        source_type: str,
        sink_type: str,
        sink_location: str,
        input_value: str,
        sanitized: bool = False,
        evidence: Dict[str, Any] = None,
    ):
        self.event_id = event_id
        self.request_id = request_id
        self.source_type = source_type  # "http_parameter", "url_path", "header"
        self.sink_type = sink_type  # "sql", "subprocess", "template", "path"
        self.sink_location = sink_location  # stack trace location
        self.input_value = input_value  # first 200 chars
        self.sanitized = sanitized
        self.evidence = evidence or {}
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for JSON serialization."""
        return {
            "event_id": self.event_id,
            "request_id": self.request_id,
            "source_type": self.source_type,
            "sink_type": self.sink_type,
            "sink_location": self.sink_location,
            "input_value": self.input_value[:200],
            "sanitized": self.sanitized,
            "evidence": self.evidence,
            "timestamp": self.timestamp,
        }


def set_request_context(request_id: str, request_data: Dict[str, Any]):
    """Set the current HTTP request context for tracking."""
    _request_context.data = {
        "request_id": request_id,
        "request_data": request_data,
        "timestamp": time.time(),
    }


def get_request_context() -> Optional[Dict[str, Any]]:
    """Get the current request context if set."""
    return getattr(_request_context, "data", None)


def clear_request_context():
    """Clear the request context."""
    if hasattr(_request_context, "data"):
        delattr(_request_context, "data")


def _get_source_value(request_data: Dict[str, Any]) -> str:
    """Extract the first parameter value from request data for evidence."""
    # Look for common parameter names
    for key in ["query", "q", "search", "id", "user_id", "username", "email"]:
        if key in request_data:
            return str(request_data[key])[:100]
    
    # Fallback to first parameter
    for value in request_data.values():
        return str(value)[:100]
    
    return "unknown"


def _get_stack_location() -> str:
    """Get the call stack location for debugging."""
    stack = inspect.stack()
    # Skip first few frames (this function, the hooked function, etc.)
    for frame_info in stack[3:]:
        if "iast_agent" not in frame_info.filename:
            return f"{frame_info.filename}:{frame_info.lineno} in {frame_info.function}"
    return "unknown"


def _emit_event(event: IASTEvent):
    """Emit an IAST event to the event queue."""
    _event_queue.put(event.to_dict())


def _hook_sql_execution(func: Callable, sink_type: str) -> Callable:
    """Hook for SQL execution functions (sqlite3, psycopg2, etc.)."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        context = get_request_context()
        
        # Extract SQL query from arguments
        sql_query = None
        if args:
            sql_query = str(args[0])[:200]
        elif "query" in kwargs:
            sql_query = str(kwargs["query"])[:200]
        elif "sql" in kwargs:
            sql_query = str(kwargs["sql"])[:200]
        
        # Check if query contains suspicious patterns indicating SQL injection
        sanitized = _check_sql_sanitization(sql_query) if sql_query else True
        
        if context and sql_query:
            event = IASTEvent(
                event_id=str(uuid.uuid4()),
                request_id=context["request_id"],
                source_type="http_parameter",
                sink_type=sink_type,
                sink_location=_get_stack_location(),
                input_value=_get_source_value(context["request_data"]),
                sanitized=sanitized,
                evidence={
                    "sql_query": sql_query,
                    "query_length": len(sql_query),
                    "suspicious_keywords": _find_sql_injection_keywords(sql_query),
                },
            )
            _emit_event(event)
        
        # Call the original function
        return func(*args, **kwargs)
    
    return wrapper


def _hook_subprocess_execution(func: Callable) -> Callable:
    """Hook for subprocess execution functions."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        context = get_request_context()
        
        # Extract command from arguments
        command = None
        if args:
            command = str(args[0])[:200]
        elif "args" in kwargs:
            command = str(kwargs["args"])[:200]
        elif "cmd" in kwargs:
            command = str(kwargs["cmd"])[:200]
        
        # Check if command contains suspicious patterns
        sanitized = _check_command_sanitization(command) if command else True
        
        if context and command:
            event = IASTEvent(
                event_id=str(uuid.uuid4()),
                request_id=context["request_id"],
                source_type="http_parameter",
                sink_type="subprocess",
                sink_location=_get_stack_location(),
                input_value=_get_source_value(context["request_data"]),
                sanitized=sanitized,
                evidence={
                    "command": command,
                    "has_shell_operators": any(
                        op in command for op in ["|", "&", ";", "`", "$"]
                    ),
                },
            )
            _emit_event(event)
        
        # Call the original function
        return func(*args, **kwargs)
    
    return wrapper


def _hook_template_rendering(func: Callable, template_engine: str) -> Callable:
    """Hook for template rendering functions."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        context = get_request_context()
        
        # Extract template content
        template_content = None
        if args:
            template_content = str(args[0])[:200]
        elif "template" in kwargs:
            template_content = str(kwargs["template"])[:200]
        elif "template_string" in kwargs:
            template_content = str(kwargs["template_string"])[:200]
        
        # Check for SSTI indicators
        sanitized = _check_ssti_sanitization(template_content) if template_content else True
        
        if context and template_content:
            event = IASTEvent(
                event_id=str(uuid.uuid4()),
                request_id=context["request_id"],
                source_type="http_parameter",
                sink_type="template",
                sink_location=_get_stack_location(),
                input_value=_get_source_value(context["request_data"]),
                sanitized=sanitized,
                evidence={
                    "template_engine": template_engine,
                    "template_preview": template_content[:100],
                    "ssti_indicators": _find_ssti_patterns(template_content),
                },
            )
            _emit_event(event)
        
        # Call the original function
        return func(*args, **kwargs)
    
    return wrapper


def _check_sql_sanitization(query: str) -> bool:
    """Check if SQL query appears to be properly sanitized."""
    # Suspicious patterns that suggest unsanitized input
    suspicious = [
        "' or '",
        "' or 1=1",
        "union",
        "select",
        ";",
        "--",
        "/*",
    ]
    query_lower = query.lower()
    return not any(pattern in query_lower for pattern in suspicious)


def _find_sql_injection_keywords(query: str) -> List[str]:
    """Find SQL injection keywords in a query."""
    keywords = ["union", "select", "insert", "update", "delete", "drop", "where"]
    query_lower = query.lower()
    return [kw for kw in keywords if kw in query_lower]


def _check_command_sanitization(command: str) -> bool:
    """Check if command appears to be properly sanitized."""
    # Commands with shell operators suggest unsanitized input
    shell_operators = ["|", "&", ";", "`", "$", "$(", "${"]
    return not any(op in command for op in shell_operators)


def _check_ssti_sanitization(template: str) -> bool:
    """Check if template appears to have SSTI vulnerabilities."""
    # SSTI patterns
    ssti_patterns = [
        "{{",
        "{%",
        "${",
        "<%",
        "[["
    ]
    return not any(pattern in template for pattern in ssti_patterns)


def _find_ssti_patterns(template: str) -> List[str]:
    """Find SSTI patterns in template content."""
    patterns = []
    if "{{" in template:
        patterns.append("jinja2_variable")
    if "{%" in template:
        patterns.append("jinja2_tag")
    if "${" in template:
        patterns.append("el_expression")
    if "{#" in template:
        patterns.append("velocity_macro")
    return patterns


def install_hooks():
    """Install all IAST hooks into instrumented functions."""
    try:
        # Hook SQLite
        import sqlite3
        sqlite3.Connection.execute = _hook_sql_execution(
            sqlite3.Connection.execute, "sqlite3"
        )
    except (ImportError, AttributeError):
        pass
    
    try:
        # Hook psycopg2 (PostgreSQL)
        import psycopg2
        import psycopg2.extensions
        psycopg2.extensions.connection.execute = _hook_sql_execution(
            psycopg2.extensions.connection.execute, "psycopg2"
        )
    except (ImportError, AttributeError):
        pass
    
    try:
        # Hook subprocess
        import subprocess
        subprocess.Popen = _hook_subprocess_execution(subprocess.Popen)
    except (ImportError, AttributeError):
        pass
    
    try:
        # Hook os.system
        import os
        os.system = _hook_subprocess_execution(os.system)
    except (ImportError, AttributeError):
        pass
    
    try:
        # Hook Jinja2
        from jinja2 import Template
        Template.render = _hook_template_rendering(
            Template.render, "jinja2"
        )
    except (ImportError, AttributeError):
        pass


def get_events() -> List[Dict[str, Any]]:
    """Get all accumulated events from the queue."""
    events = []
    while not _event_queue.empty():
        try:
            events.append(_event_queue.get_nowait())
        except queue.Empty:
            break
    return events


def export_events(filepath: str):
    """Export accumulated events to a JSON file."""
    events = get_events()
    with open(filepath, "w") as f:
        json.dump(events, f, indent=2)
    return len(events)


# Auto-install hooks when module is imported
if not os.environ.get("DISABLE_IAST_AGENT"):
    install_hooks()
