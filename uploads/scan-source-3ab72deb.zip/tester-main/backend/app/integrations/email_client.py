"""Email (SMTP) integration — post-scan report delivery.

SMTP server credentials come from environment variables (see ``Settings``);
recipients and the on/off toggle live in the ``integration_settings`` table
and are managed from the dashboard (Tools → Integrations → Email).
"""

from __future__ import annotations

import asyncio
import html
import logging
import smtplib
from email.message import EmailMessage
from pathlib import Path

from sqlalchemy import select

from app.core.config import settings

logger = logging.getLogger(__name__)

_SMTP_TIMEOUT_SECONDS = 30


def smtp_configured() -> bool:
    """True when the SMTP env vars required to send mail are all set."""
    return bool(settings.SMTP_HOST and settings.SMTP_USERNAME and settings.SMTP_PASSWORD)


def _from_email() -> str:
    return settings.SMTP_FROM_EMAIL or settings.SMTP_USERNAME


def _send_sync(msg: EmailMessage) -> None:
    """Blocking SMTP send — run via asyncio.to_thread."""
    if settings.SMTP_PORT == 465:
        with smtplib.SMTP_SSL(
            settings.SMTP_HOST, settings.SMTP_PORT, timeout=_SMTP_TIMEOUT_SECONDS
        ) as server:
            server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.send_message(msg)
        return
    with smtplib.SMTP(
        settings.SMTP_HOST, settings.SMTP_PORT, timeout=_SMTP_TIMEOUT_SECONDS
    ) as server:
        if settings.SMTP_USE_TLS:
            server.starttls()
        server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
        server.send_message(msg)


async def send_email(
    recipients: list[str],
    subject: str,
    html_body: str,
    attachments: list[tuple[str, bytes, str, str]] | None = None,
) -> None:
    """Send an HTML email. Attachments are (filename, data, maintype, subtype).

    Raises on SMTP failure — callers decide whether that is fatal.
    """
    if not smtp_configured():
        raise RuntimeError(
            "SMTP is not configured — set SMTP_HOST, SMTP_USERNAME and SMTP_PASSWORD"
        )
    if not recipients:
        raise RuntimeError("No recipients configured")

    msg = EmailMessage()
    msg["From"] = _from_email()
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content("This email contains an HTML report. Open in an HTML-capable client.")
    msg.add_alternative(html_body, subtype="html")
    for filename, data, maintype, subtype in attachments or []:
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=filename)

    await asyncio.to_thread(_send_sync, msg)


async def get_email_integration_settings(db) -> tuple[bool, list[str]]:
    """Return (enabled, recipients) for the email integration."""
    from app.models.integration_setting import IntegrationSetting

    result = await db.execute(
        select(IntegrationSetting).where(IntegrationSetting.key == "email")
    )
    row = result.scalar_one_or_none()
    if not row:
        return False, []
    recipients = [r for r in (row.config or {}).get("recipients", []) if r]
    return bool(row.enabled), recipients


def _summary_html(scan: dict, project: dict, findings: list[dict]) -> str:
    """Compact inline summary for the email body (theme-independent HTML)."""
    summary = scan.get("results_summary") or {}
    sev_rows = "".join(
        f"<tr><td style='padding:4px 12px 4px 0;color:{color}'><b>{label}</b></td>"
        f"<td style='padding:4px 0;text-align:right'><b>{summary.get(key, 0)}</b></td></tr>"
        for key, label, color in (
            ("critical", "Critical", "#cf222e"),
            ("high", "High", "#bc4c00"),
            ("medium", "Medium", "#9a6700"),
            ("low", "Low", "#1a7f37"),
            ("info", "Info", "#0969da"),
        )
    )
    top = sorted(findings, key=lambda f: f.get("risk_score") or 0, reverse=True)[:5]
    top_rows = "".join(
        "<li style='margin:2px 0'>"
        f"[{html.escape(str(f.get('severity', '')).upper())}] "
        f"{html.escape(f.get('title') or 'Untitled')}"
        f"{' — <code>' + html.escape(f['endpoint']) + '</code>' if f.get('endpoint') else ''}"
        "</li>"
        for f in top
    )
    return f"""
<div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px">
  <h2 style="margin:0 0 4px">TraceON scan report — {html.escape(project.get('name') or 'Project')}</h2>
  <p style="margin:0 0 16px;color:#59636e">
    Target: <code>{html.escape(project.get('target_url') or project.get('repo_url') or '—')}</code><br>
    Completed: {html.escape(scan.get('completed_at') or '—')} ·
    Total findings: <b>{summary.get('total_findings', len(findings))}</b>
  </p>
  <table style="border-collapse:collapse;margin:0 0 16px">{sev_rows}</table>
  {f"<p style='margin:0 0 4px'><b>Highest-risk findings</b></p><ul style='margin:0 0 16px;padding-left:20px'>{top_rows}</ul>" if top_rows else ""}
  <p style="margin:0;color:#59636e">The full report is attached as HTML.</p>
</div>
"""


async def send_scan_report_email(scan_id: str, ws=None) -> None:
    """Generate the HTML report for a completed scan and email it.

    Fire-and-forget: opens its own DB session, logs every failure, never raises.
    """
    try:
        if not smtp_configured():
            return

        from app.core.database import async_session_factory
        from app.models.finding import Finding
        from app.models.project import Project
        from app.models.scan import Scan

        async with async_session_factory() as db:
            enabled, recipients = await get_email_integration_settings(db)
            if not enabled or not recipients:
                return

            scan = (
                await db.execute(select(Scan).where(Scan.id == scan_id))
            ).scalar_one_or_none()
            if not scan:
                logger.warning("email integration: scan %s not found", scan_id)
                return
            project = (
                await db.execute(select(Project).where(Project.id == scan.project_id))
            ).scalar_one_or_none()
            findings = (
                (
                    await db.execute(
                        select(Finding).where(
                            Finding.scan_id == scan_id,
                            Finding.status != "duplicate",
                        )
                    )
                )
                .scalars()
                .all()
            )

            scan_data = scan.to_dict()
            project_data = project.to_dict() if project else {}
            findings_data = [f.to_dict() for f in findings]

        # Generate the standalone HTML report (same path as the reports API)
        from app.reports.html_report import HTMLReportGenerator

        report_dir = settings.REPORTS_DIR / scan_id
        report_dir.mkdir(parents=True, exist_ok=True)
        file_path = await HTMLReportGenerator().generate(
            scan_data, project_data, findings_data, report_dir
        )
        report_bytes = Path(file_path).read_bytes()

        project_name = project_data.get("name") or "project"
        summary = scan_data.get("results_summary") or {}
        subject = (
            f"TraceON report — {project_name}: "
            f"{summary.get('total_findings', len(findings_data))} findings "
            f"({summary.get('critical', 0)} critical, {summary.get('high', 0)} high)"
        )
        await send_email(
            recipients,
            subject,
            _summary_html(scan_data, project_data, findings_data),
            attachments=[
                (f"traceon-report-{scan_id[:8]}.html", report_bytes, "text", "html")
            ],
        )
        logger.info(
            "email integration: report for scan %s sent to %d recipient(s)",
            scan_id,
            len(recipients),
        )
        if ws is not None:
            try:
                await ws.send_scan_log(
                    scan_id, f"Report emailed to {len(recipients)} recipient(s)"
                )
            except Exception:  # noqa: BLE001 — log delivery is best-effort
                pass
    except Exception:  # noqa: BLE001 — never let email delivery break anything
        logger.exception("email integration: failed to send report for scan %s", scan_id)
