"""GitNexus MCP client and evidence helpers."""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any

import httpx

from app.core.config import settings
from app.utils.normalizers import normalize_endpoint_value, normalize_file_path

logger = logging.getLogger(__name__)

_MCP_PROTOCOL_VERSION = "2025-11-25"
_PARAM_RE = re.compile(r"[<{][^>}]+[>}]|:(\w+)")
_LINE_SUFFIX_RE = re.compile(r":\d+(?::\d+)?$")


def endpoints_match(ep1: str, ep2: str) -> bool:
    if not ep1 or not ep2:
        return False
    ep1_clean = _PARAM_RE.sub("*", normalize_endpoint_value(ep1))
    ep2_clean = _PARAM_RE.sub("*", normalize_endpoint_value(ep2))
    if ep1_clean == ep2_clean:
        return True
    parts1 = ep1_clean.split("/")
    parts2 = ep2_clean.split("/")
    if len(parts1) != len(parts2):
        return False
    for p1, p2 in zip(parts1, parts2):
        if p1 == "*" or p2 == "*":
            continue
        if p1 != p2:
            return False
    return True


def _strip_line_suffix(path: str) -> str:
    return _LINE_SUFFIX_RE.sub("", path or "")


def file_paths_match(path_a: str, path_b: str) -> bool:
    if not path_a or not path_b:
        return False
    norm_a = _strip_line_suffix(normalize_file_path(path_a))
    norm_b = _strip_line_suffix(normalize_file_path(path_b))
    return norm_a.endswith(norm_b) or norm_b.endswith(norm_a)


def build_flow_evidence(
    api_impact: dict | None,
    *,
    endpoint: str | None,
    file_path: str | None,
) -> dict:
    if not api_impact:
        return {
            "status": "unavailable",
            "flow_confirmed": None,
            "reason": "no data",
        }

    if isinstance(api_impact, dict) and api_impact.get("error"):
        return {
            "status": "unavailable",
            "flow_confirmed": None,
            "reason": str(api_impact.get("error")),
        }

    routes: list[dict] = []
    if isinstance(api_impact, dict) and isinstance(api_impact.get("routes"), list):
        routes = api_impact.get("routes", [])
    elif isinstance(api_impact, dict):
        routes = [api_impact]

    matched_route = ""
    matched_handler = ""
    route_match = False
    handler_match = False

    for route in routes:
        route_path = str(route.get("route", "") or "")
        handler = str(route.get("handler", "") or "")
        route_match = bool(endpoint and route_path and endpoints_match(endpoint, route_path))
        handler_match = bool(file_path and handler and file_paths_match(file_path, handler))
        if route_match and (handler_match or not file_path):
            matched_route = route_path
            matched_handler = handler
            break

    if matched_route:
        return {
            "status": "confirmed" if matched_handler or not file_path else "route_only",
            "flow_confirmed": True,
            "matched_route": matched_route,
            "matched_handler": matched_handler,
            "checked_route": endpoint or "",
            "checked_file": file_path or "",
            "route_match": True,
            "handler_match": bool(matched_handler),
        }

    if routes:
        return {
            "status": "no_match",
            "flow_confirmed": False,
            "checked_route": endpoint or "",
            "checked_file": file_path or "",
        }

    return {
        "status": "unavailable",
        "flow_confirmed": None,
        "reason": "no routes returned",
    }


@dataclass
class GitNexusConfig:
    mcp_url: str
    repo: str
    timeout_seconds: int

    @staticmethod
    def from_settings() -> "GitNexusConfig":
        return GitNexusConfig(
            mcp_url=str(settings.GITNEXUS_MCP_URL).rstrip("/"),
            repo=str(settings.GITNEXUS_REPO or "").strip(),
            timeout_seconds=int(settings.GITNEXUS_TIMEOUT_SECONDS),
        )


class GitNexusClient:
    def __init__(self, *, config: GitNexusConfig):
        self._config = config
        self._client = httpx.AsyncClient(timeout=self._config.timeout_seconds)
        self._initialized = False
        self._session_id: str | None = None
        self._next_id = 1

    async def __aenter__(self) -> "GitNexusClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    async def api_impact(
        self,
        *,
        route: str | None = None,
        file: str | None = None,
        repo: str | None = None,
    ) -> dict | None:
        params: dict[str, Any] = {}
        if route:
            params["route"] = route
        if file:
            params["file"] = file
        if repo or self._config.repo:
            params["repo"] = repo or self._config.repo
        if not params:
            return None
        return await self.call_tool("api_impact", params)

    async def call_tool(self, name: str, args: dict[str, Any]) -> dict | None:
        await self._ensure_session()
        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id,
            "method": "tools/call",
            "params": {
                "name": name,
                "arguments": args,
            },
        }
        self._next_id += 1
        response = await self._post(payload, expect_response=True)
        if not response:
            return None
        if response.get("error"):
            return {"error": response.get("error")}
        result = response.get("result", {})
        if result.get("isError"):
            return {"error": result}
        content = result.get("content") or []
        text_blocks = [c.get("text", "") for c in content if c.get("type") == "text"]
        text = "".join(text_blocks).strip()
        if not text:
            return {"raw": result}
        try:
            return json.loads(text)
        except Exception:
            return {"raw": result, "raw_text": text}

    async def _ensure_session(self) -> None:
        if self._initialized:
            return
        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id,
            "method": "initialize",
            "params": {
                "protocolVersion": _MCP_PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "clientInfo": {
                    "name": "traceon",
                    "version": settings.APP_VERSION,
                },
            },
        }
        self._next_id += 1
        response = await self._post(payload, expect_response=True)
        if not response or response.get("error"):
            raise RuntimeError("GitNexus MCP initialization failed")
        self._initialized = True

        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {},
        }
        await self._post(notification, expect_response=False)

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/json, text/event-stream",
            "Content-Type": "application/json",
            "MCP-Protocol-Version": _MCP_PROTOCOL_VERSION,
        }
        if self._session_id:
            headers["MCP-Session-Id"] = self._session_id
        return headers

    async def _post(self, payload: dict, *, expect_response: bool) -> dict | None:
        try:
            resp = await self._client.post(
                self._config.mcp_url,
                json=payload,
                headers=self._build_headers(),
            )
        except Exception as exc:
            logger.warning("GitNexus MCP request failed: %s", exc)
            return None

        session_id = resp.headers.get("mcp-session-id") or resp.headers.get("MCP-Session-Id")
        if session_id:
            self._session_id = session_id

        if not expect_response:
            return None

        if resp.status_code == 404 and self._session_id:
            self._session_id = None
            self._initialized = False
            return await self._post(payload, expect_response=expect_response)

        if resp.status_code >= 400:
            return {"error": {"code": resp.status_code, "message": resp.text}}

        content_type = resp.headers.get("content-type", "").lower()
        if "text/event-stream" in content_type:
            return await self._parse_sse_stream(resp, payload.get("id"))

        try:
            return resp.json()
        except Exception:
            text = resp.text.strip()
            if text:
                try:
                    return json.loads(text)
                except Exception:
                    return {"raw_text": text}
            return None

    async def _parse_sse_stream(self, resp: httpx.Response, request_id: int | None) -> dict | None:
        try:
            async for line in resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data = line[len("data:"):].strip()
                if not data:
                    continue
                try:
                    msg = json.loads(data)
                except Exception:
                    continue
                if request_id is None or msg.get("id") == request_id:
                    return msg
        except Exception:
            return None
        return None
