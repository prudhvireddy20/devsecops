"""TrustScan Platform HTTP client."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class TrustScanClient:
    """HTTP client for TrustScan Platform API."""

    def __init__(self, base_url: str, token: str, timeout: int = 30):
        """Initialize client with platform URL and PAT token.

        Args:
            base_url: TrustScan Platform base URL (e.g., http://localhost:8085)
            token: Personal Access Token (PAT) prefixed with 'tm_'
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={"Authorization": f"Bearer {token}"},
        )

    async def __aenter__(self) -> TrustScanClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def validate_token(self) -> dict[str, Any]:
        """Validate the token by fetching a single job.

        Returns:
            Dict with owner_id and email on success.

        Raises:
            httpx.HTTPStatusError: If token is invalid (401/403).
        """
        try:
            resp = await self._client.get(
                f"{self.base_url}/api/jobs",
                params={"limit": 1},
            )
            resp.raise_for_status()
            data = resp.json()

            return {
                "owner_id": data.get("owner_id") or "unknown",
                "email": data.get("email") or "",
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code in (401, 403):
                logger.error("Invalid TrustScan token: %s", e.response.status_code)
                raise
            raise

    async def list_jobs(self, limit: int = 50) -> list[dict[str, Any]]:
        """List scan jobs from TrustScan Platform.

        Args:
            limit: Maximum number of jobs to return.

        Returns:
            List of job dicts.
        """
        try:
            resp = await self._client.get(
                f"{self.base_url}/api/jobs",
                params={"limit": limit},
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("jobs", []) if isinstance(data, dict) else data
        except Exception as e:
            logger.error("Failed to list TrustScan jobs: %s", e)
            return []

    async def get_job(self, job_id: str) -> dict[str, Any] | None:
        """Get a single scan job by ID.

        Args:
            job_id: UUID of the scan job.

        Returns:
            Job dict or None on error.
        """
        try:
            resp = await self._client.get(f"{self.base_url}/api/jobs/{job_id}")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error("Failed to get TrustScan job %s: %s", job_id, e)
            return None

    async def get_findings(self, job_id: str) -> dict[str, Any] | None:
        """Get normalized findings for a job.

        Fetches from /api/results/{job_id} and transforms to traceon_version format.

        Args:
            job_id: UUID of the scan job.

        Returns:
            Transformed findings dict (traceon_version format) or None on error.
        """
        try:
            resp = await self._client.get(f"{self.base_url}/api/results/{job_id}")
            resp.raise_for_status()
            raw_data = resp.json()

            job = await self.get_job(job_id)
            if not job:
                logger.warning("Could not fetch job metadata for %s", job_id)

            transformed = self._transform_findings(job or {}, raw_data)
            return transformed
        except Exception as e:
            logger.error("Failed to get TrustScan findings for %s: %s", job_id, e)
            return None

    async def download_source(self, job_id: str, dest_path: Path) -> bool:
        """Download source code ZIP from TrustScan Platform.

        Args:
            job_id: UUID of the scan job.
            dest_path: Local path where ZIP should be saved.

        Returns:
            True on success, False on error.
        """
        try:
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            async with self._client.stream(
                "GET",
                f"{self.base_url}/api/source/{job_id}",
            ) as resp:
                resp.raise_for_status()
                async for chunk in resp.aiter_bytes(chunk_size=8192):
                    if chunk:
                        dest_path.write_bytes(dest_path.read_bytes() + chunk if dest_path.exists() else chunk)
            logger.info("Downloaded source from TrustScan for job %s to %s", job_id, dest_path)
            return True
        except Exception as e:
            logger.error("Failed to download source from TrustScan for %s: %s", job_id, e)
            if dest_path.exists():
                dest_path.unlink()
            return False

    def _transform_findings(
        self, job: dict[str, Any], raw_results: dict[str, Any]
    ) -> dict[str, Any]:
        """Transform TrustScan v2.0.0 NormalizedFinding format to traceon_version.

        The TrustScan Platform produces findings in the NormalizedFinding schema (v2.0.0).
        This method wraps them in the traceon_version format that ExternalFindingImporter._parse_trustscan()
        expects.

        Args:
            job: The scan job metadata dict.
            raw_results: The raw response from /api/results/{job_id}.

        Returns:
            Dict in traceon_version format.
        """
        findings_list = []

        raw_findings = raw_results.get("findings", []) if isinstance(raw_results, dict) else []
        if not isinstance(raw_findings, list):
            raw_findings = []

        for finding in raw_findings:
            if not isinstance(finding, dict):
                continue

            location = finding.get("location") or {}
            identifiers = finding.get("identifiers") or {}
            severity = finding.get("severity") or {}
            confidence = finding.get("confidence") or {}
            evidence = finding.get("evidence") or {}
            tool = finding.get("tool") or {}

            vuln_type = self._infer_vulnerability_type(tool.get("type", ""))

            cwe = ""
            if isinstance(identifiers.get("cwe"), list) and identifiers["cwe"]:
                cwe = str(identifiers["cwe"][0])
                if not cwe.startswith("CWE-"):
                    cwe = f"CWE-{cwe}"
            elif isinstance(identifiers.get("cwe"), str):
                cwe = identifiers["cwe"]
                if not cwe.startswith("CWE-"):
                    cwe = f"CWE-{cwe}"

            findings_list.append({
                "id": finding.get("id", ""),
                "title": finding.get("title") or evidence.get("description", ""),
                "vulnerability_type": vuln_type,
                "severity": severity.get("normalized", "medium").lower(),
                "confidence": confidence.get("normalized", "").lower(),
                "cwe": cwe,
                "location": {
                    "file_path": location.get("file", ""),
                    "line_number": location.get("line_start", 0),
                    "code_snippet": evidence.get("code_snippet", ""),
                },
                "endpoint": finding.get("endpoint", ""),
                "parameter": finding.get("parameter", ""),
                "rule_id": finding.get("rule_id", ""),
                "remediation": evidence.get("description", ""),
                "description": evidence.get("description", ""),
                "dataflow": finding.get("data_flow", []),
                "references": finding.get("references", []),
                "raw": finding,
            })

        return {
            "traceon_version": "1.0",
            "scan_metadata": {
                "job_id": job.get("id", ""),
                "repository": {
                    "url": job.get("repo_url", ""),
                },
                "scanners": [tool.get("type", "") for tool in raw_results.get("tools", [])],
            },
            "findings": findings_list,
        }

    @staticmethod
    def _infer_vulnerability_type(tool_type: str) -> str:
        """Infer vulnerability type from scanner tool type.

        Args:
            tool_type: Scanner type (SAST, DAST, SCA, SECRET, etc.)

        Returns:
            Mapped vulnerability type.
        """
        tool_type = (tool_type or "").upper()
        type_map = {
            "SAST": "unknown",
            "DAST": "unknown",
            "SCA": "dependency_cve",
            "SECRET": "secret",
            "SBOM": "dependency_cve",
        }
        return type_map.get(tool_type, "unknown")
