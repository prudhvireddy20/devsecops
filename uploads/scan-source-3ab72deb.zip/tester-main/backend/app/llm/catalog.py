"""Static LLM provider catalog and model options."""

from app.core.config import settings


PROVIDER_CATALOG: dict[str, dict[str, object]] = {
    "anthropic": {
        "label": "Anthropic",
        "default_model": "claude-sonnet-4-6",
        "models": [
            "claude-sonnet-4-6",
            "claude-opus-4-8",
            "claude-haiku-4-5-20251001",
            "claude-3-5-sonnet-latest",
            "claude-3-5-haiku-latest",
        ],
    },
    "openai": {
        "label": "OpenAI",
        "default_model": "gpt-4o-mini",
        "models": [
            "gpt-4o-mini",
            "gpt-4.1-mini",
            "gpt-4.1",
            "o3-mini",
        ],
    },
    "openrouter": {
        "label": "OpenRouter",
        "default_model": "openai/gpt-4o-mini",
        "models": [
            "openai/gpt-4o-mini",
            "openai/gpt-4.1-mini",
            "anthropic/claude-3.5-sonnet",
            "anthropic/claude-sonnet-4-5",
            "google/gemini-2.0-flash",
            "meta-llama/llama-3.3-70b-instruct:free",
            "google/gemma-3-12b-it:free",
            "google/gemma-4-31b-it:free",
            "minimax/minimax-m2.5:free",
            "nvidia/nemotron-3-super-120b-a12b:free",
            "qwen/qwen3-next-80b-a3b-instruct:free",
            "poolside/laguna-m.1:free",
        ],
    },
    "google": {
        "label": "Google",
        "default_model": "gemini-2.5-pro",
        "models": [
            "gemini-2.5-pro",
            "gemini-2.0-flash",
            "gemini-1.5-pro",
            "gemini-1.5-flash",
        ],
    },
    "github": {
        "label": "GitHub Copilot",
        "default_model": "gpt-4o-mini",
        "models": [
            "gpt-4o-mini",
            "gpt-4",
            "gpt-3.5-turbo",
        ],
    },
}

SUPPORTED_PROVIDERS = tuple(PROVIDER_CATALOG.keys())


def list_providers() -> list[str]:
    """Return provider names in UI order."""
    return list(SUPPORTED_PROVIDERS)


def get_provider_label(provider: str) -> str:
    """Return human label for provider."""
    data = PROVIDER_CATALOG.get(provider, {})
    return str(data.get("label", provider))


def get_provider_models(provider: str) -> list[str]:
    """Return curated model list for provider."""
    data = PROVIDER_CATALOG.get(provider, {})
    models = data.get("models", [])
    return [str(m) for m in models]


def get_default_model(provider: str) -> str:
    """Return curated default model for provider."""
    data = PROVIDER_CATALOG.get(provider, {})
    return str(data.get("default_model", ""))


def get_provider_auth_mode(provider: str) -> str:
    """Return the configured auth mode for the provider."""
    data = PROVIDER_CATALOG.get(provider, {})
    return str(data.get("auth_mode", "api_key"))


def get_env_api_key(provider: str) -> str:
    """Return API key from environment settings for provider."""
    if provider == "anthropic":
        return settings.ANTHROPIC_API_KEY
    if provider == "openai":
        return settings.OPENAI_API_KEY
    if provider == "openrouter":
        return settings.OPENROUTER_API_KEY
    if provider == "google":
        return settings.GOOGLE_API_KEY
    if provider == "github":
        return settings.GITHUB_COPILOT_TOKEN or settings.COPILOT_API_KEY
    return ""
