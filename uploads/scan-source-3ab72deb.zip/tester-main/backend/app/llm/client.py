"""Unified multi-provider LLM client with strict JSON responses."""

import asyncio
import json
import logging
from typing import Any, Optional

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)


class LLMCredentialValidationError(RuntimeError):
    """Raised when provider rejects API key/model validation."""


class LLMProviderConnectivityError(RuntimeError):
    """Raised when provider cannot be reached for validation."""


class LLMClient:
    """Thin async client supporting Anthropic, OpenAI-compatible, and Google APIs."""

    def __init__(
        self,
        *,
        enabled: bool | None = None,
        provider: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
    ):
        self.enabled = bool(settings.LLM_ENABLED if enabled is None else enabled)
        normalized_provider = (provider or settings.LLM_PROVIDER or "anthropic").strip().lower()
        if normalized_provider == "copilot":
            normalized_provider = "github"
        self.provider = normalized_provider
        self.timeout = max(5, int(settings.LLM_TIMEOUT_SECONDS))
        self.retries = max(0, int(settings.LLM_MAX_RETRIES))
        self.model = (model or settings.LLM_MODEL or "").strip()
        self._override_api_key = (api_key or "").strip()

    def is_available(self) -> bool:
        """Return True when LLM feature is enabled and provider credentials exist."""
        if not self.enabled:
            return False
        if self._override_api_key:
            return True
        if self.provider == "anthropic":
            return bool(settings.ANTHROPIC_API_KEY)
        if self.provider == "openai":
            return bool(settings.OPENAI_API_KEY)
        if self.provider == "openrouter":
            return bool(settings.OPENROUTER_API_KEY)
        if self.provider == "google":
            return bool(settings.GOOGLE_API_KEY)
        if self.provider == "github":
            return bool(settings.GITHUB_COPILOT_TOKEN or settings.COPILOT_API_KEY)
        if self.provider == "copilot":
            return bool(settings.GITHUB_COPILOT_TOKEN or settings.COPILOT_API_KEY)
        return False

    def _api_key(self) -> str:
        """Return effective API key for current provider."""
        if self._override_api_key:
            return self._override_api_key
        if self.provider == "anthropic":
            return settings.ANTHROPIC_API_KEY
        if self.provider == "openai":
            return settings.OPENAI_API_KEY
        if self.provider == "openrouter":
            return settings.OPENROUTER_API_KEY
        if self.provider == "google":
            return settings.GOOGLE_API_KEY
        if self.provider == "github":
            return settings.GITHUB_COPILOT_TOKEN or settings.COPILOT_API_KEY
        if self.provider == "copilot":
            return settings.GITHUB_COPILOT_TOKEN or settings.COPILOT_API_KEY
        return ""

    async def validate_connection(self) -> None:
        """Validate provider credentials by issuing a minimal chat request.

        This checks that the provided API key is accepted and that the selected
        model is usable for the account.
        """
        if not self._api_key():
            raise LLMCredentialValidationError("API key is required")

        try:
            await self._chat_text(
                "You are a connectivity check assistant. Reply with JSON only. "
                "Return exactly: {\"ok\": true}",
                "Return a JSON object exactly: {\"ok\": true}",
            )
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            body = ""
            try:
                body = (exc.response.text or "").lower()
            except Exception:
                body = ""

            if status in (401, 403):
                raise LLMCredentialValidationError(
                    f"Invalid API key for provider '{self.provider}'."
                ) from exc
            if status in (400, 404, 422):
                if any(
                    token in body
                    for token in (
                        "api key",
                        "apikey",
                        "invalid key",
                        "unauthorized",
                        "authentication",
                        "auth",
                        "credential",
                        "forbidden",
                        "permission",
                    )
                ):
                    raise LLMCredentialValidationError(
                        f"Invalid API key for provider '{self.provider}'."
                    ) from exc

                model = self.model or "default"
                raise LLMCredentialValidationError(
                    f"Provider '{self.provider}' rejected model '{model}'. "
                    "Choose a supported model for your account."
                ) from exc
            if status == 429:
                raise LLMProviderConnectivityError(
                    f"Provider '{self.provider}' is rate limiting validation requests. "
                    "Try again shortly."
                ) from exc
            raise LLMProviderConnectivityError(
                f"Provider '{self.provider}' validation request failed with HTTP {status}."
            ) from exc
        except httpx.TimeoutException as exc:
            raise LLMProviderConnectivityError(
                f"Timed out while validating provider '{self.provider}'."
            ) from exc
        except httpx.RequestError as exc:
            raise LLMProviderConnectivityError(
                f"Could not reach provider '{self.provider}' for validation."
            ) from exc
        except ValueError as exc:
            raise LLMCredentialValidationError(str(exc)) from exc

    async def chat_json(self, system_prompt: str, user_prompt: str) -> dict:
        """Call configured provider and parse strict JSON response."""
        if not self.is_available():
            raise RuntimeError("LLM provider is not available")

        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                raw = await self._chat_text(system_prompt, user_prompt)
                return self._extract_json(raw)
            except Exception as exc:
                if self.provider == "openrouter":
                    fallback_model = "openai/gpt-4o-mini"
                    is_404 = isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code == 404
                    is_empty = isinstance(exc, ValueError) and "empty llm response" in str(exc).lower()
                    if (is_404 or is_empty) and self.model != fallback_model:
                        logger.warning(
                            "OpenRouter model '%s' failed (%s). Retrying with fallback model '%s'.",
                            self.model,
                            exc,
                            fallback_model,
                        )
                        self.model = fallback_model
                        continue

                last_error = exc
                if attempt < self.retries:
                    await asyncio.sleep(0.5 * (attempt + 1))
                else:
                    break
        raise RuntimeError(f"LLM request failed: {last_error}")

    async def _chat_text(self, system_prompt: str, user_prompt: str) -> str:
        provider = self.provider
        if provider == "anthropic":
            return await self._anthropic_chat(system_prompt, user_prompt)
        if provider in ("openai", "openrouter", "github", "copilot"):
            return await self._openai_compatible_chat(system_prompt, user_prompt)
        if provider == "google":
            return await self._google_chat(system_prompt, user_prompt)
        raise ValueError(f"Unsupported LLM provider: {provider}")

    async def _anthropic_chat(self, system_prompt: str, user_prompt: str) -> str:
        headers = {
            "x-api-key": self._api_key(),
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        model = self.model or "claude-3-5-sonnet-latest"
        payload = {
            "model": model,
            "max_tokens": 900,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "temperature": 0,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers,
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
            content = data.get("content", [])
            if isinstance(content, list) and content:
                return str(content[0].get("text", ""))
            return ""

    async def _openai_compatible_chat(self, system_prompt: str, user_prompt: str) -> str:
        if self.provider == "openai":
            base = settings.OPENAI_BASE_URL.rstrip("/")
            api_key = self._api_key()
            model = self.model or "gpt-4o-mini"
            extra_headers: dict[str, str] = {}
        elif self.provider == "openrouter":
            base = settings.OPENROUTER_BASE_URL.rstrip("/")
            api_key = self._api_key()
            model = self.model or "openai/gpt-4o-mini"
            extra_headers = {
                "HTTP-Referer": "https://traceon.local",
                "X-Title": "TraceON",
            }
        else:
            # GitHub Copilot proxy (OpenAI-compatible style).
            base = (settings.GITHUB_COPILOT_BASE_URL or settings.COPILOT_BASE_URL).rstrip("/")
            api_key = self._api_key()
            model = self.model or "gpt-4o-mini"
            extra_headers = {}  # GitHub Copilot doesn't require referer/title headers

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            **extra_headers,
        }
        payload = {
            "model": model,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }

        endpoint = f"{base}/chat/completions"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(endpoint, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            choices = data.get("choices", [])
            if not choices:
                return ""
            return str(choices[0].get("message", {}).get("content", ""))

    async def _google_chat(self, system_prompt: str, user_prompt: str) -> str:
        base = settings.GOOGLE_BASE_URL.rstrip("/")
        model = self.model or "gemini-1.5-pro"
        endpoint = f"{base}/models/{model}:generateContent"

        payload = {
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"parts": [{"text": user_prompt}]}],
            "generationConfig": {
                "temperature": 0,
                "responseMimeType": "application/json",
            },
        }
        params = {"key": settings.GOOGLE_API_KEY}
        if self._api_key():
            params = {"key": self._api_key()}

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(endpoint, params=params, json=payload)
            resp.raise_for_status()
            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                return ""
            parts = candidates[0].get("content", {}).get("parts", [])
            if not parts:
                return ""
            return str(parts[0].get("text", ""))

    @staticmethod
    def _extract_json(text: str) -> dict:
        """Extract JSON object from raw model text."""
        raw = (text or "").strip()
        if not raw:
            raise ValueError("Empty LLM response")

        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1 and end > start:
            snippet = raw[start : end + 1]
            parsed = json.loads(snippet)
            if isinstance(parsed, dict):
                return parsed

        logger.debug("Failed to parse LLM JSON: %s", raw[:600])
        raise ValueError("Model did not return valid JSON object")
