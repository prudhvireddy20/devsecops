"""Build compact, redacted context payloads for LLM tasks."""

from pathlib import Path

from app.core.config import settings
from app.llm.redaction import redact_text, truncate_text


def build_planner_context(
    *,
    checkpoint: str,
    project,
    scan,
    routes: list[dict],
    sinks: list[dict],
    sast_findings: list[dict],
    dast_findings: list[dict],
) -> dict:
    """Build planner context from orchestrator state."""
    sink_counts: dict[str, int] = {}
    for s in sinks:
        st = str(s.get("type", "unknown"))
        sink_counts[st] = sink_counts.get(st, 0) + 1

    top_sast_types: dict[str, int] = {}
    for f in sast_findings[:500]:
        vt = str(f.get("vulnerability_type", "unknown"))
        top_sast_types[vt] = top_sast_types.get(vt, 0) + 1

    top_dast_types: dict[str, int] = {}
    for f in dast_findings[:500]:
        vt = str(f.get("vulnerability_type", "unknown"))
        top_dast_types[vt] = top_dast_types.get(vt, 0) + 1

    return {
        "checkpoint": checkpoint,
        "project": {
            "id": getattr(project, "id", ""),
            "framework": getattr(project, "framework", "unknown"),
            "target_url": getattr(project, "target_url", ""),
        },
        "scan": {
            "id": getattr(scan, "id", ""),
            "scan_type": getattr(scan, "scan_type", "full"),
            "modules_enabled": getattr(scan, "modules_enabled", {}) or {},
            "scan_config": getattr(scan, "scan_config", {}) or {},
        },
        "routes_discovered": len(routes),
        "sink_counts": sink_counts,
        "top_sast_types": top_sast_types,
        "top_dast_types": top_dast_types,
        "sast_count": len(sast_findings),
        "dast_count": len(dast_findings),
    }


def _read_file_snippet(file_path: str, line_number: int, radius: int = 25) -> str:
    """Read a snippet around line_number from file_path."""
    if not file_path:
        return ""

    path = Path(file_path)
    if not path.exists() or not path.is_file():
        return ""

    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return ""

    if not lines:
        return ""

    line_no = max(1, int(line_number or 1))
    start = max(1, line_no - radius)
    end = min(len(lines), line_no + radius)
    snippet_lines = []
    for idx in range(start, end + 1):
        snippet_lines.append(f"{idx}: {lines[idx - 1]}")
    return "\n".join(snippet_lines)


def build_remediation_context(*, finding, project=None) -> dict:
    """Build remediation context for a finding with redaction + truncation."""
    if isinstance(finding, dict):
        file_path = finding.get("file_path", "")
        line_number = finding.get("line_number", 0)
        code_snippet = finding.get("code_snippet", "")
        payload = finding.get("payload", "")
        evidence = finding.get("response_evidence", "")
        vuln_type = finding.get("vulnerability_type", "")
    else:
        file_path = getattr(finding, "file_path", "")
        line_number = getattr(finding, "line_number", 0)
        code_snippet = getattr(finding, "code_snippet", "")
        payload = getattr(finding, "payload", "")
        evidence = getattr(finding, "response_evidence", "")
        vuln_type = getattr(finding, "vulnerability_type", "")

    local_snippet = _read_file_snippet(file_path, line_number)
    merged_snippet = (code_snippet or "")
    if local_snippet:
        merged_snippet = (merged_snippet + "\n\n# Context\n" + local_snippet).strip()

    max_chars = max(1000, int(settings.LLM_MAX_SNIPPET_CHARS))
    merged_snippet = truncate_text(redact_text(merged_snippet), max_chars)
    payload = truncate_text(redact_text(payload or ""), 2000)
    evidence = truncate_text(redact_text(evidence or ""), 3000)

    return {
        "project": {
            "framework": getattr(project, "framework", "") if project else "",
            "target_url": getattr(project, "target_url", "") if project else "",
        },
        "finding": {
            "title": finding.get("title", "") if isinstance(finding, dict) else getattr(finding, "title", ""),
            "vulnerability_type": vuln_type,
            "severity": finding.get("severity", "") if isinstance(finding, dict) else getattr(finding, "severity", ""),
            "confidence": finding.get("confidence", "") if isinstance(finding, dict) else getattr(finding, "confidence", ""),
            "cwe": finding.get("cwe", "") if isinstance(finding, dict) else getattr(finding, "cwe", ""),
            "file_path": file_path,
            "line_number": line_number,
            "endpoint": finding.get("endpoint", "") if isinstance(finding, dict) else getattr(finding, "endpoint", ""),
            "parameter": finding.get("parameter", "") if isinstance(finding, dict) else getattr(finding, "parameter", ""),
            "scanner_source": finding.get("scanner_source", "") if isinstance(finding, dict) else getattr(finding, "scanner_source", ""),
        },
        "evidence": {
            "code_snippet": merged_snippet,
            "payload": payload,
            "response_evidence": evidence,
            "data_flow": finding.get("data_flow", "") if isinstance(finding, dict) else getattr(finding, "data_flow", ""),
            "remediation_text": finding.get("remediation_text", "") if isinstance(finding, dict) else getattr(finding, "remediation_text", ""),
        },
    }
