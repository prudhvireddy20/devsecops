"""Compress Finding objects into one-liner format for LLM context efficiency.

This module handles:
1. Converting Finding ORM list → compressed one-liner format (~22 tokens per finding)
2. Building tech stack string from detected_stack JSON
3. Building auth topology string from auth_config JSON
4. Truncating large finding lists to stay within token budgets

No LLM calls in this file — pure Python. This is the key to token efficiency.
"""

from typing import Optional


SEVERITY_RANK = {
    "critical": 5,
    "high": 4,
    "medium": 3,
    "low": 2,
    "info": 1,
}

CONFIDENCE_RANK = {
    "verified": 3,
    "probable": 2,
    "observed": 1,
}


def compress_findings(
    findings: list,
    max_findings: int = 50,
) -> tuple[str, bool]:
    """Compress findings into one-liner format, truncate if needed.

    Format per finding:
    # ID type severity confidence | endpoint method param | file:line | cwe

    Example:
    F01 sqli HIGH prob | /api/users GET id | users.py:42 | CWE-89
    F02 xss MED obs | /api/comments POST body | — | CWE-79

    Args:
        findings: List of Finding ORM objects
        max_findings: Hard cap on findings to include (default 50 for token budget)

    Returns:
        Tuple of (compressed_string, was_truncated)
    """
    if not findings:
        return "", False

    # Sort by severity DESC, then confidence DESC
    sorted_findings = sorted(
        findings,
        key=lambda f: (
            SEVERITY_RANK.get(f.severity, 0),
            CONFIDENCE_RANK.get(f.confidence, 0),
        ),
        reverse=True,
    )

    # Truncate if needed
    was_truncated = len(sorted_findings) > max_findings
    truncated_findings = sorted_findings[:max_findings]

    lines = []

    # Header line
    if was_truncated:
        lines.append(f"# NOTE: showing {max_findings} of {len(sorted_findings)} findings (top by severity)")
    lines.append(f"# ID type severity confidence | endpoint method param | file:line | cwe")
    lines.append("")

    # One line per finding
    for i, finding in enumerate(truncated_findings, 1):
        finding_id = f"F{i:02d}"

        # Type: sqli, xss, ssrf, etc.
        vuln_type = finding.vulnerability_type[:10]  # Truncate if too long

        # Severity: HIGH, MED, LOW, CRIT, INFO
        severity = finding.severity.upper()[:4]

        # Confidence: prob, obs, ver
        conf_short = {
            "verified": "ver",
            "probable": "prob",
            "observed": "obs",
        }.get(finding.confidence, "?")

        # Endpoint: /api/users or — if empty
        endpoint = finding.endpoint or "—"

        # Method: GET, POST, etc. or — if empty
        method = finding.http_method or "—"

        # Parameter: id, body, etc. or — if empty
        param = finding.parameter or "—"

        # File location: users.py:42 or — if empty
        file_line = "—"
        if finding.file_path:
            file_line = finding.file_path.split("/")[-1]  # Just filename
            if finding.line_number:
                file_line = f"{file_line}:{finding.line_number}"

        # CWE: CWE-89 or —
        cwe = finding.cwe or "—"

        # Build line
        line = f"{finding_id} {vuln_type} {severity} {conf_short} | {endpoint} {method} {param} | {file_line} | {cwe}"
        lines.append(line)

    compressed = "\n".join(lines)
    return compressed, was_truncated


def build_stack_string(detected_stack: Optional[dict]) -> str:
    """Convert detected_stack JSON to human-readable tech stack string.

    Example output: "Django 3.2 + MySQL 8 + Nginx"

    Args:
        detected_stack: Dict with keys like 'framework', 'database', 'server', etc.
                       Value: {name, version}

    Returns:
        String like "Django 3.2 + MySQL 8" or "unknown" if stack is empty/None
    """
    if not detected_stack:
        return "unknown"

    # Order of precedence for display
    order = ["language", "framework", "database", "server", "cdn", "cms"]

    components = []
    for key in order:
        if key in detected_stack and detected_stack[key]:
            item = detected_stack[key]
            if isinstance(item, dict):
                name = item.get("name", "")
                version = item.get("version", "")
                if name:
                    if version:
                        components.append(f"{name} {version}")
                    else:
                        components.append(name)
            elif isinstance(item, str):
                components.append(item)

    return " + ".join(components) if components else "unknown"


def build_auth_topology_string(auth_config: Optional[dict]) -> str:
    """Convert auth_config JSON to human-readable auth topology string.

    Example output: "form-login, session-cookie, multi-role"

    Args:
        auth_config: Dict with auth setup details

    Returns:
        String like "form-login, session-cookie" or "none" if no auth
    """
    if not auth_config:
        return "none"

    parts = []

    auth_type = auth_config.get("auth_type", "").lower()
    if auth_type:
        if auth_type == "form":
            parts.append("form-login")
        elif auth_type == "api_key":
            parts.append("api-key")
        elif auth_type == "oauth":
            parts.append("oauth2")
        elif auth_type == "jwt":
            parts.append("jwt")
        elif auth_type in ("none", "basic"):
            parts.append(auth_type)

    # Session/token type
    token_type = auth_config.get("session_type", "").lower()
    if token_type:
        if token_type == "cookie":
            parts.append("session-cookie")
        elif token_type == "bearer":
            parts.append("bearer-token")

    # Roles
    roles = auth_config.get("roles", [])
    if isinstance(roles, list) and len(roles) > 1:
        parts.append("multi-role")
    elif isinstance(roles, list) and len(roles) == 1:
        parts.append("single-role")

    return ", ".join(parts) if parts else "none"


def compress_finding_types(findings: list) -> str:
    """Count findings by type, return as compact string.

    Example output: "2 sqli, 3 xss, 1 ssrf"

    Args:
        findings: List of Finding ORM objects

    Returns:
        String with type counts
    """
    type_counts = {}
    for finding in findings:
        vuln_type = finding.vulnerability_type
        type_counts[vuln_type] = type_counts.get(vuln_type, 0) + 1

    # Sort by count DESC
    sorted_counts = sorted(type_counts.items(), key=lambda x: x[1], reverse=True)

    parts = [f"{count} {vuln_type}" for vuln_type, count in sorted_counts]
    return ", ".join(parts)
