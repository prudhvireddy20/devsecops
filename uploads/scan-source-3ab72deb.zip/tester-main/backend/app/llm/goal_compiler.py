"""Compile natural-language scan goals into structured plan intent."""

from __future__ import annotations

from app.llm.client import LLMClient
from app.llm.prompts import GOAL_COMPILER_SYSTEM_PROMPT, goal_compiler_user_prompt
from app.llm.schemas import GoalPlanIntent


KEYWORD_TO_PRIORITY = {
    "sql": "sqli",
    "injection": "sqli",
    "xss": "xss",
    "csrf": "csrf",
    "auth": "authz",
    "authorization": "authz",
    "admin": "authz",
    "ssrf": "ssrf",
    "path": "path_traversal",
    "traversal": "path_traversal",
    "secret": "secret",
    "dependency": "dependency",
}


def _heuristic_intent(goals: list[str]) -> GoalPlanIntent:
    text = " ".join(goals).lower()
    priorities = []
    for token, mapped in KEYWORD_TO_PRIORITY.items():
        if token in text and mapped not in priorities:
            priorities.append(mapped)

    route_keywords = []
    for token in ("checkout", "cart", "order", "admin", "login", "profile", "payment", "api"):
        if token in text:
            route_keywords.append(token)

    role_focus = []
    for token in ("guest", "user", "admin"):
        if token in text:
            role_focus.append(token)

    modules_focus = {
        "sast": True,
        "dast": True,
        "secrets": True,
        "dependencies": True,
        "coverage": "coverage" in text or "route" in text,
    }

    suggested_scan_config = {
        "scan_depth": 6 if "deep" in text or "thorough" in text else 5,
        "timeout": 2400 if "deep" in text or "thorough" in text else 1800,
        "ajax_spider": "spa" in text or "javascript" in text,
        "context_aware_payloads": True,
    }

    return GoalPlanIntent(
        priorities=priorities,
        route_keywords=route_keywords,
        role_focus=role_focus,
        modules_focus=modules_focus,
        suggested_scan_config=suggested_scan_config,
        reasoning="Heuristic goal compilation fallback.",
    )


async def compile_goals_to_intent(
    *,
    goals: list[str],
    scan_context: dict,
    llm_client: LLMClient | None = None,
) -> GoalPlanIntent:
    """Compile goals to a structured intent using LLM when available."""
    clean_goals = [str(g).strip() for g in goals if str(g).strip()]
    if not clean_goals:
        return GoalPlanIntent()

    if llm_client and llm_client.is_available():
        try:
            raw = await llm_client.chat_json(
                GOAL_COMPILER_SYSTEM_PROMPT,
                goal_compiler_user_prompt(clean_goals, scan_context),
            )
            return GoalPlanIntent.model_validate(raw)
        except Exception:
            # Fallback to deterministic heuristic on any LLM failure.
            pass

    return _heuristic_intent(clean_goals)
