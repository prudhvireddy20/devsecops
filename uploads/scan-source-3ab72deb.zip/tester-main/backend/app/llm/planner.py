"""Planner wrapper that asks LLM for guarded scan tuning actions."""

import logging

from app.llm.client import LLMClient
from app.llm.prompts import PLANNER_SYSTEM_PROMPT, planner_user_prompt
from app.llm.schemas import PlannerDecision

logger = logging.getLogger(__name__)

ALLOWED_ACTIONS = {
    "no_change",
    "update_scan_config",
    "prioritize_vuln_types",
    "recommend_targeted_retry",
}

ALLOWED_SCAN_CONFIG_KEYS = {
    "scan_depth",
    "timeout",
    "max_children",
    "ajax_spider",
    "inscope_only",
    "adaptive_timeout",
    "context_aware_payloads",
    "sast_runtime_focus",
}


class LLMPlanner:
    """LLM planner with strict action validation."""

    def __init__(self, client: LLMClient):
        self.client = client

    async def decide(self, *, checkpoint: str, context: dict) -> PlannerDecision:
        """Get planner decision from LLM and validate allowed actions."""
        raw = await self.client.chat_json(
            PLANNER_SYSTEM_PROMPT,
            planner_user_prompt(checkpoint, context),
        )
        decision = PlannerDecision.model_validate(raw)
        decision.actions = [a for a in decision.actions if a.action in ALLOWED_ACTIONS]
        for action in decision.actions:
            if action.action == "update_scan_config":
                action.params = {
                    k: v for k, v in (action.params or {}).items() if k in ALLOWED_SCAN_CONFIG_KEYS
                }
        return decision

    @staticmethod
    def apply_scan_config_updates(scan_config: dict, updates: dict) -> dict:
        """Apply safe bounded scan config updates."""
        cfg = dict(scan_config or {})
        for key, value in (updates or {}).items():
            if key == "scan_depth":
                cfg[key] = max(1, min(int(value), 20))
            elif key == "timeout":
                cfg[key] = max(30, min(int(value), 14400))  # Increased from 7200 to 14400 (4 hours)
            elif key == "max_children":
                cfg[key] = max(1, min(int(value), 500))
            elif key in {
                "ajax_spider",
                "inscope_only",
                "adaptive_timeout",
                "context_aware_payloads",
                "sast_runtime_focus",
            }:
                cfg[key] = bool(value)
        return cfg
