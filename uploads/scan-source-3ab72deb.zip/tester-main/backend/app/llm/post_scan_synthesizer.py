"""Post-scan LLM synthesis: chains + FP flags + executive summary.

Fires once after all tools complete. One combined call that does three things:
1. Detect attack chains across findings
2. Flag likely false positives (whitebox mode only, probable findings only)
3. Generate 60-word executive summary

This is ONE API call, not three — saves ~60% of tokens vs. three separate calls.
"""

import json
import logging
from typing import Optional

from app.llm.client import LLMClient
from app.llm.context_compressor import (
    compress_findings,
    build_stack_string,
    build_auth_topology_string,
)
from app.llm.prompts import SYNTHESIS_SYSTEM_PROMPT, synthesis_prompt

logger = logging.getLogger(__name__)


class PostScanSynthesizer:
    """Synthesize findings after scan completes."""

    def __init__(
        self,
        provider: str = "anthropic",
        model: str = "claude-3-5-sonnet-latest",
        api_key: Optional[str] = None,
    ):
        # enabled=True: callers gate on the resolved config's enabled flag,
        # which may come from DB credentials rather than the LLM_ENABLED env var.
        self.client = LLMClient(enabled=True, provider=provider, model=model, api_key=api_key)

    async def synthesize(
        self,
        findings: list,
        scan_mode: str,
        detected_stack: Optional[dict] = None,
        auth_config: Optional[dict] = None,
    ) -> dict:
        """Synthesize findings into chains, FP flags, and summary.

        Args:
            findings: List of Finding ORM objects
            scan_mode: "whitebox" or "blackbox"
            detected_stack: Dict of detected technologies
            auth_config: Auth configuration dict

        Returns:
            {
                "attack_chains": [{finding_ids, severity, narrative}],
                "probable_fps": [{"finding_id", "likely_reason"}],
                "summary": "60-word executive summary",
                "truncated": bool,
            }

        If synthesis is skipped (<=2 findings, LLM error), returns minimal dict:
            {"attack_chains": [], "probable_fps": [], "summary": "", "skipped": True}
        """

        # Skip if too few findings
        if len(findings) <= 2:
            logger.info(f"Skipping synthesis: only {len(findings)} findings (need >2 for chains)")
            return {
                "attack_chains": [],
                "probable_fps": [],
                "summary": "",
                "skipped": True,
                "skipped_reason": "insufficient_findings",
            }

        # Compress findings
        compressed_findings, was_truncated = compress_findings(findings, max_findings=50)

        # Build context strings
        stack_string = build_stack_string(detected_stack)
        auth_string = build_auth_topology_string(auth_config)

        # Filter findings for FP review: whitebox mode, probable confidence only
        probable_findings_for_fp = []
        if scan_mode == "whitebox":
            probable_findings_for_fp = [
                f for f in findings if f.confidence == "probable"
            ]

        # Build prompt
        try:
            prompt = synthesis_prompt(
                compressed_findings=compressed_findings,
                stack_string=stack_string,
                auth_string=auth_string,
                scan_mode=scan_mode,
                has_probable_findings=len(probable_findings_for_fp) > 0,
                finding_count=len(findings),
            )
        except Exception as e:
            logger.error(f"Failed to build synthesis prompt: {e}")
            return {
                "attack_chains": [],
                "probable_fps": [],
                "summary": "",
                "error": str(e),
            }

        # Call LLM
        try:
            response = await self.client.chat_json(
                system_prompt=SYNTHESIS_SYSTEM_PROMPT,
                user_prompt=prompt,
            )
        except Exception as e:
            logger.error(f"LLM synthesis call failed: {e}")
            return {
                "attack_chains": [],
                "probable_fps": [],
                "summary": "",
                "error": str(e),
                "error_type": type(e).__name__,
            }

        # Parse response
        try:
            attack_chains = response.get("attack_chains", [])
            probable_fps = response.get("probable_fps", [])
            summary = response.get("summary", "")

            # Validate outputs
            if not isinstance(attack_chains, list):
                attack_chains = []
            if not isinstance(probable_fps, list):
                probable_fps = []
            if not isinstance(summary, str):
                summary = ""

            # Truncate summary to 60 words
            summary_words = summary.split()[:60]
            summary = " ".join(summary_words)

            return {
                "attack_chains": attack_chains,
                "probable_fps": probable_fps,
                "summary": summary,
                "truncated": was_truncated,
                "skipped": False,
            }

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM synthesis response: {e}")
            logger.debug(f"Raw response: {response}")
            return {
                "attack_chains": [],
                "probable_fps": [],
                "summary": "",
                "error": "json_parse_failed",
            }
        except KeyError as e:
            logger.error(f"Missing expected field in LLM response: {e}")
            return {
                "attack_chains": [],
                "probable_fps": [],
                "summary": "",
                "error": f"missing_field: {e}",
            }


async def synthesize_scan_findings(
    findings: list,
    scan_mode: str,
    detected_stack: Optional[dict] = None,
    auth_config: Optional[dict] = None,
    api_key: Optional[str] = None,
    provider: str = "anthropic",
    model: str = "",
) -> dict:
    """Convenience function for orchestrator to call synthesis.

    Returns dict with attack_chains, probable_fps, summary.
    Gracefully handles errors — scan continues regardless.
    """
    # Empty model lets LLMClient fall back to its per-provider default.
    synthesizer = PostScanSynthesizer(provider=provider, model=model, api_key=api_key)
    return await synthesizer.synthesize(
        findings=findings,
        scan_mode=scan_mode,
        detected_stack=detected_stack,
        auth_config=auth_config,
    )
