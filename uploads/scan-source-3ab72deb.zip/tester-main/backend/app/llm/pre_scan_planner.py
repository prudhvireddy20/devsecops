"""Pre-scan LLM planning: read project description, output focus areas + skip hints.

Fires once before scanning starts — only if project has a description.
Cached by description SHA-256 for 24 hours.

Output guides:
- Nuclei template category selection
- ZAP scope priority paths
- Risk hypothesis for the report

Skipped if: description < 15 characters, or LLM disabled.
"""

import hashlib
import json
import logging
from typing import Optional

from app.llm.client import LLMClient
from app.llm.prompts import pre_scan_prompt

logger = logging.getLogger(__name__)

# In-memory cache: {description_hash: (result, timestamp)}
# In production, use Redis or database cache
_PLAN_CACHE: dict = {}
CACHE_TTL_SECONDS = 24 * 3600  # 24 hours


class PreScanPlanner:
    """Plan a scan based on project description."""

    def __init__(
        self,
        provider: str = "anthropic",
        model: str = "claude-3-5-haiku-latest",
        api_key: Optional[str] = None,
    ):
        # enabled=True: callers gate on the resolved config's enabled flag,
        # which may come from DB credentials rather than the LLM_ENABLED env var.
        self.client = LLMClient(enabled=True, provider=provider, model=model, api_key=api_key)

    def _cache_key(self, description: str, scan_mode: str) -> str:
        """Generate cache key from description + mode."""
        combined = f"{description}|{scan_mode}"
        return hashlib.sha256(combined.encode()).hexdigest()

    async def plan(
        self,
        project_description: str,
        scan_mode: str,
        target_domain: str,
        finding_types: str = "",
    ) -> Optional[dict]:
        """Generate pre-scan plan from project description.

        Args:
            project_description: User-provided description
            scan_mode: "whitebox" or "blackbox"
            target_domain: Domain to scan (e.g., "api.example.com")
            finding_types: For whitebox: "2 sqli, 3 xss, 1 ssrf"

        Returns:
            {
                "focus_areas": ["endpoint1", "endpoint2"],
                "skip_hint": ["path1", "path2"],
                "risk_hypothesis": "what we expect to find",
            }

            OR None if skipped (no description, LLM error, etc.)
        """

        # Skip if description is too short
        if not project_description or len(project_description.strip()) < 15:
            logger.info(f"Skipping pre-scan planner: description too short (<15 chars)")
            return None

        # Check cache
        cache_key = self._cache_key(project_description, scan_mode)
        if cache_key in _PLAN_CACHE:
            cached_result, cached_time = _PLAN_CACHE[cache_key]
            logger.info(f"Using cached plan (key: {cache_key[:8]}...)")
            return cached_result

        # Build prompt
        try:
            prompt = pre_scan_prompt(
                project_description=project_description,
                scan_mode=scan_mode,
                target_domain=target_domain,
                finding_types=finding_types,
            )
        except Exception as e:
            logger.error(f"Failed to build pre-scan prompt: {e}")
            return None

        # Call LLM
        try:
            response = await self.client.chat_json(
                system_prompt=self._get_system_prompt(),
                user_prompt=prompt,
            )
        except Exception as e:
            logger.error(f"LLM pre-scan planning failed: {e}")
            return None

        # Validate and cache
        try:
            plan = {
                "focus_areas": response.get("focus_areas", []),
                "skip_hint": response.get("skip_hint", []),
                "risk_hypothesis": response.get("risk_hypothesis", ""),
            }

            # Validate types
            if not isinstance(plan["focus_areas"], list):
                plan["focus_areas"] = []
            if not isinstance(plan["skip_hint"], list):
                plan["skip_hint"] = []
            if not isinstance(plan["risk_hypothesis"], str):
                plan["risk_hypothesis"] = ""

            # Cache it
            _PLAN_CACHE[cache_key] = (plan, None)  # None for timestamp, not using it yet
            logger.info(f"Cached plan (key: {cache_key[:8]}...)")

            return plan

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse pre-scan plan JSON: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error processing pre-scan plan: {e}")
            return None

    @staticmethod
    def _get_system_prompt() -> str:
        """Get the system prompt for pre-scan planning."""
        from app.llm.prompts import PRE_SCAN_SYSTEM_PROMPT
        return PRE_SCAN_SYSTEM_PROMPT


async def plan_scan(
    project_description: str,
    scan_mode: str,
    target_domain: str,
    finding_types: str = "",
    api_key: Optional[str] = None,
    provider: str = "anthropic",
    model: str = "",
) -> Optional[dict]:
    """Convenience function for orchestrator to call pre-scan planning.

    Returns dict with focus_areas, skip_hint, risk_hypothesis.
    Returns None if skipped or on error (scan continues either way).
    """
    # Empty model lets LLMClient fall back to its per-provider default.
    planner = PreScanPlanner(provider=provider, model=model, api_key=api_key)
    return await planner.plan(
        project_description=project_description,
        scan_mode=scan_mode,
        target_domain=target_domain,
        finding_types=finding_types,
    )
