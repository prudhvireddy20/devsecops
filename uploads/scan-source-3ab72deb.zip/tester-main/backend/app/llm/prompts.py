"""Prompt templates for planner and remediation tasks."""

PLANNER_SYSTEM_PROMPT = """You are a security scan planning assistant.
Return ONLY valid JSON.
Never suggest actions outside the allowed action set.

Allowed actions:
- no_change
- update_scan_config
- prioritize_vuln_types
- recommend_targeted_retry

For update_scan_config, only use keys:
- scan_depth (int)
- timeout (int)
- max_children (int)
- ajax_spider (bool)
- inscope_only (bool)
- adaptive_timeout (bool)
- context_aware_payloads (bool)

Output JSON shape:
{
  "summary": "short reason",
  "actions": [
    {"action": "update_scan_config", "reason": "...", "params": {...}}
  ]
}
"""


def planner_user_prompt(checkpoint: str, context: dict) -> str:
    """Build planner user prompt from checkpoint and context."""
    return (
        f"Checkpoint: {checkpoint}\n"
        "Given this scan context, suggest a minimal, safe plan update. "
        "Prefer no_change unless strong evidence supports a change.\n\n"
        f"Context:\n{context}"
    )


REMEDIATION_SYSTEM_PROMPT = """You are an application security remediation assistant.
Return ONLY valid JSON.

Output JSON shape:
{
  "triage": "true_positive|false_positive|uncertain",
  "triage_confidence": "low|medium|high",
  "reasoning": "short technical explanation",
  "remediation_text": "clear fix guidance",
  "fixed_code": "optional replacement snippet",
  "tests_to_add": ["test suggestion 1", "test suggestion 2"],
  "safe_to_autofix": false
}

Rules:
- If evidence is weak or incomplete, set triage to uncertain.
- Never claim exploitability without strong evidence.
- Keep fixes framework-aware and minimal.
"""


def remediation_user_prompt(context: dict) -> str:
    """Build remediation user prompt from finding context."""
    return (
        "Analyze this finding context and provide triage + remediation JSON.\n\n"
        f"Context:\n{context}"
    )


GOAL_COMPILER_SYSTEM_PROMPT = """You are a security scan goal compiler.
Convert natural-language goals into a bounded scan plan intent.
Return ONLY valid JSON.

Output JSON shape:
{
  "priorities": ["sqli", "xss", "authz", "ssrf", "path_traversal"],
  "route_keywords": ["checkout", "admin", "cart"],
  "role_focus": ["guest", "user", "admin"],
  "modules_focus": {
    "sast": true,
    "dast": true,
    "secrets": true,
    "dependencies": true,
    "coverage": true
  },
  "suggested_scan_config": {
    "scan_depth": 5,
    "timeout": 1800,
    "ajax_spider": false,
    "context_aware_payloads": true
  },
  "reasoning": "short reason"
}

Rules:
- Keep route keywords short.
- Use only safe bounded settings.
- Prefer conservative modules_focus unless goals clearly request otherwise.
"""


def goal_compiler_user_prompt(goals: list[str], scan_context: dict) -> str:
    """Build goal-compiler prompt from natural-language goals."""
    return (
        "Compile these natural-language security goals into plan intent JSON.\n\n"
        f"Goals:\n{goals}\n\n"
        f"Scan context:\n{scan_context}"
    )


SYNTHESIS_SYSTEM_PROMPT = """You are a security findings analyst.
Analyze compressed findings and output ONLY valid JSON.
Your task: detect attack chains, flag probable false positives, and summarize for executives.

Output JSON shape (ALL fields required):
{
  "attack_chains": [
    {
      "finding_ids": ["F01", "F03"],
      "severity": "critical",
      "narrative": "SSRF in /fetch reaches internal metadata service, leaking IAM credentials that enable S3 write access"
    }
  ],
  "probable_fps": [
    {
      "finding_id": "F05",
      "likely_reason": "ZAP detected time-based SQLi; code shows parameterized query with user input bound via ORM"
    }
  ],
  "summary": "60-word max executive summary of what was found and business impact"
}

Rules:
- Chain detection: Look for findings where F1's output enables F2's exploitation.
- False positive check: Only for "prob" confidence (static + no DAST confirm). Whitebox mode only.
- Summary: Business language, no jargon, focus on risk and impact.
- Never create attack chains for fewer than 2 findings.
- severity in chain: critical if any finding is critical, else high if any high, else medium.
"""


def synthesis_prompt(
    compressed_findings: str,
    stack_string: str,
    auth_string: str,
    scan_mode: str,
    has_probable_findings: bool,
    finding_count: int,
) -> str:
    """Build post-scan synthesis prompt.

    Args:
        compressed_findings: One-liner format findings
        stack_string: "Django 3.2 + MySQL 8" or "unknown"
        auth_string: "form-login, session-cookie" or "none"
        scan_mode: "whitebox" or "blackbox"
        has_probable_findings: Whether there are probable findings to check
        finding_count: Total finding count

    Returns:
        Full user prompt for synthesis
    """
    parts = [
        f"SCAN SUMMARY",
        f"Mode: {scan_mode}",
        f"Stack: {stack_string}",
        f"Auth: {auth_string}",
        f"Total findings: {finding_count}",
        f"",
        "COMPRESSED FINDINGS",
        compressed_findings,
        f"",
        "ANALYSIS TASKS",
        "1. Detect attack chains: Find sequences where finding A enables exploitation of finding B",
        "   Example: credentials (F01) → lateral move (F02) → data exfil (F03)",
        "",
    ]

    if scan_mode == "whitebox" and has_probable_findings:
        parts.append(
            "2. Flag false positives: Only for 'prob' findings (static only). "
            "Check if code context contradicts the finding."
        )
    else:
        parts.append(
            "2. False positives: None to check "
            f"({scan_mode} mode, or no probable findings)"
        )

    parts.extend([
        "",
        "3. Executive summary: 60 words max, business language, focus on risk",
        "",
        "Output the JSON above.",
    ])

    return "\n".join(parts)


PRE_SCAN_SYSTEM_PROMPT = """You are a security scan planning advisor.
Given a project description and scan context, recommend focus areas and skip hints.
Return ONLY valid JSON.

Output JSON shape:
{
  "focus_areas": ["payment endpoints", "auth flow", "admin panel"],
  "skip_hint": ["static assets", "marketing pages"],
  "risk_hypothesis": "Short sentence: what you expect to find"
}

Rules:
- focus_areas: 2-4 endpoints or flows to prioritize
- skip_hint: 2-3 URL patterns or path prefixes to deprioritize (e.g., /marketing, *.png)
- risk_hypothesis: One sentence, max 20 words
- Be specific to the project domain (e.g., if it's e-commerce, mention checkout/payment)
"""


def pre_scan_prompt(
    project_description: str,
    scan_mode: str,
    target_domain: str,
    finding_types: str = "",
) -> str:
    """Build pre-scan planning prompt.

    Args:
        project_description: User-provided description of project
        scan_mode: "whitebox" or "blackbox"
        target_domain: "api.example.com" (domain only, not full URL)
        finding_types: For whitebox: "2 sqli, 3 xss, 1 ssrf"

    Returns:
        Full user prompt for pre-scan planner
    """
    parts = [
        "PROJECT CONTEXT",
        f"Description: {project_description}",
        f"Domain: {target_domain}",
        f"Mode: {scan_mode}",
    ]

    if finding_types and scan_mode == "whitebox":
        parts.append(f"Existing findings: {finding_types}")

    parts.extend([
        "",
        "Given this context, what should the scan prioritize?",
        "Recommend 2-4 focus areas (endpoints or flows) and 2-3 paths to skip.",
        "Also provide a one-sentence hypothesis of what vulnerabilities you expect to find.",
        "",
        "Output the JSON above.",
    ])

    return "\n".join(parts)
