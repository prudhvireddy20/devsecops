"""Resolve effective LLM provider configuration from scan/project/global settings."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import decrypt_token
from app.models.llm_provider_credential import LLMProviderCredential
from app.llm.catalog import get_default_model

# ponytail: security — Fernet key (ENCRYPTION_KEY) must be stored outside
# the database. If the DB is compromised and ENCRYPTION_KEY is in the same
# .env file, encryption is theater. Rotate ENCRYPTION_KEY after any DB
# compromise and re-encrypt all stored credentials.

ALLOWED_LLM_PROVIDERS = {"anthropic", "openai", "openrouter", "google", "github"}


def normalize_provider(provider: str | None) -> str:
    """Normalize provider string to known value or empty string."""
    value = (provider or "").strip().lower()
    if value == "copilot":
        value = "github"
    if not value:
        return ""
    return value if value in ALLOWED_LLM_PROVIDERS else ""


def resolve_llm_provider_config(project=None, scan_config: dict | None = None) -> dict:
    """Resolve provider/model/api_key using scan overrides then project then env.

    Priority:
    1. scan_config overrides (llm_provider, llm_model, llm_api_key)
    2. project-level values (llm_provider, llm_model, llm_api_key_encrypted)
    3. global settings defaults
    """
    cfg = scan_config or {}

    scan_provider = normalize_provider(cfg.get("llm_provider"))
    project_provider = normalize_provider(getattr(project, "llm_provider", ""))
    provider = scan_provider or project_provider or normalize_provider(settings.LLM_PROVIDER) or "anthropic"

    scan_model = str(cfg.get("llm_model", "") or "").strip()
    project_model = str(getattr(project, "llm_model", "") or "").strip()
    model = scan_model or project_model or (settings.LLM_MODEL or "").strip()
    if provider == "openrouter" and model == "openrouter/free":
        model = get_default_model("openrouter")

    scan_key = str(cfg.get("llm_api_key", "") or "").strip()
    scan_enc = str(cfg.get("llm_api_key_encrypted", "") or "").strip()
    if not scan_key and scan_enc:
        scan_key = decrypt_token(scan_enc)
    project_enc = str(getattr(project, "llm_api_key_encrypted", "") or "").strip()
    project_key = decrypt_token(project_enc) if project_enc else ""

    api_key = scan_key or project_key

    # ponytail: env vars deliberately excluded — keys come only from
    # scan config or DB credentials (frontend-entered). This avoids
    # requiring ANTHROPIC_API_KEY / OPENAI_API_KEY in deployment env.

    return {
        "provider": provider,
        "model": model,
        "api_key": api_key,
        "enabled": bool(settings.LLM_ENABLED),
    }


async def resolve_llm_provider_config_async(
    db: AsyncSession,
    project=None,
    scan_config: dict | None = None,
    user_id: str = "",
) -> dict:
    """Resolve provider/model/api_key with DB-backed global provider credentials.

    Priority:
    1. scan_config overrides (llm_provider, llm_model, llm_api_key, llm_api_key_encrypted)
    2. global provider credentials table (api_key_encrypted/default_model)
    3. project-level values (legacy fallback)
    4. environment settings

    LLM is auto-enabled if:
    - LLM_ENABLED=True in settings, OR
    - Any provider credentials are stored in database
    """
    cfg = scan_config or {}

    scan_provider = normalize_provider(cfg.get("llm_provider"))
    project_provider = normalize_provider(getattr(project, "llm_provider", ""))
    provider = scan_provider or project_provider or normalize_provider(settings.LLM_PROVIDER) or "anthropic"

    scan_model = str(cfg.get("llm_model", "") or "").strip()
    project_model = str(getattr(project, "llm_model", "") or "").strip()

    owner = user_id or getattr(project, "owner_id", "") or ""
    cred_result = await db.execute(
        select(LLMProviderCredential).where(
            LLMProviderCredential.provider == provider,
            LLMProviderCredential.user_id == owner,
        )
    )
    credential = cred_result.scalar_one_or_none()

    # Backward compatibility: if looking for 'github' but find 'copilot', use that
    if not credential and provider == "github":
        cred_result = await db.execute(
            select(LLMProviderCredential).where(
                LLMProviderCredential.provider == "copilot",
                LLMProviderCredential.user_id == owner,
            )
        )
        credential = cred_result.scalar_one_or_none()

    stored_default_model = str(getattr(credential, "default_model", "") or "").strip()
    model = scan_model or stored_default_model or project_model or (settings.LLM_MODEL or "").strip() or get_default_model(provider)
    if provider == "openrouter" and model == "openrouter/free":
        model = get_default_model("openrouter")

    scan_key = str(cfg.get("llm_api_key", "") or "").strip()
    scan_enc = str(cfg.get("llm_api_key_encrypted", "") or "").strip()
    if not scan_key and scan_enc:
        scan_key = decrypt_token(scan_enc)

    stored_key = ""
    if credential and credential.encrypted_token:
        stored_key = decrypt_token(str(credential.encrypted_token))

    project_enc = str(getattr(project, "llm_api_key_encrypted", "") or "").strip()
    project_key = decrypt_token(project_enc) if project_enc else ""

    api_key = scan_key or stored_key or project_key

    # Auto-enable LLM if ANY provider has credentials stored in database
    # This allows users to configure providers via dashboard without needing LLM_ENABLED=true
    has_current_provider_key = stored_key and bool(stored_key.strip())

    # Check if any provider is configured in database (for auto-enable)
    has_any_provider_configured = False
    if not has_current_provider_key:
        # Current provider isn't configured, check if ANY provider for this user is
        any_cred_result = await db.execute(
            select(LLMProviderCredential).where(
                LLMProviderCredential.user_id == owner,
                LLMProviderCredential.encrypted_token != "",
            )
        )
        any_credentials = any_cred_result.scalars().first()
        has_any_provider_configured = bool(any_credentials)
    else:
        # Current provider is configured
        has_any_provider_configured = True

    llm_enabled = bool(settings.LLM_ENABLED) or has_any_provider_configured

    return {
        "provider": provider,
        "model": model,
        "api_key": api_key,
        "enabled": llm_enabled,
        "has_stored_provider_key": bool(stored_key),
        "has_env_provider_key": False,
    }
