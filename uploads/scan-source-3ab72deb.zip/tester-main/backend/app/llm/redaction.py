"""Helpers for redacting secret-like data before sending to LLM providers."""

import re

# Conservative patterns for obvious credentials/secrets.
_REDACTION_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key\s*[:=]\s*['\"]?)([^'\"\s]{8,})(['\"]?)"),
    re.compile(r"(?i)(password\s*[:=]\s*['\"]?)([^'\"\s]{4,})(['\"]?)"),
    re.compile(r"(?i)(secret[_-]?key\s*[:=]\s*['\"]?)([^'\"\s]{8,})(['\"]?)"),
    re.compile(r"(?i)(authorization\s*:\s*bearer\s+)([A-Za-z0-9._\-]+)"),
    re.compile(r"(ghp_[A-Za-z0-9]{20,})"),
    re.compile(r"(AKIA[0-9A-Z]{16})"),
    re.compile(r"-----BEGIN(?: RSA)? PRIVATE KEY-----[\s\S]*?-----END(?: RSA)? PRIVATE KEY-----"),
]


def redact_text(text: str) -> str:
    """Redact obvious secrets from text while preserving useful context."""
    if not text:
        return text

    def _replacement(match: re.Match[str]) -> str:
        group_count = match.re.groups
        if group_count >= 3:
            suffix = match.group(3) or ""
            return f"{match.group(1)}<REDACTED>{suffix}"
        if group_count >= 2:
            return f"{match.group(1)}<REDACTED>"
        return "<REDACTED>"

    redacted = text
    for pattern in _REDACTION_PATTERNS:
        redacted = pattern.sub(_replacement, redacted)
    return redacted


def truncate_text(text: str, max_chars: int) -> str:
    """Truncate text to max chars with a suffix marker."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n...<TRUNCATED>"
