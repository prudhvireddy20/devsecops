"""Pydantic schemas for strict LLM JSON outputs."""

from pydantic import BaseModel, Field


class PlannerAction(BaseModel):
    """Single planner action emitted by LLM."""

    action: str = Field(
        default="no_change",
        description=(
            "Allowed actions: no_change, update_scan_config, "
            "prioritize_vuln_types, recommend_targeted_retry"
        ),
    )
    reason: str = ""
    params: dict = Field(default_factory=dict)


class PlannerDecision(BaseModel):
    """Planner decision wrapper."""

    summary: str = ""
    actions: list[PlannerAction] = Field(default_factory=list)


class RemediationSuggestion(BaseModel):
    """LLM remediation + triage output."""

    triage: str = "uncertain"  # true_positive | false_positive | uncertain
    triage_confidence: str = "low"  # low | medium | high
    reasoning: str = ""
    remediation_text: str = ""
    fixed_code: str = ""
    tests_to_add: list[str] = Field(default_factory=list)
    safe_to_autofix: bool = False


class GoalPlanIntent(BaseModel):
    """Compiled scan intent from natural-language goals."""

    priorities: list[str] = Field(default_factory=list)
    route_keywords: list[str] = Field(default_factory=list)
    role_focus: list[str] = Field(default_factory=list)
    modules_focus: dict = Field(default_factory=dict)
    suggested_scan_config: dict = Field(default_factory=dict)
    reasoning: str = ""
