"""FastAPI application entry point."""
import asyncio
import base64
import hashlib
import hmac
import ipaddress
import json
import logging
import secrets
import time
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import init_db, close_db, run_migrations, get_db
from app.core.auth import require_api_key, get_current_user
from app.core.rate_limit import get_rate_limiter
from app.core.logging import setup_structured_logging
from app.api import projects, scans, findings, reports, llm, users, integrations
from app.api import cp_adapter, trustscan_connector
from app.api.websocket import ws_manager

# Configure structured logging
setup_structured_logging(debug=settings.DEBUG)
logger = logging.getLogger(__name__)

_WS_TOKEN_TTL_SECONDS = 120
_USED_WS_TOKENS: dict[str, int] = {}


def _cleanup_ws_tokens(now: float | None = None) -> None:
    """Drop expired consumed WebSocket token markers."""
    current = int(now if now is not None else time.time())
    expired = [tok for tok, exp in _USED_WS_TOKENS.items() if exp <= current]
    for tok in expired:
        _USED_WS_TOKENS.pop(tok, None)


def _urlsafe_b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _urlsafe_b64decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def _extract_hostname(host_header: str) -> str:
    if not host_header:
        return ""
    host = host_header.split(",", 1)[0].strip()
    if host.startswith("["):
        end = host.find("]")
        if end != -1:
            return host[1:end].lower()
    return host.split(":", 1)[0].lower()


def _should_enforce_https_headers(request: Request) -> bool:
    forwarded_proto = request.headers.get("x-forwarded-proto", "").split(",", 1)[0].strip().lower()
    is_https = request.url.scheme == "https" or forwarded_proto == "https"
    hostname = _extract_hostname(request.headers.get("host", ""))
    is_local = hostname in {"localhost", "127.0.0.1", "::1"} or hostname.endswith(".localhost")
    return is_https and not is_local


def _is_local_or_private(value: str) -> bool:
    normalized = (value or "").strip().lower()
    if not normalized:
        return False
    if normalized.startswith("[") and normalized.endswith("]"):
        normalized = normalized[1:-1]
    if normalized == "localhost" or normalized.endswith(".localhost"):
        return True
    try:
        parsed = ipaddress.ip_address(normalized)
    except ValueError:
        return False
    return parsed.is_loopback or parsed.is_private or parsed.is_link_local


def _should_inject_api_key(request: Request) -> bool:
    if not settings.DEBUG:
        return False
    host_name = _extract_hostname(request.headers.get("host", ""))
    client_host = request.client.host if request.client else ""
    return _is_local_or_private(host_name) or _is_local_or_private(client_host)


def _sign_ws_payload(payload_b64: str) -> str:
    secret = settings.API_KEY.encode()
    digest = hmac.new(secret, payload_b64.encode(), hashlib.sha256).digest()
    return _urlsafe_b64encode(digest)


def _issue_ws_token(scope: str, scan_id: str = "") -> str:
    payload = {
        "scope": scope,
        "scan_id": scan_id,
        "exp": int(time.time()) + _WS_TOKEN_TTL_SECONDS,
        "nonce": secrets.token_urlsafe(8),
    }
    payload_b64 = _urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    )
    signature = _sign_ws_payload(payload_b64)
    return f"{payload_b64}.{signature}"


def _validate_ws_token(token: str, *, scope: str, scan_id: str = "", consume: bool = False) -> bool:
    _cleanup_ws_tokens()
    if token in _USED_WS_TOKENS:
        return False

    try:
        payload_b64, provided_sig = token.split(".", 1)
    except ValueError:
        return False

    expected_sig = _sign_ws_payload(payload_b64)
    if not hmac.compare_digest(provided_sig, expected_sig):
        return False

    try:
        payload = json.loads(_urlsafe_b64decode(payload_b64))
    except Exception:
        return False

    if not isinstance(payload, dict):
        return False
    if str(payload.get("scope", "")) != scope:
        return False

    try:
        expires_at = int(payload.get("exp", 0))
    except Exception:
        return False
    if expires_at <= int(time.time()):
        return False

    if scope == "scan" and str(payload.get("scan_id", "")) != scan_id:
        return False

    if consume:
        _USED_WS_TOKENS[token] = expires_at

    return True


class WebSocketTokenRequest(BaseModel):
    scope: str = "scan"  # scan | dashboard
    scan_id: str = ""


async def _seed_admin_user() -> None:
    """Create the admin user from settings.API_KEY if not yet in the users table."""
    from hashlib import sha256 as _sha256
    from sqlalchemy import select as _select
    from app.core.database import async_session_factory
    from app.models.user import User

    if not settings.API_KEY:
        logger.warning("API_KEY not set — cannot seed admin user")
        return

    key_hash = _sha256(settings.API_KEY.encode()).hexdigest()
    async with async_session_factory() as db:
        existing = await db.scalar(_select(User).where(User.api_key_hash == key_hash))
        if existing:
            return

        import uuid as _uuid
        admin = User(
            id=str(_uuid.uuid4()),
            api_key_hash=key_hash,
            label="admin",
            is_active=True,
            is_admin=True,
        )
        db.add(admin)
        await db.commit()
        logger.info("Admin user seeded from API_KEY")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    # Import models so SQLAlchemy discovers them
    import app.models  # noqa: F401
    await init_db()
    await run_migrations()
    await _seed_admin_user()
    cp_adapter.validate_cp_runtime_settings()
    await scans.recover_interrupted_scans()
    await scans.start_scan_queue_worker()
    logger.info("Database initialized")
    # Start rate limiter cleanup task
    rate_limiter = get_rate_limiter()
    await rate_limiter.start()
    logger.info("Rate limiter started")
    yield
    # Stop rate limiter
    await scans.stop_scan_queue_worker()
    await rate_limiter.stop()
    await close_db()
    logger.info("Application shutdown complete")


# Create FastAPI app
app = FastAPI(
    title="TraceON",
    version=settings.APP_VERSION,
    description="White-box security testing tool with SAST/DAST correlation",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-API-Key"],
)


# Security headers middleware
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)
    enforce_https_headers = _should_enforce_https_headers(request)
    csp_parts = [
        "default-src 'self'",
        "script-src 'self'",
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: https:",
        "font-src 'self' data:",
        "connect-src 'self' ws: wss:",
        "frame-ancestors 'none'",
    ]
    if enforce_https_headers:
        csp_parts.append("upgrade-insecure-requests")
    response.headers["Content-Security-Policy"] = "; ".join(csp_parts)
    # Prevent clickjacking
    response.headers["X-Frame-Options"] = "DENY"
    # Prevent MIME type sniffing
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Enable XSS protection in legacy browsers
    response.headers["X-XSS-Protection"] = "1; mode=block"
    if enforce_https_headers:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    # Referrer policy
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Feature policy
    response.headers["Permissions-Policy"] = "microphone=(), camera=(), geolocation=()"
    return response

# Rate limiting middleware
@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Apply rate limiting per client IP."""
    # Default to socket peer IP; trust X-Forwarded-For only for local deployments.
    client_ip = request.client.host if request.client else "unknown"
    if settings.TRUST_PROXY:
        forwarded = request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
        if forwarded:
            client_ip = forwarded

    # Skip rate limiting for health checks and local/private network clients
    if request.url.path in ("/api/health", "/api/v1/health"):
        return await call_next(request)
    if _is_local_or_private(client_ip):
        return await call_next(request)

    # Check rate limit
    rate_limiter = get_rate_limiter()
    limit_str = str(rate_limiter.requests_per_minute)
    if not rate_limiter.is_allowed(client_ip):
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded"},
            headers={
                "X-RateLimit-Limit": limit_str,
                "X-RateLimit-Window": "60"
            }
        )

    response = await call_next(request)
    # Add remaining requests header
    remaining = rate_limiter.get_remaining(client_ip)
    response.headers["X-RateLimit-Remaining"] = str(remaining)
    response.headers["X-RateLimit-Limit"] = limit_str
    response.headers["X-RateLimit-Window"] = "60"
    return response

# Global exception handler — suppress stack traces in production
@app.exception_handler(Exception)
async def _unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    if settings.DEBUG:
        raise exc
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


# API Routers — all protected by API key
_auth_deps = [Depends(require_api_key)]

# Other API endpoints
app.include_router(projects.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(scans.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(findings.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(reports.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(llm.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(users.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(integrations.router, prefix="/api/v1", dependencies=_auth_deps)
app.include_router(trustscan_connector.router, prefix="/api/v1")

# Legacy compatibility aliases (prefer /api/v1 for new clients).
app.include_router(projects.router, prefix="/api", dependencies=_auth_deps)
app.include_router(scans.router, prefix="/api", dependencies=_auth_deps)
app.include_router(findings.router, prefix="/api", dependencies=_auth_deps)
app.include_router(reports.router, prefix="/api", dependencies=_auth_deps)
app.include_router(llm.router, prefix="/api", dependencies=_auth_deps)
app.include_router(integrations.router, prefix="/api", dependencies=_auth_deps)
app.include_router(trustscan_connector.router, prefix="/api")

# CloudGuard Control Plane adapter — uses its own HMAC / JWKS auth.
# Routes: GET /api/manifest, GET /sso-entry
app.include_router(cp_adapter.router)


@app.websocket("/ws/scan/{scan_id}")
async def websocket_scan(websocket: WebSocket, scan_id: str):
    """WebSocket endpoint for real-time scan progress."""
    token = websocket.query_params.get("token", "")
    if not token or not _validate_ws_token(token, scope="scan", scan_id=scan_id, consume=True):
        await websocket.close(code=4003, reason="Invalid or missing websocket token")
        return
    await ws_manager.connect(websocket, scan_id)

    async def _keepalive():
        """Send ping every 30s to keep proxy from timing out idle connection."""
        while True:
            try:
                await asyncio.sleep(30)
                await websocket.send_text('{"type":"ping"}')
            except Exception:
                break

    ping_task = asyncio.create_task(_keepalive())
    try:
        while True:
            # Keep connection alive, receive any client messages
            data = await websocket.receive_text()
            # Ignore ping/pong messages
            if data in ('{"type":"ping"}', '{"type":"pong"}', "ping", "pong"):
                continue
            # Client can send commands like cancel
            if data == "cancel":
                from app.core.database import async_session_factory
                from app.api.scans import _do_cancel_scan
                try:
                    async with async_session_factory() as session:
                        await _do_cancel_scan(scan_id, session)
                    await websocket.send_json({"type": "cancelled", "scan_id": scan_id})
                except Exception as e:
                    await websocket.send_json({"type": "error", "message": str(e)})
    except WebSocketDisconnect:
        await ws_manager.disconnect(websocket, scan_id)
    except Exception:
        await ws_manager.disconnect(websocket, scan_id)
    finally:
        ping_task.cancel()
        try:
            await ping_task
        except asyncio.CancelledError:
            pass


@app.websocket("/ws/dashboard")
async def websocket_dashboard(websocket: WebSocket):
    """WebSocket endpoint for dashboard updates using one-time token query."""
    token = websocket.query_params.get("token", "")
    if not token or not _validate_ws_token(token, scope="dashboard", consume=True):
        await websocket.close(code=4003, reason="Invalid or missing websocket token")
        return
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        await ws_manager.disconnect(websocket)
    except Exception:
        await ws_manager.disconnect(websocket)


# Health check
@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
    }


# Health check (v1 compatibility)
@app.get("/api/v1/health")
async def health_check_v1():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
    }


# Secure API key endpoint (frontend initialization)
@app.get("/api/v1/auth/key", dependencies=[Depends(require_api_key)])
async def get_api_key():
    """Return the current API key for authenticated requests."""
    return {"api_key": settings.API_KEY}


@app.post("/api/v1/auth/ws-token", dependencies=[Depends(require_api_key)])
async def create_ws_token(request: WebSocketTokenRequest):
    """Issue one-time, short-lived websocket token."""
    scope = (request.scope or "scan").strip().lower()
    if scope not in {"scan", "dashboard"}:
        raise HTTPException(400, "scope must be one of: scan, dashboard")

    if scope == "scan":
        scan_id = (request.scan_id or "").strip()
        if not scan_id:
            raise HTTPException(400, "scan_id is required for scan scope")
        token = _issue_ws_token("scan", scan_id=scan_id)
        ws_path = f"/ws/scan/{scan_id}?token={token}"
    else:
        token = _issue_ws_token("dashboard")
        ws_path = f"/ws/dashboard?token={token}"

    return {
        "token": token,
        "scope": scope,
        "ws_path": ws_path,
        "expires_in": _WS_TOKEN_TTL_SECONDS,
    }


# Dashboard stats endpoint
@app.get("/api/v1/dashboard/stats")
async def dashboard_stats(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get dashboard statistics scoped to the current user."""
    from sqlalchemy import select, func, case, literal
    from app.models.project import Project
    from app.models.scan import Scan
    from app.models.finding import Finding

    # Count projects (scoped to current user unless admin)
    proj_where = Project.is_active.is_(True)
    if not current_user.is_admin:
        proj_where = proj_where & (Project.owner_id == current_user.id)
    result = await db.execute(select(func.count(Project.id)).where(proj_where))
    total_projects = result.scalar() or 0

    # Count scans (scoped to current user's projects unless admin)
    scan_q = select(func.count(Scan.id)).join(Project, Scan.project_id == Project.id)
    if not current_user.is_admin:
        scan_q = scan_q.where(Project.owner_id == current_user.id)
    result = await db.execute(scan_q)
    total_scans = result.scalar() or 0

    # Recent scans (scoped to current user's projects unless admin)
    recent_q = (
        select(Scan)
        .join(Project, Scan.project_id == Project.id)
        .order_by(Scan.created_at.desc())
        .limit(5)
    )
    if not current_user.is_admin:
        recent_q = recent_q.where(Project.owner_id == current_user.id)
    result = await db.execute(recent_q)
    recent_scans_raw = result.scalars().all()
    recent_scans = []
    project_name_cache: dict[str, str] = {}
    for s in recent_scans_raw:
        d = s.to_dict()
        pid = d["project_id"]
        if pid not in project_name_cache:
            p_result = await db.execute(select(Project).where(Project.id == pid))
            p = p_result.scalar_one_or_none()
            project_name_cache[pid] = p.name if p else pid[:8]
        d["project_name"] = project_name_cache[pid]
        recent_scans.append(d)

    # Finding summary (scoped to current user's projects unless admin)
    finding_q = select(
        func.count(Finding.id).label("total"),
        func.sum(case((Finding.severity == "critical", literal(1)), else_=literal(0))).label("critical"),
        func.sum(case((Finding.severity == "high", literal(1)), else_=literal(0))).label("high"),
        func.sum(case((Finding.severity == "medium", literal(1)), else_=literal(0))).label("medium"),
        func.sum(case((Finding.severity == "low", literal(1)), else_=literal(0))).label("low"),
        func.sum(case((Finding.severity == "info", literal(1)), else_=literal(0))).label("info"),
    ).select_from(Finding).join(Scan, Finding.scan_id == Scan.id).join(Project, Scan.project_id == Project.id)
    if not current_user.is_admin:
        finding_q = finding_q.where(Project.owner_id == current_user.id)
    finding_counts = await db.execute(finding_q)
    row = finding_counts.one()
    finding_summary = {
        "total": row.total or 0,
        "critical": row.critical or 0,
        "high": row.high or 0,
        "medium": row.medium or 0,
        "low": row.low or 0,
        "info": row.info or 0,
    }

    return {
        "total_projects": total_projects,
        "total_scans": total_scans,
        "recent_scans": recent_scans,
        "finding_summary": finding_summary,
    }


@app.get("/api/dashboard/stats")
async def dashboard_stats_legacy(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Legacy dashboard stats path; prefer /api/v1/dashboard/stats."""
    return await dashboard_stats(current_user=current_user, db=db)


# ---------- Serve React frontend (production) ----------
# In Docker, the built frontend is copied to /app/static
_static_dir = Path(__file__).resolve().parent.parent / "static"
if _static_dir.is_dir():
    # Serve JS/CSS/assets at /assets
    _assets_dir = _static_dir / "assets"
    if _assets_dir.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets_dir)), name="assets")

     # Pre-read and patch index.html so the frontend receives the API key
    # without manual configuration. A separate secure endpoint provides the key.
    _index_path = _static_dir / "index.html"
    _index_html_raw = _index_path.read_text(encoding="utf-8") if _index_path.is_file() else ""

    def _build_index_html(request: Request) -> str:
        if not _should_inject_api_key(request):
            return _index_html_raw
        key_script = f"<script>window.__DT_API_KEY__={json.dumps(settings.API_KEY)};</script>"
        if "</head>" in _index_html_raw:
            return _index_html_raw.replace("</head>", f"  {key_script}\n  </head>", 1)
        return f"{key_script}\n{_index_html_raw}"

    @app.get("/{full_path:path}")
    async def serve_spa(request: Request, full_path: str):
        """Catch-all: serve index.html for any non-API/non-WS route (SPA routing)."""
        # Never serve index.html for API or WS paths — let them 404 properly
        if full_path.startswith(("api/", "ws/")):
            raise HTTPException(404, "Not found")
        # Try to serve exact file first (e.g. favicon.ico, manifest.json)
        file_path = _static_dir / full_path
        # Prevent path traversal by validating the resolved path is within static dir
        try:
            resolved_path = file_path.resolve()
            static_dir_resolved = _static_dir.resolve()
            # Ensure resolved path is within static directory
            resolved_path.relative_to(static_dir_resolved)
        except ValueError:
            raise HTTPException(404, "Not found")
        except RuntimeError:
            raise HTTPException(404, "Not found")
        
        if full_path and full_path != "index.html" and resolved_path.is_file():
            return FileResponse(str(resolved_path))
        # Fall back to index.html for SPA routing
        from fastapi.responses import HTMLResponse
        return HTMLResponse(_build_index_html(request))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
    )
