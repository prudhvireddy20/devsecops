"""Finding SQLAlchemy model."""
import uuid
from datetime import UTC, datetime

from sqlalchemy import String, Text, DateTime, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Finding(Base):
    """Represents a security finding/vulnerability discovered during a scan."""

    __tablename__ = "findings"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    scan_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("scans.id"), nullable=False
    )

    # Classification
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    vulnerability_type: Mapped[str] = mapped_column(
        String(100), nullable=False
    )  # sqli, xss, cmdi, ssrf, path_traversal, secret, dependency_cve, config
    severity: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # critical, high, medium, low, info
    confidence: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # verified, probable, observed
    cwe: Mapped[str] = mapped_column(String(20), default="")  # CWE-89, CWE-79, etc.
    owasp_category: Mapped[str] = mapped_column(Text, default="")

    # Location
    endpoint: Mapped[str] = mapped_column(String(500), default="")
    http_method: Mapped[str] = mapped_column(String(10), default="")
    parameter: Mapped[str] = mapped_column(String(200), default="")

    # Source Code Context (from SAST)
    file_path: Mapped[str] = mapped_column(Text, default="")
    line_number: Mapped[int] = mapped_column(Integer, default=0)
    code_snippet: Mapped[str] = mapped_column(Text, default="")
    data_flow: Mapped[str] = mapped_column(Text, default="")  # source -> ... -> sink

    # Dynamic Proof (from DAST)
    payload: Mapped[str] = mapped_column(Text, default="")
    response_code: Mapped[int] = mapped_column(Integer, default=0)
    response_evidence: Mapped[str] = mapped_column(Text, default="")
    auth_role: Mapped[str] = mapped_column(String(80), default="")
    journey_source: Mapped[str] = mapped_column(String(80), default="")
    workflow_graph_id: Mapped[str] = mapped_column(String(36), default="")
    workflow_step_id: Mapped[str] = mapped_column(String(36), default="")
    repro_bundle: Mapped[dict] = mapped_column(JSON, default=lambda: {})
    risk_score: Mapped[int] = mapped_column(Integer, default=0)
    risk_level: Mapped[str] = mapped_column(String(20), default="")

    # Scanner Source
    scanner_source: Mapped[str] = mapped_column(
        String(50), nullable=False
    )  # semgrep, zap, detect-secrets, pip-audit, correlation
    scanner_rule_id: Mapped[str] = mapped_column(String(200), default="")
    raw_scanner_output: Mapped[dict] = mapped_column(JSON, default=lambda: {})

    # Remediation
    remediation_text: Mapped[str] = mapped_column(Text, default="")
    generated_fix_payload: Mapped[dict] = mapped_column(JSON, default=lambda: {})
    fix_available: Mapped[bool] = mapped_column(default=False)
    fix_applied: Mapped[bool] = mapped_column(default=False)

    # Status
    status: Mapped[str] = mapped_column(
        String(20), default="open"
    )  # open, confirmed, false_positive, resolved, duplicate
    duplicate_of: Mapped[str] = mapped_column(
        String(36), default=""
    )  # ID of the primary finding this is a duplicate of
    notes: Mapped[str] = mapped_column(Text, default="")

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(UTC).replace(tzinfo=None)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(UTC).replace(tzinfo=None),
        onupdate=lambda: datetime.now(UTC).replace(tzinfo=None),
    )

    # Relationships
    scan = relationship("Scan", back_populates="findings")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "scan_id": self.scan_id,
            "title": self.title,
            "vulnerability_type": self.vulnerability_type,
            "severity": self.severity,
            "confidence": self.confidence,
            "cwe": self.cwe,
            "owasp_category": self.owasp_category,
            "endpoint": self.endpoint,
            "http_method": self.http_method,
            "parameter": self.parameter,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "code_snippet": self.code_snippet,
            "data_flow": self.data_flow,
            "payload": self.payload,
            "response_code": self.response_code,
            "response_evidence": self.response_evidence,
            "auth_role": self.auth_role,
            "journey_source": self.journey_source,
            "workflow_graph_id": self.workflow_graph_id,
            "workflow_step_id": self.workflow_step_id,
            "repro_bundle": self.repro_bundle,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "scanner_source": self.scanner_source,
            "scanner_rule_id": self.scanner_rule_id,
            "remediation_text": self.remediation_text,
            "generated_fix_payload": self.generated_fix_payload,
            "fix_available": self.fix_available,
            "fix_applied": self.fix_applied,
            "status": self.status,
            "duplicate_of": self.duplicate_of,
            "notes": self.notes,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
