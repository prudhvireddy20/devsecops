"""Global LLM provider credentials (encrypted API keys)."""

from datetime import UTC, datetime
from typing import Optional

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class LLMProviderCredential(Base):
    """Stores an encrypted API key and optional default model per provider."""

    __tablename__ = "llm_provider_credentials"

    user_id: Mapped[str] = mapped_column(
        String(255), primary_key=True, default=""
    )  # API key for user, empty for legacy
    provider: Mapped[str] = mapped_column(String(50), primary_key=True)
    auth_method: Mapped[str] = mapped_column(
        String(50), default="api_key"
    )  # Reserved for future auth modes

    # API Key authentication
    encrypted_token: Mapped[str] = mapped_column(Text, default="")

    # Reserved OAuth columns (unused, kept for future compatibility)
    oauth_username: Mapped[Optional[str]] = mapped_column(String(255), default=None)
    subscription_verified_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime, default=None
    )

    # Common fields
    default_model: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, default=None)

    def to_dict(self) -> dict:
        return {
            "user_id": self.user_id,
            "provider": self.provider,
            "auth_method": self.auth_method,
            "default_model": self.default_model,
            "has_token": bool(self.encrypted_token),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
