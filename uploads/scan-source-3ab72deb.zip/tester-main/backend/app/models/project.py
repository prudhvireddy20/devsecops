"""Project SQLAlchemy model."""
import uuid
from datetime import UTC, datetime

from sqlalchemy import JSON, String, Text, DateTime, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


def _utcnow() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class Project(Base):
    """Represents a source code project to be analyzed."""

    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    source_type: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # "local", "git", "zip"
    source_path: Mapped[str] = mapped_column(Text, default="")
    git_url: Mapped[str] = mapped_column(Text, default="")
    git_branch: Mapped[str] = mapped_column(String(100), default="main")
    target_url: Mapped[str] = mapped_column(Text, default="")
    llm_provider: Mapped[str] = mapped_column(String(50), default="")
    llm_model: Mapped[str] = mapped_column(String(120), default="")
    llm_api_key_encrypted: Mapped[str] = mapped_column(Text, default="")
    openapi_spec_files: Mapped[str] = mapped_column(Text, default="")
    postman_collection_files: Mapped[str] = mapped_column(Text, default="")
    journey_replay_files: Mapped[str] = mapped_column(Text, default="")
    framework: Mapped[str] = mapped_column(
        String(50), default=""
    )  # "flask", "django", "fastapi", "unknown"
    language: Mapped[str] = mapped_column(String(50), default="python")
    local_path: Mapped[str] = mapped_column(Text, default="")
    source_available: Mapped[bool] = mapped_column(Boolean, default=False)
    scan_mode: Mapped[str] = mapped_column(String(20), default="whitebox")  # whitebox, blackbox
    trustscan_url: Mapped[str] = mapped_column(Text, default="")
    trustscan_token_encrypted: Mapped[str] = mapped_column(Text, default="")
    trustscan_job_id: Mapped[str] = mapped_column(Text, default="")
    external_findings_path: Mapped[str] = mapped_column(Text, default="")
    external_findings_format: Mapped[str] = mapped_column(Text, default="")
    auth_config: Mapped[dict] = mapped_column(JSON, nullable=True, default=lambda: {})
    owner_id: Mapped[str] = mapped_column(String(36), default="", index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    scans = relationship("Scan", back_populates="project", cascade="all, delete-orphan")
    artifacts = relationship(
        "ProjectArtifact", back_populates="project", cascade="all, delete-orphan"
    )
    workflow_graphs = relationship(
        "WorkflowGraph", back_populates="project", cascade="all, delete-orphan"
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "source_type": self.source_type,
            "source_path": self.source_path,
            "git_url": self.git_url,
            "git_branch": self.git_branch,
            "target_url": self.target_url,
            "framework": self.framework,
            "language": self.language,
            "local_path": self.local_path,
            "scan_mode": self.scan_mode,
            "trustscan_url": self.trustscan_url or "",
            "has_trustscan_token": bool(self.trustscan_token_encrypted),
            "trustscan_job_id": self.trustscan_job_id or "",
            "external_findings_path": self.external_findings_path or "",
            "external_findings_format": self.external_findings_format or "",
            "llm_provider": self.llm_provider,
            "llm_model": self.llm_model,
            "has_llm_api_key": bool(self.llm_api_key_encrypted),
            "openapi_spec_files": self.openapi_spec_files,
            "postman_collection_files": self.postman_collection_files,
            "journey_replay_files": self.journey_replay_files,
            "is_active": self.is_active,
            "has_auth_config": bool(self.auth_config),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
