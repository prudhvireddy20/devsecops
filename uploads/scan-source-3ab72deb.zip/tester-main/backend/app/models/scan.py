"""Scan SQLAlchemy model."""
import uuid
from datetime import UTC, datetime

from sqlalchemy import String, Text, DateTime, Integer, ForeignKey, JSON, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Scan(Base):
    """Represents a security scan run against a project."""

    __tablename__ = "scans"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    project_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("projects.id"), nullable=False
    )
    status: Mapped[str] = mapped_column(
        String(20), default="pending"
    )  # pending, running, completed, failed, cancelled
    scan_type: Mapped[str] = mapped_column(
        String(50), default="full"
    )  # full, dast_only
    progress: Mapped[int] = mapped_column(Integer, default=0)  # 0-100
    current_phase: Mapped[str] = mapped_column(
        String(50), default=""
    )  # importing, auth, spider, active_scan, correlation
    source_available: Mapped[bool] = mapped_column(
        Boolean, default=False
    )
    scan_mode: Mapped[str] = mapped_column(String(20), default="whitebox")  # whitebox, blackbox
    modules_enabled: Mapped[dict] = mapped_column(
        JSON, default=lambda: {
            "dast": True,
            "nuclei": True,
            "coverage": False,
        }
    )
    auth_config: Mapped[dict] = mapped_column(
        JSON, default=lambda: {}
    )  # playwright script, credentials, roles
    scan_goals: Mapped[list] = mapped_column(
        JSON, default=lambda: []
    )  # Natural-language goals and goal metadata
    plan_intent: Mapped[dict] = mapped_column(
        JSON, default=lambda: {}
    )  # Validated planner intent compiled from goals
    scan_config: Mapped[dict] = mapped_column(
        JSON, default=lambda: {
            "scan_depth": 5,
            "timeout": 3600,
            "max_children": 10,
            "context_aware_payloads": True,
        }
    )
    results_summary: Mapped[dict] = mapped_column(
        JSON, default=lambda: {
            "total_findings": 0,
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "info": 0,
            "verified": 0,
            "probable": 0,
            "observed": 0,
        }
    )
    routes_discovered: Mapped[int] = mapped_column(Integer, default=0)
    coverage_percentage: Mapped[int] = mapped_column(Integer, default=0)
    log: Mapped[str] = mapped_column(Text, default="")
    error_message: Mapped[str] = mapped_column(Text, default="")
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(UTC).replace(tzinfo=None)
    )

    # LLM Analysis Results
    llm_status: Mapped[str] = mapped_column(
        String(20), default="pending"
    )  # pending, skipped, ok, failed
    llm_error: Mapped[str] = mapped_column(Text, default="")  # Error message if failed
    attack_chains: Mapped[list] = mapped_column(
        JSON, default=lambda: []
    )  # [{finding_ids: [], severity: "", narrative: ""}]
    llm_summary: Mapped[str] = mapped_column(Text, default="")  # 60-word executive summary

    # LLM Planning (from pre-scan planner)
    plan_result: Mapped[dict] = mapped_column(
        JSON, default=lambda: {}
    )  # {focus_areas: [], skip_hint: [], risk_hypothesis: ""}

    # Technology Stack (detected during fingerprinting)
    detected_stack: Mapped[dict] = mapped_column(
        JSON, default=lambda: {}
    )  # {framework: {name, version}, database: {name, version}, ...}

    # CloudGuard CP context (populated when a CP user starts a scan)
    cp_job_id: Mapped[str] = mapped_column(String(36), default="")
    cp_org_id: Mapped[str] = mapped_column(String(36), default="")
    cp_callback_url: Mapped[str] = mapped_column(Text, default="")
    cp_nonce: Mapped[str] = mapped_column(String(128), default="")

    # Relationships
    project = relationship("Project", back_populates="scans")
    findings = relationship(
        "Finding", back_populates="scan", cascade="all, delete-orphan"
    )

    def to_dict(self) -> dict:
        safe_scan_config = dict(self.scan_config or {})
        safe_scan_config.pop("llm_api_key", None)
        safe_scan_config.pop("llm_api_key_encrypted", None)
        return {
            "id": self.id,
            "project_id": self.project_id,
            "scan_mode": self.scan_mode,
            "status": self.status,
            "scan_type": self.scan_type,
            "progress": self.progress,
            "current_phase": self.current_phase,
            "modules_enabled": self.modules_enabled,
            "scan_goals": self.scan_goals,
            "plan_intent": self.plan_intent,
            "scan_config": safe_scan_config,
            "results_summary": self.results_summary,
            "plan_result": self.plan_result or {},
            "routes_discovered": self.routes_discovered,
            "coverage_percentage": self.coverage_percentage,
            "log": self.log,
            "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }



