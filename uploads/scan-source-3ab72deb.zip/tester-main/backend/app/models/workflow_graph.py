"""Workflow graph and step models for imported developer flows."""

import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class WorkflowGraph(Base):
    """Normalized workflow graph derived from imported artifacts."""

    __tablename__ = "workflow_graphs"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    project_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("projects.id"), nullable=False
    )
    artifact_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("project_artifacts.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), default="")
    source_kind: Mapped[str] = mapped_column(String(32), default="")
    version: Mapped[str] = mapped_column(String(32), default="v1")
    status: Mapped[str] = mapped_column(String(32), default="ready")
    metadata_json: Mapped[dict] = mapped_column(JSON, default=lambda: {})
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(UTC).replace(tzinfo=None)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(UTC).replace(tzinfo=None),
        onupdate=lambda: datetime.now(UTC).replace(tzinfo=None),
    )

    project = relationship("Project", back_populates="workflow_graphs")
    artifact = relationship("ProjectArtifact")
    steps = relationship("WorkflowStep", back_populates="graph", cascade="all, delete-orphan")
    attack_points = relationship(
        "WorkflowAttackPoint", back_populates="graph", cascade="all, delete-orphan"
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "artifact_id": self.artifact_id,
            "name": self.name,
            "source_kind": self.source_kind,
            "version": self.version,
            "status": self.status,
            "metadata": self.metadata_json,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class WorkflowStep(Base):
    """Single ordered workflow step."""

    __tablename__ = "workflow_steps"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    graph_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("workflow_graphs.id"), nullable=False
    )
    step_index: Mapped[int] = mapped_column(Integer, default=0)
    step_type: Mapped[str] = mapped_column(String(32), default="request")
    method: Mapped[str] = mapped_column(String(16), default="GET")
    path: Mapped[str] = mapped_column(Text, default="")
    endpoint_url: Mapped[str] = mapped_column(Text, default="")
    role: Mapped[str] = mapped_column(String(80), default="")
    request_headers: Mapped[dict] = mapped_column(JSON, default=lambda: {})
    request_body: Mapped[str] = mapped_column(Text, default="")
    expected_status: Mapped[int] = mapped_column(Integer, default=0)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=lambda: {})

    graph = relationship("WorkflowGraph", back_populates="steps")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "graph_id": self.graph_id,
            "step_index": self.step_index,
            "step_type": self.step_type,
            "method": self.method,
            "path": self.path,
            "endpoint_url": self.endpoint_url,
            "role": self.role,
            "request_headers": self.request_headers,
            "request_body": self.request_body,
            "expected_status": self.expected_status,
            "metadata": self.metadata_json,
        }


class WorkflowAttackPoint(Base):
    """Attackable parameter/field extracted from workflow steps."""

    __tablename__ = "workflow_attack_points"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    graph_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("workflow_graphs.id"), nullable=False
    )
    step_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("workflow_steps.id"), nullable=False
    )
    param_name: Mapped[str] = mapped_column(String(255), default="")
    param_location: Mapped[str] = mapped_column(String(32), default="query")
    sample_value: Mapped[str] = mapped_column(Text, default="")
    metadata_json: Mapped[dict] = mapped_column(JSON, default=lambda: {})

    graph = relationship("WorkflowGraph", back_populates="attack_points")
    step = relationship("WorkflowStep")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "graph_id": self.graph_id,
            "step_id": self.step_id,
            "param_name": self.param_name,
            "param_location": self.param_location,
            "sample_value": self.sample_value,
            "metadata": self.metadata_json,
        }
