"""Fix generator - generates code fixes for security vulnerabilities."""
import difflib
import logging
import re

logger = logging.getLogger(__name__)


class FixGenerator:
    """Generates template-based code fixes for identified vulnerabilities."""

    def generate_fix(self, finding) -> dict | None:
        """Generate a fix for a finding.

        Args:
            finding: Finding model instance or dict

        Returns:
            Dict with original_code, fixed_code, remediation_text, and diff.
        """
        # Support both SQLAlchemy model instances and plain dicts
        if isinstance(finding, dict):
            vuln_type = finding.get("vulnerability_type", "")
            code_snippet = finding.get("code_snippet", "")
            file_path = finding.get("file_path", "")
        else:
            vuln_type = getattr(finding, "vulnerability_type", "") or ""
            code_snippet = getattr(finding, "code_snippet", "") or ""
            file_path = getattr(finding, "file_path", "") or ""

        if not code_snippet:
            return None

        fix_methods = {
            "sqli": self._fix_sqli,
            "sql_injection": self._fix_sqli,
            "xss": self._fix_xss,
            "cross-site-scripting": self._fix_xss,
            "cmdi": self._fix_cmdi,
            "command_injection": self._fix_cmdi,
            "secret": self._fix_secret,
            "hardcoded-secret": self._fix_secret,
            "path_traversal": self._fix_path_traversal,
            "deserialization": self._fix_deserialization,
        }

        fix_method = fix_methods.get(vuln_type)
        if not fix_method:
            return self._generic_fix(vuln_type, code_snippet)

        try:
            return fix_method(code_snippet, file_path)
        except Exception as e:
            logger.warning(f"Fix generation failed for {vuln_type}: {e}")
            return self._generic_fix(vuln_type, code_snippet)

    def _fix_sqli(self, code: str, file_path: str) -> dict:
        """Generate fix for SQL injection."""
        original = code.strip()
        fixed = original

        # Pattern: db.execute(f"SELECT ... WHERE id = {var}")
        f_string_match = re.search(
            r'(\.execute\s*\(\s*)f["\'](.+?)\{(\w+)\}(.+?)["\'](\s*\))',
            code, re.DOTALL,
        )
        if f_string_match:
            prefix = f_string_match.group(1)
            sql_before = f_string_match.group(2)
            param = f_string_match.group(3)
            sql_after = f_string_match.group(4)
            suffix = f_string_match.group(5)
            fixed = f'{prefix}"{sql_before}?{sql_after}", ({param},){suffix}'

        # Pattern: cursor.execute("SELECT ... %s" % var)
        format_match = re.search(
            r'(\.execute\s*\(\s*["\'].+?)%s(.+?["\'])\s*%\s*(\w+)',
            code, re.DOTALL,
        )
        if format_match and fixed == original:
            sql_part = f'{format_match.group(1)}?{format_match.group(2)}'
            param = format_match.group(3)
            fixed = f'{sql_part}, ({param},))'

        # Pattern: .execute("SELECT ... " + var)
        concat_match = re.search(
            r'(\.execute\s*\(\s*["\'].+?["\'])\s*\+\s*(\w+)',
            code, re.DOTALL,
        )
        if concat_match and fixed == original:
            sql_part = concat_match.group(1)
            param = concat_match.group(2)
            fixed = f'{sql_part.rstrip()}, ({param},))'
            # Replace the concatenation point with a placeholder
            fixed = re.sub(r'["\']$', ' = ?", ', fixed.rsplit('"', 1)[0] if '"' in fixed else fixed.rsplit("'", 1)[0])
            fixed = f'{fixed}({param},))'

        if fixed == original:
            # Couldn't auto-fix, provide guidance
            fixed = f"# FIXED: Use parameterized query\n# {original}\n# Example: db.execute('SELECT * FROM table WHERE id = ?', (param,))"

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Use parameterized queries instead of string interpolation. "
                "This prevents SQL injection by separating SQL logic from data. "
                "Example: db.execute('SELECT * FROM users WHERE id = ?', (user_id,))"
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _fix_xss(self, code: str, file_path: str) -> dict:
        """Generate fix for XSS."""
        original = code.strip()
        fixed = original

        # Pattern: render_template_string(user_input)
        if "render_template_string" in code:
            var_match = re.search(r'render_template_string\s*\(\s*(\w+)', code)
            if var_match:
                var = var_match.group(1)
                fixed = code.replace(
                    f"render_template_string({var})",
                    f"render_template_string(escape({var}))"
                )
                fixed = f"from markupsafe import escape\n{fixed}"

        # Pattern: Markup(user_input)
        elif "Markup(" in code:
            var_match = re.search(r'Markup\s*\(\s*(\w+)\s*\)', code)
            if var_match:
                var = var_match.group(1)
                fixed = code.replace(
                    f"Markup({var})",
                    f"Markup(escape({var}))"
                )

        # Pattern: | safe in Jinja
        elif "| safe" in code or "|safe" in code:
            fixed = code.replace("| safe", "| e").replace("|safe", "|e")

        # Pattern: mark_safe(user_input)
        elif "mark_safe" in code:
            fixed = code.replace("mark_safe", "conditional_escape")

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Enable auto-escaping in templates and avoid marking user input as safe. "
                "Use the escape() function for any user-controlled content rendered in HTML."
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _fix_cmdi(self, code: str, file_path: str) -> dict:
        """Generate fix for command injection."""
        original = code.strip()
        fixed = original

        # Pattern: os.system(f"command {var}")
        if "os.system" in code:
            match = re.search(r'os\.system\s*\(\s*(?:f["\']|["\'].*?\+)', code)
            if match:
                # Extract the command parts
                cmd_match = re.search(r'os\.system\s*\(\s*f?["\'](\w+)\s+', code)
                if cmd_match:
                    cmd = cmd_match.group(1)
                    fixed = f'import subprocess\nsubprocess.run(["{cmd}", user_input], check=True, capture_output=True)'

        # Pattern: os.popen(user_input)
        elif "os.popen" in code:
            fixed = code.replace("os.popen", "subprocess.run")
            fixed = f"import subprocess\n# {original}\n{fixed}"

        # Pattern: subprocess.call(f"cmd {var}", shell=True)
        elif "shell=True" in code:
            fixed = code.replace("shell=True", "shell=False")
            # Try to convert string command to list
            fixed = re.sub(
                r'subprocess\.\w+\s*\(\s*f?["\'](.+?)\s+\{(\w+)\}["\']',
                r'subprocess.run(["\1", \2]',
                fixed,
            )

        if fixed == original:
            fixed = (
                f"import subprocess\n"
                f"# FIXED: Use subprocess with list arguments\n"
                f"# {original}\n"
                f"subprocess.run(['command', arg1, arg2], check=True, capture_output=True)"
            )

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Use subprocess.run() with a list of arguments instead of shell commands. "
                "Never use shell=True with user-controlled input. "
                "Avoid os.system() and os.popen() entirely."
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _fix_secret(self, code: str, file_path: str) -> dict:
        """Generate fix for hardcoded secrets."""
        original = code.strip()

        # Extract the variable name and value
        match = re.search(r'(\w+)\s*[:=]\s*["\']([^"\']+)["\']', code)
        if match:
            var_name = match.group(1)
            env_var = var_name.upper()
            fixed = f'{var_name} = os.environ.get("{env_var}")'
            if "import os" not in code:
                fixed = f"import os\n{fixed}"
        else:
            fixed = f"import os\n# {original}\n# Move secret to environment variable"

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Move secrets to environment variables or a secrets manager. "
                "Use os.environ.get('SECRET_NAME') to read them at runtime. "
                "Add the variable name to your .env.example file without the actual value."
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _fix_path_traversal(self, code: str, file_path: str) -> dict:
        """Generate fix for path traversal."""
        original = code.strip()
        fixed = f"""import os

# Validate path is within allowed directory
ALLOWED_DIR = os.path.abspath("/path/to/allowed/directory")
requested_path = os.path.abspath(os.path.join(ALLOWED_DIR, user_input))

if not requested_path.startswith(ALLOWED_DIR):
    raise ValueError("Path traversal detected")

# {original}
# Now safe to use requested_path"""

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Validate file paths using os.path.abspath() and verify the resolved path "
                "starts with the expected base directory. Reject any path that escapes the allowed directory."
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _fix_deserialization(self, code: str, file_path: str) -> dict:
        """Generate fix for insecure deserialization."""
        original = code.strip()

        if "pickle" in code:
            fixed = original.replace("pickle.loads", "json.loads").replace("pickle.load", "json.load")
            fixed = fixed.replace("import pickle", "import json")
        elif "yaml.load" in code:
            fixed = original.replace("yaml.load(", "yaml.safe_load(")
        elif "yaml.unsafe_load" in code:
            fixed = original.replace("yaml.unsafe_load(", "yaml.safe_load(")
        else:
            fixed = f"# FIXED: Use safe deserialization\n# {original}\nimport json\ndata = json.loads(input_data)"

        return {
            "original_code": original,
            "fixed_code": fixed,
            "remediation_text": (
                "Never deserialize untrusted data with pickle, marshal, or yaml.load(). "
                "Use json.loads() for data interchange or yaml.safe_load() for YAML."
            ),
            "diff": self._generate_diff(original, fixed),
        }

    def _generic_fix(self, vuln_type: str, code: str) -> dict:
        """Generate a generic fix suggestion."""
        return {
            "original_code": code.strip(),
            "fixed_code": f"# Action Required: Remediate {vuln_type} vulnerability\n# {code.strip()}",
            "remediation_text": f"Review and fix the identified {vuln_type} vulnerability. Consult OWASP guidelines for remediation.",
            "diff": "",
        }

    def _generate_diff(self, original: str, fixed: str) -> str:
        """Generate a unified diff between original and fixed code."""
        orig_lines = original.splitlines(keepends=True)
        fixed_lines = fixed.splitlines(keepends=True)

        diff = difflib.unified_diff(
            orig_lines,
            fixed_lines,
            fromfile="before",
            tofile="after",
            lineterm="",
        )
        return "".join(diff)
