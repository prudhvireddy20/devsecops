"""Fix templates package."""
