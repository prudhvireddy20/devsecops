"""Command injection fix templates."""

CMDI_FIX_TEMPLATES = {
    "subprocess_list": {
        "description": "Replace shell commands with subprocess using list arguments",
        "patterns": [
            {
                "match": r'os\.system\s*\(\s*(?:f["\']|["\'].*?\+)',
                "replace": "subprocess.run([cmd, arg1, arg2], check=True, capture_output=True)",
                "import": "import subprocess",
            },
            {
                "match": r'os\.popen\s*\(',
                "replace": "subprocess.run(cmd_list, capture_output=True, text=True)",
                "import": "import subprocess",
            },
            {
                "match": r'subprocess\.\w+\s*\(.*shell\s*=\s*True',
                "replace": "subprocess.run(cmd_list, shell=False, check=True)",
                "note": "Never use shell=True with user-controlled input",
            },
        ],
        "notes": [
            "Always use subprocess.run() with a list of arguments",
            "Set shell=False (default) to prevent shell interpretation",
            "Use shlex.quote() if shell=True is absolutely necessary",
            "Validate and whitelist allowed commands",
        ],
    },
    "input_validation": {
        "description": "Validate command arguments against whitelist",
        "example": """
import subprocess
import shlex

ALLOWED_COMMANDS = {'ls', 'cat', 'head', 'tail', 'wc'}

def safe_execute(command: str, args: list[str]):
    if command not in ALLOWED_COMMANDS:
        raise ValueError(f"Command not allowed: {command}")
    # Validate args don't contain shell metacharacters
    for arg in args:
        if any(c in arg for c in ';|&$`'):
            raise ValueError(f"Invalid character in argument: {arg}")
    return subprocess.run([command] + args, capture_output=True, text=True, check=True)
""",
    },
}
