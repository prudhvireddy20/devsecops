"""Secrets fix templates."""

SECRETS_FIX_TEMPLATES = {
    "environment_variable": {
        "description": "Move secrets to environment variables",
        "patterns": [
            {
                "match": r'(\w+)\s*=\s*["\']([^"\']{8,})["\']',
                "replace": '{var} = os.environ.get("{VAR}")',
                "import": "import os",
            },
        ],
        "examples": {
            "before": 'SECRET_KEY = "my-super-secret-key-12345"',
            "after": 'SECRET_KEY = os.environ.get("SECRET_KEY")',
            "env_file": 'SECRET_KEY=my-super-secret-key-12345',
        },
    },
    "dotenv": {
        "description": "Use python-dotenv for local development",
        "setup": """
# Install: pip install python-dotenv

# In your main.py or settings.py:
from dotenv import load_dotenv
import os

load_dotenv()  # Load .env file

SECRET_KEY = os.environ.get("SECRET_KEY")
DATABASE_URL = os.environ.get("DATABASE_URL")
API_KEY = os.environ.get("API_KEY")
""",
        "env_example": """
# .env.example (commit this, NOT .env)
SECRET_KEY=change-me-in-production
DATABASE_URL=sqlite:///dev.db
API_KEY=your-api-key-here
""",
    },
    "vault": {
        "description": "Use HashiCorp Vault or AWS Secrets Manager for production",
        "example": """
# Using AWS Secrets Manager
import boto3
import json

def get_secret(secret_name: str) -> dict:
    client = boto3.client('secretsmanager')
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

secrets = get_secret('my-app/production')
SECRET_KEY = secrets['SECRET_KEY']
""",
    },
    "gitignore": {
        "description": "Ensure .env files are in .gitignore",
        "entries": [
            ".env",
            ".env.local",
            ".env.production",
            "*.pem",
            "*.key",
            "credentials.json",
            "service-account.json",
        ],
    },
}
