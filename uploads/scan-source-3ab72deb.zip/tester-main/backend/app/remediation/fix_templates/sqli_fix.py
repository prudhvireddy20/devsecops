"""SQLi fix templates."""


SQLI_FIX_TEMPLATES = {
    "parameterized_query": {
        "description": "Replace string interpolation with parameterized queries",
        "patterns": [
            {
                "match": r'\.execute\s*\(\s*f["\'](.+?)\{(\w+)\}(.+?)["\']',
                "replace": r'.execute("\1?\3", (\2,))',
                "example_before": 'db.execute(f"DELETE FROM users WHERE id = {user_id}")',
                "example_after": 'db.execute("DELETE FROM users WHERE id = ?", (user_id,))',
            },
            {
                "match": r'\.execute\s*\(\s*["\'](.+?)%s(.+?)["\']\s*%\s*(\w+)',
                "replace": r'.execute("\1?\2", (\3,))',
                "example_before": 'cursor.execute("SELECT * FROM users WHERE name = %s" % name)',
                "example_after": 'cursor.execute("SELECT * FROM users WHERE name = ?", (name,))',
            },
            {
                "match": r'\.execute\s*\(\s*["\'](.+?)["\']\s*\+\s*(\w+)',
                "replace": r'.execute("\1 = ?", (\2,))',
                "example_before": 'db.execute("SELECT * FROM users WHERE id = " + user_id)',
                "example_after": 'db.execute("SELECT * FROM users WHERE id = ?", (user_id,))',
            },
        ],
        "notes": [
            "SQLAlchemy: Use text() with :param syntax: text('SELECT * FROM users WHERE id = :id').bindparams(id=user_id)",
            "Django ORM: Use .filter() methods instead of raw SQL",
            "For complex queries, consider using an ORM's query builder",
        ],
    },
    "orm_usage": {
        "description": "Replace raw SQL with ORM queries",
        "flask_sqlalchemy": {
            "before": 'db.execute(f"SELECT * FROM users WHERE id = {user_id}")',
            "after": "User.query.filter_by(id=user_id).first()",
        },
        "django": {
            "before": 'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")',
            "after": "User.objects.filter(id=user_id).first()",
        },
    },
}
