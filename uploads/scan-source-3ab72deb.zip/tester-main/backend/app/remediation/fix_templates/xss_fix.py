"""XSS fix templates."""

XSS_FIX_TEMPLATES = {
    "template_escaping": {
        "description": "Enable auto-escaping and sanitize output",
        "patterns": [
            {
                "match": r'render_template_string\s*\(\s*(\w+)',
                "replace": r'render_template_string(escape(\1))',
                "import": "from markupsafe import escape",
            },
            {
                "match": r'Markup\s*\(\s*(\w+)\s*\)',
                "replace": r'Markup(escape(\1))',
                "import": "from markupsafe import escape",
            },
            {
                "match": r'\|\s*safe\b',
                "replace": "| e",
                "note": "Replace | safe filter with | e (escape) filter in Jinja templates",
            },
            {
                "match": r'mark_safe\s*\(\s*(\w+)\s*\)',
                "replace": r'conditional_escape(\1)',
                "import": "from django.utils.html import conditional_escape",
            },
        ],
    },
    "content_security_policy": {
        "description": "Add Content-Security-Policy header",
        "flask": "response.headers['Content-Security-Policy'] = \"default-src 'self'\"",
        "django": "# In settings.py:\nCSP_DEFAULT_SRC = (\"'self'\",)",
        "fastapi": "response.headers['Content-Security-Policy'] = \"default-src 'self'\"",
    },
}
