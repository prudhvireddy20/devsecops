"""LLM-backed remediation and triage generator with safe fallback behavior."""

import logging

from app.llm.client import LLMClient
from app.llm.context_builder import build_remediation_context
from app.llm.prompts import REMEDIATION_SYSTEM_PROMPT, remediation_user_prompt
from app.llm.schemas import RemediationSuggestion

logger = logging.getLogger(__name__)


class LLMFixGenerator:
    """Generate triage + remediation suggestions from a language model."""

    def __init__(self, client: LLMClient):
        self.client = client

    async def generate(self, finding, project=None) -> dict | None:
        """Return remediation payload dict or None on unavailable client."""
        if not self.client.is_available():
            return None

        context = build_remediation_context(finding=finding, project=project)
        try:
            raw = await self.client.chat_json(
                REMEDIATION_SYSTEM_PROMPT,
                remediation_user_prompt(context),
            )
            suggestion = RemediationSuggestion.model_validate(raw)
            return suggestion.model_dump()
        except Exception as exc:
            logger.warning("LLM remediation generation failed: %s", exc)
            return None
