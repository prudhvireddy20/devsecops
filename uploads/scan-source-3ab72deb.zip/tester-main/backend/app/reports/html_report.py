"""HTML report generator using Jinja2 templates."""
import logging
from datetime import datetime, timezone
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

logger = logging.getLogger(__name__)

_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
_CONFIDENCE_ORDER = {"verified": 0, "probable": 1, "observed": 2}


def sort_findings(findings_data: list[dict]) -> list[dict]:
    """Sort findings: critical first, then by confidence. Shared by all report formats."""
    return sorted(
        findings_data,
        key=lambda f: (
            _SEVERITY_ORDER.get(f.get("severity", "info"), 4),
            _CONFIDENCE_ORDER.get(f.get("confidence", "observed"), 2),
        ),
    )


# Inline template for when template files aren't available.
# Screen media renders the dark console theme; print media (used by WeasyPrint
# for the PDF and by the browser's print dialog) switches to a light, paginated
# layout with page numbers.
INLINE_TEMPLATE = """<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Scan Report - {{ project.name }}</title>
    <style>
        :root {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --bg-card: #1e293b;
            --bg-code: #0d1117;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --border: #334155;
            --accent: #3b82f6;
            --critical: #ef4444;
            --high: #f97316;
            --medium: #eab308;
            --low: #22c55e;
            --info: #6366f1;
            --verified: #ef4444;
            --probable: #f97316;
            --observed: #3b82f6;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            padding: 2rem;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { font-size: 2rem; margin-bottom: 1rem; color: var(--accent); }
        h2 { font-size: 1.5rem; margin: 2rem 0 1rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem; }
        h3 { font-size: 1.2rem; margin: 1rem 0 0.5rem; }
        h4 { margin-top: 1rem; }

        /* Aligned key/value grids for scan meta and finding details */
        .kv {
            display: grid;
            grid-template-columns: 130px 1fr;
            row-gap: 0.3rem;
            column-gap: 0.75rem;
        }
        .kv .label { color: var(--text-secondary); }
        .kv .value { overflow-wrap: anywhere; }
        .meta { margin-bottom: 2rem; }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin: 1rem 0 2rem;
        }
        .summary-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
        }
        .summary-card .number { font-size: 2rem; font-weight: bold; font-variant-numeric: tabular-nums; }
        .summary-card .label { color: var(--text-secondary); font-size: 0.9rem; }
        .severity-critical .number { color: var(--critical); }
        .severity-high .number { color: var(--high); }
        .severity-medium .number { color: var(--medium); }
        .severity-low .number { color: var(--low); }
        .severity-info .number { color: var(--info); }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            background: var(--bg-card);
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;
        }
        th, td {
            padding: 0.6rem 0.9rem;
            text-align: left;
            vertical-align: top;
            border-bottom: 1px solid var(--border);
            overflow-wrap: anywhere;
        }
        th { background: var(--bg-secondary); font-weight: 600; overflow-wrap: normal; }
        tr:hover { background: rgba(59, 130, 246, 0.1); }

        .badge {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .badge-critical { background: rgba(239, 68, 68, 0.2); color: var(--critical); }
        .badge-high { background: rgba(249, 115, 22, 0.2); color: var(--high); }
        .badge-medium { background: rgba(234, 179, 8, 0.2); color: var(--medium); }
        .badge-low { background: rgba(34, 197, 94, 0.2); color: var(--low); }
        .badge-info { background: rgba(99, 102, 241, 0.2); color: var(--info); }
        .badge-verified { background: rgba(239, 68, 68, 0.2); color: var(--verified); }
        .badge-probable { background: rgba(249, 115, 22, 0.2); color: var(--probable); }
        .badge-observed { background: rgba(59, 130, 246, 0.2); color: var(--observed); }

        .finding-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.5rem;
            margin: 1rem 0;
        }
        .finding-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        .finding-header h3 { margin: 0; flex: 1; }
        .finding-header .badges { display: flex; gap: 0.4rem; flex-shrink: 0; }

        pre, code {
            background: var(--bg-code);
            border: 1px solid var(--border);
            border-radius: 4px;
            font-family: 'Fira Code', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
            font-size: 0.85rem;
        }
        pre {
            padding: 0.75rem;
            white-space: pre-wrap;
            word-break: break-word;
            margin: 0.5rem 0;
        }
        code { padding: 0.1rem 0.3rem; overflow-wrap: anywhere; }
        .data-flow { color: var(--accent); font-style: italic; }

        .footer {
            text-align: center;
            color: var(--text-secondary);
            margin-top: 3rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border);
            font-size: 0.85rem;
        }

        /* ---- Print / PDF: light paginated layout ------------------------ */
        @page {
            size: A4;
            margin: 16mm 14mm 18mm;
            @bottom-left {
                content: "TraceON Security Report";
                font-size: 8pt;
                color: #59636e;
            }
            @bottom-right {
                content: "Page " counter(page) " of " counter(pages);
                font-size: 8pt;
                color: #59636e;
            }
        }
        @media print {
            :root {
                --bg-primary: #ffffff;
                --bg-secondary: #f6f8fa;
                --bg-card: #ffffff;
                --bg-code: #f6f8fa;
                --text-primary: #1f2328;
                --text-secondary: #59636e;
                --border: #d0d7de;
                --accent: #0969da;
                --critical: #cf222e;
                --high: #bc4c00;
                --medium: #9a6700;
                --low: #1a7f37;
                --info: #0969da;
                --verified: #cf222e;
                --probable: #bc4c00;
                --observed: #0969da;
            }
            body { padding: 0; font-size: 10pt; }
            .container { max-width: none; }
            h1 { font-size: 20pt; }
            h2 { font-size: 14pt; break-after: avoid; }
            h3 { font-size: 11pt; }
            h4 { break-after: avoid; }
            /* Flex fallback: WeasyPrint's grid support is weaker than its flex support */
            .summary-grid { display: flex; flex-wrap: wrap; gap: 0.5rem; }
            .summary-card { flex: 1 1 0; padding: 0.75rem 0.5rem; }
            .summary-card .number { font-size: 1.4rem; }
            .badge { background: transparent !important; border: 1px solid currentColor; font-size: 7pt; padding: 0.1rem 0.3rem; }
            table { font-size: 8.5pt; }
            th, td { padding: 0.4rem 0.5rem; }
            thead { display: table-header-group; }
            tr { break-inside: avoid; }
            .finding-card { break-inside: avoid; }
            pre, code { font-size: 8pt; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Security Scan Report</h1>
        <div class="kv meta">
            <span class="label">Project</span><span class="value"><strong>{{ project.name }}</strong></span>
            {% if project.target_url %}<span class="label">Target</span><span class="value">{{ project.target_url }}</span>{% endif %}
            <span class="label">Scan ID</span><span class="value">{{ scan.id }}</span>
            {% if scan.scan_type %}<span class="label">Scan Type</span><span class="value">{{ scan.scan_type }}</span>{% endif %}
            <span class="label">Status</span><span class="value">{{ scan.status }}</span>
            <span class="label">Generated</span><span class="value">{{ generated_at }}</span>
        </div>

        <h2>Summary</h2>
        <div class="summary-grid">
            <div class="summary-card">
                <div class="number">{{ findings|length }}</div>
                <div class="label">Total Findings</div>
            </div>
            <div class="summary-card severity-critical">
                <div class="number">{{ findings|selectattr('severity', 'equalto', 'critical')|list|length }}</div>
                <div class="label">Critical</div>
            </div>
            <div class="summary-card severity-high">
                <div class="number">{{ findings|selectattr('severity', 'equalto', 'high')|list|length }}</div>
                <div class="label">High</div>
            </div>
            <div class="summary-card severity-medium">
                <div class="number">{{ findings|selectattr('severity', 'equalto', 'medium')|list|length }}</div>
                <div class="label">Medium</div>
            </div>
            <div class="summary-card severity-low">
                <div class="number">{{ findings|selectattr('severity', 'equalto', 'low')|list|length }}</div>
                <div class="label">Low</div>
            </div>
        </div>

        <div class="summary-grid">
            <div class="summary-card">
                <div class="number" style="color: var(--verified);">{{ findings|selectattr('confidence', 'equalto', 'verified')|list|length }}</div>
                <div class="label">Verified</div>
            </div>
            <div class="summary-card">
                <div class="number" style="color: var(--probable);">{{ findings|selectattr('confidence', 'equalto', 'probable')|list|length }}</div>
                <div class="label">Probable</div>
            </div>
            <div class="summary-card">
                <div class="number" style="color: var(--observed);">{{ findings|selectattr('confidence', 'equalto', 'observed')|list|length }}</div>
                <div class="label">Observed</div>
            </div>
            <div class="summary-card">
                <div class="number">{{ scan.routes_discovered or 0 }}</div>
                <div class="label">Routes Discovered</div>
            </div>
        </div>

        <h2>Findings Overview</h2>
        <table>
            <colgroup>
                <col style="width: 4%">
                <col style="width: 24%">
                <col style="width: 11%">
                <col style="width: 12%">
                <col style="width: 9%">
                <col style="width: 20%">
                <col style="width: 20%">
            </colgroup>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Severity</th>
                    <th>Confidence</th>
                    <th>CWE</th>
                    <th>Endpoint</th>
                    <th>File</th>
                </tr>
            </thead>
            <tbody>
                {% for finding in findings %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td>{{ finding.title }}</td>
                    <td><span class="badge badge-{{ finding.severity }}">{{ finding.severity }}</span></td>
                    <td><span class="badge badge-{{ finding.confidence }}">{{ finding.confidence }}</span></td>
                    <td style="overflow-wrap: normal;">{{ finding.cwe or '-' }}</td>
                    <td>{{ finding.endpoint or '-' }}</td>
                    <td>{{ finding.file_path or '-' }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>

        <h2>Detailed Findings</h2>
        {% for finding in findings %}
        <div class="finding-card" id="finding-{{ loop.index }}">
            <div class="finding-header">
                <h3>{{ loop.index }}. {{ finding.title }}</h3>
                <div class="badges">
                    <span class="badge badge-{{ finding.severity }}">{{ finding.severity }}</span>
                    <span class="badge badge-{{ finding.confidence }}">{{ finding.confidence }}</span>
                </div>
            </div>

            <div class="kv">
                {% if finding.cwe %}<span class="label">CWE</span><span class="value">{{ finding.cwe }}</span>{% endif %}
                {% if finding.endpoint %}<span class="label">Endpoint</span><span class="value">{{ finding.http_method }} {{ finding.endpoint }}</span>{% endif %}
                {% if finding.parameter %}<span class="label">Parameter</span><span class="value">{{ finding.parameter }}</span>{% endif %}
                {% if finding.file_path %}<span class="label">File</span><span class="value">{{ finding.file_path }}{% if finding.line_number %}:{{ finding.line_number }}{% endif %}</span>{% endif %}
                {% if finding.scanner_source %}<span class="label">Scanner</span><span class="value">{{ finding.scanner_source }}</span>{% endif %}
                {% if finding.data_flow %}<span class="label">Data Flow</span><span class="value data-flow">{{ finding.data_flow }}</span>{% endif %}
            </div>

            {% if finding.code_snippet %}
            <h4>Source Code</h4>
            <pre>{{ finding.code_snippet }}</pre>
            {% endif %}

            {% if finding.payload %}
            <h4>Dynamic Proof</h4>
            <div class="kv">
                <span class="label">Payload</span><span class="value"><code>{{ finding.payload }}</code></span>
                {% if finding.response_evidence %}
                <span class="label">Evidence</span><span class="value">{{ finding.response_evidence }}</span>
                {% endif %}
            </div>
            {% endif %}

            {% if finding.remediation_text %}
            <h4>Remediation</h4>
            <p>{{ finding.remediation_text }}</p>
            {% endif %}
        </div>
        {% endfor %}

        <div class="footer">
            <p>Generated by TraceON | {{ generated_at }}</p>
        </div>
    </div>
</body>
</html>"""


class HTMLReportGenerator:
    """Generates HTML security scan reports."""

    async def generate(
        self,
        scan_data: dict,
        project_data: dict,
        findings_data: list[dict],
        output_dir: Path,
    ) -> Path:
        """Generate an HTML report.

        Returns:
            Path to the generated HTML file.
        """
        sorted_findings = sort_findings(findings_data)

        # Try to load from template file first, fall back to inline
        try:
            templates_dir = Path(__file__).parent / "templates"
            if (templates_dir / "report.html").exists():
                env = Environment(
                    loader=FileSystemLoader(str(templates_dir)),
                    autoescape=select_autoescape(["html"]),
                )
                template = env.get_template("report.html")
            else:
                env = Environment(autoescape=select_autoescape(["html"]))
                template = env.from_string(INLINE_TEMPLATE)
        except Exception:
            env = Environment(autoescape=select_autoescape(["html"]))
            template = env.from_string(INLINE_TEMPLATE)

        html_content = template.render(
            scan=scan_data,
            project=project_data,
            findings=sorted_findings,
            generated_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        )

        output_path = output_dir / "report.html"
        output_path.write_text(html_content, encoding="utf-8")
        logger.info(f"HTML report generated: {output_path}")

        return output_path
