"""PDF report generator using WeasyPrint."""
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class PDFReportGenerator:
    """Generates PDF security scan reports from HTML."""

    async def generate(
        self,
        scan_data: dict,
        project_data: dict,
        findings_data: list[dict],
        output_dir: Path,
    ) -> Path:
        """Generate a PDF report.

        First generates HTML, then converts to PDF using WeasyPrint.

        Returns:
            Path to the generated PDF file.
        """
        from app.reports.html_report import HTMLReportGenerator

        # Generate HTML first
        html_gen = HTMLReportGenerator()
        html_path = await html_gen.generate(
            scan_data, project_data, findings_data, output_dir
        )

        output_path = output_dir / "report.pdf"

        try:
            from weasyprint import HTML

            HTML(filename=str(html_path)).write_pdf(str(output_path))
            logger.info(f"PDF report generated: {output_path}")
        except ImportError:
            logger.warning(
                "WeasyPrint not installed. Install with: pip install weasyprint. "
                "Falling back to HTML-only report."
            )
            # Copy HTML as fallback
            output_path = html_path
        except Exception as e:
            logger.error(f"PDF generation failed: {e}")
            output_path = html_path

        return output_path
