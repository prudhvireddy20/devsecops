"""SARIF export - generates SARIF 2.1.0 formatted output."""
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# CWE to taxonomy mapping
CWE_TAXONOMY = {
    "CWE-89": "SQL Injection",
    "CWE-79": "Cross-site Scripting (XSS)",
    "CWE-78": "OS Command Injection",
    "CWE-22": "Path Traversal",
    "CWE-918": "Server-Side Request Forgery (SSRF)",
    "CWE-502": "Deserialization of Untrusted Data",
    "CWE-798": "Use of Hard-coded Credentials",
    "CWE-327": "Use of a Broken or Risky Cryptographic Algorithm",
    "CWE-611": "XML External Entity (XXE)",
    "CWE-352": "Cross-Site Request Forgery (CSRF)",
    "CWE-601": "Open Redirect",
    "CWE-200": "Information Exposure",
}


class SARIFExporter:
    """Exports scan findings in SARIF 2.1.0 format for CI/CD integration."""

    async def export(
        self,
        scan_data: dict,
        project_data: dict,
        findings_data: list[dict],
        output_dir: Path,
    ) -> Path:
        """Export findings as SARIF 2.1.0 JSON.

        Returns:
            Path to the generated SARIF file.
        """
        from app.reports.html_report import sort_findings
        findings_data = sort_findings(findings_data)

        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "TraceON",
                            "version": "1.0.0",
                            "informationUri": "https://github.com/traceon",
                            "rules": self._build_rules(findings_data),
                        },
                    },
                    "results": self._build_results(findings_data),
                    "invocations": [
                        {
                            "executionSuccessful": scan_data.get("status") == "completed",
                            "startTimeUtc": scan_data.get("started_at", ""),
                            "endTimeUtc": scan_data.get("completed_at", ""),
                        }
                    ],
                    "artifacts": self._build_artifacts(findings_data),
                }
            ],
        }

        output_path = output_dir / "report.sarif"
        with open(output_path, "w") as f:
            json.dump(sarif, f, indent=2, default=str)

        logger.info(f"SARIF report generated: {output_path}")
        return output_path

    def _build_rules(self, findings: list[dict]) -> list[dict]:
        """Build SARIF rule definitions from findings."""
        rules = {}
        for finding in findings:
            rule_id = finding.get("scanner_rule_id") or finding.get("vulnerability_type", "unknown")
            if rule_id in rules:
                continue

            cwe = finding.get("cwe", "")

            rules[rule_id] = {
                "id": rule_id,
                "name": finding.get("vulnerability_type", "unknown"),
                "shortDescription": {
                    "text": finding.get("title", "Security Finding"),
                },
                "fullDescription": {
                    "text": finding.get("remediation_text", "Review the identified security issue."),
                },
                "defaultConfiguration": {
                    "level": self._severity_to_sarif_level(finding.get("severity", "medium")),
                },
                "properties": {
                    "tags": [finding.get("vulnerability_type", "security")],
                    "precision": self._confidence_to_precision(finding.get("confidence", "observed")),
                },
            }

            if cwe:
                rules[rule_id]["relationships"] = [
                    {
                        "target": {
                            "id": cwe,
                            "toolComponent": {"name": "CWE"},
                        },
                        "kinds": ["superset"],
                    }
                ]

        return list(rules.values())

    def _build_results(self, findings: list[dict]) -> list[dict]:
        """Build SARIF results from findings."""
        results = []
        for finding in findings:
            result = {
                "ruleId": finding.get("scanner_rule_id") or finding.get("vulnerability_type", "unknown"),
                "level": self._severity_to_sarif_level(finding.get("severity", "medium")),
                "message": {
                    "text": self._build_message(finding),
                },
                "locations": [],
                "properties": {
                    "confidence": finding.get("confidence", "observed"),
                    "scanner_source": finding.get("scanner_source", ""),
                },
            }

            # Add file location if available
            if finding.get("file_path"):
                location = {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding["file_path"],
                        },
                    },
                }
                if finding.get("line_number"):
                    location["physicalLocation"]["region"] = {
                        "startLine": finding["line_number"],
                    }
                    if finding.get("code_snippet"):
                        location["physicalLocation"]["region"]["snippet"] = {
                            "text": finding["code_snippet"],
                        }
                result["locations"].append(location)

            # Add web endpoint location if available
            if finding.get("endpoint"):
                result["locations"].append({
                    "logicalLocations": [
                        {
                            "fullyQualifiedName": f"{finding.get('http_method', 'GET')} {finding['endpoint']}",
                            "kind": "endpoint",
                        }
                    ],
                })

            # Add fix info
            if finding.get("remediation_text"):
                result["fixes"] = [
                    {
                        "description": {
                            "text": finding["remediation_text"],
                        },
                    }
                ]

            # Add code flow / data flow
            if finding.get("data_flow"):
                result["codeFlows"] = [
                    {
                        "message": {"text": finding["data_flow"]},
                        "threadFlows": [
                            {
                                "locations": [
                                    {
                                        "location": {
                                            "message": {"text": finding["data_flow"]},
                                        },
                                    }
                                ],
                            }
                        ],
                    }
                ]

            results.append(result)

        return results

    def _build_artifacts(self, findings: list[dict]) -> list[dict]:
        """Build SARIF artifact list from findings."""
        files = set()
        for finding in findings:
            if finding.get("file_path"):
                files.add(finding["file_path"])

        return [
            {"location": {"uri": f}, "roles": ["analysisTarget"]}
            for f in sorted(files)
        ]

    def _build_message(self, finding: dict) -> str:
        """Build a descriptive message for a SARIF result."""
        parts = [finding.get("title", "Security Finding")]

        if finding.get("confidence"):
            parts.append(f"[{finding['confidence'].upper()}]")

        if finding.get("endpoint"):
            parts.append(f"at {finding.get('http_method', '')} {finding['endpoint']}")

        if finding.get("parameter"):
            parts.append(f"parameter: {finding['parameter']}")

        if finding.get("cwe"):
            parts.append(f"({finding['cwe']})")

        return " ".join(parts)

    def _severity_to_sarif_level(self, severity: str) -> str:
        """Map severity to SARIF level."""
        mapping = {
            "critical": "error",
            "high": "error",
            "medium": "warning",
            "low": "note",
            "info": "note",
        }
        return mapping.get(severity, "warning")

    def _confidence_to_precision(self, confidence: str) -> str:
        """Map confidence to SARIF precision."""
        mapping = {
            "verified": "very-high",
            "probable": "high",
            "observed": "medium",
        }
        return mapping.get(confidence, "medium")
