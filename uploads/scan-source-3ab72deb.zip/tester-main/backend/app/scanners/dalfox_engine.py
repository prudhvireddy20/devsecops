"""XSS scanner via dalfox.

dalfox is a dedicated XSS detection tool that's faster and more accurate
than ZAP's XSS rules, especially for reflected and DOM-based XSS.
Outputs JSON findings.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)


class DalfoxEngine:
    """Detect cross-site scripting using dalfox."""

    def __init__(self, timeout: int = 300):
        self.timeout = timeout

    async def scan(self, target_url: str) -> list[dict]:
        """Run dalfox and return XSS findings."""
        if not shutil.which("dalfox"):
            logger.warning("dalfox not found on PATH — skipping XSS scan")
            return []

        _fd, tmpfile = tempfile.mkstemp(suffix=".json", prefix="dalfox_")
        os.close(_fd)

        cmd = [
            "dalfox",
            "url", target_url,
            "--format", "json",
            "--output", tmpfile,
            "--skip-bav",
            "--no-color",
            "--silence",
        ]
        findings: list[dict] = []
        try:
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                try:
                    await asyncio.wait_for(proc.wait(), timeout=self.timeout)
                except asyncio.TimeoutError:
                    proc.kill()
                    await proc.wait()
                    logger.warning("dalfox timed out after %ds", self.timeout)
                    return []
            except Exception as e:
                logger.warning("dalfox error: %s", e)
                return []

            try:
                if not os.path.exists(tmpfile):
                    return findings
                raw_text = Path(tmpfile).read_text(errors="replace").strip()
                if not raw_text:
                    return findings
                data = json.loads(raw_text)
                for item in data if isinstance(data, list) else [data]:
                    param = item.get("param", "")
                    poc = item.get("poc", "")
                    xss_type = item.get("type", "R")
                    type_label = {"R": "Reflected", "S": "Stored", "D": "DOM"}.get(xss_type, "XSS")
                    findings.append({
                        "title": f"[dalfox] {type_label} XSS — {param or 'unknown param'}",
                        "description": f"{type_label} cross-site scripting via parameter '{param}'",
                        "vulnerability_type": "xss",
                        "severity": "high",
                        "cwe": "79",
                        "file_path": "",
                        "line_number": 0,
                        "code_snippet": poc,
                        "endpoint": item.get("data", target_url),
                        "parameter": param,
                        "rule_id": f"dalfox-xss-{xss_type.lower()}",
                        "remediation": "Encode all user-controlled output. Use Content-Security-Policy.",
                        "source": "dalfox",
                        "raw": item,
                    })
            except (json.JSONDecodeError, ValueError, OSError) as e:
                logger.warning("dalfox result parse error: %s", e)
        finally:
            try:
                os.unlink(tmpfile)
            except OSError:
                pass

        if findings:
            logger.info("dalfox found %d XSS vulnerability(s)", len(findings))
        return findings
