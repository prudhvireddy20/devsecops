"""OWASP ZAP DAST engine - runs dynamic analysis using ZAP API."""
import asyncio
import json
import logging
import time
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx

from app.core.url_safety import validate_external_target_url
from app.utils.normalizers import normalize_endpoint_value

logger = logging.getLogger(__name__)

# ZAP alert to vulnerability type mapping
ZAP_ALERT_MAP = {
    "40018": {"type": "sqli", "cwe": "CWE-89"},
    "40019": {"type": "sqli", "cwe": "CWE-89"},
    "40020": {"type": "sqli", "cwe": "CWE-89"},
    "40021": {"type": "sqli", "cwe": "CWE-89"},
    "40022": {"type": "sqli", "cwe": "CWE-89"},
    "40012": {"type": "xss", "cwe": "CWE-79"},
    "40014": {"type": "xss", "cwe": "CWE-79"},
    "40016": {"type": "xss", "cwe": "CWE-79"},
    "40017": {"type": "xss", "cwe": "CWE-79"},
    "90019": {"type": "cmdi", "cwe": "CWE-78"},
    "90020": {"type": "cmdi", "cwe": "CWE-78"},
    "6": {"type": "path_traversal", "cwe": "CWE-22"},
    "40003": {"type": "path_traversal", "cwe": "CWE-22"},
    "40032": {"type": "path_traversal", "cwe": "CWE-22"},
    "40034": {"type": "ssrf", "cwe": "CWE-918"},
    "10010": {"type": "cookie", "cwe": "CWE-614"},
    "10011": {"type": "cookie", "cwe": "CWE-1004"},
    "10015": {"type": "config", "cwe": "CWE-525"},
    "10017": {"type": "csrf", "cwe": "CWE-352"},
    "10020": {"type": "header", "cwe": "CWE-693"},
    "10021": {"type": "header", "cwe": "CWE-693"},
    "10035": {"type": "header", "cwe": "CWE-693"},
    "10036": {"type": "header", "cwe": "CWE-497"},
    "10038": {"type": "header", "cwe": "CWE-693"},
    "10096": {"type": "timestamp", "cwe": "CWE-200"},
    "10202": {"type": "absence", "cwe": "CWE-693"},
}

# Conservative compatibility map for alerts that frequently come through as
# unknown. These mappings are intentionally low/medium trust and are not
# automatically sufficient for "verified" correlation.
ZAP_COMPATIBILITY_MAP = {
    "10098": {"type": "config", "cwe": "CWE-942", "tier": "medium"},  # Cross-Domain Misconfiguration
    "90022": {"type": "info_disclosure", "cwe": "CWE-209", "tier": "low"},  # Application Error Disclosure
    "10024": {"type": "info_disclosure", "cwe": "CWE-200", "tier": "low"},  # Sensitive Information in URL
    "10023": {"type": "info_disclosure", "cwe": "CWE-209", "tier": "medium"},  # Debug Error Messages
    "10027": {"type": "info_disclosure", "cwe": "CWE-615", "tier": "low"},  # Suspicious Comments
    "10104": {"type": "info_disclosure", "cwe": "CWE-200", "tier": "low"},  # User Agent Fuzzer
    "10109": {"type": "config", "cwe": "CWE-16", "tier": "low"},  # Modern Web Application
    "10111": {"type": "auth", "cwe": "CWE-287", "tier": "low"},  # Authentication Request Identified
}


class DASTEngine:
    """Integrates with OWASP ZAP for dynamic application security testing."""

    STATIC_EXTENSIONS = {
        ".js", ".css", ".map", ".png", ".jpg", ".jpeg", ".gif", ".svg",
        ".ico", ".woff", ".woff2", ".ttf", ".eot", ".webp", ".mp4", ".mp3",
        ".wav", ".pdf", ".txt",
    }
    STATIC_PATH_PREFIXES = (
        "/assets/",
        "/static/",
        "/public/",
        "/_next/",
    )

    def __init__(self):
        from app.core.config import settings
        self.zap_url = settings.ZAP_API_URL
        self.api_key = settings.ZAP_API_KEY
        self._zap = None

    @staticmethod
    def _validate_target_url(target_url: str) -> None:
        ok, err = validate_external_target_url(target_url)
        if not ok:
            raise ValueError(f"Unsafe target URL: {err}")

    def _get_zap(self):
        """Get or create ZAP API client."""
        if self._zap is None:
            try:
                from zapv2 import ZAPv2
                self._zap = ZAPv2(
                    apikey=self.api_key,
                    proxies={
                        "http": self.zap_url,
                        "https": self.zap_url,
                    },
                )
            except ImportError:
                logger.warning("python-owasp-zap-v2.4 not installed")
                raise
            except Exception as e:
                logger.error(f"Failed to connect to ZAP: {e}")
                raise
        return self._zap

    async def _wait_for_zap_ready(self, zap, timeout: int = 60) -> None:
        """Wait for ZAP API readiness before issuing scan commands."""
        started = time.time()
        last_error = ""
        while time.time() - started < timeout:
            try:
                zap.core.version
                return
            except Exception as exc:
                last_error = str(exc)
                await asyncio.sleep(2)
        raise ConnectionError(f"ZAP is not ready after {timeout}s: {last_error}")

    async def _check_zap_alive(self, zap) -> bool:
        """Fast ZAP liveness probe.  Returns False if ZAP is unreachable.

        A False return strongly suggests the ZAP container has OOM'd or
        been restarted — the caller should fail fast rather than waiting
        for a long timeout.
        """
        try:
            zap.core.version
            return True
        except Exception:
            return False

    @staticmethod
    def _is_transient_zap_error(exc: Exception) -> bool:
        """Return True if exception looks like a transient ZAP connectivity issue."""
        message = str(exc).lower()
        transient_markers = (
            "connection refused",
            "max retries exceeded",
            "proxyerror",
            "failed to establish a new connection",
            "temporarily unavailable",
            "connection reset",
            "read timed out",
        )
        return any(marker in message for marker in transient_markers)

    async def _start_active_scan_with_retry(self, zap, target_url: str, inscope_only: bool) -> str:
        """Start active scan with retry on transient proxy/network errors."""
        retries = 3

        # When inscope_only is requested, create a ZAP context restricted to the target domain.
        # Without a context, ZAP's inscopeonly parameter is silently ignored.
        context_id = None
        if inscope_only:
            import re as _re
            from urllib.parse import urlparse as _urlparse
            parsed = _urlparse(target_url)
            domain_pattern = _re.escape(f"{parsed.scheme}://{parsed.netloc}") + ".*"
            ctx_name = "traceon_inscope"
            try:
                context_id = zap.context.new_context(ctx_name)
                zap.context.include_in_context(ctx_name, domain_pattern)
                logger.info("ZAP context created for in-scope scan (pattern: %s)", domain_pattern)
            except Exception as e:
                logger.warning("Failed to create ZAP context for inscope_only: %s", e)
                context_id = None

        # Build list of URL variants to try (with/without trailing slash)
        url_variants = [target_url]
        if target_url.endswith("/"):
            url_variants.append(target_url.rstrip("/"))
        else:
            url_variants.append(target_url + "/")

        for attempt in range(1, retries + 1):
            for url_variant in url_variants:
                try:
                    # Critical fix: Must pass scanpolicyname or ZAP uses internal defaults
                    # which may have weak/disabled settings and ignore our attack_strength settings
                    scan_id = zap.ascan.scan(
                        url_variant,
                        recurse="true",
                        inscopeonly="true" if inscope_only else "false",
                        scanpolicyname="Default Policy",  # ← Explicit policy ensures attack_strength applies
                        contextid=str(context_id) if context_id is not None else None,
                    )
                    # Validate scan_id is numeric (ZAP returns numeric string)
                    if isinstance(scan_id, str) and scan_id.lstrip("-").isdigit():
                        if url_variant != target_url:
                            logger.info(
                                "Active scan started with URL variant: %s (original: %s)",
                                url_variant,
                                target_url,
                            )
                        return scan_id
                    # Non-numeric means error message from ZAP
                    error_msg = str(scan_id).lower()
                    if "url_not_found" in error_msg or "not found" in error_msg:
                        logger.warning(
                            "ZAP url_not_found for '%s' (attempt %s/%s), trying next variant",
                            url_variant,
                            attempt,
                            retries,
                        )
                        continue  # try next URL variant
                    logger.warning(
                        "ZAP returned non-numeric scan ID: '%s' (attempt %s/%s)",
                        scan_id,
                        attempt,
                        retries,
                    )
                    break  # non-url_not_found error, go to retry logic
                except RuntimeError:
                    raise
                except Exception as exc:
                    if attempt == retries or not self._is_transient_zap_error(exc):
                        raise
                    break  # go to retry sleep

            else:
                # All URL variants returned url_not_found for this attempt
                if attempt == retries:
                    # Last attempt: try accessing the URL one more time and retry
                    logger.warning(
                        "All URL variants returned url_not_found on final attempt. "
                        "Re-accessing target and making one last try."
                    )
                    try:
                        zap.urlopen(target_url)
                        await asyncio.sleep(3)
                        scan_id = zap.ascan.scan(
                            target_url,
                            recurse="true",
                            inscopeonly="true" if inscope_only else "false",
                            scanpolicyname="Default Policy",  # ← Explicit policy
                            contextid=str(context_id) if context_id is not None else None,
                        )
                        if isinstance(scan_id, str) and scan_id.lstrip("-").isdigit():
                            return scan_id
                    except Exception:
                        pass
                    raise RuntimeError(f"ZAP active scan start failed: url_not_found for {target_url}")

            wait_seconds = attempt * 3
            logger.warning(
                "Active scan start failed (attempt %s/%s); retrying in %ss",
                attempt,
                retries,
                wait_seconds,
            )
            await asyncio.sleep(wait_seconds)
            await self._wait_for_zap_ready(zap, timeout=30)

        raise RuntimeError("Unable to start active scan")

    async def _ensure_url_in_site_tree(self, zap, target_url: str) -> bool:
        """Ensure the target URL is present in ZAP's site tree.

        Returns True if the URL was confirmed in ZAP's site tree, False otherwise.
        Never raises — the caller decides what to do if the URL is absent.

        ZAP's active scanner requires the target URL to already exist in
        its internal site tree.  The spider populates the tree, but for
        SPAs (e.g. Juice Shop) the base URL may not survive in the tree
        if it was a redirect or if ZAP cleared passive state.  We
        explicitly access the URL (with and without trailing slash) and
        verify it appears in ZAP's known sites before proceeding.
        """
        # Normalise: try both with and without trailing slash
        urls_to_try = [target_url]
        if target_url.endswith("/"):
            urls_to_try.append(target_url.rstrip("/"))
        else:
            urls_to_try.append(target_url + "/")

        for url in urls_to_try:
            try:
                zap.urlopen(url)
            except Exception as exc:
                logger.debug("urlopen(%s) failed: %s", url, exc)

        # Give ZAP a moment to index the accessed URL
        await asyncio.sleep(3)

        # Check if target is now in ZAP's sites list
        try:
            sites = zap.core.sites or []
            parsed_target = urlparse(target_url)
            target_origin = f"{parsed_target.scheme}://{parsed_target.netloc}".lower()
            found = any(target_origin in s.lower() for s in sites)
            if found:
                logger.info("Target confirmed in ZAP site tree: %s", target_url)
                return True

            logger.warning(
                "Target %s NOT found in ZAP sites %s — retrying with direct path access",
                target_url,
                sites,
            )
            # Last resort: access a few known paths to force site tree entry
            for path in ["/", "/index.html", "/api", "/rest"]:
                try:
                    zap.urlopen(f"{target_origin}{path}")
                except Exception:
                    pass
            await asyncio.sleep(2)

            # Re-check after forced access
            sites = zap.core.sites or []
            found = any(target_origin in s.lower() for s in sites)
            if found:
                logger.info("Target confirmed in ZAP site tree after forced access: %s", target_url)
                return True

            logger.warning(
                "Target %s still NOT found in ZAP site tree after forced access — "
                "active scan may fail",
                target_url,
            )
            return False
        except Exception as exc:
            logger.debug("Could not verify ZAP site tree: %s", exc)
            return False

    async def _get_active_scan_status_with_retry(self, zap, scan_id: str) -> int:
        """Read active scan status with retry for transient proxy issues."""
        retries = 3
        for attempt in range(1, retries + 1):
            try:
                raw = zap.ascan.status(scan_id)
                # ZAP returns "does_not_exist" when the scan ID is unknown
                # (e.g. scan was garbage-collected).  Treat as 100% complete.
                if isinstance(raw, str) and not raw.lstrip("-").isdigit():
                    logger.warning(
                        "ZAP returned non-numeric scan status '%s' for scan %s — treating as completed",
                        raw,
                        scan_id,
                    )
                    return 100
                return int(raw)
            except ValueError:
                # int() conversion failed — ZAP returned unexpected string
                logger.warning(
                    "ZAP scan status not numeric for scan %s — treating as completed",
                    scan_id,
                )
                return 100
            except Exception as exc:
                if attempt == retries or not self._is_transient_zap_error(exc):
                    raise
                wait_seconds = attempt * 2
                logger.warning(
                    "Status read failed (attempt %s/%s): %s; retrying in %ss",
                    attempt,
                    retries,
                    exc,
                    wait_seconds,
                )
                await asyncio.sleep(wait_seconds)
                await self._wait_for_zap_ready(zap, timeout=30)

        return 0

    OPENAPI_PROBE_PATHS = (
        "/openapi.json",
        "/swagger.json",
        "/api-docs",
        "/swagger/v1/swagger.json",
        "/v1/swagger.json",
        "/v2/api-docs",
        "/v3/api-docs",
        "/api/swagger.json",
        "/api/openapi.json",
    )

    _OPENAPI_ALERT_PREFIXES = (
        "/openapi.json",
        "/swagger.json",
        "/api-docs",
        "/swagger/v1/swagger.json",
        "/v1/swagger.json",
        "/v2/api-docs",
        "/v3/api-docs",
        "/api/swagger.json",
        "/api/openapi.json",
    )

    async def _try_import_openapi(self, zap, target_url: str) -> list[dict]:
        """Auto-discover and import OpenAPI/Swagger spec into ZAP.

        Returns routes extracted from the spec so they can be merged
        into the scan's route list even if the spider finds nothing.
        """
        spec_routes: list[dict] = []

        self._validate_target_url(target_url)

        async with httpx.AsyncClient(timeout=10, follow_redirects=False) as client:
            for probe_path in self.OPENAPI_PROBE_PATHS:
                spec_url = urljoin(target_url, probe_path)
                try:
                    resp = await client.get(spec_url)
                    if resp.status_code != 200:
                        continue
                    body = resp.text

                    # Quick sanity: must look like JSON with openapi/swagger key
                    import json as _json
                    try:
                        spec = _json.loads(body)
                    except Exception:
                        continue

                    if not (spec.get("openapi") or spec.get("swagger") or spec.get("paths")):
                        continue

                    logger.info("Found OpenAPI spec at %s — importing into ZAP", spec_url)

                    try:
                        result = zap.openapi.import_url(spec_url, hostoverride=None)
                        logger.info("ZAP OpenAPI import result: %s", result)
                    except Exception as exc:
                        logger.warning("ZAP OpenAPI import failed: %s", exc)

                    # Extract routes from spec for our route list
                    for path, methods_obj in spec.get("paths", {}).items():
                        if not isinstance(methods_obj, dict):
                            continue
                        http_methods = [
                            m.upper()
                            for m in methods_obj.keys()
                            if m.lower() in ("get", "post", "put", "patch", "delete", "head", "options")
                        ]
                        spec_routes.append({
                            "path": path,
                            "methods": http_methods or ["GET"],
                            "handler": "openapi_spec",
                            "source": "openapi_import",
                            "tested": False,
                        })

                    logger.info("Extracted %d routes from OpenAPI spec", len(spec_routes))
                    return spec_routes

                except (httpx.HTTPError, OSError):
                    continue
                except Exception as exc:
                    logger.debug("OpenAPI probe %s failed: %s", probe_path, exc)
                    continue

        logger.info("No OpenAPI/Swagger spec found at target")
        return spec_routes

    async def spider(
        self,
        target_url: str,
        routes: list[dict],
        scan_config: Optional[dict] = None,
        auth: Optional[dict] = None,
        stop_requested=None,
    ) -> list[dict]:
        """Spider the target application, seeding with discovered routes."""
        self._validate_target_url(target_url)
        zap = self._get_zap()
        config = scan_config or {}
        await self._wait_for_zap_ready(zap)

        # Start a fresh ZAP session to free memory from previous scans.
        # Without this, leftover site-tree / alert data from earlier scans
        # can push ZAP past its 2 GB container limit during active scan.
        try:
            zap.core.new_session(overwrite=True)
            logger.info("Started fresh ZAP session (cleared old scan data)")
            await asyncio.sleep(2)
        except Exception as e:
            logger.warning("Failed to create new ZAP session: %s", e)

        logger.info(f"Starting ZAP spider on {target_url}")

        # Auto-discover and import OpenAPI spec (critical for API-first apps)
        openapi_routes = await self._try_import_openapi(zap, target_url)

        # Set up authentication in ZAP if credentials are available
        if auth:
            if auth.get("cookies"):
                await self.set_auth_cookies(auth["cookies"])
            if auth.get("token"):
                await self.set_auth_header(auth["token"])

        # Add target to scope
        try:
            zap.urlopen(target_url)
            await asyncio.sleep(2)
        except Exception as e:
            logger.warning(f"Failed to access target: {e}")

        # Seed ZAP with discovered routes (static + OpenAPI)
        all_seed_routes = list(routes) + openapi_routes
        for route in all_seed_routes:
            route_url = urljoin(target_url, route["path"])
            try:
                zap.urlopen(route_url)
            except Exception:
                pass

        # Start spider
        max_children = int(config.get("max_children", 10))
        scan_depth = int(config.get("scan_depth", 5))
        try:
            try:
                zap.spider.set_option_max_depth(str(scan_depth))
            except Exception:
                logger.debug("Unable to set ZAP spider max depth", exc_info=True)

            scan_id = zap.spider.scan(
                target_url,
                maxchildren=str(max_children),
                recurse="true",
                subtreeonly="true",
            )

            # Wait for spider to complete
            timeout = config.get("timeout", 300)
            start_time = time.time()
            while int(zap.spider.status(scan_id)) < 100:
                if stop_requested and await stop_requested():
                    logger.info("Spider stop requested by scan cancellation")
                    try:
                        zap.spider.stop(scan_id)
                    except Exception:
                        logger.debug("Failed to stop spider after cancellation", exc_info=True)
                    break
                if time.time() - start_time > timeout:
                    logger.warning("Spider timed out")
                    zap.spider.stop(scan_id)
                    break
                await asyncio.sleep(2)

            discovered_urls = zap.spider.results(scan_id) or []

            if bool(config.get("ajax_spider", False)):
                try:
                    zap.ajaxSpider.scan(target_url)
                    ajax_timeout = max(20, min(int(config.get("timeout", 300)) // 3, 600))
                    ajax_started = time.time()
                    while self._get_ajax_status(zap) == "running":
                        if stop_requested and await stop_requested():
                            logger.info("AJAX spider stop requested by scan cancellation")
                            try:
                                zap.ajaxSpider.stop()
                            except Exception:
                                logger.debug("Failed to stop AJAX spider after cancellation", exc_info=True)
                            break
                        if time.time() - ajax_started > ajax_timeout:
                            logger.warning("AJAX spider timed out")
                            try:
                                zap.ajaxSpider.stop()
                            except Exception:
                                logger.debug("Failed to stop AJAX spider", exc_info=True)
                            break
                        await asyncio.sleep(2)

                    discovered_urls.extend(zap.core.urls(baseurl=target_url) or [])
                except Exception:
                    logger.warning("AJAX spider execution failed", exc_info=True)

            # Playwright JS spider — discovers routes in React/Vue/Angular SPAs
            # that ZAP's traditional spider misses (content rendered by JavaScript)
            try:
                from app.scanners.playwright_spider import playwright_crawl
                pw_urls = await playwright_crawl(target_url, timeout=60)
                if pw_urls:
                    for url in pw_urls:
                        try:
                            zap.urlopen(url)
                        except Exception:
                            pass
                    discovered_urls.extend(pw_urls)
                    logger.info("Playwright JS spider found %d additional routes", len(pw_urls))
            except ImportError:
                logger.debug("Playwright not installed — skipping JS spider")
            except Exception as e:
                logger.warning("Playwright spider failed: %s", e)

            logger.info(f"Spider completed. URLs found: {len(discovered_urls)}")
            spider_routes = self._routes_from_urls(target_url, discovered_urls)

            # Merge OpenAPI-discovered routes with spider-discovered routes
            if openapi_routes:
                existing_paths = {r["path"] for r in spider_routes}
                for oar in openapi_routes:
                    if oar["path"] not in existing_paths:
                        existing_paths.add(oar["path"])
                        spider_routes.append(oar)
                logger.info(
                    "After OpenAPI merge: %d total routes (%d from spec)",
                    len(spider_routes),
                    len(openapi_routes),
                )

            return spider_routes

        except Exception as e:
            logger.error(f"Spider failed: {e}")
            raise

    def _routes_from_urls(self, target_url: str, urls: list[str]) -> list[dict]:
        """Convert discovered URLs into normalized route dicts."""
        target_host = urlparse(target_url).netloc.lower()
        seen: set[str] = set()
        routes: list[dict] = []

        for raw_url in urls:
            try:
                parsed = urlparse(raw_url)
            except Exception:
                continue

            if parsed.scheme not in ("http", "https"):
                continue

            if target_host and parsed.netloc.lower() != target_host:
                continue

            path = parsed.path or "/"
            if not path.startswith("/"):
                path = f"/{path}"

            lower_path = path.lower()
            if lower_path.startswith(self.STATIC_PATH_PREFIXES):
                continue

            if "/node_modules/" in lower_path:
                continue

            file_segment = lower_path.rsplit("/", 1)[-1].split(":", 1)[0]
            if "." in file_segment:
                ext = "." + file_segment.rsplit(".", 1)[-1]
                if ext in self.STATIC_EXTENSIONS:
                    continue

            if path in seen:
                continue

            seen.add(path)
            routes.append({
                "path": path,
                "methods": ["GET"],
                "handler": "dynamic_discovery",
                "source": "zap_spider",
                "tested": False,
            })

        return routes

    @staticmethod
    def _get_ajax_status(zap) -> str:
        """Read AJAX spider status from zapv2 across versions."""
        status_attr = getattr(zap.ajaxSpider, "status", None)
        if callable(status_attr):
            try:
                return str(status_attr()).lower()
            except Exception:
                return ""
        if status_attr is None:
            return ""
        return str(status_attr).lower()

    async def active_scan(
        self,
        target_url: str,
        routes: list[dict],
        sinks: Optional[list[dict]] = None,
        auth: Optional[dict] = None,
        scan_config: Optional[dict] = None,
        stop_requested=None,
        on_progress=None,
    ) -> list[dict]:
        """Run ZAP active scan with optional context-aware payloads."""
        self._validate_target_url(target_url)
        zap = self._get_zap()
        config = scan_config or {}
        await self._wait_for_zap_ready(zap)

        if auth:
            if auth.get("cookies"):
                await self.set_auth_cookies(auth["cookies"])
            if auth.get("token"):
                await self.set_auth_header(auth["token"])

        logger.info(f"Starting ZAP active scan on {target_url}")

        # Optimize ZAP settings based on target location
        try:
            from urllib.parse import urlparse
            target_host = urlparse(target_url).hostname or ""
            is_local_target = target_host in ("localhost", "127.0.0.1", "0.0.0.0", "127.0.0.0/8")

            if is_local_target:
                thread_count = 2
                logger.info("Local target — 2 threads, default attack strength")
            else:
                # Remote/external targets: 2 threads to avoid overwhelming the server
                # and triggering rate-limiting (which stalls the scan).
                # Low strength = fewer payloads per rule, ~10-15 min, still finds OWASP Top 10.
                thread_count = 2
                zap.ascan.set_option_thread_per_host(thread_count)
                zap.ascan.set_option_default_attack_strength("Low")
                # Add 50ms delay between requests so the server doesn't rate-limit ZAP
                try:
                    zap.ascan.set_option_delay_in_ms(50)
                except Exception:
                    pass
                logger.info(
                    f"Remote target ({target_host}) — 2 threads, Low strength, 50ms delay "
                    "(avoids rate-limiting, ~10-15 min scan)"
                )

        except Exception as e:
            logger.debug(f"Unable to optimize ZAP settings: {e}")

        # Ensure the target URL is in ZAP's site tree before active scan.
        # The spider may have run in a different ZAP session or the site tree
        # may not have the exact URL form that ascan.scan() expects.
        site_tree_ok = await self._ensure_url_in_site_tree(zap, target_url)

        # If site tree is empty, do a lightweight targeted spider
        # using discovered routes to force ZAP to populate the tree.
        if not site_tree_ok and routes:
            logger.info("Populating ZAP site tree with discovered routes...")
            for route in routes:
                route_url = urljoin(target_url, route.get("path", ""))
                try:
                    zap.urlopen(route_url)
                except Exception:
                    pass
            await asyncio.sleep(5)
            # Re-check after forced population
            site_tree_ok = await self._ensure_url_in_site_tree(zap, target_url)

        # Configure scan policies based on detected sinks
        if sinks:
            await self._configure_context_aware_scan(zap, sinks, routes)

        try:
            inscope_only = bool(config.get("inscope_only", False))

            # Retry the entire active scan up to 2 times if ZAP loses state
            max_scan_attempts = 2
            TRANSIENT_FAILURE_WINDOW = 45  # seconds before giving up on transient errors
            ZAP_LIVENESS_INTERVAL = 25     # check ZAP is alive every N polling cycles
            liveness_counter = 0

            # Load timeout settings from config
            from app.core.config import settings
            ABSOLUTE_MAX_SCAN_TIME = int(config.get("absolute_max_timeout", settings.DAST_ABSOLUTE_MAX_TIMEOUT))
            STALL_TIMEOUT = int(config.get("stall_timeout", settings.DAST_STALL_TIMEOUT))

            for scan_attempt in range(1, max_scan_attempts + 1):
                scan_id = await self._start_active_scan_with_retry(zap, target_url, inscope_only)

                # Wait for active scan
                timeout = max(30, int(config.get("timeout", settings.DAST_BASE_TIMEOUT)))
                if bool(config.get("adaptive_timeout", settings.DAST_ADAPTIVE_TIMEOUT)):
                    target_host = urlparse(target_url).hostname or ""
                    is_local_target = target_host in ("localhost", "127.0.0.1", "0.0.0.0")
                    if not is_local_target:
                        timeout = max(timeout, 300)
                    # Add 6 seconds per discovered route (reduced from 12s)
                    # Cap at 2400s (40 minutes) to match DAST_ABSOLUTE_MAX_TIMEOUT
                    timeout = min(2400, timeout + max(0, len(routes)) * 6)
                start_time = time.time()
                last_progress_time = start_time
                last_progress = 0
                ever_saw_progress = False
                transient_failure_started = None
                scan_lost = False
                while True:
                    if stop_requested and await stop_requested():
                        logger.info("Active scan stop requested by scan cancellation")
                        try:
                            zap.ascan.stop(scan_id)
                        except Exception:
                            logger.debug("Failed to stop active scan after cancellation", exc_info=True)
                        break

                    # Periodic ZAP liveness check — detects OOM restarts early
                    liveness_counter += 1
                    if liveness_counter % ZAP_LIVENESS_INTERVAL == 0:
                        if not await self._check_zap_alive(zap):
                            logger.error(
                                "ZAP liveness check failed — ZAP container likely OOM'd or restarted. "
                                "Failing active scan for scan %s.",
                                scan_id,
                            )
                            raise ConnectionError(
                                "ZAP is unreachable during active scan — "
                                "container may have run out of memory. "
                                "Increase ZAP memory limit or reduce scan scope."
                            )

                    try:
                        progress = await self._get_active_scan_status_with_retry(zap, scan_id)
                        transient_failure_started = None
                    except Exception as exc:
                        if self._is_transient_zap_error(exc):
                            if transient_failure_started is None:
                                transient_failure_started = time.time()
                            if time.time() - transient_failure_started < TRANSIENT_FAILURE_WINDOW:
                                logger.warning(
                                    "Transient active scan status error (%.0fs/%ds): %s",
                                    time.time() - transient_failure_started,
                                    TRANSIENT_FAILURE_WINDOW,
                                    exc,
                                )
                                await asyncio.sleep(5)
                                continue
                            logger.error(
                                "Transient errors persisted for >%ds — ZAP may have OOM'd. "
                                "Failing active scan.",
                                TRANSIENT_FAILURE_WINDOW,
                            )
                        raise

                    if progress > 0 and progress < 100:
                        ever_saw_progress = True

                    # Notify orchestrator of ZAP progress so overall scan bar moves
                    if on_progress and progress > last_progress:
                        try:
                            await on_progress(progress)
                        except Exception:
                            pass

                    if progress >= 100:
                        elapsed = time.time() - start_time
                        # If scan "completed" suspiciously fast (<60s) and we never
                        # saw intermediate progress, ZAP likely lost the scan state.
                        if elapsed < 60 and not ever_saw_progress and len(routes) > 5:
                            logger.warning(
                                "Active scan reported complete in %.0fs with no intermediate "
                                "progress and %d routes — ZAP likely lost scan state "
                                "(attempt %d/%d)",
                                elapsed,
                                len(routes),
                                scan_attempt,
                                max_scan_attempts,
                            )
                            scan_lost = True
                            break
                        break

                    now = time.time()
                    if progress > last_progress:
                        last_progress = progress
                        last_progress_time = now

                    elapsed = now - start_time
                    stalled_time = now - last_progress_time

                    # Hard timeout: absolute maximum time (prevents infinite hangs)
                    if elapsed > ABSOLUTE_MAX_SCAN_TIME:
                        logger.warning(
                            f"Active scan exceeded absolute maximum time ({ABSOLUTE_MAX_SCAN_TIME}s). "
                            f"Current progress: {progress}%"
                        )
                        try:
                            zap.ascan.stop(scan_id)
                        except Exception:
                            pass
                        raise TimeoutError(
                            f"Active scan exceeded absolute maximum time limit of {ABSOLUTE_MAX_SCAN_TIME}s. "
                            f"Current progress: {progress}%. "
                            f"Increase ABSOLUTE_MAX_SCAN_TIME or reduce scan scope."
                        )

                    # Stall-recovery: if progress has been stuck for a long time
                    # and we already have meaningful progress (>= 30%), collect
                    # partial results and move on rather than timing out hard.
                    EARLY_COLLECT_STALL = 300  # 5 min stall at >=30% = collect & continue
                    if (
                        stalled_time > EARLY_COLLECT_STALL
                        and progress >= 30
                        and elapsed < ABSOLUTE_MAX_SCAN_TIME
                    ):
                        logger.warning(
                            f"Active scan stalled at {progress}% for {stalled_time:.0f}s — "
                            f"collecting partial results and moving on"
                        )
                        try:
                            zap.ascan.stop(scan_id)
                        except Exception:
                            pass
                        break  # exit loop, collect partial alerts below

                    # Soft timeout: exceeded configured timeout AND no progress
                    if elapsed > timeout and stalled_time > STALL_TIMEOUT:
                        logger.warning(
                            f"Active scan timed out: elapsed={elapsed:.0f}s (limit={timeout}s), "
                            f"stalled={stalled_time:.0f}s (limit={STALL_TIMEOUT}s), progress={progress}%"
                        )
                        try:
                            zap.ascan.stop(scan_id)
                        except Exception:
                            pass
                        logger.warning(
                            "Collecting partial alerts despite timeout (progress=%d%%)", progress
                        )
                        break  # collect partial results instead of raising

                    # Alert if stalled for extended time (warning, not failure)
                    if stalled_time > 60 and progress < 100:
                        if int(stalled_time) % 30 == 0:  # Log every 30 seconds
                            logger.warning(
                                f"Active scan progress stalled at {progress}% for {stalled_time:.0f}s "
                                f"(may be normal for slow targets)"
                            )

                    await asyncio.sleep(5)

                if scan_lost and scan_attempt < max_scan_attempts:
                    logger.info(
                        "Re-accessing target and retrying active scan (attempt %d/%d)",
                        scan_attempt + 1,
                        max_scan_attempts,
                    )
                    await self._ensure_url_in_site_tree(zap, target_url)
                    await asyncio.sleep(5)
                    continue  # retry

                break  # scan completed normally (or we're out of retries)

            logger.info("Active scan completed")

            # Always collect partial results — even if the scan was stopped
            # mid-way (user cancel, timeout, stall), ZAP still holds whatever
            # vulnerabilities it found up to that point.
            alerts = []
            for attempt in range(1, 4):
                try:
                    alerts = zap.core.alerts(baseurl=target_url)
                    break
                except Exception as exc:
                    if attempt == 3 or not self._is_transient_zap_error(exc):
                        logger.warning("Could not fetch ZAP alerts after scan: %s", exc)
                        break
                    logger.warning("Alert fetch failed (attempt %s/3): %s", attempt, exc)
                    await asyncio.sleep(2 * attempt)
            if alerts:
                logger.info("Active scan collected %d alert(s) from ZAP", len(alerts))
            return self._parse_alerts(alerts, target_url)

        except Exception as e:
            logger.error(f"Active scan failed: {e}")
            raise

    async def _configure_context_aware_scan(
        self, zap, sinks: list[dict], routes: list[dict]
    ):
        """Configure ZAP scan policies based on detected code sinks."""
        logger.info("Configuring context-aware scan policies...")

        # Map sinks to endpoints
        sink_types = set(s["type"] for s in sinks)

        # Enable/disable scan rules based on detected sinks
        # This reduces scan time and false positives
        policy_name = "context_aware"
        try:
            zap.ascan.remove_scan_policy(policy_name)
        except Exception:
            pass

        try:
            zap.ascan.add_scan_policy(policy_name)

            # If SQL injection sinks found, enable SQL injection scanners
            if "sql_injection" in sink_types:
                # Enable all SQL injection scanners (40018-40022)
                for scanner_id in ["40018", "40019", "40020", "40021", "40022"]:
                    zap.ascan.set_scanner_attack_strength(
                        scanner_id, "HIGH", policy_name
                    )

            if "xss" in sink_types:
                for scanner_id in ["40012", "40014", "40016", "40017"]:
                    zap.ascan.set_scanner_attack_strength(
                        scanner_id, "HIGH", policy_name
                    )

            if "command_injection" in sink_types:
                for scanner_id in ["90019", "90020"]:
                    zap.ascan.set_scanner_attack_strength(
                        scanner_id, "HIGH", policy_name
                    )

            if "path_traversal" in sink_types:
                for scanner_id in ["6", "40003", "40032"]:
                    zap.ascan.set_scanner_attack_strength(
                        scanner_id, "HIGH", policy_name
                    )

        except Exception as e:
            logger.warning(f"Failed to configure context-aware policy: {e}")

    # Vulnerability types that warrant "critical" when ZAP risk is High
    CRITICAL_VULN_TYPES = frozenset({
        "sqli", "cmdi", "code_injection", "ssrf", "path_traversal",
    })

    def _map_zap_severity(self, alert: dict, vuln_type: str) -> str:
        """Map ZAP risk to internal severity (critical/high/medium/low/info).

        ZAP returns risk as a text string ("High", "Medium", "Low",
        "Informational") via core.alerts().  Some endpoints also include a
        numeric ``riskcode`` (3/2/1/0).  We handle both.

        Active-exploit vuln types (SQLi, command injection, SSRF, etc.) are
        promoted to "critical" when ZAP risk is High.
        """
        # Try numeric riskcode first (some ZAP API responses include it)
        riskcode = alert.get("riskcode")
        if riskcode is not None:
            numeric_map = {3: "high", 2: "medium", 1: "low", 0: "info"}
            severity = numeric_map.get(int(riskcode), "medium")
        else:
            # Text-based risk field (core.alerts() always provides this)
            risk_text = str(alert.get("risk", "Medium")).strip().lower()
            text_map = {
                "high": "high",
                "medium": "medium",
                "low": "low",
                "informational": "info",
                "info": "info",
            }
            severity = text_map.get(risk_text, "medium")

        # Promote high → critical for actively-exploitable vuln types
        if severity == "high" and vuln_type in self.CRITICAL_VULN_TYPES:
            severity = "critical"

        return severity

    @staticmethod
    def _map_zap_confidence(alert: dict) -> str:
        """Map ZAP confidence to internal confidence level.

        ZAP confidence values: "High", "Medium", "Low", "False Positive",
        or numeric confidencecode 3/2/1/0.

        Internal levels: "verified", "probable", "observed".
        DAST-only findings can't be "verified" (that requires SAST
        correlation), so High → probable, Medium/Low → observed.
        """
        conf = str(alert.get("confidence", "Medium")).strip().lower()
        if conf in ("high", "confirmed"):
            return "probable"
        # Medium, Low, False Positive → observed
        return "observed"

    def _coerce_alerts_payload(self, alerts: Any) -> list[dict]:
        """Normalize ZAP alert payloads into a list of dict alerts."""
        payload = alerts
        if payload is None:
            return []

        if isinstance(payload, str):
            raw = payload.strip()
            if not raw:
                return []
            try:
                payload = json.loads(raw)
            except Exception:
                logger.warning("ZAP alerts payload is non-JSON string; ignoring payload")
                return []

        if isinstance(payload, dict):
            if isinstance(payload.get("alerts"), list):
                payload = payload.get("alerts", [])
            elif payload.get("pluginId"):
                payload = [payload]
            else:
                logger.warning("ZAP alerts payload dict has unexpected shape; ignoring payload")
                return []

        if not isinstance(payload, list):
            logger.warning("ZAP alerts payload is not a list; ignoring payload")
            return []

        normalized: list[dict] = []
        for item in payload:
            candidate = item
            if isinstance(candidate, str):
                text = candidate.strip()
                if not text:
                    continue
                try:
                    candidate = json.loads(text)
                except Exception:
                    continue
            if isinstance(candidate, dict):
                normalized.append(candidate)

        return normalized

    def _parse_alerts(self, alerts: Any, target_url: str) -> list[dict]:
        """Parse ZAP alerts into finding dicts."""
        alerts = self._coerce_alerts_payload(alerts)
        findings = []

        for alert in alerts:
            alert_ref = str(alert.get("pluginId", ""))
            mapping_source = "builtin"
            mapping_tier = "high"
            vuln_info = ZAP_ALERT_MAP.get(alert_ref, {"type": "unknown", "cwe": ""})
            if vuln_info.get("type") == "unknown":
                compat = ZAP_COMPATIBILITY_MAP.get(alert_ref)
                if compat:
                    vuln_info = compat
                    mapping_source = "compatibility"
                    mapping_tier = compat.get("tier", "low")
                else:
                    mapping_source = "none"
                    mapping_tier = "none"
            vuln_type = vuln_info["type"]

            # Parse URL to extract endpoint
            url = alert.get("url", "")
            endpoint = self._normalize_alert_endpoint(url)

            # Determine HTTP method
            method = alert.get("method", "GET")

            # Get parameter
            param = alert.get("param", "")

            # Severity and confidence — use ZAP's actual values
            severity = self._map_zap_severity(alert, vuln_type)
            confidence = self._map_zap_confidence(alert)
            strong_evidence = bool(
                mapping_tier == "high"
                or confidence == "probable"
                or str(alert.get("risk", "")).strip().lower() == "high"
            )

            # CWE: prefer curated mapping when available to avoid noisy
            # scanner-provided IDs that vary by plugin/context.
            cwe = self._normalize_alert_cwe(alert, vuln_info)

            finding = {
                "title": alert.get("alert", "DAST Finding"),
                "vulnerability_type": vuln_type,
                "severity": severity,
                "confidence": confidence,
                "cwe": cwe,
                "endpoint": endpoint,
                "http_method": method,
                "parameter": param,
                "payload": alert.get("attack", ""),
                "response_code": 0,
                "evidence": alert.get("evidence", ""),
                "strong_evidence": strong_evidence,
                "mapping_source": mapping_source,
                "mapping_tier": mapping_tier,
                "remediation": alert.get("solution", ""),
                "alert_ref": alert_ref,
                "raw": {
                    "pluginId": alert_ref,
                    "alert": alert.get("alert", ""),
                    "url": url,
                    "endpoint": endpoint,
                    "cweid": alert.get("cweid", ""),
                    "cwe": cwe,
                    "mapping_source": mapping_source,
                    "mapping_tier": mapping_tier,
                    "risk": alert.get("risk", ""),
                    "confidence": alert.get("confidence", ""),
                    "description": alert.get("description", ""),
                    "reference": alert.get("reference", ""),
                    "tags": alert.get("tags", {}),
                },
            }
            findings.append(finding)

        return findings

    @classmethod
    def _normalize_alert_endpoint(cls, raw_url: str) -> str:
        """Normalize alert URL into correlation-friendly endpoint path."""
        path = normalize_endpoint_value(raw_url)

        lower = path.lower()
        for prefix in cls._OPENAPI_ALERT_PREFIXES:
            pref = prefix.rstrip("/").lower()
            marker = pref + "/"
            if lower.startswith(marker):
                remainder = path[len(pref):]
                if remainder.startswith("/") and len(remainder) > 1:
                    return remainder.rstrip("/") or "/"
                break

        return path

    @staticmethod
    def _normalize_alert_cwe(alert: dict, vuln_info: dict) -> str:
        """Normalize CWE, preferring curated per-plugin mappings."""
        mapped_cwe = str(vuln_info.get("cwe", "")).strip().upper()
        if mapped_cwe and mapped_cwe.startswith("CWE-"):
            return mapped_cwe

        raw_cweid = str(alert.get("cweid", "")).strip().upper()
        if not raw_cweid or raw_cweid in {"0", "-1"}:
            return ""
        if raw_cweid.startswith("CWE-"):
            return raw_cweid
        if raw_cweid.isdigit():
            return f"CWE-{raw_cweid}"
        return ""

    async def get_scan_progress(self, scan_id: str) -> int:
        """Get the progress of an active scan."""
        try:
            zap = self._get_zap()
            return int(zap.ascan.status(scan_id))
        except Exception:
            return 0

    async def stop_scan(self, scan_id: str):
        """Stop a running scan."""
        try:
            zap = self._get_zap()
            zap.ascan.stop(scan_id)
        except Exception as e:
            logger.error(f"Failed to stop scan: {e}")

    async def set_auth_cookies(self, cookies: list[dict]):
        """Set authentication cookies in ZAP via request header replacement."""
        try:
            zap = self._get_zap()
            cookie_str = "; ".join(
                f"{c.get('name', '')}={c.get('value', '')}"
                for c in cookies if c.get("name")
            )
            if not cookie_str:
                return
            zap.replacer.add_rule(
                description="Auth Cookies",
                enabled="true",
                matchtype="REQ_HEADER",
                matchregex="false",
                matchstring="Cookie",
                replacement=cookie_str,
            )
        except Exception as e:
            logger.warning("Failed to set auth cookies: %s", e)

    async def set_auth_header(self, token: str, header_name: str = "Authorization"):
        """Set authentication header in ZAP."""
        try:
            zap = self._get_zap()
            zap.replacer.add_rule(
                description="Auth Header",
                enabled="true",
                matchtype="REQ_HEADER",
                matchregex="false",
                matchstring=header_name,
                replacement=token if token.lower().startswith(("bearer ", "basic ")) else f"Bearer {token}",
            )
        except Exception as e:
            logger.warning(f"Failed to set auth header: {e}")


def get_zap_client():
    """Create and return a ZAPv2 client instance.

    Intended for lightweight ZAP operations (e.g. script management,
    scanner configuration) that don't need the full DastEngine wrapper.
    """
    from app.core.config import settings
    from zapv2 import ZAPv2

    return ZAPv2(
        apikey=settings.ZAP_API_KEY,
        proxies={"http": settings.ZAP_API_URL, "https": settings.ZAP_API_URL},
    )
