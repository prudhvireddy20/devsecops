"""Import findings from external SAST tool JSON output.

Supports auto-detection of multiple formats:
  - Semgrep native JSON
  - SARIF (CodeQL, etc.)
  - Gitleaks JSON
  - Trivy JSON
  - Noir (API endpoint discovery)
  - Generic fallback
"""
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class ExternalFindingImporter:
    """Parse findings from external static-analysis tool JSON output."""

    FORMAT_SEMGREP = "semgrep"
    FORMAT_SARIF = "sarif"
    FORMAT_GITLEAKS = "gitleaks"
    FORMAT_TRIVY = "trivy"
    FORMAT_NOIR = "noir"
    FORMAT_TRUSTSCAN = "trustscan"
    FORMAT_GENERIC = "generic"

    def detect_format(self, data: object) -> str:
        """Auto-detect the format of external JSON data."""
        if not isinstance(data, dict) and not isinstance(data, list):
            return self.FORMAT_GENERIC

        if isinstance(data, dict):
            # Semgrep: {"results": [{...}]}
            semgrep_results = data.get("results")
            if isinstance(semgrep_results, list) and semgrep_results and isinstance(semgrep_results[0], dict):
                if "check_id" in semgrep_results[0]:
                    return self.FORMAT_SEMGREP
                if "Vulnerabilities" in semgrep_results[0]:
                    return self.FORMAT_TRIVY

            # Trivy also uses {"Results": [{"Vulnerabilities": [...]}]} (capital R)
            trivy_results = data.get("Results")
            if isinstance(trivy_results, list) and trivy_results and isinstance(trivy_results[0], dict):
                if "Vulnerabilities" in trivy_results[0]:
                    return self.FORMAT_TRIVY

            # SARIF: {"$schema": "...", "runs": [{...}]}
            if "runs" in data and isinstance(data["runs"], list):
                return self.FORMAT_SARIF

            # Noir: {"paths": [{...}]}
            if "paths" in data and isinstance(data["paths"], list):
                return self.FORMAT_NOIR

            # TrustScan NormalizedFinding: {"traceon_version": "...", "findings": [...]}
            if "traceon_version" in data and "findings" in data:
                return self.FORMAT_TRUSTSCAN

        # Gitleaks: [{...}] flat array of finding objects
        if isinstance(data, list) and data and isinstance(data[0], dict):
            if "Description" in data[0] or "RuleID" in data[0]:
                return self.FORMAT_GITLEAKS

        return self.FORMAT_GENERIC

    def import_findings(
        self, data: object, *, format: str | None = None, auto_detect: bool = True
    ) -> list[dict]:
        """Parse external findings into standard Finding dicts.

        Args:
            data: Parsed JSON data (dict or list).
            format: Explicit format override. If None, auto-detects.
            auto_detect: Whether to fall back to auto-detection.

        Returns:
            List of finding dicts compatible with orchestrator Finding creation.
        """
        fmt = format
        if not fmt and auto_detect:
            fmt = self.detect_format(data)
        if not fmt:
            logger.warning("Could not determine external findings format")
            return []

        logger.info("Importing external findings using format: %s", fmt)

        parsers = {
            self.FORMAT_SEMGREP: self._parse_semgrep,
            self.FORMAT_SARIF: self._parse_sarif,
            self.FORMAT_GITLEAKS: self._parse_gitleaks,
            self.FORMAT_TRIVY: self._parse_trivy,
            self.FORMAT_NOIR: self._parse_noir,
            self.FORMAT_TRUSTSCAN: self._parse_trustscan,
            self.FORMAT_GENERIC: self._parse_generic,
        }
        parser = parsers.get(fmt)
        if not parser:
            logger.warning("Unknown external findings format: %s", fmt)
            return []

        try:
            return parser(data)
        except Exception as exc:
            logger.exception("Failed to parse external findings as %s: %s", fmt, exc)
            return []

    # ── Per-format parsers ──────────────────────────────────────────────────

    def _parse_semgrep(self, data: dict) -> list[dict]:
        """Parse Semgrep JSON output.

        Semgrep format: {"results": [{"check_id": ..., "path": ..., "start": {"line": ...}, ...}]}
        """
        findings = []
        for result in data.get("results") or []:
            if not isinstance(result, dict):
                continue
            rule_id = result.get("check_id") or ""
            message = (result.get("extra") or {}).get("message") or ""
            severity_raw = (result.get("extra") or {}).get("severity") or "WARNING"
            metadata = (result.get("extra") or {}).get("metadata") or {}

            severity_map = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}
            severity = severity_map.get(severity_raw, "medium")

            file_path = result.get("path") or ""
            start_line = (result.get("start") or {}).get("line") or 0
            code_snippet = (result.get("extra") or {}).get("lines") or ""

            vuln_type = self._infer_type(rule_id, message, metadata)
            cwe = self._extract_cwe(metadata)
            remediation = self._generate_remediation(vuln_type)

            findings.append({
                "title": message or f"{vuln_type.upper()} finding",
                "vulnerability_type": vuln_type,
                "severity": severity,
                "cwe": cwe,
                "file_path": file_path,
                "line_number": start_line,
                "code_snippet": code_snippet,
                "endpoint": str(metadata.get("endpoint") or "").strip(),
                "parameter": str(metadata.get("parameter") or "").strip(),
                "rule_id": rule_id,
                "remediation": remediation,
                "raw": result,
            })
        return findings

    def _parse_sarif(self, data: dict) -> list[dict]:
        """Parse SARIF 2.1.0 output (used by CodeQL, etc.).

        SARIF format: {"runs": [{"tool": {...}, "results": [{...}]}]}
        """
        findings = []
        runs = data.get("runs") or []
        for run in runs:
            if not isinstance(run, dict):
                continue
            driver = (run.get("tool") or {}).get("driver") or {}
            rules_map = {}
            for rule in driver.get("rules") or []:
                if isinstance(rule, dict):
                    rules_map[rule.get("id") or ""] = rule

            results = run.get("results") or []
            for result in results:
                if not isinstance(result, dict):
                    continue
                rule_id = result.get("ruleId") or ""
                level = result.get("level") or "warning"
                message_text = ((result.get("message") or {}).get("text") or "")

                rule_obj = rules_map.get(rule_id, {})
                short_desc = (rule_obj.get("shortDescription") or {}).get("text") or ""
                full_desc = (rule_obj.get("fullDescription") or {}).get("text") or ""

                severity_map = {"error": "high", "warning": "medium", "note": "low"}
                severity = severity_map.get(level, "medium")

                file_path = ""
                start_line = 0
                locations = result.get("locations") or []
                for loc in locations:
                    phys = (loc.get("physicalLocation") or {})
                    art = (phys.get("artifactLocation") or {})
                    region = (phys.get("region") or {})
                    if art.get("uri"):
                        file_path = art["uri"]
                    if region.get("startLine"):
                        start_line = region["startLine"]

                vuln_type = self._infer_type(rule_id, message_text or short_desc, {})
                cwe = self._extract_cwe_from_properties(result.get("properties") or {})

                findings.append({
                    "title": message_text or short_desc or full_desc or rule_id,
                    "vulnerability_type": vuln_type,
                    "severity": severity,
                    "cwe": cwe,
                    "file_path": file_path,
                    "line_number": start_line,
                    "code_snippet": "",
                    "endpoint": "",
                    "parameter": "",
                    "rule_id": rule_id,
                    "remediation": self._generate_remediation(vuln_type),
                    "raw": result,
                })
        return findings

    def _parse_gitleaks(self, data: list) -> list[dict]:
        """Parse Gitleaks JSON output.

        Gitleaks format: [{"Description": ..., "File": ..., "StartLine": ..., "Secret": ..., "RuleID": ...}]
        """
        findings = []
        for item in data:
            if not isinstance(item, dict):
                continue
            desc = item.get("Description") or "Secret Detected"
            file_path = item.get("File") or ""
            start_line = item.get("StartLine") or 0
            rule_id = item.get("RuleID") or ""
            secret_preview = (item.get("Secret") or "")[:40]

            findings.append({
                "title": f"Secret: {desc}",
                "vulnerability_type": "secret",
                "severity": "high",
                "cwe": "CWE-798",
                "file_path": file_path,
                "line_number": start_line,
                "code_snippet": secret_preview,
                "endpoint": "",
                "parameter": "",
                "rule_id": rule_id,
                "remediation": "Move this secret to an environment variable or secrets manager.",
                "raw": item,
            })
        return findings

    def _parse_trivy(self, data: dict) -> list[dict]:
        """Parse Trivy filesystem scan JSON output.

        Trivy format: {"Results": [{"Target": ..., "Vulnerabilities": [{...}]}]}
        """
        findings = []
        results_list = data.get("Results") or []
        for result in results_list:
            if not isinstance(result, dict):
                continue
            target = result.get("Target") or ""
            vulns = result.get("Vulnerabilities") or []
            for vuln in vulns:
                if not isinstance(vuln, dict):
                    continue
                vuln_id = vuln.get("VulnerabilityID") or ""
                pkg_name = vuln.get("PkgName") or ""
                severity_raw = vuln.get("Severity") or "MEDIUM"
                title = vuln.get("Title") or vuln_id
                installed = vuln.get("InstalledVersion") or ""
                fixed = vuln.get("FixedVersion") or ""

                severity_map = {
                    "CRITICAL": "critical", "HIGH": "high",
                    "MEDIUM": "medium", "LOW": "low",
                }
                severity = severity_map.get(severity_raw.upper(), "medium")

                findings.append({
                    "title": f"{pkg_name}: {title}" if pkg_name else title,
                    "vulnerability_type": "dependency_cve",
                    "severity": severity,
                    "cwe": "",
                    "file_path": target,
                    "line_number": 0,
                    "code_snippet": f"{pkg_name}@{installed} – fixed in {fixed}" if fixed else f"{pkg_name}@{installed}",
                    "endpoint": "",
                    "parameter": "",
                    "rule_id": vuln_id,
                    "remediation": f"Upgrade {pkg_name} to version {fixed}" if fixed else f"Upgrade {pkg_name}",
                    "raw": vuln,
                })
        return findings

    def _parse_noir(self, data: dict) -> list[dict]:
        """Parse Noir JSON output (API endpoint discovery).

        Noir format: {"paths": [{"path": ..., "method": ..., "file": ...}]}
        This is NOT a finding parser — it outputs route discovery data.
        We still return finding dicts as routes to the scan context.
        """
        findings = []
        for entry in data.get("paths") or []:
            if not isinstance(entry, dict):
                continue
            path = entry.get("path") or "/"
            method = (entry.get("method") or "GET").upper()
            file_path = entry.get("file") or ""
            findings.append({
                "title": f"Route: {method} {path}",
                "vulnerability_type": "route",
                "severity": "info",
                "cwe": "",
                "file_path": file_path,
                "line_number": 0,
                "code_snippet": "",
                "endpoint": path,
                "parameter": "",
                "rule_id": "",
                "remediation": "",
                "raw": entry,
                "_noir_route": {"path": path, "method": method, "file": file_path},
            })
        return findings

    def _parse_trustscan(self, data: dict) -> list[dict]:
        """Parse TrustScan NormalizedFinding JSON format.

        Format: {"traceon_version": "1.0", "scan_metadata": {...}, "findings": [...]}
        Repository URL extracted from scan_metadata.repository.url if present.
        """
        findings = []
        for item in data.get("findings") or []:
            if not isinstance(item, dict):
                continue
            location = item.get("location") or {}
            cwe_raw = item.get("cwe") or []
            cwe_str = ""
            if isinstance(cwe_raw, list) and cwe_raw:
                cwe_str = str(cwe_raw[0])
                if cwe_str.isdigit():
                    cwe_str = f"CWE-{cwe_str}"
            elif isinstance(cwe_raw, str):
                cwe_str = cwe_raw if cwe_raw.startswith("CWE-") else f"CWE-{cwe_raw}"

            findings.append({
                "title": item.get("title") or item.get("description") or "TrustScan Finding",
                "vulnerability_type": item.get("vulnerability_type") or item.get("type") or "unknown",
                "severity": str(item.get("severity") or "medium").lower(),
                "confidence": str(item.get("confidence") or "").lower(),
                "cwe": cwe_str,
                "file_path": location.get("file_path") or location.get("file") or "",
                "line_number": location.get("line") or location.get("line_number") or 0,
                "code_snippet": location.get("snippet") or location.get("code_snippet") or "",
                "endpoint": str(item.get("endpoint") or "").strip(),
                "parameter": str(item.get("parameter") or "").strip(),
                "rule_id": item.get("id") or item.get("rule_id") or "",
                "remediation": item.get("remediation") or "",
                "description": item.get("description") or "",
                "dataflow": item.get("dataflow") or [],
                "references": item.get("references") or [],
                "raw": item,
            })
        return findings

    def _parse_generic(self, data: object) -> list[dict]:
        """Generic fallback parser — tries multiple shapes."""
        findings = []
        items = data if isinstance(data, list) else [data]

        for item in items:
            if not isinstance(item, dict):
                continue
            finding = {
                "title": str(item.get("title") or item.get("Title") or item.get("message") or item.get("description") or "External Finding"),
                "vulnerability_type": str(item.get("vulnerability_type") or item.get("type") or item.get("kind") or "unknown"),
                "severity": str(item.get("severity") or item.get("Severity") or "medium").lower(),
                "cwe": str(item.get("cwe") or item.get("CWE") or ""),
                "file_path": str(item.get("file_path") or item.get("file") or item.get("path") or item.get("File") or ""),
                "line_number": int(item.get("line_number") or item.get("line") or item.get("StartLine") or 0),
                "code_snippet": str(item.get("code_snippet") or item.get("code") or item.get("evidence") or ""),
                "endpoint": str(item.get("endpoint") or item.get("Endpoint") or ""),
                "parameter": str(item.get("parameter") or item.get("param") or ""),
                "rule_id": str(item.get("rule_id") or item.get("RuleID") or ""),
                "remediation": str(item.get("remediation") or item.get("recommendation") or ""),
                "raw": item,
            }
            findings.append(finding)

        return findings

    # ── Shared helpers ──────────────────────────────────────────────────────

    _VULN_KEYWORDS: dict[str, list[str]] = {
        "sqli": ["sqli", "sql", "sqlite", "mysql", "postgres", "sqli"],
        "xss": ["xss", "cross.site", "cross_site"],
        "cmdi": ["cmdi", "command.injection", "command_injection", "cmd.exec", "os.exec"],
        "ssrf": ["ssrf", "server.side.request", "server_side_request"],
        "path_traversal": ["path.traversal", "path_traversal", "dir.traversal", "lfi", "../"],
        "deserialization": ["deserialization", "unserialize", "pickle"],
        "secret": ["secret", "private.key", "api.key", "token", "password"],
        "dependency_cve": ["cve", "dependency", "vulnerability"],
        "idor": ["idor", "insecure.direct.object", "access.control"],
        "auth": ["auth", "authentication", "login", "session"],
        "cors": ["cors", "cross.origin", "access.control.allow"],
        "weak_crypto": ["weak.crypto", "md5", "sha1", "des"],
    }

    def _infer_type(self, rule_id: str, message: str, metadata: dict) -> str:
        """Infer vulnerability type from rule ID, message, and metadata."""
        combined = f"{rule_id} {message} {json.dumps(metadata)}".lower()

        for vuln_type, keywords in self._VULN_KEYWORDS.items():
            for kw in keywords:
                if kw in combined:
                    return vuln_type

        return "unknown"

    def _extract_cwe(self, metadata: dict) -> str:
        """Extract CWE from metadata dict."""
        cwe_list = metadata.get("cwe") or []
        if isinstance(cwe_list, list) and cwe_list:
            cwe = str(cwe_list[0])
            if not cwe.startswith("CWE-"):
                cwe = f"CWE-{cwe}" if cwe.isdigit() else cwe
            return cwe
        if isinstance(cwe_list, str):
            return cwe_list if cwe_list.startswith("CWE-") else f"CWE-{cwe_list}"
        return ""

    def _extract_cwe_from_properties(self, properties: dict) -> str:
        """Extract CWE from SARIF properties."""
        tags = properties.get("tags") or []
        for tag in tags:
            tag_str = str(tag)
            if tag_str.startswith("CWE-") or tag_str.startswith("cwe-"):
                return tag_str.upper()
            if "CWE" in tag_str.upper():
                return f"CWE-{tag_str.split(':')[-1].strip()}"
        return ""

    def _generate_remediation(self, vuln_type: str) -> str:
        """Generate a basic remediation suggestion."""
        remediations = {
            "sqli": "Use parameterized queries or an ORM to prevent SQL injection.",
            "xss": "Sanitize user input with context-aware escaping. Use Content-Security-Policy headers.",
            "cmdi": "Avoid shell commands with user input. Use subprocess with argument lists.",
            "ssrf": "Validate and restrict URLs to an allowlist. Block access to internal networks.",
            "path_traversal": "Validate file paths and use a safe base directory. Reject '..' sequences.",
            "secret": "Move secrets to environment variables or a secrets manager.",
            "dependency_cve": "Upgrade the affected package to a patched version.",
            "idor": "Enforce authorization checks on every object access.",
        }
        return remediations.get(vuln_type, "Review this finding and apply appropriate fixes.")

    def extract_repo_url(self, data: dict) -> str:
        """Extract repository URL from TrustScan scan_metadata."""
        metadata = data.get("scan_metadata") or {}
        repo = metadata.get("repository") or {}
        return str(repo.get("url") or "").strip()

    @classmethod
    def import_from_file(cls, file_path: str, *, format: str | None = None) -> list[dict]:
        """Convenience: load JSON file and parse findings."""
        path = Path(file_path)
        if not path.exists():
            logger.warning("External findings file not found: %s", file_path)
            return []

        raw = path.read_text(encoding="utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.warning("Failed to parse external findings JSON: %s", exc)
            return []

        importer = cls()
        return importer.import_findings(data, format=format)
