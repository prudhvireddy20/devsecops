"""Recursive directory fuzzer via feroxbuster.

feroxbuster recurses into discovered directories automatically, catching
paths that ffuf (single-level) misses. Outputs JSON lines per found URL.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile

logger = logging.getLogger(__name__)

_WORDLIST = "/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt"
_FALLBACK_WORDLIST = "/usr/share/seclists/Discovery/Web-Content/common.txt"

_SKIP_EXTENSIONS = {
    ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg",
    ".woff", ".woff2", ".ttf", ".eot", ".map", ".json",
}


class FeroxbusterEngine:
    """Recursive path discovery using feroxbuster."""

    def __init__(self, timeout: int = 180):
        self.timeout = timeout

    async def fuzz(self, target_url: str) -> list[dict]:
        """Run feroxbuster and return discovered route dicts."""
        if not shutil.which("feroxbuster"):
            logger.warning("feroxbuster not found on PATH — skipping recursive fuzzing")
            return []

        wordlist = _WORDLIST if os.path.exists(_WORDLIST) else _FALLBACK_WORDLIST
        if not os.path.exists(wordlist):
            logger.warning("feroxbuster: no wordlist found at %s or %s", _WORDLIST, _FALLBACK_WORDLIST)
            return []

        _fd, tmpfile = tempfile.mkstemp(suffix=".json", prefix="ferox_")
        os.close(_fd)

        cmd = [
            "feroxbuster",
            "--url", target_url,
            "--wordlist", wordlist,
            "--json",
            "--output", tmpfile,
            "--depth", "3",
            "--threads", "50",
            "--no-state",
            "--silent",
            "--filter-status", "404",
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(proc.wait(), timeout=self.timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                logger.warning("feroxbuster timed out after %ds", self.timeout)
        except Exception as e:
            logger.warning("feroxbuster error: %s", e)

        routes: list[dict] = []
        try:
            if not os.path.exists(tmpfile):
                return routes
            with open(tmpfile) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if entry.get("type") != "response":
                        continue
                    url = entry.get("url", "")
                    status = entry.get("status", 0)
                    if not url or status in (301, 302, 404):
                        continue
                    if any(url.lower().endswith(ext) for ext in _SKIP_EXTENSIONS):
                        continue
                    routes.append({
                        "path": url,
                        "method": entry.get("method", "GET"),
                        "source": "feroxbuster",
                        "file": "",
                        "line": 0,
                        "auth_required": False,
                        "parameters": [],
                    })
        except (OSError, ValueError) as e:
            logger.warning("feroxbuster result parse error: %s", e)
        finally:
            try:
                os.unlink(tmpfile)
            except OSError:
                pass

        logger.info("feroxbuster discovered %d paths", len(routes))
        return routes
