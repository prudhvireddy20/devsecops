"""Path fuzzing via ffuf (Fuzz Faster U Fool).

Discovers hidden endpoints, admin panels, and backup files by fuzzing URL paths
with a wordlist. Feeds results into route list for ZAP spider seeding.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_DEFAULT_WORDLIST = "/usr/share/seclists/Discovery/Web-Content/common.txt"
_API_WORDLIST = "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt"
_FALLBACK_PATHS = [
    "/admin", "/api", "/backup", "/config", "/debug",
    "/login", "/logout", "/robots.txt", "/sitemap.xml",
    "/swagger", "/test", "/.env", "/.git/config",
]


class FfufEngine:
    """Fuzz hidden URL paths using ffuf."""

    def __init__(self, wordlist: str = _DEFAULT_WORDLIST):
        self.wordlist = wordlist

    async def fuzz(self, target_url: str, depth: int = 5) -> list[dict]:
        """Run ffuf against target and return discovered path dicts."""
        if not shutil.which("ffuf"):
            logger.warning("ffuf not found on PATH — falling back to static path list")
            return self._fallback()

        if not os.path.exists(self.wordlist):
            logger.warning("ffuf wordlist missing at %s — falling back to static list", self.wordlist)
            return self._fallback()

        parsed = urlparse(target_url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        routes = await self._fuzz_url(f"{base}/FUZZ", self.wordlist)

        # Second pass: API endpoint fuzzing (finds /api/v1/users, etc.)
        if os.path.exists(_API_WORDLIST):
            api_routes = await self._fuzz_url(f"{base}/api/FUZZ", _API_WORDLIST, timeout=60)
            existing_paths = {r["path"] for r in routes}
            for r in api_routes:
                if r["path"] not in existing_paths:
                    routes.append(r)

        logger.info("ffuf discovered %d paths", len(routes))
        return routes

    async def _fuzz_url(self, fuzz_url: str, wordlist: str, timeout: int = 120) -> list[dict]:
        """Run a single ffuf scan writing results to a temp file."""
        _fd, tmpfile = tempfile.mkstemp(suffix=".json")
        os.close(_fd)
        cmd = [
            "ffuf",
            "-u", fuzz_url,
            "-w", wordlist,
            "-ac",          # auto-calibrate to suppress false positives
            "-t", "50",     # 50 threads (aggressive for private no-WAF targets)
            "-p", "0",      # no delay between requests
            "-of", "json",  # output format
            "-o", tmpfile,  # write to temp file (ffuf doesn't support stdout JSON)
            "-s",           # silent: no banner
        ]
        proc = None
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                logger.warning("ffuf timed out on %s", fuzz_url)
        except Exception as e:
            logger.warning("ffuf error: %s", e)

        routes: list[dict] = []
        try:
            if os.path.exists(tmpfile):
                with open(tmpfile) as f:
                    result = json.load(f)
                for item in result.get("results", []):
                    path = item.get("url", "")
                    if path:
                        routes.append({
                            "path": path,
                            "method": "GET",
                            "source": "ffuf",
                            "file": "",
                            "line": 0,
                            "auth_required": False,
                            "parameters": [],
                        })
        except (json.JSONDecodeError, ValueError, OSError) as e:
            logger.warning("ffuf result parse error: %s", e)
        finally:
            try:
                os.unlink(tmpfile)
            except OSError:
                pass
        return routes

    def _fallback(self) -> list[dict]:
        return [{"path": p, "method": "GET", "source": "ffuf_fallback",
                 "file": "", "line": 0, "auth_required": False, "parameters": []}
                for p in _FALLBACK_PATHS]
