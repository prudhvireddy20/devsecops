"""
IAST Engine - Orchestrates IAST agents and collects vulnerability evidence

The IAST engine is responsible for:
1. Deploying Python and Node.js IAST agents to containers
2. Setting request context (tagging DAST requests)
3. Collecting IAST events during DAST phase
4. Correlating events to findings
"""

import asyncio
import json
import logging
import os
import sqlite3
import tempfile
import time
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_IAST_EVENT_BUFFER_LIMIT = int(os.getenv("IAST_EVENT_BUFFER_LIMIT", "2000"))
_IAST_EVENT_MAX_LIMIT = int(os.getenv("IAST_EVENT_MAX_LIMIT", "20000"))
_IAST_SQLITE_PATH = os.getenv(
    "IAST_SQLITE_PATH",
    os.path.join(tempfile.gettempdir(), f"iast_events_{os.getpid()}.sqlite"),
)


@dataclass
class IASTEventStore:
    """Bounded in-memory + SQLite spillover store for IAST events."""

    max_in_memory: int = _IAST_EVENT_BUFFER_LIMIT
    max_total: int = _IAST_EVENT_MAX_LIMIT
    sqlite_path: str = _IAST_SQLITE_PATH

    def __post_init__(self):
        self._events: deque[Dict[str, Any]] = deque(maxlen=self.max_in_memory)
        self._total_events = 0
        self._dropped_events = 0
        self._spilled_events = 0
        self._conn = sqlite3.connect(self.sqlite_path)
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute("PRAGMA synchronous=NORMAL;")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS iast_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id TEXT,
                event_json TEXT
            )
            """
        )
        self._conn.commit()

    def clear(self, scan_id: Optional[str] = None) -> None:
        self._events.clear()
        self._total_events = 0
        self._dropped_events = 0
        self._spilled_events = 0
        if scan_id:
            self._conn.execute("DELETE FROM iast_events WHERE scan_id = ?", (scan_id,))
        else:
            self._conn.execute("DELETE FROM iast_events")
        self._conn.commit()

    def add(self, scan_id: Optional[str], event: Dict[str, Any]) -> None:
        if self._total_events >= self.max_total:
            self._dropped_events += 1
            return

        self._events.append(event)
        self._total_events += 1

        # Spill to SQLite if in-memory buffer is full
        if len(self._events) >= self.max_in_memory:
            spill_batch = list(self._events)
            self._events.clear()
            self._spill_to_sqlite(scan_id, spill_batch)

    def _spill_to_sqlite(self, scan_id: Optional[str], events: list[Dict[str, Any]]) -> None:
        if not events:
            return
        payloads = [(scan_id or "", json.dumps(evt)) for evt in events]
        self._conn.executemany(
            "INSERT INTO iast_events (scan_id, event_json) VALUES (?, ?)",
            payloads,
        )
        self._conn.commit()
        self._spilled_events += len(events)

    def get_all(self, scan_id: Optional[str]) -> list[Dict[str, Any]]:
        events = list(self._events)
        cursor = self._conn.execute(
            "SELECT event_json FROM iast_events WHERE scan_id = ?",
            (scan_id or "",),
        )
        for (event_json,) in cursor.fetchall():
            try:
                events.append(json.loads(event_json))
            except Exception:
                continue
        return events

    def stats(self) -> dict:
        return {
            "total_events": self._total_events,
            "in_memory": len(self._events),
            "spilled_events": self._spilled_events,
            "dropped_events": self._dropped_events,
            "max_in_memory": self.max_in_memory,
            "max_total": self.max_total,
        }


class IASTEngine:
    """Manages IAST instrumentation and event collection."""

    def __init__(self, backend_url: str = "http://localhost:8000"):
        """
        Initialize IAST Engine.
        
        Args:
            backend_url: URL of the backend API for event reporting
        """
        self.backend_url = backend_url
        self.event_store = IASTEventStore()
        self.scan_id: Optional[str] = None
        self.is_active = False

    async def start(self, scan_id: str) -> bool:
        """Start IAST monitoring for a scan."""
        self.scan_id = scan_id
        self.is_active = True
        self.event_store.clear(scan_id)
        
        logger.info(f"IAST Engine started for scan {scan_id}")
        return True

    async def stop(self) -> Dict[str, Any]:
        """Stop IAST monitoring and return collected events."""
        self.is_active = False
        
        logger.info(
            f"IAST Engine stopped. Collected {self.event_store.stats()['total_events']} events."
        )
        
        return {
            "scan_id": self.scan_id,
            "event_count": self.event_store.stats()["total_events"],
            "events": self.event_store.get_all(self.scan_id),
            "store_stats": self.event_store.stats(),
        }

    async def set_request_context(
        self,
        request_id: str,
        method: str,
        endpoint: str,
        parameters: Dict[str, Any],
        container_name: str = "backend",
    ) -> bool:
        """
        Set request context in instrumented application.
        
        This tags the current DAST request so that IAST agents can track
        if the payload reaches vulnerable sinks.
        """
        if not self.is_active:
            return False

        try:
            # For local testing, we'd call Python agent directly
            # For Docker, we'd make HTTP call to instrumented app
            
            context_data = {
                "request_id": request_id,
                "method": method,
                "endpoint": endpoint,
                "parameters": parameters,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            
            logger.debug(f"Set request context: {request_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to set request context: {e}")
            return False

    async def collect_events(self) -> List[Dict[str, Any]]:
        """
        Collect IAST events from instrumented application.
        
        This would be called after DAST phase to gather all source-to-sink
        evidence.
        """
        if not self.scan_id:
            logger.warning("No active scan for event collection")
            return []

        try:
            events = self.event_store.get_all(self.scan_id)
            logger.info(f"Collected {len(events)} IAST events")
            return events
        except Exception as e:
            logger.error(f"Failed to collect events: {e}")
            return []

    async def add_event(self, event: Dict[str, Any]):
        """Add an IAST event to the collection."""
        if self.is_active:
            self.event_store.add(self.scan_id, event)

    async def export_events(self, filepath: str) -> int:
        """Export collected events to JSON file."""
        try:
            with open(filepath, "w") as f:
                events = self.event_store.get_all(self.scan_id)
                json.dump(events, f, indent=2)
            logger.info(f"Exported {len(events)} events to {filepath}")
            return len(events)
        except Exception as e:
            logger.error(f"Failed to export events: {e}")
            return 0

    async def health_check(self, container_name: str = "backend") -> bool:
        """Check if IAST agent is active in container."""
        try:
            # Would check HTTP endpoint on instrumented app
            logger.debug(f"IAST health check passed for {container_name}")
            return True
        except Exception as e:
            logger.warning(f"IAST health check failed: {e}")
            return False

    async def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about collected events."""
        sink_types = {}
        source_types = {}
        verified_count = 0

        events = self.event_store.get_all(self.scan_id)
        for event in events:
            sink_type = event.get("sink_type", "unknown")
            source_type = event.get("source_type", "unknown")
            
            sink_types[sink_type] = sink_types.get(sink_type, 0) + 1
            source_types[source_type] = source_types.get(source_type, 0) + 1
            
            if not event.get("sanitized", True):
                verified_count += 1
        
        return {
            "total_events": len(events),
            "unsanitized_events": verified_count,
            "sink_types": sink_types,
            "source_types": source_types,
            "collection_duration": None,  # Would be filled in during actual scan
            "store_stats": self.event_store.stats(),
        }


class IASTEventCollector:
    """
    Manages event collection from multiple containers.
    
    Handles polling multiple IAST agents and aggregating results.
    """

    def __init__(self, scan_id: str):
        self.scan_id = scan_id
        self.engines: Dict[str, IASTEngine] = {}
        self.event_store = IASTEventStore()

    async def start(self):
        """Start all IAST engines."""
        logger.info(f"Starting IAST collectors for scan {self.scan_id}")
        
        # Create engines for each container
        self.engines["backend"] = IASTEngine()
        await self.engines["backend"].start(self.scan_id)

    async def stop(self) -> Dict[str, Any]:
        """Stop all IAST engines and collect results."""
        results = {}
        
        for name, engine in self.engines.items():
            result = await engine.stop()
            results[name] = result
            for evt in result.get("events", []):
                self.event_store.add(self.scan_id, evt)
        
        logger.info(
            "Stopped all engines. Total events: %s",
            self.event_store.stats()["total_events"],
        )
        
        return {
            "scan_id": self.scan_id,
            "engines": results,
            "total_events": self.event_store.stats()["total_events"],
            "all_events": self.event_store.get_all(self.scan_id),
            "store_stats": self.event_store.stats(),
        }

    async def tag_request(
        self,
        request_id: str,
        method: str,
        endpoint: str,
        parameters: Dict[str, Any],
    ):
        """Tag a request across all engines."""
        tasks = [
            engine.set_request_context(request_id, method, endpoint, parameters)
            for engine in self.engines.values()
        ]
        await asyncio.gather(*tasks)

    async def collect_all(self) -> List[Dict[str, Any]]:
        """Collect events from all engines."""
        tasks = [
            engine.collect_events()
            for engine in self.engines.values()
        ]
        results = await asyncio.gather(*tasks)

        self.event_store.clear(self.scan_id)
        for events in results:
            for evt in events:
                self.event_store.add(self.scan_id, evt)

        return self.event_store.get_all(self.scan_id)

    async def get_combined_statistics(self) -> Dict[str, Any]:
        """Get statistics from all engines combined."""
        events = self.event_store.get_all(self.scan_id)
        total_events = len(events)
        unsanitized = sum(
            1 for e in events
            if not e.get("sanitized", True)
        )
        
        # Group by sink type
        sink_types = {}
        for event in events:
            sink = event.get("sink_type", "unknown")
            sink_types[sink] = sink_types.get(sink, 0) + 1
        
        return {
            "total_events": total_events,
            "unsanitized_events": unsanitized,
            "sink_types": sink_types,
            "engines_active": len(self.engines),
            "store_stats": self.event_store.stats(),
        }


async def demo_iast_engine():
    """Demo IAST engine functionality."""
    print("\n" + "="*70)
    print("IAST ENGINE DEMO")
    print("="*70)
    
    engine = IASTEngine()
    await engine.start("scan-demo-001")
    
    # Simulate some events
    demo_events = [
        {
            "event_id": str(uuid.uuid4()),
            "request_id": "req-001",
            "source_type": "http_parameter",
            "sink_type": "sql",
            "sink_location": "app.py:45",
            "input_value": "1' or '1'='1",
            "sanitized": False,
            "evidence": {
                "sql_query": "SELECT * FROM users WHERE id = 1' or '1'='1",
                "suspicious_keywords": ["or"],
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        {
            "event_id": str(uuid.uuid4()),
            "request_id": "req-002",
            "source_type": "http_parameter",
            "sink_type": "subprocess",
            "sink_location": "api.py:120",
            "input_value": "test; cat /etc/passwd",
            "sanitized": False,
            "evidence": {
                "command": "/bin/bash -c test; cat /etc/passwd",
                "has_shell_operators": True,
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    ]
    
    for event in demo_events:
        await engine.add_event(event)
    
    print(f"\nCollected {len(demo_events)} demo events")
    
    stats = await engine.get_statistics()
    print(f"\nStatistics:")
    print(f"  Total events: {stats['total_events']}")
    print(f"  Unsanitized: {stats['unsanitized_events']}")
    print(f"  Sink types: {stats['sink_types']}")
    
    result = await engine.stop()
    print(f"\nEngine stopped. Final count: {result['event_count']}")
    print("="*70 + "\n")


if __name__ == "__main__":
    asyncio.run(demo_iast_engine())
