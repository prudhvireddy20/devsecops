"""Server audit via Nikto.

Detects server misconfigurations, default credentials, outdated software,
and dangerous HTTP methods.
"""
import asyncio
import json
import logging
import shutil

logger = logging.getLogger(__name__)


class NiktoEngine:
    """Audit server configuration using Nikto."""

    def __init__(self, timeout: int = 300):
        self.timeout = timeout

    async def scan(self, target_url: str) -> list[dict]:
        """Run Nikto against target and return finding dicts."""
        if not shutil.which("nikto"):
            logger.warning("nikto not found on PATH — skipping server audit")
            return []

        cmd = ["nikto", "-h", target_url, "-Format", "json", "-nointeractive", "-maxtime", "240"]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                logger.warning("nikto timed out")
                return []
        except Exception as e:
            logger.warning("nikto error: %s", e)
            return []

        if proc.returncode not in (0, None):
            logger.warning("nikto exited %d", proc.returncode)
            return []

        findings: list[dict] = []
        try:
            data = json.loads(stdout.decode())
            for item in data if isinstance(data, list) else [data]:
                for vuln in item.get("vulnerabilities", []):
                    findings.append({
                        "title": vuln.get("message", "Nikto Finding"),
                        "vulnerability_type": "config",
                        "severity": _nikto_severity(vuln.get("osvdb", 0)),
                        "cwe": "",
                        "file_path": "",
                        "line_number": 0,
                        "code_snippet": "",
                        "endpoint": item.get("host", target_url),
                        "parameter": "",
                        "rule_id": f"nikto-{vuln.get('id', '')}",
                        "remediation": vuln.get("remediation", ""),
                        "raw": vuln,
                    })
        except (json.JSONDecodeError, ValueError):
            logger.warning("nikto output not valid JSON")
            return []

        return findings


def _nikto_severity(osvdb: int) -> str:
    """Map Nikto OSVDB severity to TraceON severity."""
    if osvdb > 0:
        return "high" if osvdb < 5000 else "medium"
    return "low"
