"""Nuclei CLI wrapper for extended DAST scanning.

Runs the `nuclei` binary with the target URL and parses its JSON output
into the standard finding format used by the correlation engine.
Gracefully handles missing CLI or execution failures.
"""
import asyncio
import json
import logging
import shutil
from pathlib import Path
from typing import Any

from app.core.config import settings

logger = logging.getLogger(__name__)

NUCLEI_SEVERITY_MAP = {
    "critical": "critical",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "info",
    "unknown": "medium",
}

NUCLEI_VULN_MAP: dict[str, str] = {
    "cve": "cve",
    "cms": "cms",
    "exposure": "exposure",
    "generic": "generic",
    "misconfiguration": "config",
    "osint": "info",
    "tech": "tech",
    "vulnerability": "vuln",
    "wordpress": "cms",
}


async def run_nuclei(
    target_url: str,
    templates: str | None = None,
    severity: str = "medium,high,critical",
    rate_limit: int = settings.NUCLEI_DEFAULT_RATE_LIMIT,
    timeout: int = 300,
) -> list[dict[str, Any]]:
    """Run nuclei against *target_url* and return parsed findings.

    Args:
        target_url: Full URL including scheme (e.g. ``https://example.com``).
        templates: Optional path to template directory or file.  Defaults to
            nuclei's built-in template store.
        severity: Comma-separated severity filter.
        rate_limit: Maximum requests per second.
        timeout: Overall timeout for the nuclei process.

    Returns:
        List of finding dicts compatible with the correlation engine.
        Empty list if nuclei is not installed, no results, or an error occurs.
    """
    if not shutil.which("nuclei"):
        logger.info("nuclei CLI not found — skipping extended DAST")
        return []

    cmd = [
        "nuclei",
        "-u", target_url,
        "-json",
        "-severity", severity,
        "-rate-limit", str(rate_limit),
        "-no-color",
    ]
    if templates:
        cmd.extend(["-t", templates])

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=1024 * 1024,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            logger.warning("nuclei timed out after %ds", timeout)
            return []

        if proc.returncode not in (0, None):
            stderr_text = stderr.decode(errors="replace")[:2000]
            logger.warning("nuclei exited with code %d: %s", proc.returncode, stderr_text)
        if not stdout:
            return []

        findings: list[dict[str, Any]] = []
        for line in stdout.decode(errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue

            finding = _parse_nuclei_result(raw)
            if finding:
                findings.append(finding)

        return findings

    except FileNotFoundError:
        logger.info("nuclei CLI not found — skipping extended DAST")
        return []
    except Exception as exc:
        logger.warning("nuclei execution failed: %s", exc)
        return []


def _parse_nuclei_result(raw: dict[str, Any]) -> dict[str, Any] | None:
    """Convert a single nuclei JSON result line into a standard finding dict."""
    template_id = raw.get("template-id", "") or ""
    if not template_id:
        return None

    name = raw.get("name", "") or template_id
    severity_raw = (raw.get("info", {}) or {}).get("severity", "medium") or "medium"
    severity = NUCLEI_SEVERITY_MAP.get(severity_raw.lower(), "medium")

    vuln_type = "generic"
    tags = raw.get("info", {}).get("tags", [])
    if isinstance(tags, str):
        tags = [tags]
    for tag in tags:
        mapped = NUCLEI_VULN_MAP.get(tag.lower())
        if mapped:
            vuln_type = mapped
            break

    matcher_name = raw.get("matcher-name", "")
    description_parts = [name]
    if matcher_name:
        description_parts.append(f"({matcher_name})")
    description = " — ".join(description_parts)

    extracted_results = raw.get("extracted-results", [])
    request_data = raw.get("request", "")
    response_data = raw.get("response", "")

    finding: dict[str, Any] = {
        "title": f"[Nuclei] {name}",
        "description": description,
        "severity": severity,
        "vulnerability_type": vuln_type,
        "source": "nuclei",
        "endpoint": raw.get("host", ""),
        "file_path": "",
        "line_number": 0,
        "details": {
            "template_id": template_id,
            "matcher_name": matcher_name,
            "matched_at": raw.get("matched-at", ""),
            "extracted_results": extracted_results,
            "request": request_data,
            "response": response_data,
            "tags": tags,
            "raw": raw,
        },
    }

    cve_id = raw.get("info", {}).get("classification", {}).get("cve-id", "")
    if cve_id:
        finding["cve"] = cve_id

    return finding
