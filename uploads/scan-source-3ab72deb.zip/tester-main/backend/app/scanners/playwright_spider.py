"""Playwright-based JS spider for discovering routes in SPA applications.

Uses a real Chromium browser to navigate and capture all network requests,
finding routes that ZAP's traditional spider misses in React/Vue/Angular apps.
"""
import asyncio
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_SKIP_EXTENSIONS = {
    ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".ico",
    ".woff", ".woff2", ".ttf", ".svg", ".mp4", ".mp3",
    ".pdf", ".zip", ".gz", ".map",
}
_API_RESOURCE_TYPES = {"document", "xhr", "fetch"}


async def playwright_crawl(target_url: str, timeout: int = 60) -> list[str]:
    """Crawl a JS-rendered app with Chromium to discover routes.

    Returns a list of full URLs found via navigation, XHR, fetch, and anchor links.
    Falls back silently if Playwright or Chromium is not installed.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        logger.debug("playwright Python package not installed — skipping JS spider")
        return []

    target_parsed = urlparse(target_url)
    discovered: set[str] = set()

    def _capture(url: str) -> None:
        try:
            p = urlparse(url)
            if p.netloc != target_parsed.netloc:
                return
            path = p.path or "/"
            suffix = "." + path.rsplit(".", 1)[-1].lower() if "." in path.split("/")[-1] else ""
            if suffix in _SKIP_EXTENSIONS:
                return
            clean = f"{p.scheme}://{p.netloc}{path}"
            discovered.add(clean)
        except Exception:
            pass

    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
            )
            context = await browser.new_context(ignore_https_errors=True)
            page = await context.new_page()

            # Capture XHR/fetch/navigation requests
            page.on("request", lambda req: _capture(req.url) if req.resource_type in _API_RESOURCE_TYPES else None)

            try:
                await asyncio.wait_for(
                    page.goto(target_url, wait_until="networkidle"),
                    timeout=timeout * 0.6,
                )
            except Exception:
                try:
                    await asyncio.wait_for(
                        page.goto(target_url, wait_until="domcontentloaded"),
                        timeout=timeout * 0.3,
                    )
                except Exception as e:
                    logger.warning("Playwright could not load %s: %s", target_url, e)
                    await browser.close()
                    return []

            # Wait for JS to settle
            await asyncio.sleep(3)

            # Harvest all <a href> links rendered in the DOM
            try:
                links = await page.eval_on_selector_all(
                    "a[href]", "els => els.map(e => e.href)"
                )
                for link in links:
                    _capture(link)
            except Exception:
                pass

            await browser.close()

    except Exception as e:
        logger.warning("Playwright spider error: %s", e)
        return []

    result = sorted(discovered)
    logger.info("Playwright JS spider discovered %d unique URLs", len(result))
    return result
