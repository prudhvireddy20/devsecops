"""Journey replay adapters for HAR/Playwright/Cypress exported flows.

This module focuses on pragmatic flow ingestion and deterministic request replay
to improve route coverage and expose deep business paths before active DAST.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin, urlparse

import httpx

from app.core.url_safety import validate_external_target_url
from app.utils.normalizers import normalize_path

logger = logging.getLogger(__name__)


def _resolve_paths(value, project_root: str) -> list[Path]:
    if not value:
        return []

    items: list[str] = []
    if isinstance(value, str):
        items = [x.strip() for x in value.split(",")]
    elif isinstance(value, list):
        items = [str(v).strip() for v in value if isinstance(v, (str, Path))]

    root = Path(project_root)
    resolved: list[Path] = []
    for item in items:
        if not item:
            continue
        p = Path(item)
        if not p.is_absolute():
            p = root / p
        if p.exists() and p.is_file():
            resolved.append(p)
        else:
            logger.warning("Journey replay file not found: %s", p)
    return resolved


def _har_steps(payload: dict, source_file: str) -> list[dict]:
    entries = payload.get("log", {}).get("entries", [])
    if not isinstance(entries, list):
        return []

    out: list[dict] = []
    for idx, e in enumerate(entries, 1):
        if not isinstance(e, dict):
            continue
        req = e.get("request", {})
        if not isinstance(req, dict):
            continue
        url = str(req.get("url", "")).strip()
        method = str(req.get("method", "GET")).upper()
        if not url:
            continue
        out.append({
            "step": idx,
            "method": method,
            "url": url,
            "path": normalize_path(url),
            "source": "har",
            "source_file": source_file,
        })
    return out


def _request_from_node(node: dict) -> dict | None:
    req = node.get("request") if isinstance(node, dict) else None
    if isinstance(req, dict):
        method = str(req.get("method", "GET")).upper()
        url_obj = req.get("url")
        if isinstance(url_obj, dict):
            raw = str(url_obj.get("raw", "")).strip()
            path_obj = url_obj.get("path")
            if not raw and isinstance(path_obj, list):
                raw = "/" + "/".join(str(x).strip("/") for x in path_obj if str(x).strip("/"))
            if raw:
                return {"method": method, "url": raw}
        if isinstance(url_obj, str) and url_obj.strip():
            return {"method": method, "url": url_obj.strip()}
    return None


def _walk_postman_like(node) -> Iterable[dict]:
    if isinstance(node, list):
        for n in node:
            yield from _walk_postman_like(n)
        return
    if not isinstance(node, dict):
        return

    req = _request_from_node(node)
    if req:
        yield req

    child = node.get("item")
    if child is not None:
        yield from _walk_postman_like(child)


def _generic_steps(payload, source_file: str) -> list[dict]:
    """Parse generic Playwright/Cypress exported structures.

    Supported shapes:
    - {"steps": [{"url": ..., "method": ...}, ...]}
    - [{"url": ..., "method": ...}, ...]
    - Postman-like nested {"item": [...]} request objects
    """
    rows = []
    if isinstance(payload, dict) and isinstance(payload.get("steps"), list):
        rows = payload["steps"]
    elif isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict) and payload.get("item") is not None:
        rows = list(_walk_postman_like(payload.get("item")))

    out: list[dict] = []
    for idx, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            continue
        method = str(row.get("method", "GET")).upper()
        url = str(row.get("url") or row.get("path") or "").strip()
        if not url:
            continue
        source = str(row.get("source", "journey")).lower()
        out.append({
            "step": idx,
            "method": method,
            "url": url,
            "path": normalize_path(url),
            "source": source,
            "source_file": source_file,
        })
    return out


def load_journey_steps(project_root: str, scan_config: dict | None) -> dict:
    """Load journey replay steps from configured files."""
    cfg = scan_config or {}
    files = _resolve_paths(cfg.get("journey_replay_files"), project_root)

    all_steps: list[dict] = []
    for p in files:
        source_file = str(p)
        try:
            payload = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except Exception as exc:
            logger.warning("Failed to parse journey file %s: %s", p, exc)
            continue

        steps = []
        if isinstance(payload, dict) and isinstance(payload.get("log"), dict):
            steps = _har_steps(payload, source_file)
        else:
            steps = _generic_steps(payload, source_file)

        all_steps.extend(steps)

    # Deduplicate by method+path while preserving earliest step metadata.
    seen = set()
    unique_steps: list[dict] = []
    for step in all_steps:
        sig = (step.get("method", "GET"), step.get("path", "/"))
        if sig in seen:
            continue
        seen.add(sig)
        unique_steps.append(step)

    routes = [
        {
            "path": step["path"],
            "methods": [step.get("method", "GET")],
            "handler": "journey_replay",
            "source": f"journey_replay:{step.get('source', 'generic')}",
            "tested": False,
        }
        for step in unique_steps
    ]

    return {
        "files": [str(p) for p in files],
        "steps": unique_steps,
        "routes": routes,
    }


def _build_request_url(target_url: str, step_url: str) -> str:
    parsed = urlparse(step_url)
    if parsed.scheme and parsed.netloc:
        target_host = (urlparse(target_url).hostname or "").lower()
        step_host = (parsed.hostname or "").lower()
        if target_host and step_host and step_host != target_host:
            raise ValueError(
                f"Journey step host '{step_host}' does not match target host '{target_host}'"
            )
        return step_url
    return urljoin(target_url.rstrip("/") + "/", step_url.lstrip("/"))


def _assert_safe_url(url: str) -> None:
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("Invalid replay URL")
    base = f"{parsed.scheme}://{parsed.netloc}"
    ok, err = validate_external_target_url(base)
    if not ok:
        raise ValueError(f"Unsafe replay URL: {err}")


def _build_cookie_header(cookies: list[dict]) -> str:
    pairs = []
    for c in cookies:
        name = str(c.get("name", "")).strip()
        value = str(c.get("value", "")).strip()
        if name:
            pairs.append(f"{name}={value}")
    return "; ".join(pairs)


def _send_request(
    method: str,
    url: str,
    headers: dict[str, str],
    timeout: int,
    proxy_url: str = "",
) -> int:
    _assert_safe_url(url)
    if proxy_url:
        _assert_safe_url(proxy_url)
    with httpx.Client(timeout=timeout, follow_redirects=False, proxy=proxy_url or None) as client:
        resp = client.request(method, url, headers=headers)
    return int(resp.status_code)


async def replay_steps(
    *,
    target_url: str,
    steps: list[dict],
    auth: dict | None,
    timeout: int = 12,
    proxy_url: str = "",
) -> dict:
    """Replay journey steps as warm-up requests to improve scan realism."""
    _assert_safe_url(target_url)
    if not steps:
        return {"executed": 0, "failed": 0, "sample_errors": []}

    headers: dict[str, str] = {}
    if auth and auth.get("token"):
        headers["Authorization"] = f"Bearer {auth['token']}"
    if auth and auth.get("cookies"):
        cookie_header = _build_cookie_header(auth.get("cookies", []))
        if cookie_header:
            headers["Cookie"] = cookie_header

    executed = 0
    failed = 0
    errors: list[str] = []
    proxied = 0
    for step in steps:
        method = str(step.get("method", "GET")).upper()
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
            method = "GET"
        url = _build_request_url(target_url, str(step.get("url") or step.get("path") or "/"))
        try:
            await asyncio.to_thread(_send_request, method, url, headers, timeout, "")
            executed += 1
        except httpx.HTTPStatusError:
            # Non-2xx still indicates request reached the target.
            executed += 1
        except (httpx.HTTPError, TimeoutError, OSError, ValueError) as exc:
            if proxy_url:
                try:
                    await asyncio.to_thread(_send_request, method, url, headers, timeout, proxy_url)
                    proxied += 1
                    executed += 1
                    continue
                except httpx.HTTPStatusError:
                    proxied += 1
                    executed += 1
                    continue
                except Exception as proxy_exc:  # noqa: BLE001 - best effort fallback
                    failed += 1
                    if len(errors) < 5:
                        errors.append(f"{method} {url}: direct={exc}; proxied={proxy_exc}")
            else:
                failed += 1
                if len(errors) < 5:
                    errors.append(f"{method} {url}: {exc}")
        except Exception as exc:  # noqa: BLE001 - best-effort replay
            failed += 1
            if len(errors) < 5:
                errors.append(f"{method} {url}: {exc}")

    return {
        "executed": executed,
        "failed": failed,
        "proxied": proxied,
        "sample_errors": errors,
    }
