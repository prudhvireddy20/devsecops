"""Spec import adapters for OpenAPI and Postman route seeding.

This module provides optional, file-based seed extraction that complements
runtime OpenAPI probing in DASTEngine.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from urllib.parse import urlparse

from app.utils.normalizers import normalize_path

logger = logging.getLogger(__name__)


def _load_json_or_yaml(file_path: Path) -> dict:
    content = file_path.read_text(encoding="utf-8", errors="replace")
    try:
        parsed = json.loads(content)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        pass

    # Optional YAML support when dependency is available.
    try:
        import yaml  # type: ignore

        parsed = yaml.safe_load(content)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _resolve_paths(value, project_root: str) -> list[Path]:
    if not value:
        return []

    raw_items: list[str] = []
    if isinstance(value, str):
        raw_items = [part.strip() for part in value.split(",")]
    elif isinstance(value, list):
        for v in value:
            if isinstance(v, (str, Path)):
                raw_items.extend(str(v).split(","))

    root = Path(project_root)
    results: list[Path] = []
    for raw in raw_items:
        raw = raw.strip()
        if not raw:
            continue
        candidate = Path(raw)
        if not candidate.is_absolute():
            candidate = root / candidate
        if candidate.exists() and candidate.is_file():
            results.append(candidate)
        else:
            logger.warning("Spec adapter file not found: %s", candidate)
    return results


def load_openapi_routes(file_paths: list[Path]) -> list[dict]:
    routes: list[dict] = []
    seen: set[tuple[str, tuple[str, ...]]] = set()
    for file_path in file_paths:
        spec = _load_json_or_yaml(file_path)
        paths = spec.get("paths", {}) if isinstance(spec, dict) else {}
        if not isinstance(paths, dict):
            continue

        for path, methods_obj in paths.items():
            if not isinstance(methods_obj, dict):
                continue

            methods = [
                m.upper()
                for m in methods_obj.keys()
                if m.lower() in ("get", "post", "put", "patch", "delete", "head", "options")
            ]
            normalized = normalize_path(str(path))
            sig = (normalized, tuple(sorted(methods or ["GET"])))
            if sig in seen:
                continue
            seen.add(sig)
            routes.append({
                "path": normalized,
                "methods": methods or ["GET"],
                "handler": "openapi_file",
                "source": "openapi_file_import",
                "tested": False,
            })

    return routes


def _extract_postman_items(node) -> list[dict]:
    items: list[dict] = []
    if isinstance(node, list):
        for n in node:
            items.extend(_extract_postman_items(n))
        return items

    if not isinstance(node, dict):
        return items

    request = node.get("request")
    if isinstance(request, dict):
        items.append(request)

    child_items = node.get("item")
    if child_items:
        items.extend(_extract_postman_items(child_items))
    return items


def _postman_path_from_request(req: dict) -> str:
    url_obj = req.get("url")
    if isinstance(url_obj, str):
        return normalize_path(url_obj)

    if isinstance(url_obj, dict):
        if isinstance(url_obj.get("raw"), str):
            return normalize_path(url_obj["raw"])

        path = url_obj.get("path")
        if isinstance(path, list):
            joined = "/".join(str(p).strip("/") for p in path if str(p).strip("/"))
            return normalize_path("/" + joined)
        if isinstance(path, str):
            return normalize_path(path)

    return "/"


def load_postman_routes(file_paths: list[Path]) -> list[dict]:
    routes: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for file_path in file_paths:
        collection = _load_json_or_yaml(file_path)
        requests = _extract_postman_items(collection.get("item", []))
        for req in requests:
            method = str(req.get("method", "GET")).upper()
            path = _postman_path_from_request(req)
            sig = (path, method)
            if sig in seen:
                continue
            seen.add(sig)
            routes.append({
                "path": path,
                "methods": [method],
                "handler": "postman_collection",
                "source": "postman_import",
                "tested": False,
            })
    return routes


def load_spec_seed_routes(project_root: str, scan_config: dict | None) -> dict:
    """Load optional file-based route seeds from scan_config.

    Supported config keys:
      - openapi_spec_file: str | list[str]
      - postman_collection_file: str | list[str]
    """
    cfg = scan_config or {}
    openapi_files = _resolve_paths(cfg.get("openapi_spec_file"), project_root)
    postman_files = _resolve_paths(cfg.get("postman_collection_file"), project_root)

    openapi_routes = load_openapi_routes(openapi_files)
    postman_routes = load_postman_routes(postman_files)

    return {
        "openapi_routes": openapi_routes,
        "postman_routes": postman_routes,
        "openapi_files": [str(p) for p in openapi_files],
        "postman_files": [str(p) for p in postman_files],
    }
