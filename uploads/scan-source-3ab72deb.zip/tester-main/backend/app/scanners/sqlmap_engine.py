"""SQL injection scanner via sqlmap.

Runs sqlmap in batch mode against the target with low risk/level settings
to detect injectable parameters without causing data modification.
Parses stdout for CRITICAL-level and heuristic-level injection findings.
"""
import asyncio
import logging
import re
import shutil
import tempfile
import os

logger = logging.getLogger(__name__)

_CRITICAL_RE = re.compile(
    r"\[CRITICAL\]\s+(.+?)\s+appears to be\s+'(.+?)'\s+injectable",
    re.IGNORECASE,
)
_WARNING_RE = re.compile(
    r"\[WARNING\]\s+heuristic.*?parameter\s+'(.+?)'\s+might be injectable",
    re.IGNORECASE,
)


class SqlmapEngine:
    """Detect SQL injection using sqlmap."""

    def __init__(self, timeout: int = 600):
        self.timeout = timeout

    async def scan(self, target_url: str) -> list[dict]:
        """Run sqlmap and return injection findings."""
        if not shutil.which("sqlmap"):
            logger.warning("sqlmap not found on PATH — skipping SQL injection scan")
            return []

        tmpdir = tempfile.mkdtemp(prefix="sqlmap_")
        try:
            cmd = [
                "sqlmap",
                "-u", target_url,
                "--batch",
                "--level=2",
                "--risk=1",
                "--crawl=2",
                "--forms",
                "--flush-session",
                "--smart",
                "--output-dir", tmpdir,
            ]
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                try:
                    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
                except asyncio.TimeoutError:
                    proc.kill()
                    await proc.wait()
                    logger.warning("sqlmap timed out after %ds", self.timeout)
                    return []
            except Exception as e:
                logger.warning("sqlmap execution error: %s", e)
                return []

            findings: list[dict] = []
            output = stdout.decode(errors="replace")
            seen: set[str] = set()
            for line in output.splitlines():
                m = _CRITICAL_RE.search(line)
                if m:
                    param_desc = m.group(1).strip()
                    injection_type = m.group(2).strip()
                    key = f"{param_desc}::{injection_type}"
                    if key in seen:
                        continue
                    seen.add(key)
                    findings.append({
                        "title": f"[SQLMap] SQL Injection — {param_desc}",
                        "description": f"Parameter appears injectable via: {injection_type}",
                        "vulnerability_type": "sqli",
                        "severity": "high",
                        "cwe": "89",
                        "file_path": "",
                        "line_number": 0,
                        "code_snippet": "",
                        "endpoint": target_url,
                        "parameter": param_desc,
                        "rule_id": "sqlmap-sqli",
                        "remediation": "Use parameterized queries / prepared statements. Never concatenate user input into SQL.",
                        "source": "sqlmap",
                        "raw": {"injection_type": injection_type, "output_line": line.strip()},
                    })
                    continue

                w = _WARNING_RE.search(line)
                if w:
                    param_desc = w.group(1).strip()
                    key = f"{param_desc}::heuristic"
                    if key in seen:
                        continue
                    seen.add(key)
                    findings.append({
                        "title": f"[SQLMap] Possible SQL Injection — {param_desc}",
                        "description": "Heuristic test suggests parameter may be injectable. Manual verification recommended.",
                        "vulnerability_type": "sqli",
                        "severity": "medium",
                        "cwe": "89",
                        "file_path": "",
                        "line_number": 0,
                        "code_snippet": "",
                        "endpoint": target_url,
                        "parameter": param_desc,
                        "rule_id": "sqlmap-sqli-heuristic",
                        "remediation": "Use parameterized queries / prepared statements. Never concatenate user input into SQL.",
                        "source": "sqlmap",
                        "raw": {"output_line": line.strip()},
                    })

            if findings:
                logger.info("sqlmap found %d injectable parameter(s)", len(findings))
            else:
                logger.info("sqlmap: no SQL injection found")
            return findings
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
