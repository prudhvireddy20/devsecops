"""TLS/SSL audit via testssl.sh.

testssl.sh provides deep TLS configuration analysis beyond what ZAP and
nikto check: weak ciphers, BEAST, POODLE, DROWN, SWEET32, certificate
chain issues, HSTS/HPKP, and more.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from pathlib import Path
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_SEVERITY_MAP = {
    "CRITICAL": "critical",
    "HIGH": "high",
    "MEDIUM": "medium",
    "LOW": "low",
    "INFO": "info",
    "WARN": "medium",
    "OK": "info",
    "NOT applicable": "info",
}

_SKIP_SEVERITIES = {"OK", "INFO", "NOT applicable", "DEBUG"}


class TestsslEngine:
    """Audit TLS/SSL configuration using testssl.sh."""

    def __init__(self, timeout: int = 300):
        self.timeout = timeout

    async def scan(self, target_url: str) -> list[dict]:
        """Run testssl.sh and return TLS findings."""
        binary = shutil.which("testssl") or shutil.which("testssl.sh")
        if not binary:
            logger.warning("testssl.sh not found on PATH — skipping TLS audit")
            return []

        parsed = urlparse(target_url)
        if parsed.scheme not in ("https", "http"):
            logger.info("testssl: skipping non-HTTP target")
            return []

        host = parsed.netloc
        if not host:
            return []

        _fd, tmpfile = tempfile.mkstemp(suffix=".json", prefix="testssl_")
        os.close(_fd)

        cmd = [
            binary,
            "--quiet",
            "--jsonfile", tmpfile,
            "--color", "0",
            "--warnings", "off",
            host,
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(proc.wait(), timeout=self.timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                logger.warning("testssl timed out after %ds", self.timeout)
                return []
        except Exception as e:
            logger.warning("testssl error: %s", e)
            return []

        findings: list[dict] = []
        try:
            if not os.path.exists(tmpfile):
                return findings
            raw_text = Path(tmpfile).read_text(errors="replace").strip()
            if not raw_text:
                return findings
            data = json.loads(raw_text)
            for item in data if isinstance(data, list) else [data]:
                severity_raw = item.get("severity", "INFO")
                if severity_raw in _SKIP_SEVERITIES:
                    continue
                finding_text = item.get("finding", "")
                test_id = item.get("id", "")
                findings.append({
                    "title": f"[testssl] {item.get('id', 'TLS Issue')} — {finding_text[:80]}",
                    "description": finding_text,
                    "vulnerability_type": "tls",
                    "severity": _SEVERITY_MAP.get(severity_raw, "medium"),
                    "cwe": _cwe_for_id(test_id),
                    "file_path": "",
                    "line_number": 0,
                    "code_snippet": "",
                    "endpoint": target_url,
                    "parameter": "",
                    "rule_id": f"testssl-{test_id}",
                    "remediation": _remediation_for_id(test_id),
                    "source": "testssl",
                    "raw": item,
                })
        except (json.JSONDecodeError, ValueError, OSError) as e:
            logger.warning("testssl result parse error: %s", e)
        finally:
            try:
                os.unlink(tmpfile)
            except OSError:
                pass

        if findings:
            logger.info("testssl found %d TLS issue(s)", len(findings))
        return findings


def _cwe_for_id(test_id: str) -> str:
    _CWE = {
        "BEAST": "311", "POODLE_SSL": "310", "CRIME_TLS": "311",
        "SWEET32": "326", "DROWN": "310", "LOGJAM": "326",
        "FREAK": "326", "RC4": "326", "weak_cipher": "326",
        "expiration": "295", "hostname": "297", "self_signed": "295",
    }
    for key, cwe in _CWE.items():
        if key.lower() in test_id.lower():
            return cwe
    return "326"


def _remediation_for_id(test_id: str) -> str:
    tid = test_id.lower()
    if "beast" in tid:
        return "Disable TLS 1.0 and enable server-side cipher order with AES-GCM ciphers."
    if "poodle" in tid:
        return "Disable SSLv3 and TLS 1.0. Enforce TLS 1.2 minimum."
    if "sweet32" in tid:
        return "Disable 3DES ciphers. Prefer AES-GCM-128/256."
    if "crime" in tid:
        return "Disable TLS/HTTP compression."
    if "rc4" in tid or "weak_cipher" in tid:
        return "Remove RC4 and other weak ciphers from server configuration."
    if "expir" in tid:
        return "Renew the TLS certificate before it expires."
    if "self_signed" in tid:
        return "Replace self-signed certificate with a CA-signed certificate for production."
    return "Review TLS configuration and disable deprecated protocols/ciphers."
