"""Alternative DAST via Wapiti.

Covers attack vectors not fully covered by ZAP: XXE, LDAP injection,
CRLF injection, open redirect, and Server-Side Request Forgery.

Off by default in black-box mode — users can enable via toggle.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)

_MODULES = ["xxe", "ldapi", "crlf", "redirect", "ssrf", "sql", "xss", "file"]


class WapitiEngine:
    """Run Wapiti DAST scans against a target URL."""

    def __init__(self, timeout: int = 600):
        self.timeout = timeout

    async def scan(self, target_url: str, modules: list[str] | None = None) -> list[dict]:
        """Run Wapiti and return finding dicts."""
        if not shutil.which("wapiti"):
            logger.warning("wapiti not found on PATH — skipping Wapiti scan")
            return []

        mods = modules or _MODULES
        _fd, output = tempfile.mkstemp(suffix=".json", prefix="wapiti_")
        os.close(_fd)

        cmd = [
            "wapiti", "-u", target_url,
            "-m", ",".join(mods),
            "-f", "json",
            "-o", output,
            "--no-bugreport",
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
        except asyncio.TimeoutError:
            logger.warning("wapiti timed out")
            return []

        if proc.returncode not in (0, None):
            logger.warning("wapiti exited %d", proc.returncode)
            return []

        findings: list[dict] = []
        out_path = Path(output)
        if not out_path.exists():
            return findings

        try:
            data = json.loads(out_path.read_text(errors="replace"))
            # wapiti3 JSON: {"vulnerabilities": {"Category Name": [vuln_dict, ...]}}
            vulns_raw = data.get("vulnerabilities", {})
            if isinstance(vulns_raw, dict):
                all_vulns = [
                    (category, vuln)
                    for category, vuln_list in vulns_raw.items()
                    if isinstance(vuln_list, list)
                    for vuln in vuln_list
                    if isinstance(vuln, dict)
                ]
            else:
                # Flat list fallback (older wapiti format)
                all_vulns = [("unknown", v) for v in vulns_raw if isinstance(v, dict)]

            _lvl = {1: "low", 2: "medium", 3: "high"}
            for category, vuln in all_vulns:
                findings.append({
                    "title": f"[Wapiti] {category}",
                    "description": vuln.get("info", ""),
                    "vulnerability_type": _wapiti_type(category),
                    "severity": _lvl.get(vuln.get("level", 2), "medium"),
                    "cwe": "",
                    "file_path": "",
                    "line_number": 0,
                    "code_snippet": vuln.get("http_request", ""),
                    "endpoint": vuln.get("url", target_url),
                    "parameter": vuln.get("parameter", ""),
                    "rule_id": f"wapiti-{vuln.get('module', category.lower().replace(' ', '-'))}",
                    "remediation": "",
                    "source": "wapiti",
                    "raw": vuln,
                })
        except (json.JSONDecodeError, ValueError, AttributeError, KeyError, TypeError):
            logger.warning("wapiti output not valid JSON")

        out_path.unlink(missing_ok=True)
        return findings


def _wapiti_type(category: str) -> str:
    """Map Wapiti category to TraceON vulnerability type."""
    mapping = {
        "SQL Injection": "sqli",
        "XSS": "xss",
        "Command Execution": "cmdi",
        "CRLF Injection": "cmdi",
        "SSRF": "ssrf",
        "Path Traversal": "path_traversal",
        "XXE": "deserialization",
        "LDAP Injection": "cmdi",
        "Open Redirect": "open_redirect",
    }
    return mapping.get(category, "unknown")
