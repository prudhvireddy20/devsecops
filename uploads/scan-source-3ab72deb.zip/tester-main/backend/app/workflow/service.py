"""Workflow artifact ingestion and lookup services."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.project import Project
from app.models.project_artifact import ProjectArtifact
from app.models.workflow_graph import WorkflowAttackPoint, WorkflowGraph, WorkflowStep
from app.scanners.replay_adapter import load_journey_steps
from app.scanners.spec_adapter import load_openapi_routes, load_postman_routes
from app.utils.normalizers import normalize_path


def collect_project_config_artifacts(project: Project) -> list[tuple[str, str]]:
    """Collect legacy project-level artifact path fields into normalized tuples."""
    pairs: list[tuple[str, str]] = []
    mapping = {
        "openapi": str(getattr(project, "openapi_spec_files", "") or ""),
        "postman": str(getattr(project, "postman_collection_files", "") or ""),
        "journey": str(getattr(project, "journey_replay_files", "") or ""),
    }
    for kind, raw in mapping.items():
        for item in raw.split(","):
            value = item.strip()
            if value:
                pairs.append((kind, value))
    return pairs


def _extract_attack_points(path: str, method: str, request_body: str = "") -> list[dict]:
    out: list[dict] = []
    parsed = urlparse(path)
    query = parse_qs(parsed.query)
    for key, values in query.items():
        out.append(
            {
                "param_name": key,
                "param_location": "query",
                "sample_value": str(values[0]) if values else "",
            }
        )

    normalized_path = normalize_path(parsed.path or path, strip_query=True, strip_trailing_slash=True)
    for segment in normalized_path.split("/"):
        if segment.startswith("{") and segment.endswith("}"):
            out.append(
                {
                    "param_name": segment[1:-1],
                    "param_location": "path",
                    "sample_value": "",
                }
            )
        if segment.startswith(":") and len(segment) > 1:
            out.append(
                {
                    "param_name": segment[1:],
                    "param_location": "path",
                    "sample_value": "",
                }
            )

    if request_body:
        body = request_body.strip()
        if body.startswith("{") and body.endswith("}"):
            try:
                payload = json.loads(body)
                if isinstance(payload, dict):
                    for k, v in payload.items():
                        out.append(
                            {
                                "param_name": str(k),
                                "param_location": "body",
                                "sample_value": str(v)[:200],
                            }
                        )
            except Exception:
                pass

    # Deduplicate by location+name
    dedup = {}
    for p in out:
        dedup[(p["param_location"], p["param_name"])] = p
    return list(dedup.values())


def _parse_artifact_steps(project_root: str, kind: str, source_path: str) -> tuple[list[dict], str, dict]:
    p = Path(source_path)
    if not p.is_absolute():
        p = Path(project_root) / source_path

    parser = ""
    metadata: dict = {}
    steps: list[dict] = []

    if kind == "openapi":
        routes = load_openapi_routes([p])
        parser = "openapi_file"
        for idx, route in enumerate(routes, 1):
            for method in route.get("methods", ["GET"]):
                steps.append(
                    {
                        "step_index": idx,
                        "step_type": "request",
                        "method": method,
                        "path": route.get("path", "/"),
                        "endpoint_url": route.get("path", "/"),
                        "role": "",
                        "request_headers": {},
                        "request_body": "",
                        "expected_status": 0,
                        "metadata": {"source": route.get("source", "openapi")},
                    }
                )
        metadata = {"route_count": len(routes)}

    elif kind == "postman":
        routes = load_postman_routes([p])
        parser = "postman_collection"
        for idx, route in enumerate(routes, 1):
            method = (route.get("methods") or ["GET"])[0]
            steps.append(
                {
                    "step_index": idx,
                    "step_type": "request",
                    "method": method,
                    "path": route.get("path", "/"),
                    "endpoint_url": route.get("path", "/"),
                    "role": "",
                    "request_headers": {},
                    "request_body": "",
                    "expected_status": 0,
                    "metadata": {"source": route.get("source", "postman")},
                }
            )
        metadata = {"route_count": len(routes)}

    elif kind == "journey":
        info = load_journey_steps(project_root, {"journey_replay_files": [str(p)]})
        parser = "journey_replay"
        for row in info.get("steps", []):
            steps.append(
                {
                    "step_index": int(row.get("step", len(steps) + 1)),
                    "step_type": "request",
                    "method": str(row.get("method", "GET")).upper(),
                    "path": row.get("path", "/"),
                    "endpoint_url": row.get("url", row.get("path", "/")),
                    "role": str(row.get("role", "") or ""),
                    "request_headers": {},
                    "request_body": "",
                    "expected_status": 0,
                    "metadata": {"source": row.get("source", "journey")},
                }
            )
        metadata = {"step_count": len(steps)}

    return steps, parser, metadata


async def ingest_artifact_file(
    db: AsyncSession,
    project: Project,
    *,
    kind: str,
    source_path: str,
    parser_hint: str = "",
) -> dict:
    """Parse one artifact file and build a normalized workflow graph."""
    project_root = str(project.local_path or "")
    source = Path(source_path)
    if not source.is_absolute():
        source = Path(project_root) / source_path
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"Artifact file not found: {source}")

    digest = hashlib.sha256(source.read_bytes()).hexdigest()

    result = await db.execute(
        select(ProjectArtifact).where(
            ProjectArtifact.project_id == project.id,
            ProjectArtifact.kind == kind,
            ProjectArtifact.source_path == str(source_path),
        )
    )
    artifact = result.scalar_one_or_none()
    if not artifact:
        artifact = ProjectArtifact(
            project_id=project.id,
            kind=kind,
            source_path=str(source_path),
        )
        db.add(artifact)

    artifact.content_hash = digest
    artifact.parse_status = "parsing"
    artifact.parse_error = ""

    await db.flush()

    try:
        steps, inferred_parser, metadata = _parse_artifact_steps(project_root, kind, str(source_path))
        parser_name = parser_hint or inferred_parser or "generic"
        artifact.parser = parser_name
        artifact.metadata_json = {
            **(artifact.metadata_json or {}),
            **metadata,
            "step_count": len(steps),
        }

        # Replace prior graphs generated for this artifact.
        existing = await db.execute(
            select(WorkflowGraph.id).where(WorkflowGraph.artifact_id == artifact.id)
        )
        graph_ids = [row[0] for row in existing.fetchall()]
        if graph_ids:
            await db.execute(delete(WorkflowAttackPoint).where(WorkflowAttackPoint.graph_id.in_(graph_ids)))
            await db.execute(delete(WorkflowStep).where(WorkflowStep.graph_id.in_(graph_ids)))
            await db.execute(delete(WorkflowGraph).where(WorkflowGraph.id.in_(graph_ids)))

        graph = WorkflowGraph(
            project_id=project.id,
            artifact_id=artifact.id,
            name=source.name,
            source_kind=kind,
            version="v1",
            status="ready",
            metadata_json={"parser": parser_name, **metadata},
        )
        db.add(graph)
        await db.flush()

        step_rows: list[WorkflowStep] = []
        for step in steps:
            row = WorkflowStep(
                graph_id=graph.id,
                step_index=int(step.get("step_index", len(step_rows) + 1)),
                step_type=str(step.get("step_type", "request")),
                method=str(step.get("method", "GET")).upper(),
                path=normalize_path(str(step.get("path", "/")), strip_query=True, strip_trailing_slash=True),
                endpoint_url=str(step.get("endpoint_url", step.get("path", "/"))),
                role=str(step.get("role", "") or ""),
                request_headers=dict(step.get("request_headers") or {}),
                request_body=str(step.get("request_body", "") or ""),
                expected_status=int(step.get("expected_status", 0) or 0),
                metadata_json=dict(step.get("metadata") or {}),
            )
            db.add(row)
            step_rows.append(row)

        await db.flush()

        for row in step_rows:
            attack_points = _extract_attack_points(
                row.endpoint_url or row.path,
                row.method,
                row.request_body,
            )
            for ap in attack_points:
                db.add(
                    WorkflowAttackPoint(
                        graph_id=graph.id,
                        step_id=row.id,
                        param_name=ap.get("param_name", ""),
                        param_location=ap.get("param_location", "query"),
                        sample_value=ap.get("sample_value", ""),
                        metadata_json={},
                    )
                )

        artifact.parse_status = "ready"
        await db.flush()
        return {
            "artifact": artifact.to_dict(),
            "graph": graph.to_dict(),
            "steps": len(step_rows),
        }
    except Exception as exc:
        artifact.parse_status = "failed"
        artifact.parse_error = str(exc)
        await db.flush()
        raise


async def load_project_workflow_routes(db: AsyncSession, project_id: str) -> dict:
    """Return route seeds and path->workflow mapping from normalized graphs."""
    graph_result = await db.execute(
        select(WorkflowGraph).where(
            WorkflowGraph.project_id == project_id,
            WorkflowGraph.status == "ready",
        )
    )
    graphs = graph_result.scalars().all()
    if not graphs:
        return {"routes": [], "path_map": {}}

    graph_ids = [g.id for g in graphs]
    steps_result = await db.execute(
        select(WorkflowStep).where(WorkflowStep.graph_id.in_(graph_ids))
    )
    steps = steps_result.scalars().all()

    routes: list[dict] = []
    path_map: dict[str, list[dict]] = {}
    seen = set()

    for step in steps:
        path = normalize_path(step.path, strip_query=True, strip_trailing_slash=True)
        method = (step.method or "GET").upper()
        sig = (path, method)
        if sig not in seen:
            seen.add(sig)
            routes.append(
                {
                    "path": path,
                    "methods": [method],
                    "handler": "workflow_graph",
                    "source": f"workflow:{step.graph_id}",
                    "tested": False,
                    "workflow_graph_id": step.graph_id,
                    "workflow_step_id": step.id,
                }
            )

        path_map.setdefault(path, []).append(
            {
                "graph_id": step.graph_id,
                "step_id": step.id,
                "role": step.role,
            }
        )

    return {"routes": routes, "path_map": path_map}


async def ensure_project_artifacts_from_project_config(
    db: AsyncSession,
    project: Project,
) -> dict:
    """Backfill and parse artifacts defined in legacy project path fields."""
    created = 0
    parsed = 0
    for kind, rel_path in collect_project_config_artifacts(project):
        existing_result = await db.execute(
            select(ProjectArtifact).where(
                ProjectArtifact.project_id == project.id,
                ProjectArtifact.kind == kind,
                ProjectArtifact.source_path == rel_path,
            )
        )
        existing = existing_result.scalar_one_or_none()
        if not existing:
            existing = ProjectArtifact(
                project_id=project.id,
                kind=kind,
                source_path=rel_path,
                parse_status="pending",
            )
            db.add(existing)
            created += 1
            await db.flush()

        if existing.parse_status != "ready":
            try:
                await ingest_artifact_file(
                    db,
                    project,
                    kind=kind,
                    source_path=rel_path,
                )
                parsed += 1
            except Exception:
                # Keep parse_status/parse_error persisted by ingest handler.
                pass

    return {"created": created, "parsed": parsed}
