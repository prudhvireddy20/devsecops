"""Shared test fixtures for integration tests."""
import pytest
from unittest.mock import AsyncMock, patch
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from app.core.database import Base
import app.models  # noqa: F401  — ensure all models registered with Base


# ---------- Test database (in-memory SQLite, shared single connection) ----------

test_engine = create_async_engine(
    "sqlite+aiosqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
    echo=False,
)

test_session_factory = async_sessionmaker(
    test_engine, class_=AsyncSession, expire_on_commit=False,
)


async def _override_get_db():
    """Test replacement for the ``get_db`` FastAPI dependency."""
    async with test_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


async def _seed_admin():
    """Seed the admin user matching settings.API_KEY into the test DB."""
    from hashlib import sha256
    from sqlalchemy import select
    from app.models.user import User
    import app.core.config as config_mod
    async with test_session_factory() as db:
        key_hash = sha256(config_mod.settings.API_KEY.encode()).hexdigest()
        existing = await db.scalar(select(User).where(User.api_key_hash == key_hash))
        if existing:
            return
        import uuid
        admin = User(
            id=str(uuid.uuid4()),
            api_key_hash=key_hash,
            label="admin",
            is_active=True,
            is_admin=True,
        )
        db.add(admin)
        await db.commit()


# ---------- Fixtures ----------


@pytest.fixture
async def db_tables():
    """Create all tables before a test and drop them afterwards."""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture
async def db_session(db_tables):
    """Provide an async database session for direct model tests."""
    async with test_session_factory() as session:
        yield session


@pytest.fixture
async def client(db_tables, tmp_path):
    """httpx ``AsyncClient`` wired to the FastAPI app with test database.

    Patches both the ``get_db`` FastAPI dependency AND the module-level
    ``async_session_factory`` that ``dashboard_stats`` and background tasks
    import directly.
    """
    await _seed_admin()

    from httpx import ASGITransport, AsyncClient
    from app.main import app
    from app.core.database import get_db
    import app.core.config as config_mod

    # Override the FastAPI DB dependency
    app.dependency_overrides[get_db] = _override_get_db

    # Redirect filesystem directories to a temp location
    orig_projects = config_mod.settings.PROJECTS_DIR
    orig_reports = config_mod.settings.REPORTS_DIR
    config_mod.settings.PROJECTS_DIR = tmp_path / "projects"
    config_mod.settings.REPORTS_DIR = tmp_path / "reports"
    (tmp_path / "projects").mkdir()
    (tmp_path / "reports").mkdir()

    # Patch async_session_factory everywhere it is imported so that
    # dashboard_stats and _run_scan_pipeline use the test DB.
    with patch("app.core.database.async_session_factory", test_session_factory), \
         patch("app.main.async_session_factory", test_session_factory, create=True), \
         patch("app.main.get_rate_limiter") as mock_get_rate_limiter, \
         patch("app.api.scans.async_session_factory", test_session_factory, create=True), \
         patch("app.api.scans._run_scan_pipeline", new=AsyncMock(return_value=None)), \
         patch("app.api.cp_adapter.async_session_factory", test_session_factory, create=True):
        mock_get_rate_limiter.return_value.is_allowed.return_value = True
        mock_get_rate_limiter.return_value.get_remaining.return_value = 60
        transport = ASGITransport(app=app)
        async with AsyncClient(
            transport=transport,
            base_url="http://test",
            headers={"X-API-Key": config_mod.settings.API_KEY},
        ) as ac:
            yield ac

    # Cleanup
    app.dependency_overrides.clear()
    config_mod.settings.PROJECTS_DIR = orig_projects
    config_mod.settings.REPORTS_DIR = orig_reports


@pytest.fixture
async def client_no_auth(db_tables, tmp_path):
    """httpx AsyncClient wired like ``client`` but without auth header."""
    await _seed_admin()

    from httpx import ASGITransport, AsyncClient
    from app.main import app
    from app.core.database import get_db
    import app.core.config as config_mod

    app.dependency_overrides[get_db] = _override_get_db

    orig_projects = config_mod.settings.PROJECTS_DIR
    orig_reports = config_mod.settings.REPORTS_DIR
    config_mod.settings.PROJECTS_DIR = tmp_path / "projects"
    config_mod.settings.REPORTS_DIR = tmp_path / "reports"
    (tmp_path / "projects").mkdir()
    (tmp_path / "reports").mkdir()

    with patch("app.core.database.async_session_factory", test_session_factory), \
         patch("app.main.async_session_factory", test_session_factory, create=True), \
         patch("app.main.get_rate_limiter") as mock_get_rate_limiter, \
         patch("app.api.scans.async_session_factory", test_session_factory, create=True), \
         patch("app.api.scans._run_scan_pipeline", new=AsyncMock(return_value=None)), \
         patch("app.api.cp_adapter.async_session_factory", test_session_factory, create=True):
        mock_get_rate_limiter.return_value.is_allowed.return_value = True
        mock_get_rate_limiter.return_value.get_remaining.return_value = 60
        transport = ASGITransport(app=app)
        async with AsyncClient(
            transport=transport,
            base_url="http://test",
        ) as ac:
            yield ac

    app.dependency_overrides.clear()
    config_mod.settings.PROJECTS_DIR = orig_projects
    config_mod.settings.REPORTS_DIR = orig_reports
