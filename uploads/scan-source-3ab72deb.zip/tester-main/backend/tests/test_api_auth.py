"""Tests for REST API authenticator (app.auth.api_auth)."""

import httpx
import pytest

from app.auth.api_auth import RestApiAuthenticator


def _make_httpx_side_effect(responses: dict):
    """Return a side_effect callable keyed by URL substring."""

    def side_effect(method, url, json=None, headers=None):
        for keyword, (body, status, extra_headers) in responses.items():
            if keyword in url:
                req = httpx.Request(method, url)
                return httpx.Response(status, json=body, headers=extra_headers or {}, request=req)
        req = httpx.Request(method, url)
        return httpx.Response(404, json={"detail": "not found"}, request=req)

    return side_effect


@pytest.mark.asyncio
async def test_authenticate_success_with_openapi():
    """Full happy path: OpenAPI spec discovered, auto-register, login, JWT returned."""
    from unittest.mock import patch

    spec = {
        "openapi": "3.0.1",
        "paths": {
            "/users/v1/login": {"post": {"summary": "Login"}},
            "/users/v1/register": {"post": {"summary": "Register"}},
        },
        "components": {
            "securitySchemes": {
                "bearerAuth": {"type": "http", "scheme": "bearer"}
            }
        },
    }

    responses = {
        "openapi.json": (spec, 200, {}),
        "register": ({"status": "success", "message": "Registered"}, 200, {}),
        "login": ({"auth_token": "eyJhbGciOi.test.token123"}, 200, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        result = await auth.authenticate("http://target:5000")

    assert result["success"] is True
    assert result["token"] == "eyJhbGciOi.test.token123"
    assert "Bearer" in result["headers"].get("Authorization", "")
    assert result["login_endpoint"] is not None


@pytest.mark.asyncio
async def test_authenticate_with_provided_credentials():
    """When user provides username/password, skip registration."""
    from unittest.mock import patch

    responses = {
        "openapi.json": ({"openapi": "3.0.1", "paths": {"/users/v1/login": {"post": {}}}}, 200, {}),
        "login": ({"access_token": "user_provided_jwt"}, 200, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        result = await auth.authenticate(
            "http://target:5000",
            {"username": "admin", "password": "admin123"},
        )

    assert result["success"] is True
    assert result["token"] == "user_provided_jwt"


@pytest.mark.asyncio
async def test_authenticate_no_login_endpoint():
    """If no login endpoint found, returns error."""
    from unittest.mock import patch

    responses = {
        "openapi.json": ({"openapi": "3.0.1", "paths": {}}, 200, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        result = await auth.authenticate("http://target:5000")

    assert result["success"] is False
    assert "No login endpoint" in result["error"]


@pytest.mark.asyncio
async def test_authenticate_login_fails():
    """If login returns no token, result is failed."""
    from unittest.mock import patch

    responses = {
        "openapi.json": ({"openapi": "3.0.1", "paths": {"/login": {"post": {}}}}, 200, {}),
        "register": ({"status": "success"}, 200, {}),
        "login": ({"message": "Invalid credentials"}, 200, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        result = await auth.authenticate("http://target:5000")

    assert result["success"] is False
    assert result["token"] is None


@pytest.mark.asyncio
async def test_authenticate_explicit_login_url():
    """When login_url is provided in auth_config, use it directly."""
    from unittest.mock import patch

    responses = {
        "custom-login": ({"token": "custom_jwt_token_value"}, 200, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        result = await auth.authenticate(
            "http://target:5000",
            {
                "login_url": "http://target:5000/custom-login",
                "username": "u",
                "password": "p",
            },
        )

    assert result["success"] is True
    assert result["token"] == "custom_jwt_token_value"


@pytest.mark.asyncio
async def test_extract_token_nested():
    """Token extraction from nested response objects."""
    auth = RestApiAuthenticator()

    assert auth._extract_token({"auth_token": "tok123456789"}) == "tok123456789"
    assert auth._extract_token({"data": {"access_token": "nested_tok_v"}}) == "nested_tok_v"
    assert auth._extract_token({"message": "ok"}) is None
    assert auth._extract_token({"token": "short"}) is None


@pytest.mark.asyncio
async def test_register_already_exists():
    """Registration endpoint returns 409 (conflict) — treat as success."""
    from unittest.mock import patch

    responses = {
        "register": ({"message": "User already exists"}, 409, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        ok = await auth._try_register("http://target/register", "user", "pass", "e@e.com")

    assert ok["success"] is True


@pytest.mark.asyncio
async def test_probe_paths_finds_endpoint():
    """Path probing finds the first non-404 endpoint."""
    from unittest.mock import patch

    responses = {
        "/api/login": ({"detail": "unauthorized"}, 401, {}),
    }

    with patch("httpx.Client.request", side_effect=_make_httpx_side_effect(responses)):
        auth = RestApiAuthenticator()
        found = await auth._probe_paths(
            "http://target:5000",
            ("/nope", "/api/login", "/also-nope"),
        )

    assert found == "http://target:5000/api/login"


@pytest.mark.asyncio
async def test_authenticate_rejects_unsafe_target_url():
    auth = RestApiAuthenticator()
    with pytest.raises(ValueError, match="Unsafe target URL"):
        await auth.authenticate("http://169.254.169.254/latest/meta-data")


@pytest.mark.asyncio
async def test_http_request_surfaces_http_error_status():
    from unittest.mock import patch
    from app.auth.api_auth import _http_request

    def _response(method, url, json=None, headers=None):
        req = httpx.Request(method, url)
        return httpx.Response(401, json={"detail": "unauthorized"}, request=req)

    with patch("httpx.Client.request", side_effect=_response):
        status, body, _headers = _http_request("http://target:5000/login", payload={"u": "x"}, retries=0)

    assert status == 401
    assert "unauthorized" in body
