"""Integration tests for API endpoints using httpx AsyncClient + test DB."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _create_project(client, **overrides):
    """POST /api/projects and return the JSON response body.

    Defaults to ``source_type="zip"`` which does NOT try to copy/clone on
    creation — it just records the project and waits for a later upload.
    """
    payload = {
        "name": "Test Project",
        "source_type": "zip",
        "source_path": "",
        **overrides,
    }
    resp = await client.post("/api/projects", json=payload)
    return resp


async def _create_project_with_source(client, tmp_path):
    """Create a project whose local_path points at real files."""
    src = tmp_path / "projects" / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "app.py").write_text("from flask import Flask\napp = Flask(__name__)\n")
    (src / "utils.py").write_text("# utils\n")
    resp = await _create_project(client, source_type="local", source_path=str(src))
    return resp


async def _seed_project_and_scan(client):
    """Create a project + scan via API, return (project_data, scan_data)."""
    proj = await _create_project(client)
    proj_data = proj.json()
    # Manually seed local_path so start_scan doesn't reject it
    from tests.conftest import test_session_factory
    from app.models.project import Project
    from sqlalchemy import select
    async with test_session_factory() as session:
        result = await session.execute(
            select(Project).where(Project.id == proj_data["id"])
        )
        p = result.scalar_one()
        p.local_path = "/tmp/fake_src"
        await session.commit()

    return proj_data


# ===========================================================================
# /api/health
# ===========================================================================


class TestHealth:
    async def test_health_check(self, client):
        resp = await client.get("/api/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "healthy"
        assert "version" in data
        assert "app" in data


# ===========================================================================
# /api/dashboard/stats
# ===========================================================================


class TestDashboardStats:
    async def test_empty_stats(self, client):
        resp = await client.get("/api/dashboard/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_projects"] == 0
        assert data["total_scans"] == 0
        assert data["recent_scans"] == []
        assert data["finding_summary"]["total"] == 0

    async def test_stats_with_data(self, client):
        """Dashboard stats reflect projects, scans, and findings."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="StatsProject", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="completed")
            session.add(s)
            await session.flush()
            for sev in ["critical", "high", "medium"]:
                session.add(Finding(
                    scan_id=s.id, title=f"{sev} finding",
                    vulnerability_type="xss", severity=sev,
                    confidence="verified", scanner_source="semgrep",
                ))
            await session.commit()

        resp = await client.get("/api/dashboard/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_projects"] == 1
        assert data["total_scans"] == 1
        assert len(data["recent_scans"]) == 1
        assert data["recent_scans"][0]["project_name"] == "StatsProject"
        assert data["finding_summary"]["total"] == 3
        assert data["finding_summary"]["critical"] == 1


# ===========================================================================
# /api/projects
# ===========================================================================


class TestProjectsAPI:

    async def test_create_project(self, client):
        resp = await _create_project(client, name="My App")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "My App"
        assert data["source_type"] == "zip"
        assert data["is_active"] is True
        assert data["id"]

    async def test_create_project_rejects_unsafe_target_url(self, client):
        resp = await _create_project(
            client,
            name="Bad Target",
            target_url="http://169.254.169.254/latest/meta-data",
        )
        assert resp.status_code == 400
        assert "Invalid target URL" in resp.json()["detail"]

    async def test_list_projects_empty(self, client):
        resp = await client.get("/api/projects")
        assert resp.status_code == 200
        data = resp.json()
        assert data["items"] == []
        assert data["total"] == 0

    async def test_list_projects(self, client):
        await _create_project(client, name="A")
        await _create_project(client, name="B")
        resp = await client.get("/api/projects")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["items"]) == 2

    async def test_get_project(self, client):
        create_resp = await _create_project(client, name="Get Me")
        pid = create_resp.json()["id"]
        resp = await client.get(f"/api/projects/{pid}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Get Me"

    async def test_get_project_not_found(self, client):
        resp = await client.get("/api/projects/nonexistent-id")
        assert resp.status_code == 404

    async def test_update_project(self, client):
        create_resp = await _create_project(client, name="Old Name")
        pid = create_resp.json()["id"]
        resp = await client.put(f"/api/projects/{pid}", json={"name": "New Name"})
        assert resp.status_code == 200
        assert resp.json()["name"] == "New Name"

    async def test_update_project_rejects_unsafe_target_url(self, client):
        create_resp = await _create_project(client, name="Safe Name")
        pid = create_resp.json()["id"]
        resp = await client.put(
            f"/api/projects/{pid}",
            json={"target_url": "http://169.254.169.254/latest/meta-data"},
        )
        assert resp.status_code == 400
        assert "Invalid target URL" in resp.json()["detail"]

    async def test_update_project_not_found(self, client):
        resp = await client.put("/api/projects/bad-id", json={"name": "X"})
        assert resp.status_code == 404

    async def test_delete_project(self, client):
        create_resp = await _create_project(client, name="Delete Me")
        pid = create_resp.json()["id"]
        resp = await client.delete(f"/api/projects/{pid}")
        assert resp.status_code == 200
        assert resp.json()["status"] == "deleted"
        # Verify gone
        resp2 = await client.get(f"/api/projects/{pid}")
        assert resp2.status_code == 404

    async def test_delete_project_not_found(self, client):
        resp = await client.delete("/api/projects/no-such-id")
        assert resp.status_code == 404

    async def test_pagination(self, client):
        for i in range(5):
            await _create_project(client, name=f"P{i}")
        resp = await client.get("/api/projects", params={"page": 1, "page_size": 2})
        data = resp.json()
        assert data["total"] == 5
        assert len(data["items"]) == 2
        assert data["pages"] == 3

    async def test_project_files_no_source(self, client):
        create_resp = await _create_project(client, name="No Source")
        pid = create_resp.json()["id"]
        resp = await client.get(f"/api/projects/{pid}/files")
        assert resp.status_code == 400

    async def test_project_files_with_source(self, client, tmp_path):
        resp = await _create_project_with_source(client, tmp_path)
        pid = resp.json()["id"]
        files_resp = await client.get(f"/api/projects/{pid}/files")
        assert files_resp.status_code == 200
        tree = files_resp.json()["tree"]
        names = [e["name"] for e in tree]
        assert "app.py" in names

    async def test_get_file_content(self, client, tmp_path):
        resp = await _create_project_with_source(client, tmp_path)
        pid = resp.json()["id"]
        file_resp = await client.get(
            f"/api/projects/{pid}/file", params={"path": "app.py"}
        )
        assert file_resp.status_code == 200
        assert "Flask" in file_resp.json()["content"]
        assert file_resp.json()["language"] == "python"

    async def test_get_file_not_found(self, client, tmp_path):
        resp = await _create_project_with_source(client, tmp_path)
        pid = resp.json()["id"]
        file_resp = await client.get(
            f"/api/projects/{pid}/file", params={"path": "nope.py"}
        )
        assert file_resp.status_code == 404

    async def test_path_traversal_blocked(self, client, tmp_path):
        resp = await _create_project_with_source(client, tmp_path)
        pid = resp.json()["id"]
        file_resp = await client.get(
            f"/api/projects/{pid}/file", params={"path": "../../etc/passwd"}
        )
        assert file_resp.status_code == 403

    async def test_create_project_with_llm_settings(self, client):
        resp = await _create_project(
            client,
            name="LLM Project",
            llm_provider="openrouter",
            llm_model="openai/gpt-4o-mini",
            llm_api_key="sk-or-secret",
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["llm_provider"] == "openrouter"
        assert data["llm_model"] == "openai/gpt-4o-mini"
        assert data["has_llm_api_key"] is True

    async def test_update_project_llm_settings(self, client):
        create_resp = await _create_project(client, name="Update LLM")
        pid = create_resp.json()["id"]
        resp = await client.put(
            f"/api/projects/{pid}",
            json={
                "llm_provider": "OpenAI",
                "llm_model": "gpt-4o-mini",
                "llm_api_key": "sk-openai-secret",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["llm_provider"] == "openai"
        assert data["llm_model"] == "gpt-4o-mini"
        assert data["has_llm_api_key"] is True


# ===========================================================================
# /api/llm/providers
# ===========================================================================


class TestLLMProvidersAPI:

    async def test_list_llm_providers(self, client):
        resp = await client.get("/api/llm/providers")
        assert resp.status_code == 200
        data = resp.json()
        assert data["enabled"] is True
        assert len(data["providers"]) >= 4
        providers = {p["provider"] for p in data["providers"]}
        assert "openai" in providers
        assert "anthropic" in providers

    async def test_upsert_and_disconnect_llm_provider(self, client):
        from unittest.mock import AsyncMock, patch

        with patch("app.api.llm.LLMClient.validate_connection", new=AsyncMock(return_value=None)):
            upsert = await client.put(
                "/api/llm/providers/openai",
                json={
                    "api_key": "sk-openai-connected",
                    "default_model": "gpt-4o-mini",
                },
            )
        assert upsert.status_code == 200
        body = upsert.json()
        assert body["provider"] == "openai"
        assert body["connected"] is True
        assert body["source"] == "stored"
        assert body["default_model"] == "gpt-4o-mini"

        listed = await client.get("/api/llm/providers")
        providers = {p["provider"]: p for p in listed.json()["providers"]}
        assert providers["openai"]["connected"] is True
        assert providers["openai"]["source"] == "stored"
        assert providers["openai"]["default_model"] == "gpt-4o-mini"

        disconnected = await client.delete("/api/llm/providers/openai")
        assert disconnected.status_code == 200
        assert disconnected.json()["provider"] == "openai"

    async def test_upsert_llm_provider_rejects_invalid_api_key(self, client):
        from unittest.mock import AsyncMock, patch
        from app.llm.client import LLMCredentialValidationError

        with patch(
            "app.api.llm.LLMClient.validate_connection",
            new=AsyncMock(side_effect=LLMCredentialValidationError("Invalid API key for provider 'openai'.")),
        ):
            resp = await client.put(
                "/api/llm/providers/openai",
                json={
                    "api_key": "bad-key",
                    "default_model": "gpt-4o-mini",
                },
            )

        assert resp.status_code == 400
        assert "Invalid API key" in resp.json()["detail"]

        listed = await client.get("/api/llm/providers")
        providers = {p["provider"]: p for p in listed.json()["providers"]}
        assert providers["openai"]["connected"] is False

    async def test_upsert_llm_provider_returns_502_when_provider_unreachable(self, client):
        from unittest.mock import AsyncMock, patch
        from app.llm.client import LLMProviderConnectivityError

        with patch(
            "app.api.llm.LLMClient.validate_connection",
            new=AsyncMock(side_effect=LLMProviderConnectivityError("Could not reach provider 'openai' for validation.")),
        ):
            resp = await client.put(
                "/api/llm/providers/openai",
                json={
                    "api_key": "sk-openai-connected",
                    "default_model": "gpt-4o-mini",
                },
            )

        assert resp.status_code == 502
        assert "Could not reach provider" in resp.json()["detail"]

    async def test_list_llm_provider_marks_reconnect_needed_for_undecryptable_key(self, client):
        from tests.conftest import test_session_factory
        from app.models.llm_provider_credential import LLMProviderCredential
        from app.models.user import User
        from sqlalchemy import select

        async with test_session_factory() as session:
            admin = await session.scalar(select(User).where(User.is_admin == True))
            session.add(
                LLMProviderCredential(
                    user_id=admin.id,
                    provider="google",
                    encrypted_token="gAAAA_bad_token_value",
                    default_model="gemini-1.5-pro",
                )
            )
            await session.commit()

        listed = await client.get("/api/llm/providers")
        assert listed.status_code == 200
        providers = {p["provider"]: p for p in listed.json()["providers"]}
        assert providers["google"]["connected"] is False
        assert providers["google"]["needs_reconnect"] is True

    async def test_upsert_llm_provider_rejects_invalid_model(self, client):
         resp = await client.put(
             "/api/llm/providers/openai",
             json={"default_model": "made-up-model"},
         )
         assert resp.status_code == 400
         assert "Unsupported model" in resp.json()["detail"]



# ===========================================================================
# /api/scans
# ===========================================================================


class TestScansAPI:

    async def test_start_scan_project_not_found(self, client):
        resp = await client.post(
            "/api/scans", json={"project_id": "no-such-project"}
        )
        assert resp.status_code == 404

    async def test_start_scan_no_source(self, client):
        proj = await _create_project(client, name="No Source")
        pid = proj.json()["id"]

        # Manually clear local_path in DB to trigger the 400
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select
        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = ""
            await session.commit()

        resp = await client.post(
            "/api/scans", json={"project_id": pid}
        )
        assert resp.status_code == 400

    async def test_start_scan_nonexistent_local_path(self, client):
        proj = await _create_project(client, name="Bad Source")
        pid = proj.json()["id"]

        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp/path-that-does-not-exist-traceon"
            await session.commit()

        resp = await client.post("/api/scans", json={"project_id": pid})
        assert resp.status_code == 400

    async def test_start_scan_applies_profile_defaults(self, client):
        proj = await _create_project(client, name="Profile Defaults")
        pid = proj.json()["id"]

        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = "http://example.com"
            await session.commit()

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_type": "dast_only",
                "modules_enabled": {"dast": True},
                "scan_config": {"profile": "spa"},
            },
        )
        assert resp.status_code == 200
        cfg = resp.json()["scan_config"]
        assert cfg["profile"] == "spa"
        assert cfg["ajax_spider"] is True
        assert cfg["adaptive_timeout"] is True

    async def test_start_scan_enables_runtime_focused_sast_defaults(self, client):
        proj = await _create_project(client, name="Runtime Focus Defaults")
        pid = proj.json()["id"]

        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = "http://example.com"
            await session.commit()

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_type": "full",
                "modules_enabled": {"sast": True, "dast": True},
            },
        )
        assert resp.status_code == 200
        cfg = resp.json()["scan_config"]
        assert cfg["sast_runtime_focus"] is True
        assert "**/tests/**" in cfg["sast_runtime_excludes"]

    async def test_start_scan_runtime_focus_can_be_disabled(self, client):
        proj = await _create_project(client, name="Runtime Focus Off")
        pid = proj.json()["id"]

        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = "http://example.com"
            await session.commit()

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_type": "full",
                "modules_enabled": {"sast": True, "dast": True},
                "scan_config": {"sast_runtime_focus": False},
            },
        )
        assert resp.status_code == 200
        cfg = resp.json()["scan_config"]
        assert cfg["sast_runtime_focus"] is False
        assert cfg["sast_runtime_excludes"] == []

    async def test_start_scan_rejects_missing_target_url_when_dast_enabled(self, client):
        proj = await _create_project(client, name="Missing DAST Target")
        pid = proj.json()["id"]

        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = ""
            await session.commit()

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_type": "full",
                "modules_enabled": {"sast": True, "dast": True},
            },
        )
        assert resp.status_code == 400
        assert "target_url is empty" in resp.json()["detail"]

    async def test_start_scan_normalizes_llm_config(self, client):
        proj = await _create_project(client, name="LLM Scan Config")
        pid = proj.json()["id"]

        from unittest.mock import patch
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.llm_provider_credential import LLMProviderCredential
        from app.core.security import encrypt_token
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = "http://example.com"
            session.add(
                LLMProviderCredential(
                    provider="openrouter",
                    encrypted_token=encrypt_token("sk-global-openrouter"),
                    default_model="openai/gpt-4o-mini",
                )
            )
            await session.commit()

        with patch("app.api.scans.settings.LLM_ENABLED", True):
            resp = await client.post(
                "/api/scans",
                json={
                    "project_id": pid,
                    "scan_config": {
                        "llm_planner_enabled": 1,
                        "llm_provider": "OpenRouter",
                        "llm_model": "openai/gpt-4o-mini",
                        "llm_api_key": " sk-test ",
                    },
                },
            )
        assert resp.status_code == 200
        cfg = resp.json()["scan_config"]
        assert cfg["llm_planner_enabled"] is True
        assert cfg["llm_provider"] == "openrouter"
        assert cfg["llm_model"] == "openai/gpt-4o-mini"
        assert "llm_api_key" not in cfg
        assert "llm_api_key_encrypted" not in cfg

    async def test_start_scan_llm_planner_requires_connected_provider(self, client):
        proj = await _create_project(client, name="LLM Requires Provider")
        pid = proj.json()["id"]

        from unittest.mock import patch
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from sqlalchemy import select

        async with test_session_factory() as session:
            result = await session.execute(select(Project).where(Project.id == pid))
            p = result.scalar_one()
            p.local_path = "/tmp"
            p.target_url = "http://example.com"
            await session.commit()

        with patch("app.api.scans.settings.LLM_ENABLED", True):
            resp = await client.post(
                "/api/scans",
                json={
                    "project_id": pid,
                    "scan_config": {
                        "llm_planner_enabled": True,
                        "llm_provider": "openai",
                        "llm_model": "gpt-4o-mini",
                    },
                },
            )
        assert resp.status_code == 400
        assert "not connected" in resp.json()["detail"]

    async def test_list_scans_empty(self, client):
        resp = await client.get("/api/scans")
        assert resp.status_code == 200
        assert resp.json()["items"] == []

    async def test_list_scans_with_filter(self, client):
        """Create scans directly in DB and verify list + filter."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="SP", source_type="local", local_path="/tmp")
            session.add(p)
            await session.flush()
            s1 = Scan(project_id=p.id, status="completed")
            s2 = Scan(project_id=p.id, status="failed")
            session.add_all([s1, s2])
            await session.commit()

        resp = await client.get("/api/scans")
        assert resp.json()["total"] == 2

        resp = await client.get("/api/scans", params={"status": "completed"})
        assert resp.json()["total"] == 1
        assert resp.json()["items"][0]["status"] == "completed"

    async def test_get_scan(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="running", progress=42)
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.get(f"/api/scans/{scan_id}")
        assert resp.status_code == 200
        assert resp.json()["progress"] == 42

    async def test_get_scan_not_found(self, client):
        resp = await client.get("/api/scans/nonexistent")
        assert resp.status_code == 404

    async def test_cancel_scan(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="running")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.post(f"/api/scans/{scan_id}/cancel")
        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"

    async def test_cancel_completed_scan_fails(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="completed")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.post(f"/api/scans/{scan_id}/cancel")
        assert resp.status_code == 400

    async def test_scan_routes_empty(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="completed")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.get(f"/api/scans/{scan_id}/routes")
        assert resp.status_code == 200
        data = resp.json()
        assert data["items"] == []

    async def test_scan_routes_uses_persisted_discovered_routes(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="Persisted Routes", source_type="zip", local_path="")
            session.add(p)
            await session.flush()

            s = Scan(
                project_id=p.id,
                status="completed",
                modules_enabled={"dast": True},
                scan_config={
                    "discovered_routes": [
                        {"path": "/", "tested": True, "handler": "dynamic_discovery"},
                        {"path": "/api/users", "tested": False, "handler": "dynamic_discovery"},
                    ]
                },
            )
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.get(f"/api/scans/{scan_id}/routes")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        paths = {r["path"] for r in data["items"]}
        assert "/" in paths
        assert "/api/users" in paths

    async def test_start_scan_blackbox_mode(self, client):
        """Explicit blackbox scan_mode should be accepted."""
        proj = await _create_project(client, name="Black Box Scan")
        pid = proj.json()["id"]

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_mode": "blackbox",
                "modules_enabled": {"dast": False},
            },
        )
        assert resp.status_code == 200
        assert resp.json()["scan_mode"] == "blackbox"

    async def test_start_scan_whitebox_mode(self, client):
        """Explicit whitebox scan_mode should be accepted."""
        proj = await _create_project(client, name="White Box Scan")
        pid = proj.json()["id"]

        resp = await client.post(
            "/api/scans",
            json={
                "project_id": pid,
                "scan_mode": "whitebox",
                "modules_enabled": {"dast": False},
            },
        )
        assert resp.status_code == 200
        assert resp.json()["scan_mode"] == "whitebox"

    async def test_upload_findings(self, client, tmp_path):
        """Upload a Semgrep JSON file and verify format/path are persisted."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from sqlalchemy import select

        async with test_session_factory() as session:
            p = Project(name="Upload Test", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="pending", source_available=False)
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        import json
        content = json.dumps({
            "results": [{
                "check_id": "rules.xss",
                "path": "app.js",
                "start": {"line": 10},
                "extra": {"severity": "ERROR", "metadata": {"cwe": ["CWE-79"]}, "message": "XSS found", "lines": "alert(1)"},
            }]
        })

        resp = await client.post(
            f"/api/scans/{scan_id}/upload-findings",
            data={"project_id": p.id},
            files={"file": ("findings.json", content, "application/json")},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["format"] == "semgrep"
        assert body["finding_count"] == 1
        assert "external_findings.json" in body["path"]

        # Verify persistence to scan_config
        async with test_session_factory() as session:
            result = await session.execute(select(Scan).where(Scan.id == scan_id))
            s = result.scalar_one()
            cfg = s.scan_config or {}
            assert cfg.get("external_findings_path") == body["path"]
            assert cfg.get("external_findings_format") == "semgrep"

    async def test_upload_findings_invalid_json(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="Bad Upload", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="pending")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.post(
            f"/api/scans/{scan_id}/upload-findings",
            data={"project_id": p.id},
            files={"file": ("bad.json", "{{{not json", "application/json")},
        )
        assert resp.status_code == 400

    async def test_upload_findings_file_too_large(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="Big Upload", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="pending")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        # 60 MB garbage
        resp = await client.post(
            f"/api/scans/{scan_id}/upload-findings",
            data={"project_id": p.id},
            files={"file": ("big.json", b"x" * (51 * 1024 * 1024), "application/json")},
        )
        assert resp.status_code == 413


# ===========================================================================
# /api/findings
# ===========================================================================


class TestFindingsAPI:

    async def _seed_findings(self, n=3):
        """Create a project + scan + N findings directly in the test DB."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="FP", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="completed")
            session.add(s)
            await session.flush()
            scan_id = s.id
            project_id = p.id
            finding_ids = []
            severities = ["critical", "high", "medium", "low", "info"]
            for i in range(n):
                f = Finding(
                    scan_id=s.id,
                    title=f"Finding {i}",
                    vulnerability_type="xss" if i % 2 == 0 else "sqli",
                    severity=severities[i % len(severities)],
                    confidence="verified" if i == 0 else "probable",
                    scanner_source="semgrep",
                    endpoint=f"/api/v{i}",
                    file_path=f"app/views{i}.py",
                    line_number=10 + i,
                )
                session.add(f)
                await session.flush()
                finding_ids.append(f.id)
            await session.commit()
        return scan_id, project_id, finding_ids

    async def test_list_findings_empty(self, client):
        resp = await client.get("/api/findings")
        assert resp.status_code == 200
        data = resp.json()
        assert data["items"] == []
        assert data["total"] == 0

    async def test_list_findings(self, client):
        scan_id, _, fids = await self._seed_findings(5)
        resp = await client.get("/api/findings")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 5
        assert len(data["items"]) == 5

    async def test_list_findings_filter_by_scan(self, client):
        scan_id, _, _ = await self._seed_findings(3)
        resp = await client.get("/api/findings", params={"scan_id": scan_id})
        assert resp.json()["total"] == 3

    async def test_list_findings_filter_by_severity(self, client):
        await self._seed_findings(5)
        resp = await client.get("/api/findings", params={"severity": "critical"})
        assert resp.json()["total"] == 1

    async def test_list_findings_filter_by_vuln_type(self, client):
        await self._seed_findings(4)
        resp = await client.get(
            "/api/findings", params={"vulnerability_type": "xss"}
        )
        # indices 0 and 2 are xss
        assert resp.json()["total"] == 2

    async def test_list_findings_search(self, client):
        await self._seed_findings(3)
        resp = await client.get("/api/findings", params={"search": "Finding 0"})
        assert resp.json()["total"] == 1

    async def test_list_findings_sort_by_title(self, client):
        await self._seed_findings(3)
        resp = await client.get(
            "/api/findings", params={"sort_by": "title", "sort_order": "asc"}
        )
        items = resp.json()["items"]
        titles = [i["title"] for i in items]
        assert titles == sorted(titles)

    async def test_list_findings_pagination(self, client):
        await self._seed_findings(5)
        resp = await client.get(
            "/api/findings", params={"page": 1, "page_size": 2}
        )
        data = resp.json()
        assert len(data["items"]) == 2
        assert data["pages"] == 3

    async def test_list_findings_excludes_duplicates(self, client):
        """Duplicates are excluded by default."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id)
            session.add(s)
            await session.flush()
            f1 = Finding(
                scan_id=s.id, title="Original", vulnerability_type="xss",
                severity="high", confidence="verified", scanner_source="zap",
                status="open",
            )
            f2 = Finding(
                scan_id=s.id, title="Dup", vulnerability_type="xss",
                severity="high", confidence="verified", scanner_source="zap",
                status="duplicate",
            )
            session.add_all([f1, f2])
            await session.commit()

        resp = await client.get("/api/findings")
        assert resp.json()["total"] == 1

        resp_all = await client.get(
            "/api/findings", params={"include_duplicates": True}
        )
        assert resp_all.json()["total"] == 2

    async def test_get_finding(self, client):
        _, _, fids = await self._seed_findings(1)
        resp = await client.get(f"/api/findings/{fids[0]}")
        assert resp.status_code == 200
        assert resp.json()["id"] == fids[0]

    async def test_get_finding_not_found(self, client):
        resp = await client.get("/api/findings/nope")
        assert resp.status_code == 404

    async def test_update_finding(self, client):
        _, _, fids = await self._seed_findings(1)
        resp = await client.put(
            f"/api/findings/{fids[0]}",
            json={"status": "false_positive", "notes": "Not exploitable"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "false_positive"
        assert resp.json()["notes"] == "Not exploitable"

    async def test_update_finding_not_found(self, client):
        resp = await client.put("/api/findings/bad-id", json={"status": "resolved"})
        assert resp.status_code == 404

    async def test_findings_summary(self, client):
        await self._seed_findings(5)
        resp = await client.get("/api/findings/summary")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 5
        assert data["critical"] == 1
        assert data["high"] == 1
        assert data["medium"] == 1

    async def test_findings_summary_excludes_duplicates(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id)
            session.add(s)
            await session.flush()
            f1 = Finding(
                scan_id=s.id, title="A", vulnerability_type="xss",
                severity="high", confidence="verified", scanner_source="zap",
                status="open",
            )
            f2 = Finding(
                scan_id=s.id, title="B", vulnerability_type="xss",
                severity="high", confidence="verified", scanner_source="zap",
                status="duplicate",
            )
            session.add_all([f1, f2])
            await session.commit()

        resp = await client.get("/api/findings/summary")
        assert resp.json()["total"] == 1

    async def test_findings_summary_by_scan(self, client):
        scan_id, _, _ = await self._seed_findings(3)
        resp = await client.get(
            "/api/findings/summary", params={"scan_id": scan_id}
        )
        assert resp.status_code == 200
        assert resp.json()["total"] == 3

    async def test_findings_summary_respects_filters(self, client):
        await self._seed_findings(5)
        resp = await client.get(
            "/api/findings/summary",
            params={"severity": "critical", "search": "Finding 0"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["verified"] == 1
        assert data["probable"] == 0
        assert data["observed"] == 0

    async def test_generate_fix(self, client):
        """POST /{id}/generate-fix should attempt fix generation."""
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id)
            session.add(s)
            await session.flush()
            f = Finding(
                scan_id=s.id, title="SQL Injection",
                vulnerability_type="sqli", severity="high",
                confidence="verified", scanner_source="semgrep",
                code_snippet="cursor.execute(query)",
            )
            session.add(f)
            await session.flush()
            fid = f.id
            await session.commit()

        resp = await client.post(f"/api/findings/{fid}/generate-fix")
        assert resp.status_code == 200
        data = resp.json()
        assert data["finding_id"] == fid
        assert "fix_available" in data

    async def test_generate_fix_template_strategy(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="P", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id)
            session.add(s)
            await session.flush()
            f = Finding(
                scan_id=s.id,
                title="XSS",
                vulnerability_type="xss",
                severity="medium",
                confidence="probable",
                scanner_source="semgrep",
                code_snippet="render_template_string(user_input)",
            )
            session.add(f)
            await session.flush()
            fid = f.id
            await session.commit()

        resp = await client.post(
            f"/api/findings/{fid}/generate-fix",
            params={"strategy": "template"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["strategy_used"] == "template"
        assert data["fix_available"] is True

    async def test_generate_fix_not_found(self, client):
        resp = await client.post("/api/findings/bad-id/generate-fix")
        assert resp.status_code == 404

    async def test_list_findings_sort_by_confidence(self, client):
        await self._seed_findings(3)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "confidence", "sort_order": "desc"},
        )
        assert resp.status_code == 200

    async def test_list_findings_sort_by_endpoint(self, client):
        await self._seed_findings(3)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "endpoint", "sort_order": "asc"},
        )
        items = resp.json()["items"]
        endpoints = [i["endpoint"] for i in items]
        assert endpoints == sorted(endpoints)

    async def test_list_findings_filter_by_scanner(self, client):
        await self._seed_findings(3)
        resp = await client.get(
            "/api/findings", params={"scanner_source": "semgrep"}
        )
        assert resp.json()["total"] == 3

    async def test_list_findings_filter_by_status(self, client):
        await self._seed_findings(3)
        resp = await client.get("/api/findings", params={"status": "open"})
        assert resp.json()["total"] == 3

    async def test_list_findings_sort_default_created_at(self, client):
        """Unknown sort_by falls back to created_at desc."""
        await self._seed_findings(2)
        resp = await client.get(
            "/api/findings", params={"sort_by": "unknown_field"}
        )
        assert resp.status_code == 200

    async def test_list_findings_sort_by_cwe(self, client):
        await self._seed_findings(2)
        resp = await client.get(
            "/api/findings", params={"sort_by": "cwe", "sort_order": "asc"}
        )
        assert resp.status_code == 200

    async def test_list_findings_sort_by_file_path(self, client):
        await self._seed_findings(2)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "file_path", "sort_order": "asc"},
        )
        assert resp.status_code == 200

    async def test_list_findings_sort_by_vulnerability_type(self, client):
        await self._seed_findings(2)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "vulnerability_type", "sort_order": "desc"},
        )
        assert resp.status_code == 200

    async def test_list_findings_sort_by_status(self, client):
        await self._seed_findings(2)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "status", "sort_order": "asc"},
        )
        assert resp.status_code == 200

    async def test_list_findings_filter_by_confidence(self, client):
        await self._seed_findings(3)
        resp = await client.get(
            "/api/findings", params={"confidence": "verified"}
        )
        assert resp.json()["total"] == 1

    async def test_list_findings_filter_by_project(self, client):
        scan_id, project_id, _ = await self._seed_findings(3)
        resp = await client.get(
            "/api/findings", params={"project_id": project_id}
        )
        assert resp.json()["total"] == 3

    async def test_list_findings_sort_severity_asc(self, client):
        """sort_order=asc means info first."""
        await self._seed_findings(5)
        resp = await client.get(
            "/api/findings",
            params={"sort_by": "severity", "sort_order": "asc"},
        )
        items = resp.json()["items"]
        # asc: info first (case value 4), critical last (case value 0)
        assert items[0]["severity"] == "info"


# ===========================================================================
# /api/reports
# ===========================================================================


class TestReportsAPI:

    async def _seed_scan_with_findings(self):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan
        from app.models.finding import Finding

        async with test_session_factory() as session:
            p = Project(name="RP", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="completed")
            session.add(s)
            await session.flush()
            f = Finding(
                scan_id=s.id, title="SQL Injection",
                vulnerability_type="sqli", severity="high",
                confidence="verified", scanner_source="semgrep",
            )
            session.add(f)
            await session.flush()
            scan_id = s.id
            project_id = p.id
            await session.commit()
        return scan_id, project_id

    async def test_generate_json_report(self, client):
        scan_id, _ = await self._seed_scan_with_findings()
        resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "json"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["scan_id"] == scan_id
        assert data["format"] == "json"
        assert "download_url" in data
        assert data["download_url"].startswith("/api/v1/reports/")

    async def test_generate_report_scan_not_found(self, client):
        resp = await client.post(
            "/api/reports", json={"scan_id": "bad-scan", "format": "json"}
        )
        assert resp.status_code == 404

    async def test_generate_report_scan_in_progress(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="RP-running", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="running")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "json"}
        )
        assert resp.status_code == 409

    async def test_generate_report_unsupported_format(self, client):
        scan_id, _ = await self._seed_scan_with_findings()
        resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "csv"}
        )
        assert resp.status_code == 400

    async def test_download_report_not_generated(self, client):
        resp = await client.get(
            "/api/reports/some-scan-id/download", params={"format": "json"}
        )
        assert resp.status_code == 404

    async def test_download_report_unsupported_format(self, client):
        resp = await client.get(
            "/api/reports/some-id/download", params={"format": "csv"}
        )
        assert resp.status_code == 400

    async def test_download_invalid_scan_id(self, client):
        resp = await client.get(
            "/api/reports/invalid~scan/download", params={"format": "json"}
        )
        assert resp.status_code == 400

    async def test_generate_and_download_json(self, client):
        """Full round-trip: generate then download."""
        scan_id, _ = await self._seed_scan_with_findings()
        gen_resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "json"}
        )
        assert gen_resp.status_code == 200
        download_url = gen_resp.json()["download_url"]
        dl_resp = await client.get(download_url)
        assert dl_resp.status_code == 200
        report_data = dl_resp.json()
        assert "scan" in report_data
        assert "findings" in report_data

    async def test_generate_and_download_json_v1_endpoint(self, client):
        """Generated download URLs should be versioned under /api/v1."""
        scan_id, _ = await self._seed_scan_with_findings()
        gen_resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "json"}
        )
        assert gen_resp.status_code == 200
        download_url = gen_resp.json()["download_url"]
        assert download_url.startswith("/api/v1/reports/")

        dl_resp = await client.get(download_url)
        assert dl_resp.status_code == 200

    async def test_preview_report(self, client):
        scan_id, _ = await self._seed_scan_with_findings()
        resp = await client.get(f"/api/reports/{scan_id}/preview")
        assert resp.status_code == 200
        data = resp.json()
        assert "scan" in data
        assert "project" in data
        assert "findings" in data
        assert len(data["findings"]) == 1

    async def test_preview_not_found(self, client):
        resp = await client.get("/api/reports/bad-id/preview")
        assert resp.status_code == 404

    async def test_generate_html_report(self, client):
        scan_id, _ = await self._seed_scan_with_findings()
        resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "html"}
        )
        assert resp.status_code == 200
        assert resp.json()["format"] == "html"

    async def test_generate_sarif_report(self, client):
        scan_id, _ = await self._seed_scan_with_findings()
        resp = await client.post(
            "/api/reports", json={"scan_id": scan_id, "format": "sarif"}
        )
        assert resp.status_code == 200
        assert resp.json()["format"] == "sarif"


class TestWebSocketTokenAPI:

    async def test_create_scan_ws_token(self, client):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        async with test_session_factory() as session:
            p = Project(name="WS", source_type="local")
            session.add(p)
            await session.flush()
            s = Scan(project_id=p.id, status="pending")
            session.add(s)
            await session.flush()
            scan_id = s.id
            await session.commit()

        resp = await client.post(
            "/api/v1/auth/ws-token",
            json={"scope": "scan", "scan_id": scan_id},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["scope"] == "scan"
        assert body["token"]
        assert "/ws/scan/" in body["ws_path"]

    async def test_create_dashboard_ws_token(self, client):
        resp = await client.post(
            "/api/v1/auth/ws-token",
            json={"scope": "dashboard"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["scope"] == "dashboard"
        assert body["token"]
        assert body["ws_path"].startswith("/ws/dashboard?token=")

    async def test_create_ws_token_rejects_invalid_scope(self, client):
        resp = await client.post(
            "/api/v1/auth/ws-token",
            json={"scope": "invalid"},
        )
        assert resp.status_code == 400

    async def test_create_ws_token_requires_scan_id_for_scan_scope(self, client):
        resp = await client.post(
            "/api/v1/auth/ws-token",
            json={"scope": "scan"},
        )
        assert resp.status_code == 400


class TestAuthHardening:

    async def test_header_auth_required_without_key(self, client_no_auth):
        resp = await client_no_auth.get("/api/v1/dashboard/stats")
        assert resp.status_code == 401

    async def test_query_param_api_key_rejected(self, client_no_auth):
        from app.core.config import settings

        resp = await client_no_auth.get(
            "/api/v1/dashboard/stats",
            params={"api_key": settings.API_KEY},
        )
        assert resp.status_code == 401

    async def test_invalid_header_api_key_rejected(self, client_no_auth):
        resp = await client_no_auth.get(
            "/api/v1/dashboard/stats",
            headers={"X-API-Key": "wrong-key"},
        )
        assert resp.status_code == 403


# ===========================================================================
# /api/integrations
# ===========================================================================


class TestIntegrationsAPI:

    async def test_list_integrations_default_state(self, client):
        resp = await client.get("/api/integrations")
        assert resp.status_code == 200
        items = {i["key"]: i for i in resp.json()}
        assert "email" in items
        assert items["email"]["enabled"] is False
        assert items["email"]["recipients_count"] == 0

    async def test_email_integration_roundtrip(self, client):
        resp = await client.put(
            "/api/integrations/email",
            json={"enabled": True, "recipients": ["a@example.com", " b@example.com "]},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["enabled"] is True
        assert body["recipients"] == ["a@example.com", "b@example.com"]

        resp = await client.get("/api/integrations/email")
        assert resp.status_code == 200
        body = resp.json()
        assert body["enabled"] is True
        assert body["recipients"] == ["a@example.com", "b@example.com"]

    async def test_email_integration_rejects_invalid_address(self, client):
        resp = await client.put(
            "/api/integrations/email",
            json={"enabled": False, "recipients": ["not-an-email"]},
        )
        assert resp.status_code == 422
        assert "not-an-email" in resp.json()["detail"]

    async def test_email_integration_enable_requires_recipients(self, client):
        resp = await client.put(
            "/api/integrations/email",
            json={"enabled": True, "recipients": []},
        )
        assert resp.status_code == 422

    async def test_email_test_endpoint_requires_smtp_config(self, client):
        resp = await client.post("/api/integrations/email/test")
        assert resp.status_code == 409
        assert "SMTP" in resp.json()["detail"]
