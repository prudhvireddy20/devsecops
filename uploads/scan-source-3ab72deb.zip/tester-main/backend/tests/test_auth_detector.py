"""Tests for the auth detector."""
import os
import tempfile

import pytest

from app.analyzers.auth_detector import AuthDetector


class TestAuthDetector:
    """Test authentication flow detection."""

    def setup_method(self):
        self.detector = AuthDetector()

    def _create_source(self, files: dict[str, str]) -> str:
        """Create a temp dir with multiple files and return the dir path."""
        tmpdir = tempfile.mkdtemp()
        for filename, content in files.items():
            filepath = os.path.join(tmpdir, filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, "w") as f:
                f.write(content)
        return tmpdir

    @pytest.mark.asyncio
    async def test_detect_no_auth(self):
        source = self._create_source({
            "app.py": "def hello():\n    return 'hi'\n",
        })
        result = await self.detector.detect_auth(source)
        assert result["auth_type"] == "none"
        assert result["has_jwt"] is False
        assert result["has_session"] is False

    @pytest.mark.asyncio
    async def test_detect_jwt_auth(self):
        source = self._create_source({
            "auth.py": '''
import jwt

def create_token(user_id):
    return jwt.encode({"user_id": user_id}, "secret", algorithm="HS256")

def verify_token(token):
    return jwt.decode(token, "secret", algorithms=["HS256"])
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["auth_type"] == "jwt"
        assert result["has_jwt"] is True

    @pytest.mark.asyncio
    async def test_detect_session_auth(self):
        source = self._create_source({
            "views.py": '''
from flask import session

def login():
    session["user_id"] = 123
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["auth_type"] == "session"
        assert result["has_session"] is True

    @pytest.mark.asyncio
    async def test_detect_login_route(self):
        source = self._create_source({
            "routes.py": '''
from flask import Flask
app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    pass
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["has_login"] is True
        assert len(result["login_routes"]) >= 1

    @pytest.mark.asyncio
    async def test_detect_csrf(self):
        source = self._create_source({
            "app.py": '''
from flask_wtf import CSRFProtect
csrf = CSRFProtect(app)
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["has_csrf"] is True

    @pytest.mark.asyncio
    async def test_detect_oauth(self):
        source = self._create_source({
            "auth.py": '''
from authlib.integrations.flask_client import OAuth
oauth = OAuth(app)
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["has_oauth"] is True
        assert result["auth_type"] == "oauth"

    @pytest.mark.asyncio
    async def test_detect_auth_decorators(self):
        source = self._create_source({
            "views.py": '''
from flask_login import login_required

@login_required
def dashboard():
    return "protected"
''',
        })
        result = await self.detector.detect_auth(source)
        assert len(result["auth_decorators"]) >= 1

    @pytest.mark.asyncio
    async def test_detect_protected_routes(self):
        source = self._create_source({
            "views.py": '''
from flask import Flask
from flask_login import login_required

app = Flask(__name__)

@login_required
@app.route("/dashboard")
def dashboard():
    return "protected"
''',
            "public.py": '''
from flask import Flask
app = Flask(__name__)

@app.route("/public")
def public_page():
    return "public"
''',
        })
        result = await self.detector.detect_auth(source)
        protected = [r for r in result["protected_routes"] if r["path"] == "/dashboard"]
        public = [r for r in result["public_routes"] if r["path"] == "/public"]
        assert len(protected) >= 1
        assert len(public) >= 1

    @pytest.mark.asyncio
    async def test_detect_password_hashing(self):
        source = self._create_source({
            "auth.py": '''
from werkzeug.security import generate_password_hash, check_password_hash
''',
        })
        result = await self.detector.detect_auth(source)
        # Password hashing is detected but doesn't change auth_type
        assert result["auth_type"] in ("none", "custom")

    @pytest.mark.asyncio
    async def test_nonexistent_path(self):
        result = await self.detector.detect_auth("/nonexistent/path/xyz")
        assert result["auth_type"] == "none"

    @pytest.mark.asyncio
    async def test_jwt_takes_priority_over_session(self):
        """JWT should win when both JWT and session are detected."""
        source = self._create_source({
            "auth.py": '''
import jwt
from flask import session

def login():
    token = jwt.encode({"user": "x"}, "secret")
    session["token"] = token
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["auth_type"] == "jwt"
        assert result["has_jwt"] is True
        assert result["has_session"] is True

    @pytest.mark.asyncio
    async def test_fastapi_auth_patterns(self):
        source = self._create_source({
            "main.py": '''
from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

@app.post("/token")
def login():
    return create_access_token(data={"sub": user.username})
''',
        })
        result = await self.detector.detect_auth(source)
        assert result["has_jwt"] is True
        assert result["has_login"] is True


class TestAuthDetectorSuggestion:
    """Test auth script suggestion generation."""

    def setup_method(self):
        self.detector = AuthDetector()

    @pytest.mark.asyncio
    async def test_jwt_suggestion(self):
        auth_info = {"auth_type": "jwt", "login_routes": []}
        suggestion = await self.detector.generate_auth_suggestion(auth_info)
        assert suggestion["auth_type"] == "jwt"
        assert "playwright" in suggestion["script"].lower()
        assert len(suggestion["notes"]) >= 1

    @pytest.mark.asyncio
    async def test_session_suggestion(self):
        auth_info = {"auth_type": "session", "login_routes": []}
        suggestion = await self.detector.generate_auth_suggestion(auth_info)
        assert suggestion["auth_type"] == "session"
        assert "playwright" in suggestion["script"].lower()

    @pytest.mark.asyncio
    async def test_custom_suggestion(self):
        auth_info = {"auth_type": "custom", "login_routes": []}
        suggestion = await self.detector.generate_auth_suggestion(auth_info)
        assert suggestion["auth_type"] == "custom"
        assert len(suggestion["script"]) > 0

    @pytest.mark.asyncio
    async def test_none_suggestion(self):
        auth_info = {"auth_type": "none", "login_routes": []}
        suggestion = await self.detector.generate_auth_suggestion(auth_info)
        assert suggestion["script"] == ""

    @pytest.mark.asyncio
    async def test_suggestion_with_login_route(self):
        auth_info = {
            "auth_type": "jwt",
            "login_routes": [{"file": "auth.py", "line": 10, "code": "@app.post('/login')"}],
        }
        suggestion = await self.detector.generate_auth_suggestion(auth_info)
        assert any("auth.py" in note for note in suggestion["notes"])
