"""Tests for the auth script generator."""
import pytest
from app.auth.auth_script_gen import AuthScriptGenerator


class TestAuthScriptGenerator:
    """Test authentication script generation."""

    def setup_method(self):
        self.gen = AuthScriptGenerator()

    def test_generate_config_basic(self):
        auth_info = {
            "auth_type": "session",
            "login_routes": [{"code": "@app.route('/login')", "file": "app.py", "line": 10}],
        }
        config = self.gen.generate_config(auth_info, "http://localhost:5000")
        assert config["auth_type"] == "session"
        assert config["login_url"] == "http://localhost:5000/login"

    def test_generate_config_no_login_routes(self):
        auth_info = {"auth_type": "jwt", "login_routes": []}
        config = self.gen.generate_config(auth_info, "http://localhost:5000")
        assert config["login_url"] == "http://localhost:5000/login"  # default

    def test_generate_config_strips_trailing_slash(self):
        auth_info = {"auth_type": "session", "login_routes": []}
        config = self.gen.generate_config(auth_info, "http://localhost:5000/")
        assert config["login_url"] == "http://localhost:5000/login"

    @pytest.mark.asyncio
    async def test_generate_jwt_script(self):
        auth_info = {"auth_type": "jwt", "login_routes": [], "has_jwt": True}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert result["auth_type"] == "jwt"
        assert "localStorage" in result["script"]
        assert "token" in result["script"].lower()

    @pytest.mark.asyncio
    async def test_generate_session_script(self):
        auth_info = {"auth_type": "session", "login_routes": [], "has_session": True}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert result["auth_type"] == "session"
        assert "cookies" in result["script"].lower()

    @pytest.mark.asyncio
    async def test_generate_session_with_csrf(self):
        auth_info = {"auth_type": "session", "login_routes": [], "has_csrf": True}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert "csrf" in result["script"].lower()

    @pytest.mark.asyncio
    async def test_generate_oauth_script(self):
        auth_info = {"auth_type": "oauth", "login_routes": [], "has_oauth": True}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert result["auth_type"] == "oauth"
        assert "OAuth" in result["script"] or "oauth" in result["script"].lower()

    @pytest.mark.asyncio
    async def test_generate_generic_script(self):
        auth_info = {"auth_type": "unknown", "login_routes": []}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert "generic" in result["script"].lower() or "customize" in result["script"].lower()

    @pytest.mark.asyncio
    async def test_generate_notes_jwt(self):
        auth_info = {"auth_type": "jwt", "has_jwt": True, "login_routes": []}
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        notes = result["notes"]
        assert any("JWT" in n for n in notes)

    @pytest.mark.asyncio
    async def test_generate_notes_protected_routes(self):
        auth_info = {
            "auth_type": "session",
            "login_routes": [],
            "protected_routes": [{"path": "/admin"}, {"path": "/dashboard"}],
        }
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert any("2 protected" in n for n in result["notes"])

    @pytest.mark.asyncio
    async def test_login_url_extracted_from_route(self):
        auth_info = {
            "auth_type": "session",
            "login_routes": [
                {"code": "@app.route('/auth/signin')", "file": "auth.py", "line": 5}
            ],
        }
        result = await self.gen.generate(auth_info, "http://localhost:5000")
        assert "/auth/signin" in result["login_url"]
