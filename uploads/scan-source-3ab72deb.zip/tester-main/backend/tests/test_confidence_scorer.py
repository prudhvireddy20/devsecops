"""Tests for the confidence scorer."""
from app.correlation.confidence_scorer import ConfidenceScorer


class TestConfidenceScorer:
    """Test confidence score calculation."""

    def setup_method(self):
        self.scorer = ConfidenceScorer()

    def test_verified_both_scanners(self):
        sast = {"vulnerability_type": "sqli", "parameter": "id", "endpoint": "/users", "cwe": "CWE-89"}
        dast = {"vulnerability_type": "sqli", "parameter": "id", "endpoint": "/users", "cwe": "CWE-89"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert result["confidence"] == "verified"
        assert result["score"] >= 70

    def test_probable_sast_only(self):
        sast = {"vulnerability_type": "sqli", "file_path": "app.py"}
        result = self.scorer.score(sast_finding=sast)
        assert result["confidence"] == "probable"
        assert result["score"] >= 30

    def test_dast_only_is_observed(self):
        # DAST-only findings remain observed without source correlation.
        dast = {"vulnerability_type": "xss", "endpoint": "/search"}
        result = self.scorer.score(dast_finding=dast)
        assert result["confidence"] == "observed"
        assert result["score"] < 30

    def test_dast_with_exploit_evidence_boosts_score(self):
        dast_no_evidence = {"vulnerability_type": "xss"}
        dast_with_evidence = {
            "vulnerability_type": "xss",
            "payload": "<script>alert(1)</script>",
            "response_evidence": "alert(1)",
        }
        score_no = self.scorer.score(dast_finding=dast_no_evidence)
        score_yes = self.scorer.score(dast_finding=dast_with_evidence)
        assert score_yes["score"] > score_no["score"]

    def test_sast_with_sink_boosts_score(self):
        sast = {"vulnerability_type": "sqli"}
        score_no = self.scorer.score(sast_finding=sast)
        score_yes = self.scorer.score(sast_finding=sast, extra={"sink_detected": True})
        assert score_yes["score"] > score_no["score"]

    def test_parameter_match_bonus(self):
        sast = {"vulnerability_type": "sqli", "parameter": "id"}
        dast_match = {"vulnerability_type": "sqli", "parameter": "id"}
        dast_nomatch = {"vulnerability_type": "sqli", "parameter": "name"}
        score_match = self.scorer.score(sast_finding=sast, dast_finding=dast_match)
        score_nomatch = self.scorer.score(sast_finding=sast, dast_finding=dast_nomatch)
        assert score_match["score"] > score_nomatch["score"]

    def test_endpoint_match_bonus(self):
        sast = {"vulnerability_type": "sqli", "endpoint": "/users"}
        dast = {"vulnerability_type": "sqli", "endpoint": "/users"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert "Endpoint match" in " ".join(result["factors"])

    def test_endpoint_match_bonus_requires_actual_match(self):
        sast = {"vulnerability_type": "sqli", "endpoint": "/users"}
        dast = {"vulnerability_type": "sqli", "endpoint": "/admins"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert "Endpoint match" not in " ".join(result["factors"])

    def test_cwe_match_bonus(self):
        sast = {"vulnerability_type": "sqli", "cwe": "CWE-89"}
        dast = {"vulnerability_type": "sqli", "cwe": "CWE-89"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert "CWE match" in " ".join(result["factors"])

    def test_cwe_match_bonus_normalizes_variant_format(self):
        sast = {"vulnerability_type": "sqli", "cwe": "CWE-89"}
        dast = {"vulnerability_type": "sqli", "cwe": "CWE-89: Improper Neutralization of Special Elements"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert "CWE match" in " ".join(result["factors"])

    def test_no_findings_returns_observed(self):
        result = self.scorer.score()
        assert result["confidence"] == "observed"
        assert result["score"] == 0

    def test_score_capped_at_100(self):
        sast = {"vulnerability_type": "sqli", "parameter": "id", "endpoint": "/users", "cwe": "CWE-89"}
        dast = {"vulnerability_type": "sqli", "parameter": "id", "endpoint": "/users", "cwe": "CWE-89"}
        result = self.scorer.score(sast_finding=sast, dast_finding=dast)
        assert result["score"] <= 100

    def test_confidence_description(self):
        desc = self.scorer._confidence_description("verified")
        assert "confirmed" in desc.lower() or "remediation" in desc.lower()
        desc = self.scorer._confidence_description("unknown")
        assert "Unknown" in desc

    def test_adjust_for_severity(self):
        # verified + critical should have highest priority
        high_priority = self.scorer.adjust_for_severity("verified", "critical")
        low_priority = self.scorer.adjust_for_severity("observed", "low")
        assert high_priority > low_priority

    def test_adjust_for_severity_unknown_values(self):
        # Should not crash with unknown values
        result = self.scorer.adjust_for_severity("unknown", "unknown")
        assert isinstance(result, int)
