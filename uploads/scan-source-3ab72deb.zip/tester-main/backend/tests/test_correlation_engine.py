"""Tests for the correlation engine."""
from app.correlation.correlation_engine import CorrelationEngine, VULN_TYPE_EQUIVALENTS


class TestCorrelationEngine:
    """Test SAST/DAST finding correlation."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_correlate_empty_inputs(self):
        result = self.engine.correlate([], [])
        assert result == []

    def test_correlate_sast_only(self):
        sast = [{"vulnerability_type": "sqli", "file_path": "app.py", "line_number": 10}]
        result = self.engine.correlate(sast, [])
        assert len(result) == 1
        assert result[0]["confidence"] == "probable"
        assert result[0]["sast_data"] == sast[0]
        assert result[0]["dast_data"] is None

    def test_correlate_dast_only(self):
        dast = [{"vulnerability_type": "xss", "endpoint": "/search", "parameter": "q"}]
        result = self.engine.correlate([], dast)
        assert len(result) == 1
        assert result[0]["confidence"] == "observed"
        assert result[0]["dast_data"] == dast[0]
        assert result[0]["sast_data"] is None

    def test_correlate_matching_type(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_uses_file_route_candidates_when_sast_endpoint_is_stale(self):
        engine = CorrelationEngine(
            routes=[
                {"file": "src/routes/user.js", "path": "/rest/user/login"},
                {"file": "src/routes/user.js", "path": "/rest/user/register"},
            ]
        )
        sast = [{
            "vulnerability_type": "xss",
            "file_path": "src/routes/user.js",
            "endpoint": "/stale/path",
        }]
        dast = [{"vulnerability_type": "xss", "endpoint": "/rest/user/login"}]
        result = engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_equivalent_types(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/api/data"}]
        dast = [{"vulnerability_type": "sql_injection", "endpoint": "/api/data"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_no_match_different_types(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users"}]
        dast = [{"vulnerability_type": "xss", "endpoint": "/users"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 0
        assert len(result) == 2  # one probable, one observed

    def test_correlate_allows_cwe_fallback_when_types_differ(self):
        sast = [{"vulnerability_type": "code_injection", "endpoint": "/run", "cwe": "CWE-78"}]
        dast = [{"vulnerability_type": "cmdi", "endpoint": "/run", "cwe": "CWE-78: OS Command Injection"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_no_match_different_endpoints(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/products"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 0

    def test_correlate_multiple_findings(self):
        sast = [
            {"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"},
            {"vulnerability_type": "xss", "endpoint": "/search", "parameter": "q"},
            {"vulnerability_type": "cmdi", "endpoint": "/run"},
        ]
        dast = [
            {"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"},
            {"vulnerability_type": "ssrf", "endpoint": "/fetch"},
        ]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        probable = [r for r in result if r["confidence"] == "probable"]
        observed = [r for r in result if r["confidence"] == "observed"]
        assert len(verified) == 1  # sqli matched
        assert len(probable) == 2  # xss + cmdi unmatched
        assert len(observed) == 1  # ssrf unmatched

    def test_correlate_verified_without_sast_param_when_cwe_and_endpoint_match(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users/{id}", "cwe": "CWE-89"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/users/123", "parameter": "name", "cwe": "CWE-89"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_rejects_real_parameter_mismatch(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users/{id}", "parameter": "id", "cwe": "CWE-89"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/users/123", "parameter": "name", "cwe": "CWE-89"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 0

    def test_correlate_accepts_normalized_parameter_name(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users/{id}", "parameter": "id"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/users/123", "parameter": "id (path)"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_endpoints_match_parameterized(self):
        # {id} becomes wildcard *, so it matches any segment including "123"
        assert self.engine._endpoints_match("users/{id}", "users/123") is True
        assert self.engine._endpoints_match("users/{id}", "users/{user_id}") is True
        assert self.engine._endpoints_match("api/users", "api/users") is True
        # Different static segments should not match
        assert self.engine._endpoints_match("users/{id}", "products/{id}") is False

    def test_endpoints_match_decodes_encoded_path_params(self):
        assert self.engine._endpoints_match("/users/{id}", "/users/%7Bid%7D") is True

    def test_global_scope_matches_only_when_allowed(self):
        assert self.engine._endpoints_match("/*", "/api/users", allow_global_scope=True) is True
        assert self.engine._endpoints_match("/*", "/api/users", allow_global_scope=False) is False

    def test_endpoints_match_different_length(self):
        assert self.engine._endpoints_match("api/users", "api/users/list") is False

    def test_find_match_for_sast_finding(self):
        sast = [{"vulnerability_type": "sqli", "file_path": "app.py", "endpoint": "/users"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/users"}]
        correlated = self.engine.correlate(sast, dast)

        class MockFinding:
            vulnerability_type = "sqli"
            endpoint = "/users"
            file_path = "app.py"
            scanner_source = "semgrep"

        match = self.engine.find_match(MockFinding(), correlated)
        assert match is not None
        assert match["confidence"] == "verified"

    def test_find_match_returns_none_for_unmatched(self):
        correlated = self.engine.correlate([], [])

        class MockFinding:
            vulnerability_type = "sqli"
            endpoint = "/users"
            file_path = "app.py"
            scanner_source = "semgrep"

        match = self.engine.find_match(MockFinding(), correlated)
        assert match is None


class TestVulnTypeEquivalents:
    """Test vulnerability type equivalence mapping."""

    def test_sqli_equivalents(self):
        assert "sqli" in VULN_TYPE_EQUIVALENTS
        assert "sql_injection" in VULN_TYPE_EQUIVALENTS["sqli"]

    def test_xss_equivalents(self):
        assert "xss" in VULN_TYPE_EQUIVALENTS
        assert "cross-site-scripting" in VULN_TYPE_EQUIVALENTS["xss"]

    def test_cmdi_equivalents(self):
        assert "cmdi" in VULN_TYPE_EQUIVALENTS
        assert "command_injection" in VULN_TYPE_EQUIVALENTS["cmdi"]


class TestEndpointMatching:
    """Test endpoint matching with various URL parameter formats."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_express_colon_params(self):
        """Express :id should normalize to wildcard and match {id}."""
        assert self.engine._endpoints_match("/users/:id", "/users/{id}") is True
        assert self.engine._endpoints_match("/users/:id", "/users/123") is True
        assert self.engine._endpoints_match("/api/:version/users/:id", "/api/{v}/users/{userId}") is True

    def test_flask_angle_bracket_params(self):
        """Flask <int:id> should normalize to wildcard."""
        assert self.engine._endpoints_match("/users/<int:id>", "/users/{id}") is True
        assert self.engine._endpoints_match("/users/<int:id>", "/users/:id") is True
        assert self.engine._endpoints_match("/users/<string:name>", "/users/john") is True

    def test_fastapi_curly_brace_params(self):
        """FastAPI {id} should normalize to wildcard."""
        assert self.engine._endpoints_match("/users/{id}", "/users/{user_id}") is True
        assert self.engine._endpoints_match("/users/{id}", "/users/42") is True

    def test_static_segments_must_match(self):
        assert self.engine._endpoints_match("/users/:id", "/products/:id") is False
        assert self.engine._endpoints_match("/api/v1/users", "/api/v2/users") is False

    def test_different_lengths_no_match(self):
        assert self.engine._endpoints_match("/users/:id/posts", "/users/:id") is False


class TestGlobalScopeCorrelation:
    """Test strict global-scope endpoint handling."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_correlate_allows_global_scope_for_config_class(self):
        sast = [{"vulnerability_type": "config", "endpoint": "/*", "cwe": "CWE-942"}]
        dast = [{"vulnerability_type": "config", "endpoint": "/api/users", "cwe": "CWE-942"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_correlate_rejects_global_scope_for_injection_class(self):
        sast = [{"vulnerability_type": "sqli", "endpoint": "/*", "cwe": "CWE-89"}]
        dast = [{"vulnerability_type": "sqli", "endpoint": "/api/users", "cwe": "CWE-89"}]
        result = self.engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 0


class TestCweNormalization:
    """Test CWE normalization in the verified-guards logic."""

    def test_short_cwe_matches_long(self):
        """CWE-89 should match 'CWE-89: Improper Neutralization of ...'."""
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "", "cwe": "CWE-89"},
            {"parameter": "", "cwe": "CWE-89: Improper Neutralization of Special Elements"},
            endpoint_match=True,
        )
        assert result is True

    def test_identical_short_cwes(self):
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "", "cwe": "CWE-79"},
            {"parameter": "", "cwe": "CWE-79"},
            endpoint_match=True,
        )
        assert result is True

    def test_different_cwes_no_param(self):
        """Different CWE IDs without parameter match should fail."""
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "", "cwe": "CWE-89"},
            {"parameter": "", "cwe": "CWE-79"},
            endpoint_match=True,
        )
        assert result is False

    def test_cwe_case_insensitive(self):
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "", "cwe": "cwe-89"},
            {"parameter": "", "cwe": "CWE-89"},
            endpoint_match=True,
        )
        assert result is True

    def test_empty_cwes_with_param_match(self):
        """Parameter match alone should pass the guards."""
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "id", "cwe": ""},
            {"parameter": "id", "cwe": ""},
            endpoint_match=True,
        )
        assert result is True

    def test_no_endpoint_match_always_fails(self):
        """Without endpoint match, guards always fail."""
        result = CorrelationEngine._passes_verified_guards(
            {"parameter": "id", "cwe": "CWE-89"},
            {"parameter": "id", "cwe": "CWE-89"},
            endpoint_match=False,
        )
        assert result is False


class TestRoleAwareCorrelation:
    """Test role-aware correlation for access control issues."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_correlate_by_role_empty_inputs(self):
        """Test with empty SAST and DAST."""
        result = self.engine.correlate_by_role([], {})
        assert result == []

    def test_correlate_by_role_single_role(self):
        """Test with findings from single role."""
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"}]
        dast_by_role = {
            "user": [
                {"vulnerability_type": "sqli", "endpoint": "/users", "parameter": "id"}
            ]
        }
        result = self.engine.correlate_by_role(sast, dast_by_role)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1
        assert verified[0]["dast_data"]["_auth_role"] == "user"

    def test_correlate_by_role_preserves_role_context(self):
        """Test that role context is preserved in results."""
        sast = [{"vulnerability_type": "sqli", "endpoint": "/users"}]
        dast_by_role = {
            "guest": [{"vulnerability_type": "sqli", "endpoint": "/users"}],
            "admin": [{"vulnerability_type": "sqli", "endpoint": "/users"}],
        }
        result = self.engine.correlate_by_role(sast, dast_by_role)
        assert len(result) >= 1
        # Check that at least one finding has role annotation
        annotated = [r for r in result if r.get("dast_data", {}).get("_auth_role")]
        assert len(annotated) >= 1

    def test_correlate_by_role_multiple_roles_different_endpoints(self):
        """Test correlation across multiple roles with different endpoints."""
        sast = [{"vulnerability_type": "sqli", "endpoint": "/admin/users"}]
        dast_by_role = {
            "user": [{"vulnerability_type": "sqli", "endpoint": "/admin/users"}],
            "admin": [{"vulnerability_type": "sqli", "endpoint": "/admin/users"}],
        }
        result = self.engine.correlate_by_role(sast, dast_by_role)
        # Should still correlate normally since same endpoint
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) >= 1

    def test_verify_idor_two_roles_same_endpoint(self):
        """Test IDOR verification when 2+ roles access same parameterized endpoint."""
        sast = {"vulnerability_type": "idor", "endpoint": "/api/users/{id}", "parameter": "id"}
        dast_by_role = {
            "user": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "id"}
            ],
            "guest": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "id"}
            ],
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is True

    def test_verify_idor_single_role_not_verified(self):
        """Test IDOR not verified with single role."""
        sast = {"vulnerability_type": "idor", "endpoint": "/api/users/{id}", "parameter": "id"}
        dast_by_role = {
            "user": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "id"}
            ]
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is False

    def test_verify_idor_no_parameter(self):
        """Test IDOR not verified when no parameter in SAST."""
        sast = {"vulnerability_type": "idor", "endpoint": "/api/users"}
        dast_by_role = {
            "user": [{"vulnerability_type": "idor", "endpoint": "/api/users/42"}],
            "admin": [{"vulnerability_type": "idor", "endpoint": "/api/users/42"}],
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is False

    def test_verify_idor_different_type(self):
        """Test IDOR verification skipped for non-IDOR types."""
        sast = {"vulnerability_type": "sqli", "endpoint": "/api/users/{id}", "parameter": "id"}
        dast_by_role = {
            "user": [{"vulnerability_type": "sqli", "endpoint": "/api/users/42"}],
            "admin": [{"vulnerability_type": "sqli", "endpoint": "/api/users/42"}],
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is False

    def test_verify_idor_parameter_mismatch(self):
        """Test IDOR not verified when parameter names don't match."""
        sast = {"vulnerability_type": "idor", "endpoint": "/api/users/{id}", "parameter": "user_id"}
        dast_by_role = {
            "user": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "product_id"}
            ],
            "admin": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "product_id"}
            ],
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is False

    def test_verify_idor_normalized_parameter_names(self):
        """Test IDOR verified with normalized parameter names."""
        sast = {"vulnerability_type": "idor", "endpoint": "/api/users/{id}", "parameter": "user_id"}
        dast_by_role = {
            "user": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "userId"}
            ],
            "admin": [
                {"vulnerability_type": "idor", "endpoint": "/api/users/42", "parameter": "userId"}
            ],
        }
        is_verified = self.engine._verify_idor(sast, dast_by_role)
        assert is_verified is True

    def test_verify_auth_logic_privilege_escalation(self):
        """Test auth issue verification with privilege escalation."""
        sast = {"vulnerability_type": "auth", "endpoint": "/api/admin"}
        dast_by_role = {
            "guest": [{"vulnerability_type": "auth", "endpoint": "/api/admin"}],
            "admin": [{"vulnerability_type": "auth", "endpoint": "/api/admin"}],
        }
        is_verified = self.engine._verify_auth_logic(sast, dast_by_role)
        assert is_verified is True

    def test_verify_auth_logic_no_escalation(self):
        """Test auth not verified when all roles are same privilege level."""
        sast = {"vulnerability_type": "auth", "endpoint": "/api/data"}
        dast_by_role = {
            "user": [{"vulnerability_type": "auth", "endpoint": "/api/data"}],
            "guest": [{"vulnerability_type": "auth", "endpoint": "/api/data"}],
        }
        is_verified = self.engine._verify_auth_logic(sast, dast_by_role)
        assert is_verified is False

    def test_verify_auth_logic_admin_only(self):
        """Test auth not verified when only admin has access."""
        sast = {"vulnerability_type": "auth", "endpoint": "/api/admin"}
        dast_by_role = {
            "admin": [{"vulnerability_type": "auth", "endpoint": "/api/admin"}],
        }
        is_verified = self.engine._verify_auth_logic(sast, dast_by_role)
        assert is_verified is False

    def test_verify_auth_logic_different_type(self):
        """Test auth verification skipped for non-auth types."""
        sast = {"vulnerability_type": "sqli", "endpoint": "/api/admin"}
        dast_by_role = {
            "guest": [{"vulnerability_type": "sqli", "endpoint": "/api/admin"}],
            "admin": [{"vulnerability_type": "sqli", "endpoint": "/api/admin"}],
        }
        is_verified = self.engine._verify_auth_logic(sast, dast_by_role)
        assert is_verified is False

    def test_verify_auth_logic_user_to_admin_escalation(self):
        """Test auth issue verified for user accessing admin endpoint."""
        sast = {"vulnerability_type": "auth", "endpoint": "/api/admin/settings"}
        dast_by_role = {
            "user": [{"vulnerability_type": "auth", "endpoint": "/api/admin/settings"}],
            "admin": [{"vulnerability_type": "auth", "endpoint": "/api/admin/settings"}],
        }
        is_verified = self.engine._verify_auth_logic(sast, dast_by_role)
        assert is_verified is True

    def test_correlate_by_role_idor_integration(self):
        """Integration test: IDOR should use role-aware correlation."""
        sast = [
            {"vulnerability_type": "idor", "endpoint": "/api/profile/{id}", "parameter": "id"}
        ]
        dast_by_role = {
            "user": [
                {"vulnerability_type": "idor", "endpoint": "/api/profile/99", "parameter": "id"}
            ],
            "admin": [
                {"vulnerability_type": "idor", "endpoint": "/api/profile/99", "parameter": "id"}
            ],
        }
        result = self.engine.correlate_by_role(sast, dast_by_role)
        # At least one result should have role annotation
        assert any(
            r.get("dast_data", {}).get("_auth_role") for r in result
        )

    def test_correlate_by_role_auth_logic_integration(self):
        """Integration test: Auth logic should use role-aware correlation."""
        sast = [
            {"vulnerability_type": "auth", "endpoint": "/api/admin"}
        ]
        dast_by_role = {
            "guest": [
                {"vulnerability_type": "auth", "endpoint": "/api/admin"}
            ],
            "admin": [
                {"vulnerability_type": "auth", "endpoint": "/api/admin"}
            ],
        }
        result = self.engine.correlate_by_role(sast, dast_by_role)
        # Should have at least one finding with role context
        assert len(result) >= 1


class TestMassAssignmentVerification:
    """Test mass assignment vulnerability verification."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_verify_mass_assignment_endpoint_match(self):
        """Test mass assignment verified when DAST finds endpoint."""
        sast = {"vulnerability_type": "mass_assignment", "endpoint": "/api/users"}
        dast_findings = [
            {"vulnerability_type": "mass_assignment", "endpoint": "/api/users"}
        ]
        is_verified = self.engine._verify_mass_assignment(sast, dast_findings)
        assert is_verified is True

    def test_verify_mass_assignment_no_match(self):
        """Test mass assignment not verified without endpoint match."""
        sast = {"vulnerability_type": "mass_assignment", "endpoint": "/api/users"}
        dast_findings = [
            {"vulnerability_type": "mass_assignment", "endpoint": "/api/products"}
        ]
        is_verified = self.engine._verify_mass_assignment(sast, dast_findings)
        assert is_verified is False

    def test_verify_mass_assignment_different_type(self):
        """Test mass assignment not verified for non-mass-assignment types."""
        sast = {"vulnerability_type": "sqli", "endpoint": "/api/users"}
        dast_findings = [
            {"vulnerability_type": "mass_assignment", "endpoint": "/api/users"}
        ]
        is_verified = self.engine._verify_mass_assignment(sast, dast_findings)
        assert is_verified is False

    def test_verify_mass_assignment_no_endpoint(self):
        """Test mass assignment not verified without SAST endpoint."""
        sast = {"vulnerability_type": "mass_assignment"}
        dast_findings = [
            {"vulnerability_type": "mass_assignment", "endpoint": "/api/users"}
        ]
        is_verified = self.engine._verify_mass_assignment(sast, dast_findings)
        assert is_verified is False


class TestConfigIssueVerification:
    """Test configuration issue verification."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_verify_config_by_cwe_match(self):
        """Test config issue verified by CWE match."""
        sast = {"vulnerability_type": "config", "cwe": "CWE-942"}
        dast_findings = [
            {"vulnerability_type": "config", "cwe": "CWE-942"}
        ]
        is_verified = self.engine._verify_config_issue(sast, dast_findings)
        assert is_verified is True

    def test_verify_config_by_keyword_match(self):
        """Test config issue verified by description keyword."""
        sast = {"vulnerability_type": "config", "description": "Debug mode enabled"}
        dast_findings = [
            {"vulnerability_type": "header", "description": "Debug mode detected in response"}
        ]
        is_verified = self.engine._verify_config_issue(sast, dast_findings)
        assert is_verified is True

    def test_verify_config_cache_control(self):
        """Test config issue verified for cache-control misconfiguration."""
        sast = {"vulnerability_type": "config", "description": "missing cache-control header"}
        dast_findings = [
            {"vulnerability_type": "header", "description": "cache-control header not found"}
        ]
        is_verified = self.engine._verify_config_issue(sast, dast_findings)
        assert is_verified is True

    def test_verify_config_different_type(self):
        """Test config not verified for non-config SAST type."""
        sast = {"vulnerability_type": "sqli", "cwe": "CWE-89"}
        dast_findings = [
            {"vulnerability_type": "config", "cwe": "CWE-89"}
        ]
        is_verified = self.engine._verify_config_issue(sast, dast_findings)
        assert is_verified is False


class TestInfoDisclosureVerification:
    """Test information disclosure verification."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_verify_info_disclosure_by_cwe(self):
        """Test info disclosure verified by CWE match."""
        sast = {"vulnerability_type": "info_disclosure", "cwe": "CWE-209"}
        dast_findings = [
            {"vulnerability_type": "info_disclosure", "cwe": "CWE-209"}
        ]
        is_verified = self.engine._verify_info_disclosure(sast, dast_findings)
        assert is_verified is True

    def test_verify_info_disclosure_by_keyword(self):
        """Test info disclosure verified by keyword in evidence."""
        sast = {"vulnerability_type": "info_disclosure", "description": "Stack trace exposed"}
        dast_findings = [
            {
                "vulnerability_type": "error",
                "description": "Error page contains stack trace",
                "evidence": "at app.js:45"
            }
        ]
        is_verified = self.engine._verify_info_disclosure(sast, dast_findings)
        assert is_verified is True

    def test_verify_info_disclosure_version_leak(self):
        """Test info disclosure verified for version information leak."""
        sast = {"vulnerability_type": "info_disclosure", "description": "Version number exposed"}
        dast_findings = [
            {
                "vulnerability_type": "header",
                "description": "Server header reveals version",
                "evidence": "Server: Apache/2.4.41"
            }
        ]
        is_verified = self.engine._verify_info_disclosure(sast, dast_findings)
        assert is_verified is True

    def test_verify_info_disclosure_endpoint_match(self):
        """Test info disclosure verified with endpoint matching."""
        sast = {
            "vulnerability_type": "info_disclosure",
            "endpoint": "/api/debug",
            "description": "debug endpoint exposes internals"
        }
        dast_findings = [
            {
                "vulnerability_type": "info_disclosure",
                "endpoint": "/api/debug",
                "evidence": "debug mode enabled in response"
            }
        ]
        is_verified = self.engine._verify_info_disclosure(sast, dast_findings)
        assert is_verified is True

    def test_verify_info_disclosure_different_type(self):
        """Test info disclosure not verified for non-info-disclosure SAST."""
        sast = {"vulnerability_type": "sqli", "description": "SQL injection"}
        dast_findings = [
            {"vulnerability_type": "info_disclosure", "description": "Information exposed"}
        ]
        is_verified = self.engine._verify_info_disclosure(sast, dast_findings)
        assert is_verified is False


class TestBruteForceVerification:
    """Test brute force / rate limiting vulnerability verification."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_verify_brute_force_matching_cwe(self):
        """Test brute force verified when CWE matches."""
        sast = {
            "vulnerability_type": "brute_force",
            "cwe": "CWE-307",
            "endpoint": "/api/login",
            "description": "Missing rate limiting on authentication"
        }
        dast_findings = [
            {
                "vulnerability_type": "brute_force",
                "cwe": "CWE-307",
                "endpoint": "/api/login",
                "evidence": "No rate limit headers detected"
            }
        ]
        is_verified = self.engine._verify_brute_force(sast, dast_findings)
        assert is_verified is True

    def test_verify_brute_force_via_evidence(self):
        """Test brute force verified via evidence keywords."""
        sast = {
            "vulnerability_type": "brute_force",
            "endpoint": "/login",
            "description": "No rate limiting"
        }
        dast_findings = [
            {
                "vulnerability_type": "auth",
                "endpoint": "/login",
                "evidence": "HTTP 429 Too Many Requests detected"
            }
        ]
        is_verified = self.engine._verify_brute_force(sast, dast_findings)
        assert is_verified is True

    def test_verify_brute_force_no_match(self):
        """Test brute force not verified with mismatched endpoints."""
        sast = {
            "vulnerability_type": "brute_force",
            "endpoint": "/api/login",
            "description": "No rate limiting"
        }
        dast_findings = [
            {
                "vulnerability_type": "brute_force",
                "endpoint": "/api/register",
                "evidence": "Rate limiting bypassed"
            }
        ]
        is_verified = self.engine._verify_brute_force(sast, dast_findings)
        assert is_verified is False

    def test_verify_brute_force_wrong_type(self):
        """Test brute force not verified for non-brute_force SAST."""
        sast = {"vulnerability_type": "xss", "description": "XSS vulnerability"}
        dast_findings = [
            {"vulnerability_type": "brute_force", "description": "Rate limit bypass"}
        ]
        is_verified = self.engine._verify_brute_force(sast, dast_findings)
        assert is_verified is False

    def test_verify_brute_force_retry_keyword(self):
        """Test brute force verified with retry-related evidence."""
        sast = {
            "vulnerability_type": "brute_force",
            "description": "Missing rate limiting"
        }
        dast_findings = [
            {
                "vulnerability_type": "auth",
                "description": "Authentication requests can be retried indefinitely",
                "evidence": "No retry limits in response headers"
            }
        ]
        is_verified = self.engine._verify_brute_force(sast, dast_findings)
        assert is_verified is True


class TestCORSVerification:
    """Test CORS misconfiguration vulnerability verification."""

    def setup_method(self):
        self.engine = CorrelationEngine()

    def test_verify_cors_matching_cwe(self):
        """Test CORS verified when CWE matches."""
        sast = {
            "vulnerability_type": "cors",
            "cwe": "CWE-942",
            "description": "CORS allows all origins"
        }
        dast_findings = [
            {
                "vulnerability_type": "cors",
                "cwe": "CWE-942",
                "evidence": "Access-Control-Allow-Origin: *"
            }
        ]
        is_verified = self.engine._verify_cors(sast, dast_findings)
        assert is_verified is True


# ============================================================================
# PHASE 1 TEST CASES: NEW CORRELATION ENHANCEMENTS
# ============================================================================

class TestPhase1ParameterMatching:
    """Test PHASE 1: Enhanced parameter matching with abbreviations and fuzzy matching."""

    def test_parameter_fuzzy_match_typo(self):
        """Test fuzzy matching allows minor typos (80%+ similarity)."""
        # "userid" vs "userif" should match (only 1 char different out of 6)
        assert CorrelationEngine._parameters_match("userid", "userif") is True

    def test_parameter_fuzzy_match_abbreviation_user(self):
        """Test abbreviation: 'user' matches 'usr'."""
        assert CorrelationEngine._parameters_match("user", "usr") is True
        assert CorrelationEngine._parameters_match("usr", "user") is True

    def test_parameter_fuzzy_match_abbreviation_customer(self):
        """Test abbreviation: 'customer' matches 'cust'."""
        assert CorrelationEngine._parameters_match("customer", "cust") is True

    def test_parameter_fuzzy_match_abbreviation_email(self):
        """Test abbreviation: 'email' matches 'mail'."""
        assert CorrelationEngine._parameters_match("email", "mail") is True

    def test_parameter_exact_match_after_normalization(self):
        """Test exact match after camelCase→snake_case normalization."""
        assert CorrelationEngine._parameters_match("userId", "user_id") is True

    def test_parameter_no_match_unrelated(self):
        """Test no match for unrelated parameter names."""
        assert CorrelationEngine._parameters_match("userId", "productId") is False

    def test_parameter_nested_extraction(self):
        """Test nested parameter extraction: 'request.body.user_id' → 'userid'."""
        left = CorrelationEngine._normalize_parameter_name("request.body.user_id")
        right = CorrelationEngine._normalize_parameter_name("user_id")
        assert left == right


class TestPhase1MultiRouteEndpoints:
    """Test PHASE 1: Multi-route file endpoint handling."""

    def test_extract_multiple_endpoints_from_file(self):
        """Test extracting all endpoints when file has multiple routes."""
        engine = CorrelationEngine(
            routes=[
                {"file": "app.py", "path": "/users"},
                {"file": "app.py", "path": "/admin"},
                {"file": "app.py", "path": "/users/{id}"},
            ]
        )
        finding = {"file_path": "app.py", "endpoint": ""}
        endpoints = engine._extract_endpoints(finding)
        # Should return all 3 endpoints, not just one
        assert len(endpoints) >= 2  # At least /users and /admin
        assert "/users" in endpoints or "/users/" in [e.rstrip("/") for e in endpoints]

    def test_correlate_with_multiendpoint_file_cwe_match(self):
        """Test verification succeeds for multi-endpoint file if CWE matches."""
        engine = CorrelationEngine(
            routes=[
                {"file": "app.py", "path": "/api/users"},
                {"file": "app.py", "path": "/api/admin"},
            ]
        )
        sast = [{
            "vulnerability_type": "sqli",
            "file_path": "app.py",
            "cwe": "CWE-89",
            "endpoint": "",  # No explicit endpoint
            "parameter": ""   # No explicit parameter
        }]
        dast = [{
            "vulnerability_type": "sqli",
            "endpoint": "/api/admin",
            "cwe": "CWE-89",
            "parameter": "id"
        }]
        result = engine.correlate(sast, dast)
        # Should verify because CWE matches, even without endpoint match
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) >= 1


class TestPhase1RoleAwareCorrelation:
    """Test PHASE 1: Role-aware correlation for IDOR and auth."""

    def test_correlate_by_role_idor_verified_across_roles(self):
        """Test IDOR verified when 2+ different roles access same endpoint."""
        engine = CorrelationEngine()
        sast = [{
            "vulnerability_type": "idor",
            "endpoint": "/api/users/{id}",
            "parameter": "id"
        }]
        dast_by_role = {
            "admin": [{
                "vulnerability_type": "idor",
                "endpoint": "/api/users/1",
                "parameter": "id"
            }],
            "user": [{
                "vulnerability_type": "idor",
                "endpoint": "/api/users/2",
                "parameter": "id"
            }]
        }
        result = engine.correlate_by_role(sast, dast_by_role)
        # Should have at least one verified (IDOR across roles)
        # Note: verify_idor is called internally
        assert len(result) >= 1

    def test_dast_findings_grouped_by_role(self):
        """Test that DAST findings are properly grouped by auth_role."""
        findings = [
            {"endpoint": "/admin", "_auth_role": "admin"},
            {"endpoint": "/user", "_auth_role": "user"},
            {"endpoint": "/public", "_auth_role": "admin"},
        ]
        by_role = {}
        for finding in findings:
            role = finding.get("_auth_role", "default")
            if role not in by_role:
                by_role[role] = []
            by_role[role].append(finding)
        
        assert len(by_role) == 2
        assert len(by_role["admin"]) == 2
        assert len(by_role["user"]) == 1


class TestPhase1ExpandedTypeSupport:
    """Test PHASE 1: Expanded vulnerability type support."""

    def test_auth_type_in_equivalents(self):
        """Test that 'auth' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "auth" in VULN_TYPE_EQUIVALENTS
        assert "jwt" in VULN_TYPE_EQUIVALENTS["auth"]

    def test_idor_type_in_equivalents(self):
        """Test that 'idor' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "idor" in VULN_TYPE_EQUIVALENTS

    def test_mass_assignment_type_in_equivalents(self):
        """Test that 'mass_assignment' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "mass_assignment" in VULN_TYPE_EQUIVALENTS

    def test_weak_crypto_type_in_equivalents(self):
        """Test that 'weak_crypto' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "weak_crypto" in VULN_TYPE_EQUIVALENTS

    def test_brute_force_type_in_equivalents(self):
        """Test that 'brute_force' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "brute_force" in VULN_TYPE_EQUIVALENTS

    def test_cors_type_in_equivalents(self):
        """Test that 'cors' type is now in VULN_TYPE_EQUIVALENTS."""
        assert "cors" in VULN_TYPE_EQUIVALENTS

    def test_is_type_verifiable_for_new_types(self):
        """Test _is_type_verifiable returns True for new types."""
        assert CorrelationEngine._is_type_verifiable("auth") is True
        assert CorrelationEngine._is_type_verifiable("idor") is True
        assert CorrelationEngine._is_type_verifiable("mass_assignment") is True
        assert CorrelationEngine._is_type_verifiable("weak_crypto") is True


class TestPhase1IntegrationScenarios:
    """Test PHASE 1: Real-world integration scenarios."""

    def setup_method(self):
        """Set up test fixtures."""
        self.engine = CorrelationEngine()

    def test_scenario_sqli_with_multiple_parameter_names(self):
        """
        Real scenario: SQLi on /users?userId parameter
        SAST reports: parameter="user_id"
        DAST reports: parameter="userId"
        Should verify because parameters match after normalization.
        """
        engine = CorrelationEngine()
        sast = [{
            "vulnerability_type": "sqli",
            "endpoint": "/users",
            "parameter": "user_id",
            "cwe": "CWE-89"
        }]
        dast = [{
            "vulnerability_type": "sqli",
            "endpoint": "/users",
            "parameter": "userId",
            "cwe": "CWE-89"
        }]
        result = engine.correlate(sast, dast)
        verified = [r for r in result if r["confidence"] == "verified"]
        assert len(verified) == 1

    def test_scenario_xss_from_multiendpoint_file(self):
        """
        Real scenario: /app.py has 2 endpoints, XSS on one
        SAST: file_path="app.py", line_number=45 (between two route definitions)
        DAST: endpoint="/admin/dashboard"
        Should verify if endpoints extracted correctly.
        """
        engine = CorrelationEngine(
            routes=[
                {"file": "app.py", "path": "/user/profile", "line": 30},
                {"file": "app.py", "path": "/admin/dashboard", "line": 60},
            ]
        )
        sast = [{
            "vulnerability_type": "xss",
            "file_path": "app.py",
            "line_number": 45,
            "endpoint": "",
        }]
        dast = [{
            "vulnerability_type": "xss",
            "endpoint": "/admin/dashboard",
        }]
        result = engine.correlate(sast, dast)
        # Should correlate because /admin/dashboard is a candidate endpoint
        assert len(result) == 1

    def test_scenario_idor_two_roles(self):
        """
        Real scenario: IDOR vulnerability verified across roles
        SAST: Detects IDOR pattern in /api/users/{id}
        DAST/admin: Accesses /api/users/1
        DAST/user: Accesses /api/users/2 (should fail but doesn't)
        Should verify IDOR because multiple roles accessed same endpoint.
        """
        engine = CorrelationEngine()
        sast = [{
            "vulnerability_type": "idor",
            "endpoint": "/api/users/{id}",
            "parameter": "id"
        }]
        dast_by_role = {
            "admin": [{
                "vulnerability_type": "idor",
                "endpoint": "/api/users/999",
                "parameter": "id"
            }],
            "user": [{
                "vulnerability_type": "idor",
                "endpoint": "/api/users/888",
                "parameter": "id"
            }]
        }
        result = engine.correlate_by_role(sast, dast_by_role)
        # At least one finding should be present
        assert len(result) >= 1


    def test_verify_cors_access_control_header(self):
        """Test CORS verified with access-control header mention."""
        sast = {
            "vulnerability_type": "cors",
            "description": "Overly permissive CORS"
        }
        dast_findings = [
            {
                "vulnerability_type": "cors",
                "description": "CORS header allows any origin",
                "evidence": "access-control-allow-origin header permits unauthorized cross-origin access"
            }
        ]
        is_verified = self.engine._verify_cors(sast, dast_findings)
        assert is_verified is True

    def test_verify_cors_no_match(self):
        """Test CORS not verified for non-CORS DAST findings."""
        sast = {
            "vulnerability_type": "cors",
            "description": "CORS misconfiguration"
        }
        dast_findings = [
            {
                "vulnerability_type": "xss",
                "description": "XSS vulnerability found"
            }
        ]
        is_verified = self.engine._verify_cors(sast, dast_findings)
        assert is_verified is False

    def test_verify_cors_wrong_type(self):
        """Test CORS not verified for non-CORS SAST."""
        sast = {"vulnerability_type": "config", "description": "Debug mode enabled"}
        dast_findings = [
            {"vulnerability_type": "cors", "evidence": "Access-Control-Allow-Origin: *"}
        ]
        is_verified = self.engine._verify_cors(sast, dast_findings)
        assert is_verified is False

    def test_verify_cors_origin_keyword(self):
        """Test CORS verified with origin keyword."""
        sast = {
            "vulnerability_type": "cors",
            "description": "CORS allows malicious origins"
        }
        dast_findings = [
            {
                "vulnerability_type": "cors",
                "description": "Improper CORS validation",
                "evidence": "Any origin can access this resource"
            }
        ]
        is_verified = self.engine._verify_cors(sast, dast_findings)
        assert is_verified is True

