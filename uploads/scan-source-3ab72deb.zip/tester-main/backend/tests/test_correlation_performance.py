"""Performance benchmarks for correlation engine optimizations (P0 and P1)."""
import time
from app.correlation.correlation_engine import CorrelationEngine


class TestCorrelationPerformanceP0:
    """Performance tests for P0: Type-based bucketing optimization."""

    def generate_findings_by_type(self, num_types: int = 5, per_type: int = 50) -> tuple[list[dict], list[dict]]:
        """Generate SAST and DAST findings with multiple vulnerability types."""
        types = ["sqli", "xss", "cmdi", "path_traversal", "ssrf"][:num_types]
        
        sast_findings = []
        dast_findings = []
        
        for type_idx, vuln_type in enumerate(types):
            for i in range(per_type):
                sast_findings.append({
                    "vulnerability_type": vuln_type,
                    "file_path": f"src/app_{type_idx}.py",
                    "line_number": 100 + i,
                    "endpoint": f"/api/endpoint_{type_idx}_{i}",
                    "parameter": f"param_{i}",
                    "cwe": f"CWE-{79 + type_idx}",
                })
                dast_findings.append({
                    "vulnerability_type": vuln_type,
                    "endpoint": f"/api/endpoint_{type_idx}_{i}",
                    "parameter": f"param_{i}",
                    "evidence": f"payload_{i}",
                    "cwe": f"CWE-{79 + type_idx}",
                })
        
        return sast_findings, dast_findings

    def test_correlation_with_5_types_50_per_type(self):
        """Benchmark correlation with 5 types × 50 findings (250 total pairs)."""
        engine = CorrelationEngine()
        sast, dast = self.generate_findings_by_type(num_types=5, per_type=50)
        
        start = time.time()
        result = engine.correlate(sast, dast)
        elapsed = time.time() - start
        
        # Expect ~250 verified (same type, endpoint, parameter)
        verified_count = len([r for r in result if r["confidence"] == "verified"])
        assert verified_count == 250, f"Expected 250 verified, got {verified_count}"
        
        # Performance target: < 100ms for 250 findings (with P0 bucketing)
        assert elapsed < 0.1, f"Correlation took {elapsed:.3f}s, expected < 0.1s"
        print(f"✓ P0 benchmark (5 types × 50): {elapsed*1000:.2f}ms ({verified_count} verified)")

    def test_correlation_with_10_types_100_per_type(self):
        """Benchmark correlation with 10 types × 100 findings (1000 total pairs)."""
        engine = CorrelationEngine()
        
        # Generate 10 types with 100 findings each
        types = ["sqli", "xss", "cmdi", "path_traversal", "ssrf", "idor", "auth", "mass_assignment", "cors", "brute_force"]
        sast_findings = []
        dast_findings = []
        
        for type_idx, vuln_type in enumerate(types):
            for i in range(100):
                sast_findings.append({
                    "vulnerability_type": vuln_type,
                    "file_path": f"src/app_{type_idx}.py",
                    "line_number": 100 + i,
                    "endpoint": f"/api/endpoint_{type_idx}_{i}",
                    "parameter": f"param_{i}",
                })
                dast_findings.append({
                    "vulnerability_type": vuln_type,
                    "endpoint": f"/api/endpoint_{type_idx}_{i}",
                    "parameter": f"param_{i}",
                })
        
        start = time.time()
        result = engine.correlate(sast_findings, dast_findings)
        elapsed = time.time() - start
        
        verified_count = len([r for r in result if r["confidence"] == "verified"])
        assert verified_count == 1000, f"Expected 1000 verified, got {verified_count}"
        
        # With P0 bucketing: should handle 1000 findings in < 500ms
        assert elapsed < 0.5, f"Correlation took {elapsed:.3f}s, expected < 0.5s"
        print(f"✓ P0 benchmark (10 types × 100): {elapsed*1000:.2f}ms ({verified_count} verified)")


class TestCorrelationPerformanceP1:
    """Performance tests for P1: Fuzzy matching with LRU cache."""

    def test_fuzzy_parameter_matching_cache_hit_rate(self):
        """Verify P1 LRU cache for fuzzy parameter matching."""
        engine = CorrelationEngine()
        
        # Create findings with repeated parameter names (to trigger cache hits)
        sast_findings = []
        dast_findings = []
        
        # 50 findings with repeated parameter names across 5 types
        param_variations = ["user_id", "userid", "userID", "user-id", "user"]
        
        for i in range(200):
            param_idx = i % len(param_variations)
            sast_findings.append({
                "vulnerability_type": "sqli",
                "endpoint": "/api/data",
                "parameter": param_variations[param_idx],
                "file_path": "app.py",
                "line_number": 100 + i,
            })
            dast_findings.append({
                "vulnerability_type": "sqli",
                "endpoint": "/api/data",
                "parameter": "user_id",  # Always "user_id" - tests fuzzy matching
                "evidence": f"payload_{i}",
            })
        
        # Clear cache before test
        engine.clear_caches()
        
        start = time.time()
        result = engine.correlate(sast_findings, dast_findings)
        elapsed = time.time() - start
        
        # Get cache stats
        cache_stats = engine.get_cache_stats()
        
        verified_count = len([r for r in result if r["confidence"] == "verified"])
        
        # With P1 LRU cache, should process 200 findings with high cache hit rate
        assert elapsed < 0.2, f"Correlation took {elapsed:.3f}s, expected < 0.2s"
        assert cache_stats["hits"] > 0, f"Expected cache hits, got {cache_stats['hits']}"
        
        hit_rate = cache_stats["hits"] / (cache_stats["hits"] + cache_stats["misses"] + 1) * 100
        print(f"✓ P1 cache stats: {cache_stats['hits']} hits, {cache_stats['misses']} misses, hit rate: {hit_rate:.1f}%")
        print(f"✓ P1 benchmark (200 findings, fuzzy params): {elapsed*1000:.2f}ms ({verified_count} verified)")

    def test_fuzzy_matching_eliminates_repeated_imports(self):
        """Verify P1 eliminates SequenceMatcher import in loop."""
        engine = CorrelationEngine()
        
        # Create findings with 500 parameter comparisons
        sast_findings = []
        dast_findings = []
        
        # Many findings that require fuzzy matching
        for i in range(100):
            sast_findings.append({
                "vulnerability_type": "xss",
                "endpoint": f"/api/search",
                "parameter": f"query_param_{i}",
                "file_path": "app.py",
                "line_number": 100 + i,
            })
            dast_findings.append({
                "vulnerability_type": "xss",
                "endpoint": f"/api/search",
                "parameter": "query_param",  # Similar but not exact - tests fuzzy
                "evidence": f"xss_{i}",
            })
        
        # With P1 module-level import + LRU cache:
        # - SequenceMatcher imported once at module load (not 500+ times)
        # - Fuzzy matching results cached (not re-computed)
        start = time.time()
        result = engine.correlate(sast_findings, dast_findings)
        elapsed = time.time() - start
        
        # Should be sub-100ms (vs 500ms+ without optimization)
        assert elapsed < 0.1, f"Correlation took {elapsed:.3f}s, expected < 0.1s (P1 optimization not effective)"
        print(f"✓ P1 fuzzy matching (100 findings): {elapsed*1000:.2f}ms")


class TestCombinedP0P1Performance:
    """Integration tests for P0 + P1 combined performance."""

    def test_large_scale_correlation_with_p0_p1(self):
        """Test realistic large-scale correlation with both P0 and P1 optimizations."""
        engine = CorrelationEngine()
        
        # Simulate a large scan: 8 types, 150 findings per type = 1200 total
        types = ["sqli", "xss", "cmdi", "path_traversal", "ssrf", "idor", "auth", "brute_force"]
        sast_findings = []
        dast_findings = []
        
        for type_idx, vuln_type in enumerate(types):
            for i in range(150):
                # Vary parameter names to test P1 fuzzy matching
                base_param = f"param_{i % 10}"
                param_variations = [base_param, base_param + "_id", base_param.replace("_", "-")]
                
                sast_findings.append({
                    "vulnerability_type": vuln_type,
                    "file_path": f"src/app_{type_idx}.py",
                    "line_number": 100 + i,
                    "endpoint": f"/api/endpoint_{i % 30}",
                    "parameter": param_variations[i % 3],
                    "cwe": f"CWE-{78 + type_idx}",
                })
                dast_findings.append({
                    "vulnerability_type": vuln_type,
                    "endpoint": f"/api/endpoint_{i % 30}",
                    "parameter": base_param,
                    "evidence": f"payload_{type_idx}_{i}",
                })
        
        engine.clear_caches()
        
        start = time.time()
        result = engine.correlate(sast_findings, dast_findings)
        elapsed = time.time() - start
        
        verified = len([r for r in result if r["confidence"] == "verified"])
        probable = len([r for r in result if r["confidence"] == "probable"])
        observed = len([r for r in result if r["confidence"] == "observed"])
        
        # Performance target: 1200 findings in < 500ms with P0+P1
        assert elapsed < 0.5, f"Correlation took {elapsed:.3f}s, expected < 0.5s (P0+P1 should be ~500ms)"
        
        cache_stats = engine.get_cache_stats()
        print(f"✓ P0+P1 combined (1200 findings): {elapsed*1000:.2f}ms")
        print(f"  - Verified: {verified}, Probable: {probable}, Observed: {observed}")
        print(f"  - Cache: {cache_stats['hits']} hits, {cache_stats['misses']} misses")


class TestCorrelationBucketing:
    """Direct tests for P0 bucketing implementation."""

    def test_bucket_findings_by_type(self):
        """Test that _bucket_findings_by_type correctly groups findings."""
        engine = CorrelationEngine()
        
        findings = [
            {"vulnerability_type": "sqli", "endpoint": "/api/1"},
            {"vulnerability_type": "sql_injection", "endpoint": "/api/2"},  # Equivalent to sqli
            {"vulnerability_type": "xss", "endpoint": "/api/3"},
            {"vulnerability_type": "cross-site-scripting", "endpoint": "/api/4"},  # Equivalent to xss
            {"vulnerability_type": "sqli", "endpoint": "/api/5"},
        ]
        
        buckets = engine._bucket_findings_by_type(findings)
        
        # Should have 2 buckets: sqli and xss
        assert len(buckets) == 2, f"Expected 2 buckets, got {len(buckets)}"
        assert "sqli" in buckets, "sqli bucket missing"
        assert "xss" in buckets, "xss bucket missing"
        
        # sqli bucket should have 3 findings (2 sqli + 1 sql_injection)
        # Now returns tuples of (index, finding)
        assert len(buckets["sqli"]) == 3, f"Expected 3 sqli findings, got {len(buckets['sqli'])}"
        
        # xss bucket should have 2 findings (1 xss + 1 cross-site-scripting)
        assert len(buckets["xss"]) == 2, f"Expected 2 xss findings, got {len(buckets['xss'])}"
        
        # Verify indices are correct
        sqli_indices = [idx for idx, _ in buckets["sqli"]]
        assert sqli_indices == [0, 1, 4], f"Expected sqli indices [0, 1, 4], got {sqli_indices}"
        
        xss_indices = [idx for idx, _ in buckets["xss"]]
        assert xss_indices == [2, 3], f"Expected xss indices [2, 3], got {xss_indices}"
        
        print(f"✓ Bucketing correctly grouped {sum(len(b) for b in buckets.values())} findings into {len(buckets)} types")


    def test_bucketing_reduces_comparisons(self):
        """Verify that bucketing reduces the number of comparisons."""
        engine = CorrelationEngine()
        
        # Create 5 types × 100 findings = 500 total
        # Without bucketing: 500 × 500 = 250,000 comparisons
        # With bucketing: 100 × 100 × 5 = 50,000 comparisons (80% reduction)
        
        types = ["sqli", "xss", "cmdi", "path_traversal", "ssrf"]
        sast_findings = []
        dast_findings = []
        
        for type_idx, vuln_type in enumerate(types):
            for i in range(100):
                sast_findings.append({
                    "vulnerability_type": vuln_type,
                    "endpoint": f"/api/{i}",
                })
                dast_findings.append({
                    "vulnerability_type": vuln_type,
                    "endpoint": f"/api/{i}",
                })
        
        sast_buckets = engine._bucket_findings_by_type(sast_findings)
        dast_buckets = engine._bucket_findings_by_type(dast_findings)
        
        # Calculate comparisons with bucketing
        bucketed_comparisons = 0
        for vuln_type in sast_buckets:
            if vuln_type in dast_buckets:
                bucketed_comparisons += len(sast_buckets[vuln_type]) * len(dast_buckets[vuln_type])
        
        # Without bucketing would be 500 × 500 = 250,000
        unbucketed_comparisons = 500 * 500
        
        reduction_pct = (1 - bucketed_comparisons / unbucketed_comparisons) * 100
        
        assert bucketed_comparisons == 50000, f"Expected 50,000 bucketed comparisons, got {bucketed_comparisons}"
        assert reduction_pct > 75, f"Expected >75% reduction, got {reduction_pct:.1f}%"
        
        print(f"✓ Bucketing reduced comparisons from {unbucketed_comparisons:,} to {bucketed_comparisons:,} ({reduction_pct:.1f}%)")
