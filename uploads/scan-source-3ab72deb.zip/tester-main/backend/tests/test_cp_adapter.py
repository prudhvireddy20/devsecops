"""Integration tests for the CloudGuard CP adapter endpoints (Pattern 2 only)."""
import json
import uuid

import pytest
from unittest.mock import patch, AsyncMock

from app.api import cp_adapter
from app.api import scans as scans_api
from app.core import cp_hmac, cp_session


# ---------------------------------------------------------------------------
# GET /api/manifest
# ---------------------------------------------------------------------------


class TestManifest:
    """Test the manifest endpoint (no auth)."""

    @pytest.mark.asyncio
    async def test_manifest_returns_scanner_identity(self, client, monkeypatch):
        monkeypatch.setattr(
            cp_adapter.settings, "CP_APP_LAUNCH_URL",
            "https://scanner.example.com/sso-entry",
        )
        resp = await client.get("/api/manifest")
        assert resp.status_code == 200
        data = resp.json()
        assert data["key"] == "traceon"
        assert data["integrationMode"] == "embedded_app"
        assert data["appLaunchUrl"] == "https://scanner.example.com/sso-entry"
        assert "credentialSchema" not in data

    @pytest.mark.asyncio
    async def test_manifest_includes_dashboard_base_url(self, client, monkeypatch):
        monkeypatch.setattr(
            cp_adapter.settings, "CP_APP_LAUNCH_URL",
            "https://scanner.example.com/sso-entry",
        )
        resp = await client.get("/api/manifest")
        assert resp.status_code == 200
        data = resp.json()
        # appLaunchUrl ends with /sso-entry, so dashboardBaseUrl is its parent.
        assert data["dashboardBaseUrl"] == "https://scanner.example.com"

    @pytest.mark.asyncio
    async def test_manifest_no_auth_required(self, client_no_auth):
        resp = await client_no_auth.get("/api/manifest")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_manifest_rejects_empty_key(self, client, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "CP_SCANNER_KEY", "")
        resp = await client.get("/api/manifest")
        assert resp.status_code == 500


class TestCPRuntimeValidation:
    def test_runtime_validation_rejects_bad_key(self, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "CP_SCANNER_KEY", "Bad-Key")
        with pytest.raises(RuntimeError):
            cp_adapter.validate_cp_runtime_settings()

    def test_runtime_validation_skips_url_and_issuer_check_in_non_debug(self, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "DEBUG", False)
        monkeypatch.setattr(cp_adapter.settings, "CP_SCANNER_KEY", "traceon")
        monkeypatch.setattr(cp_adapter.settings, "CP_APP_LAUNCH_URL", "")
        monkeypatch.setattr(cp_adapter.settings, "CP_EXPECTED_ISSUER", "")
        cp_adapter.validate_cp_runtime_settings()

    def test_runtime_validation_accepts_valid_p2_settings_in_non_debug(self, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "DEBUG", False)
        monkeypatch.setattr(cp_adapter.settings, "CP_SCANNER_KEY", "traceon")
        monkeypatch.setattr(cp_adapter.settings, "CP_APP_LAUNCH_URL", "https://scanner.example.com/sso-entry")
        monkeypatch.setattr(cp_adapter.settings, "CP_EXPECTED_ISSUER", "https://cp.example.com")
        cp_adapter.validate_cp_runtime_settings()


class TestViewToken:
    """POST /api/scans/{scan_id}/view-token (§4.4) — HMAC-signed by the CP."""

    _SECRET = "test-cp-shared-secret"

    def _signed(self, body: dict):
        raw = json.dumps(body, separators=(",", ":"), sort_keys=True).encode()
        nonce = cp_hmac.generate_nonce()
        sig = cp_hmac.sign(raw, nonce, self._SECRET)
        return raw, {"X-Scanner-Nonce": nonce, "X-Scanner-Signature": sig,
                     "Content-Type": "application/json"}

    @pytest.mark.asyncio
    async def test_valid_signature_returns_view_secret(self, client, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "CP_SHARED_SECRET", self._SECRET)
        raw, headers = self._signed({"scanId": "scan-1"})
        resp = await client.post("/api/scans/scan-1/view-token", content=raw, headers=headers)
        assert resp.status_code == 200
        assert resp.json().get("viewSecret")

    @pytest.mark.asyncio
    async def test_bad_signature_returns_401(self, client, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "CP_SHARED_SECRET", self._SECRET)
        raw, headers = self._signed({"scanId": "scan-1"})
        headers["X-Scanner-Signature"] = "deadbeef"
        resp = await client.post("/api/scans/scan-1/view-token", content=raw, headers=headers)
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_missing_secret_returns_503(self, client, monkeypatch):
        monkeypatch.setattr(cp_adapter.settings, "CP_SHARED_SECRET", "")
        raw, headers = self._signed({"scanId": "scan-1"})
        resp = await client.post("/api/scans/scan-1/view-token", content=raw, headers=headers)
        assert resp.status_code == 503


class TestCookieAuthPrecedence:
    """A valid CP session cookie must scope the user even when an admin key
    header is also present (data-isolation fix)."""

    @pytest.mark.asyncio
    async def test_cp_cookie_wins_over_admin_key_header(self, client):
        claims = {
            "sub": str(uuid.uuid4()),
            "org_id": str(uuid.uuid4()),
            "email": "priya@acme.com",
            "name": "Priya",
            "exp": 9999999999,
        }
        token = cp_session.issue_session_token(claims)
        # client fixture already sends the admin X-API-Key header.
        resp = await client.get(
            "/api/v1/users/me",
            cookies={cp_session.COOKIE_NAME: token},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["is_admin"] is False
        assert data["label"] == "priya@acme.com"
        assert data.get("cp_email") == "priya@acme.com"


class TestInterruptedScanRecovery:
    @pytest.mark.asyncio
    async def test_recover_interrupted_cp_scan_marks_failed_and_notifies_cp(self, db_session):
        from tests.conftest import test_session_factory
        from app.models.project import Project
        from app.models.scan import Scan

        project = Project(name="Recover test", source_type="local")
        db_session.add(project)
        await db_session.flush()

        scan = Scan(
            project_id=project.id,
            status="running",
            cp_callback_url="https://cp.example.com/callback",
            cp_nonce="nonce-123",
        )
        db_session.add(scan)
        await db_session.commit()

        with patch("app.core.database.async_session_factory", test_session_factory), \
             patch("app.core.cp_callback.post_failed", new=AsyncMock(return_value=True)) as mock_failed:
            recovered = await scans_api.recover_interrupted_scans()

        assert recovered >= 1
        await db_session.refresh(scan)
        assert scan.status == "failed"
        assert "interrupted by service restart" in (scan.error_message or "")
        assert mock_failed.await_count == 1
