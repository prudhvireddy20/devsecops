"""Tests for CloudGuard CP HMAC authentication module."""
import pytest

from app.core.cp_hmac import sign, verify, generate_nonce


class TestHMACSignVerify:
    """Test the core HMAC sign/verify helpers."""

    def test_sign_returns_hex_string(self):
        sig = sign(b"hello", "nonce123", "secret")
        assert isinstance(sig, str)
        # SHA-256 hex digest is always 64 chars
        assert len(sig) == 64
        assert all(c in "0123456789abcdef" for c in sig)

    def test_verify_correct_signature(self):
        body = b'{"jobId":"abc","orgId":"org1"}'
        nonce = "nonce-xyz"
        secret = "my-shared-secret"
        sig = sign(body, nonce, secret)
        assert verify(body, nonce, sig, secret) is True

    def test_verify_wrong_secret(self):
        body = b'{"test":true}'
        nonce = "n1"
        sig = sign(body, nonce, "correct-secret")
        assert verify(body, nonce, sig, "wrong-secret") is False

    def test_verify_wrong_nonce(self):
        body = b'{"test":true}'
        secret = "s1"
        sig = sign(body, "nonce-a", secret)
        assert verify(body, "nonce-b", sig, secret) is False

    def test_verify_tampered_body(self):
        body = b'{"amount":100}'
        nonce = "n1"
        secret = "s1"
        sig = sign(body, nonce, secret)
        assert verify(b'{"amount":999}', nonce, sig, secret) is False

    def test_verify_empty_body(self):
        body = b""
        nonce = "n1"
        secret = "s1"
        sig = sign(body, nonce, secret)
        assert verify(body, nonce, sig, secret) is True

    def test_deterministic(self):
        """Same inputs always produce the same signature."""
        body = b"data"
        nonce = "n"
        secret = "s"
        assert sign(body, nonce, secret) == sign(body, nonce, secret)

    def test_different_inputs_different_signatures(self):
        secret = "s"
        sig1 = sign(b"body1", "n", secret)
        sig2 = sign(b"body2", "n", secret)
        assert sig1 != sig2


class TestGenerateNonce:
    """Test nonce generation."""

    def test_nonce_length(self):
        nonce = generate_nonce()
        assert len(nonce) == 32  # 16 bytes = 32 hex chars

    def test_nonce_uniqueness(self):
        nonces = {generate_nonce() for _ in range(100)}
        assert len(nonces) == 100  # All unique

    def test_nonce_hex_characters(self):
        nonce = generate_nonce()
        assert all(c in "0123456789abcdef" for c in nonce)
