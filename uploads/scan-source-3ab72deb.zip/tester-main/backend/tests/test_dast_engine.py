"""Tests for the DAST engine (ZAP alert parsing and mapping)."""
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from app.scanners.dast_engine import DASTEngine, ZAP_ALERT_MAP


class TestZAPAlertMap:
    """Test the ZAP alert ID to vulnerability type mapping."""

    def test_all_entries_have_required_fields(self):
        for alert_id, info in ZAP_ALERT_MAP.items():
            assert "type" in info, f"Missing 'type' for alert: {alert_id}"
            assert "cwe" in info, f"Missing 'cwe' for alert: {alert_id}"

    def test_sqli_alerts_mapped(self):
        sqli_alerts = [k for k, v in ZAP_ALERT_MAP.items() if v["type"] == "sqli"]
        assert len(sqli_alerts) >= 4

    def test_xss_alerts_mapped(self):
        xss_alerts = [k for k, v in ZAP_ALERT_MAP.items() if v["type"] == "xss"]
        assert len(xss_alerts) >= 3

    def test_cmdi_alerts_mapped(self):
        cmdi_alerts = [k for k, v in ZAP_ALERT_MAP.items() if v["type"] == "cmdi"]
        assert len(cmdi_alerts) >= 2

    def test_cwe_format(self):
        for alert_id, info in ZAP_ALERT_MAP.items():
            assert info["cwe"].startswith("CWE-"), f"Invalid CWE for alert: {alert_id}"


class TestDASTEngineParseAlerts:
    """Test ZAP alert parsing logic (no ZAP connection needed)."""

    def setup_method(self):
        # We can't instantiate DASTEngine directly because it tries to load
        # config settings, so we test _parse_alerts as a static-like method.
        # Create a minimal instance by patching __init__
        self.engine = DASTEngine.__new__(DASTEngine)
        self.engine.zap_url = "http://localhost:8080"
        self.engine.api_key = "test"
        self.engine._zap = None

    def test_parse_empty_alerts(self):
        findings = self.engine._parse_alerts([], "http://target.local")
        assert findings == []

    def test_parse_sqli_alert(self):
        alerts = [
            {
                "pluginId": "40018",
                "alert": "SQL Injection",
                "url": "http://target.local/api/users?id=1",
                "method": "GET",
                "param": "id",
                "risk": "High",
                "riskcode": 3,
                "cweid": "89",
                "attack": "' OR 1=1 --",
                "evidence": "SQL syntax error",
                "solution": "Use parameterized queries",
                "description": "SQL injection detected",
                "reference": "https://owasp.org",
                "tags": {},
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://target.local")
        assert len(findings) == 1
        f = findings[0]
        assert f["vulnerability_type"] == "sqli"
        assert f["severity"] == "critical"
        assert f["cwe"] == "CWE-89"
        assert f["endpoint"] == "/api/users"
        assert f["http_method"] == "GET"
        assert f["parameter"] == "id"
        assert f["payload"] == "' OR 1=1 --"

    def test_parse_xss_alert(self):
        alerts = [
            {
                "pluginId": "40012",
                "alert": "Cross Site Scripting (Reflected)",
                "url": "http://target.local/search?q=test",
                "method": "GET",
                "param": "q",
                "risk": "Medium",
                "riskcode": 2,
                "cweid": "79",
                "attack": '<script>alert(1)</script>',
                "evidence": "",
                "solution": "Encode output",
                "description": "",
                "reference": "",
                "tags": {},
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://target.local")
        assert len(findings) == 1
        assert findings[0]["vulnerability_type"] == "xss"
        assert findings[0]["severity"] == "medium"

    def test_parse_unknown_alert(self):
        alerts = [
            {
                "pluginId": "99999",
                "alert": "Unknown Issue",
                "url": "http://target.local/",
                "risk": "Low",
                "riskcode": 1,
                "cweid": "200",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://target.local")
        assert len(findings) == 1
        assert findings[0]["vulnerability_type"] == "unknown"
        assert findings[0]["cwe"] == "CWE-200"

    def test_parse_severity_mapping(self):
        """Severity mapping via riskcode (numeric) and text risk field."""
        # Via riskcode (numeric) — this is the primary path
        for riskcode, expected in [(3, "high"), (2, "medium"), (1, "low"), (0, "info")]:
            alerts = [
                {"pluginId": "99999", "alert": "Test", "url": "http://t/", "risk": "N/A", "riskcode": riskcode}
            ]
            findings = self.engine._parse_alerts(alerts, "http://t")
            assert findings[0]["severity"] == expected, (
                f"riskcode={riskcode}: expected {expected}, got {findings[0]['severity']}"
            )
        # Via text risk field (when riskcode is absent)
        for risk_text, expected in [("High", "high"), ("Medium", "medium"), ("Low", "low"), ("Informational", "info")]:
            alerts = [
                {"pluginId": "99999", "alert": "Test", "url": "http://t/", "risk": risk_text}
            ]
            findings = self.engine._parse_alerts(alerts, "http://t")
            assert findings[0]["severity"] == expected, (
                f"risk={risk_text}: expected {expected}, got {findings[0]['severity']}"
            )

    def test_parse_multiple_alerts(self):
        alerts = [
            {"pluginId": "40018", "alert": "SQLi", "url": "http://t/a", "risk": "High", "riskcode": 3},
            {"pluginId": "40012", "alert": "XSS", "url": "http://t/b", "risk": "Medium", "riskcode": 2},
            {"pluginId": "90019", "alert": "CMDi", "url": "http://t/c", "risk": "High", "riskcode": 3},
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert len(findings) == 3
        types = {f["vulnerability_type"] for f in findings}
        assert types == {"sqli", "xss", "cmdi"}

    def test_parse_alerts_from_wrapped_payload_dict(self):
        payload = {
            "alerts": [
                {
                    "pluginId": "40018",
                    "alert": "SQL Injection",
                    "url": "http://t/api/users?id=1",
                    "risk": "High",
                    "riskcode": 3,
                }
            ]
        }
        findings = self.engine._parse_alerts(payload, "http://t")
        assert len(findings) == 1
        assert findings[0]["vulnerability_type"] == "sqli"

    def test_parse_alerts_from_json_string_payload(self):
        payload = '[{"pluginId":"40012","alert":"XSS","url":"http://t/search?q=1","risk":"Medium","riskcode":2}]'
        findings = self.engine._parse_alerts(payload, "http://t")
        assert len(findings) == 1
        assert findings[0]["vulnerability_type"] == "xss"

    def test_parse_alerts_ignores_non_json_string_payload(self):
        findings = self.engine._parse_alerts("error: zap unavailable", "http://t")
        assert findings == []

    def test_parse_alert_raw_field(self):
        alerts = [
            {
                "pluginId": "40018",
                "alert": "SQL Injection",
                "url": "http://t/api",
                "risk": "High",
                "riskcode": 3,
                "description": "desc text",
                "reference": "ref text",
                "tags": {"OWASP": "A03"},
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        raw = findings[0]["raw"]
        assert raw["description"] == "desc text"
        assert raw["reference"] == "ref text"
        assert raw["tags"] == {"OWASP": "A03"}

    def test_routes_from_urls_keeps_target_host_and_deduplicates(self):
        urls = [
            "http://target.local/",
            "http://target.local/api/users?x=1",
            "https://other.local/admin",
            "http://target.local/api/users",
            "http://target.local/main.js",
            "http://target.local/src/node_modules/pkg/index.js:12:3",
        ]
        routes = self.engine._routes_from_urls("http://target.local", urls)
        paths = [r["path"] for r in routes]
        assert "/" in paths
        assert "/api/users" in paths
        assert paths.count("/api/users") == 1
        assert "/admin" not in paths
        assert "/main.js" not in paths
        assert "/src/node_modules/pkg/index.js:12:3" not in paths

    def test_get_ajax_status_supports_attr_and_callable(self):
        class _AjaxAttr:
            status = "running"

        class _AjaxCall:
            @staticmethod
            def status():
                return "stopped"

        class _Zap:
            def __init__(self, ajax):
                self.ajaxSpider = ajax

        assert self.engine._get_ajax_status(_Zap(_AjaxAttr())) == "running"
        assert self.engine._get_ajax_status(_Zap(_AjaxCall())) == "stopped"


class TestDASTEngineInit:
    """Test DASTEngine instantiation and _get_zap."""

    def test_init_sets_attributes(self):
        engine = DASTEngine.__new__(DASTEngine)
        engine.zap_url = "http://localhost:8080"
        engine.api_key = "test-key"
        engine._zap = None
        assert engine.zap_url == "http://localhost:8080"
        assert engine.api_key == "test-key"
        assert engine._zap is None

    def test_get_zap_import_error(self):
        """_get_zap should raise ImportError if zapv2 is not installed."""
        engine = DASTEngine.__new__(DASTEngine)
        engine.zap_url = "http://localhost:8080"
        engine.api_key = "test"
        engine._zap = None

        with patch.dict("sys.modules", {"zapv2": None}):
            with pytest.raises(ImportError):
                engine._get_zap()

    def test_get_zap_returns_cached(self):
        """If _zap is already set, _get_zap should return it without re-creating."""
        engine = DASTEngine.__new__(DASTEngine)
        engine.zap_url = "http://localhost:8080"
        engine.api_key = "test"
        mock_zap = MagicMock()
        engine._zap = mock_zap
        assert engine._get_zap() is mock_zap


class TestDASTEngineAsyncMethods:
    """Test async methods with mocked ZAP client."""

    def setup_method(self):
        self.engine = DASTEngine.__new__(DASTEngine)
        self.engine.zap_url = "http://localhost:8080"
        self.engine.api_key = "test"
        self.mock_zap = MagicMock()
        self.engine._zap = self.mock_zap

    @pytest.mark.asyncio
    async def test_get_scan_progress(self):
        """get_scan_progress should return int from zap.ascan.status."""
        self.mock_zap.ascan.status.return_value = "75"
        progress = await self.engine.get_scan_progress("scan-1")
        assert progress == 75

    @pytest.mark.asyncio
    async def test_get_scan_progress_error(self):
        """get_scan_progress should return 0 on error."""
        self.mock_zap.ascan.status.side_effect = Exception("connection lost")
        progress = await self.engine.get_scan_progress("scan-1")
        assert progress == 0

    @pytest.mark.asyncio
    async def test_spider_rejects_unsafe_target_url(self):
        with pytest.raises(ValueError, match="Unsafe target URL"):
            await self.engine.spider("http://169.254.169.254/latest/meta-data", routes=[])

    @pytest.mark.asyncio
    async def test_active_scan_rejects_unsafe_target_url(self):
        with pytest.raises(ValueError, match="Unsafe target URL"):
            await self.engine.active_scan("http://169.254.169.254/latest/meta-data", routes=[])

    @pytest.mark.asyncio
    async def test_stop_scan(self):
        """stop_scan should call zap.ascan.stop."""
        await self.engine.stop_scan("scan-1")
        self.mock_zap.ascan.stop.assert_called_once_with("scan-1")

    @pytest.mark.asyncio
    async def test_stop_scan_error(self):
        """stop_scan should not raise on error."""
        self.mock_zap.ascan.stop.side_effect = Exception("already stopped")
        # Should not raise
        await self.engine.stop_scan("scan-1")

    @pytest.mark.asyncio
    async def test_set_auth_cookies(self):
        """set_auth_cookies should inject all cookies as a single Cookie header via replacer."""
        cookies = [
            {"domain": "example.com", "name": "session", "value": "abc123"},
            {"domain": "example.com", "name": "csrf", "value": "xyz789"},
        ]
        await self.engine.set_auth_cookies(cookies)
        self.mock_zap.replacer.add_rule.assert_called_once()
        call_kwargs = self.mock_zap.replacer.add_rule.call_args
        assert "session=abc123" in str(call_kwargs)
        assert "csrf=xyz789" in str(call_kwargs)

    @pytest.mark.asyncio
    async def test_set_auth_cookies_error(self):
        """set_auth_cookies should not raise on error."""
        self.mock_zap.replacer.add_rule.side_effect = Exception("fail")
        # Should not raise
        await self.engine.set_auth_cookies([{"domain": "x", "name": "y", "value": "z"}])

    @pytest.mark.asyncio
    async def test_set_auth_header(self):
        """set_auth_header should add a replacer rule."""
        await self.engine.set_auth_header("my-token-123")
        self.mock_zap.replacer.add_rule.assert_called_once()
        call_kwargs = self.mock_zap.replacer.add_rule.call_args
        assert "Bearer my-token-123" in str(call_kwargs)

    @pytest.mark.asyncio
    async def test_set_auth_header_error(self):
        """set_auth_header should not raise on error."""
        self.mock_zap.replacer.add_rule.side_effect = Exception("fail")
        # Should not raise
        await self.engine.set_auth_header("token")

    @pytest.mark.asyncio
    async def test_configure_context_aware_scan(self):
        """_configure_context_aware_scan should set scanner strengths."""
        sinks = [
            {"type": "sql_injection"},
            {"type": "xss"},
            {"type": "command_injection"},
            {"type": "path_traversal"},
        ]
        routes = [{"path": "/api/test"}]
        await self.engine._configure_context_aware_scan(self.mock_zap, sinks, routes)
        # Should have called set_scanner_attack_strength multiple times
        assert self.mock_zap.ascan.set_scanner_attack_strength.call_count >= 10

    @pytest.mark.asyncio
    async def test_configure_context_aware_scan_error(self):
        """_configure_context_aware_scan should handle errors gracefully."""
        self.mock_zap.ascan.add_scan_policy.side_effect = Exception("policy error")
        sinks = [{"type": "sql_injection"}]
        # Should not raise
        await self.engine._configure_context_aware_scan(self.mock_zap, sinks, [])

    @pytest.mark.asyncio
    async def test_active_scan_uses_scan_config_timeout_and_scope(self):
        """active_scan should honor timeout and inscope_only configuration."""
        self.mock_zap.ascan.scan.return_value = "1"
        self.mock_zap.ascan.status.return_value = "100"
        self.mock_zap.core.alerts.return_value = []

        result = await self.engine.active_scan(
            "http://target.local",
            routes=[],
            sinks=[],
            scan_config={"timeout": 120, "inscope_only": True},
        )

        assert result == []
        call_kwargs = self.mock_zap.ascan.scan.call_args
        assert call_kwargs is not None
        assert call_kwargs.args[0] == "http://target.local"
        assert call_kwargs.kwargs.get("recurse") == "true"
        assert call_kwargs.kwargs.get("inscopeonly") == "true"
        assert call_kwargs.kwargs.get("scanpolicyname") == "Default Policy"
        # contextid is passed when inscope_only=True and a ZAP context is created

    @pytest.mark.asyncio
    async def test_active_scan_timeout_raises(self):
        """active_scan should raise on timeout instead of silently continuing."""
        self.mock_zap.ascan.scan.return_value = "2"
        self.mock_zap.ascan.status.return_value = "0"
        self.mock_zap.ascan.stop = MagicMock()

        # Patch only the dast_engine module's own reference to time.time, NOT
        # the global time module.  Patching time.time globally also intercepts
        # Python's logging internals (LogRecord.created uses time.time()), which
        # burns through the fake call-count budget before start_time is captured,
        # making start_time=10000 and elapsed=0 so the timeout never fires.
        # By patching dast_engine.time we only affect calls inside that module.
        import app.scanners.dast_engine as _dast_mod
        fake_time_values = iter([0.0, 10000.0])
        fake_time_mod = MagicMock()
        fake_time_mod.time = lambda: next(fake_time_values, 10000.0)

        with patch.object(self.engine, "_wait_for_zap_ready", new=AsyncMock()):
            with patch.object(_dast_mod, "time", fake_time_mod):
                with patch("app.scanners.dast_engine.asyncio.sleep", new=AsyncMock()):
                    with pytest.raises(TimeoutError):
                        await self.engine.active_scan(
                            "http://target.local",
                            routes=[],
                            sinks=[],
                            scan_config={"timeout": 1, "adaptive_timeout": False},
                        )

    @pytest.mark.asyncio
    async def test_active_scan_retries_transient_start_failure(self):
        """active_scan should retry transient start failures before succeeding."""
        self.mock_zap.ascan.scan.side_effect = [
            Exception("Connection refused"),
            "9",  # numeric scan ID (ZAP returns numeric strings)
        ]
        self.mock_zap.ascan.status.return_value = "100"
        self.mock_zap.core.alerts.return_value = []

        with patch("app.scanners.dast_engine.asyncio.sleep", new=AsyncMock()):
            result = await self.engine.active_scan(
                "http://target.local",
                routes=[],
                sinks=[],
                scan_config={"timeout": 120},
            )

        assert result == []
        assert self.mock_zap.ascan.scan.call_count == 2

    @pytest.mark.asyncio
    async def test_active_scan_retries_status_read_transient_errors(self):
        """active_scan should tolerate transient status read failures."""
        self.mock_zap.ascan.scan.return_value = "22"  # numeric scan ID
        self.mock_zap.ascan.status.side_effect = [
            Exception("Connection refused"),
            Exception("Connection refused"),
            "100",
        ]
        self.mock_zap.core.alerts.return_value = []

        with patch("app.scanners.dast_engine.asyncio.sleep", new=AsyncMock()):
            result = await self.engine.active_scan(
                "http://target.local",
                routes=[],
                sinks=[],
                scan_config={"timeout": 120},
            )

        assert result == []
        assert self.mock_zap.ascan.status.call_count == 3

    def test_parse_alert_no_cweid_uses_map(self):
        """When cweid is empty, CWE should come from ZAP_ALERT_MAP."""
        alerts = [
            {
                "pluginId": "40018",
                "alert": "SQL Injection",
                "url": "http://t/api",
                "risk": "High",
                "riskcode": 3,
                "cweid": "",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["cwe"] == "CWE-89"  # From ZAP_ALERT_MAP

    def test_parse_alert_prefers_curated_cwe_over_raw_cweid(self):
        alerts = [
            {
                "pluginId": "90022",
                "alert": "Application Error Disclosure",
                "url": "http://t/me",
                "risk": "Low",
                "riskcode": 1,
                "cweid": "550",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["vulnerability_type"] == "info_disclosure"
        assert findings[0]["cwe"] == "CWE-209"
        assert findings[0]["mapping_source"] == "compatibility"

    def test_parse_alert_builtin_mapping_source(self):
        alerts = [
            {
                "pluginId": "40018",
                "alert": "SQL Injection",
                "url": "http://t/api",
                "risk": "High",
                "riskcode": 3,
                "cweid": "89",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["mapping_source"] == "builtin"
        assert findings[0]["mapping_tier"] == "high"

    def test_parse_alert_compatibility_mapping_applied(self):
        alerts = [
            {
                "pluginId": "10098",
                "alert": "Cross-Domain Misconfiguration",
                "url": "http://t/api/users",
                "risk": "Low",
                "riskcode": 1,
                "cweid": "264",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["vulnerability_type"] == "config"
        assert findings[0]["cwe"] == "CWE-942"

    def test_parse_alert_endpoint_decodes_and_strips_openapi_prefix(self):
        alerts = [
            {
                "pluginId": "10036",
                "alert": "Server Header Leak",
                "url": "http://t/openapi.json/users/v1/%7Busername%7D",
                "risk": "Low",
                "riskcode": 1,
                "cweid": "497",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["endpoint"] == "/users/v1/{username}"

    def test_parse_alert_endpoint_decodes_without_openapi_prefix(self):
        alerts = [
            {
                "pluginId": "10036",
                "alert": "Server Header Leak",
                "url": "http://t/users/%7Bid%7D",
                "risk": "Low",
                "riskcode": 1,
                "cweid": "497",
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["endpoint"] == "/users/{id}"

    def test_parse_alert_no_method_defaults_get(self):
        """When method is missing, should default to GET."""
        alerts = [
            {
                "pluginId": "40018",
                "alert": "Test",
                "url": "http://t/",
                "risk": "Low",
                "riskcode": 1,
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["http_method"] == "GET"


class TestDASTEngineSeverityMapping:
    """Test risk to severity string mapping edge cases."""

    def setup_method(self):
        self.engine = DASTEngine.__new__(DASTEngine)
        self.engine.zap_url = "http://localhost:8080"
        self.engine.api_key = "test"
        self.engine._zap = None

    def test_riskcode_numeric_to_severity(self):
        """riskcode (integer) should map correctly."""
        mapping = {3: "high", 2: "medium", 1: "low", 0: "info"}
        for riskcode, expected_severity in mapping.items():
            alerts = [
                {"pluginId": "99999", "alert": "Test", "url": "http://t/", "risk": "N/A", "riskcode": riskcode}
            ]
            findings = self.engine._parse_alerts(alerts, "http://t")
            assert findings[0]["severity"] == expected_severity, (
                f"riskcode={riskcode} should map to {expected_severity}"
            )

    def test_text_risk_to_severity(self):
        """Text risk field should map correctly when riskcode is absent."""
        mapping = {"High": "high", "Medium": "medium", "Low": "low", "Informational": "info"}
        for risk_text, expected_severity in mapping.items():
            alerts = [
                {"pluginId": "99999", "alert": "Test", "url": "http://t/", "risk": risk_text}
            ]
            findings = self.engine._parse_alerts(alerts, "http://t")
            assert findings[0]["severity"] == expected_severity, (
                f"risk={risk_text} should map to {expected_severity}"
            )

    def test_sqli_critical_promotion(self):
        """SQL injection findings should be promoted to critical when risk is High."""
        alerts = [
            {
                "pluginId": "40018",
                "alert": "SQL Injection",
                "url": "http://t/",
                "risk": "High",
                "riskcode": 3,
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["severity"] == "critical"
        assert findings[0]["vulnerability_type"] == "sqli"

    def test_cmdi_critical_promotion(self):
        """Command injection findings should be promoted to critical when risk is High."""
        alerts = [
            {
                "pluginId": "90019",
                "alert": "Remote OS Command Injection",
                "url": "http://t/",
                "risk": "High",
                "riskcode": 3,
            }
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["severity"] == "critical"

    def test_unknown_risk_defaults_to_medium(self):
        """Unrecognized risk values should default to medium."""
        alerts = [
            {"pluginId": "99999", "alert": "Test", "url": "http://t/", "risk": "invalid"}
        ]
        findings = self.engine._parse_alerts(alerts, "http://t")
        assert findings[0]["severity"] == "medium"


class TestDASTEngineTransientErrors:
    """Test detection and handling of transient errors."""

    def setup_method(self):
        self.engine = DASTEngine.__new__(DASTEngine)
        self.engine.zap_url = "http://localhost:8080"
        self.engine.api_key = "test"
        self.mock_zap = MagicMock()
        self.engine._zap = self.mock_zap

    @pytest.mark.asyncio
    async def test_transient_start_failure_all_retries_exhausted(self):
        """When all start retries fail, the exception should propagate."""
        self.mock_zap.ascan.scan.side_effect = Exception("Connection refused")

        with patch("app.scanners.dast_engine.asyncio.sleep", new=AsyncMock()):
            with pytest.raises(Exception, match="Connection refused"):
                await self.engine.active_scan(
                    "http://target.local",
                    routes=[],
                    sinks=[],
                    scan_config={"timeout": 120},
                )

    @pytest.mark.asyncio
    async def test_spider_connection_error_handled(self):
        """Spider should handle connection errors gracefully."""
        self.mock_zap.spider.scan.side_effect = Exception("Connection refused")

        with patch("app.scanners.dast_engine.asyncio.sleep", new=AsyncMock()):
            with pytest.raises(Exception):
                await self.engine.spider(
                    "http://target.local",
                    routes=[],
                    scan_config={},
                )
