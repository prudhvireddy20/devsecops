"""Database engine configuration tests."""

import pytest
from sqlalchemy import text

from app.core.database import _db_url, engine


@pytest.mark.asyncio
async def test_sqlite_connection_pragmas_are_applied():
    if _db_url.get_backend_name() != "sqlite":
        pytest.skip("SQLite-only pragma test")

    async with engine.connect() as conn:
        timeout_result = await conn.execute(text("PRAGMA busy_timeout"))
        busy_timeout = int(timeout_result.scalar_one())

        journal_result = await conn.execute(text("PRAGMA journal_mode"))
        journal_mode = str(journal_result.scalar_one()).lower()

    assert busy_timeout >= 5000
    assert journal_mode in {"wal", "memory"}
