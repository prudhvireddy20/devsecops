"""Tests for the Express.js route parser."""
import os
import tempfile

import pytest

from app.analyzers.framework_parsers.express_parser import ExpressParser


class TestExpressParserExtractRoutes:
    """Test route extraction from Express.js source files."""

    def setup_method(self):
        self.parser = ExpressParser()
        self.tmpdir = tempfile.mkdtemp()

    def _write_file(self, name: str, content: str) -> str:
        path = os.path.join(self.tmpdir, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(content)
        return path

    @pytest.mark.asyncio
    async def test_basic_route_extraction(self):
        """Should extract simple get/post/put/delete routes."""
        self._write_file("app.js", """\
const express = require('express');
const app = express();

app.get('/api/users', (req, res) => {});
app.post('/api/users', (req, res) => {});
app.put('/api/users/:id', (req, res) => {});
app.delete('/api/users/:id', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        assert len(routes) == 4
        paths = [(r["path"], r["method"]) for r in routes]
        assert ("/api/users", "GET") in paths
        assert ("/api/users", "POST") in paths
        assert ("/api/users/:id", "PUT") in paths
        assert ("/api/users/:id", "DELETE") in paths

    @pytest.mark.asyncio
    async def test_router_prefix(self):
        """Routes on a Router used with app.use('/prefix', router) should get prefixed."""
        self._write_file("routes.js", """\
const express = require('express');
const router = express.Router();
const app = express();

app.use('/api', router);

router.get('/items', (req, res) => {});
router.post('/items', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        paths = [r["path"] for r in routes]
        assert "/api/items" in paths
        assert len([p for p in paths if p == "/api/items"]) == 2  # GET + POST

    @pytest.mark.asyncio
    async def test_colon_params_extracted(self):
        """Express :param style parameters should be extracted."""
        self._write_file("app.js", """\
const app = require('express')();
app.get('/users/:userId/posts/:postId', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        assert len(routes) == 1
        assert routes[0]["parameters"] == ["userId", "postId"]

    @pytest.mark.asyncio
    async def test_all_method_expands(self):
        """app.all() should expand to all HTTP methods."""
        self._write_file("app.js", """\
const app = require('express')();
app.all('/health', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        methods = {r["method"] for r in routes}
        assert methods == {"GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"}

    @pytest.mark.asyncio
    async def test_auth_middleware_detection(self):
        """Routes with auth-related middleware should have auth_required=True."""
        self._write_file("app.js", """\
const app = require('express')();
app.get('/public', (req, res) => {});
app.get('/protected', isAuthenticated, (req, res) => {});
app.get('/admin', authorize('admin'), (req, res) => {});
app.get('/jwt-route', jwt.verify, (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        auth_map = {r["path"]: r["auth_required"] for r in routes}
        assert auth_map["/public"] is False
        assert auth_map["/protected"] is True
        assert auth_map["/admin"] is True
        assert auth_map["/jwt-route"] is True

    @pytest.mark.asyncio
    async def test_empty_file(self):
        """An empty JS file should produce no routes."""
        self._write_file("empty.js", "")
        routes = await self.parser.extract_routes(self.tmpdir)
        assert routes == []

    @pytest.mark.asyncio
    async def test_typescript_files(self):
        """Should parse .ts files as well."""
        self._write_file("server.ts", """\
import express from 'express';
const app = express();
app.get('/ts-route', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        assert len(routes) == 1
        assert routes[0]["path"] == "/ts-route"
        assert routes[0]["framework"] == "express"

    @pytest.mark.asyncio
    async def test_node_modules_skipped(self):
        """Files inside node_modules should be skipped."""
        os.makedirs(os.path.join(self.tmpdir, "node_modules", "pkg"), exist_ok=True)
        self._write_file("node_modules/pkg/index.js", """\
const app = require('express')();
app.get('/internal', (req, res) => {});
""")
        self._write_file("app.js", """\
const app = require('express')();
app.get('/real', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        paths = [r["path"] for r in routes]
        assert "/real" in paths
        assert "/internal" not in paths

    @pytest.mark.asyncio
    async def test_route_file_and_line(self):
        """Each route should carry file (relative) and line number."""
        self._write_file("app.js", """\
const app = require('express')();
// comment
app.get('/line3', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        assert len(routes) == 1
        assert routes[0]["file"] == "app.js"
        assert routes[0]["line"] == 3

    @pytest.mark.asyncio
    async def test_unknown_object_ignored(self):
        """Route calls on objects that aren't app/router should be ignored."""
        self._write_file("app.js", """\
const app = require('express')();
const db = require('database');
app.get('/valid', (req, res) => {});
db.get('/not-a-route', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        paths = [r["path"] for r in routes]
        assert "/valid" in paths
        assert "/not-a-route" not in paths

    @pytest.mark.asyncio
    async def test_patch_and_options_methods(self):
        """Should handle patch and options HTTP methods."""
        self._write_file("app.js", """\
const app = require('express')();
app.patch('/api/users/:id', (req, res) => {});
app.options('/api/users', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        methods = [(r["path"], r["method"]) for r in routes]
        assert ("/api/users/:id", "PATCH") in methods
        assert ("/api/users", "OPTIONS") in methods

    @pytest.mark.asyncio
    async def test_multiple_routers_different_prefixes(self):
        """Multiple routers with different prefixes should be resolved correctly."""
        self._write_file("app.js", """\
const express = require('express');
const app = express();
const userRouter = express.Router();
const itemRouter = express.Router();

app.use('/users', userRouter);
app.use('/items', itemRouter);

userRouter.get('/', (req, res) => {});
itemRouter.get('/', (req, res) => {});
""")
        routes = await self.parser.extract_routes(self.tmpdir)
        paths = [r["path"] for r in routes]
        assert "/users/" in paths
        assert "/items/" in paths


class TestExpressParserJoinPaths:
    """Test static _join_paths helper."""

    def test_empty_prefix(self):
        assert ExpressParser._join_paths("", "/users") == "/users"

    def test_empty_prefix_no_leading_slash(self):
        assert ExpressParser._join_paths("", "users") == "/users"

    def test_prefix_and_path(self):
        assert ExpressParser._join_paths("/api", "/users") == "/api/users"

    def test_prefix_trailing_slash_stripped(self):
        assert ExpressParser._join_paths("/api/", "/users") == "/api/users"


class TestExpressParserExtractUrlParams:
    """Test static _extract_url_params helper."""

    def test_no_params(self):
        assert ExpressParser._extract_url_params("/api/users") == []

    def test_single_param(self):
        assert ExpressParser._extract_url_params("/users/:id") == ["id"]

    def test_multiple_params(self):
        assert ExpressParser._extract_url_params("/users/:userId/posts/:postId") == ["userId", "postId"]

    def test_no_match_for_non_colon(self):
        assert ExpressParser._extract_url_params("/users/{id}") == []
