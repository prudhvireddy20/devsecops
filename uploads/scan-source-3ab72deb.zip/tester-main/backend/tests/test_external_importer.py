"""Unit tests for ExternalFindingImporter — all 6 format parsers + auto-detect."""
import json
import os
import tempfile
import pytest
from app.scanners.external_importer import ExternalFindingImporter


@pytest.fixture
def importer():
    return ExternalFindingImporter()


# ── Auto-detect ─────────────────────────────────────────────────────────────


class TestDetectFormat:
    def test_semgrep(self, importer):
        data = {"results": [{"check_id": "rules.xss"}]}
        assert importer.detect_format(data) == "semgrep"

    def test_trivy_lowercase_results(self, importer):
        data = {"results": [{"Vulnerabilities": [{"VulnerabilityID": "CVE-1"}]}]}
        assert importer.detect_format(data) == "trivy"

    def test_trivy_capital_results(self, importer):
        data = {"Results": [{"Vulnerabilities": [{"VulnerabilityID": "CVE-1"}]}]}
        assert importer.detect_format(data) == "trivy"

    def test_sarif(self, importer):
        data = {"$schema": "...", "runs": [{"tool": {}, "results": []}]}
        assert importer.detect_format(data) == "sarif"

    def test_noir(self, importer):
        data = {"paths": [{"path": "/api", "method": "GET"}]}
        assert importer.detect_format(data) == "noir"

    def test_gitleaks(self, importer):
        data = [{"Description": "key", "RuleID": "aws-key"}]
        assert importer.detect_format(data) == "gitleaks"

    def test_generic_dict(self, importer):
        assert importer.detect_format({"foo": "bar"}) == "generic"

    def test_generic_empty_list(self, importer):
        assert importer.detect_format([]) == "generic"

    def test_generic_none(self, importer):
        assert importer.detect_format(None) == "generic"

    def test_sarif_before_noir_same_data(self, importer):
        """SARIF check must come before Noir when both have 'runs'."""
        data = {"runs": [], "paths": []}
        assert importer.detect_format(data) == "sarif"


# ── Semgrep ─────────────────────────────────────────────────────────────────


class TestParseSemgrep:
    def test_basic_sqli(self, importer):
        data = {
            "results": [
                {
                    "check_id": "rules.sql_injection",
                    "path": "src/login.py",
                    "start": {"line": 42},
                    "extra": {
                        "message": "SQL injection in query",
                        "severity": "ERROR",
                        "metadata": {"cwe": ["CWE-89"]},
                        "lines": "cursor.execute(q)",
                    },
                }
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["vulnerability_type"] == "sqli"
        assert f["severity"] == "high"
        assert f["cwe"] == "CWE-89"
        assert f["file_path"] == "src/login.py"
        assert f["line_number"] == 42
        assert f["rule_id"] == "rules.sql_injection"

    def test_multiple_findings(self, importer):
        data = {
            "results": [
                {"check_id": "r1", "path": "a.py", "start": {"line": 1}, "extra": {"severity": "WARNING", "metadata": {}}},
                {"check_id": "r2", "path": "b.py", "start": {"line": 2}, "extra": {"severity": "INFO", "metadata": {}}},
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 2

    def test_empty_results(self, importer):
        """Empty results array falls through to generic parsing (1 item)."""
        findings = importer.import_findings({"results": []})
        # Falls to generic parser, treats the dict as one item
        assert len(findings) == 1

    def test_malformed_result_skipped(self, importer):
        data = {"results": [None, "string", 42, {"check_id": "r1", "path": "a.py", "start": {"line": 1}, "extra": {}}]}
        findings = importer.import_findings(data)
        assert len(findings) == 1

    def test_severity_mapping(self, importer):
        data = {
            "results": [
                {"check_id": "r1", "path": "a.py", "start": {"line": 1}, "extra": {"severity": "ERROR", "metadata": {}}},
                {"check_id": "r2", "path": "b.py", "start": {"line": 2}, "extra": {"severity": "WARNING", "metadata": {}}},
                {"check_id": "r3", "path": "c.py", "start": {"line": 3}, "extra": {"severity": "INFO", "metadata": {}}},
                {"check_id": "r4", "path": "d.py", "start": {"line": 4}, "extra": {"severity": "UNKNOWN", "metadata": {}}},
            ]
        }
        findings = importer.import_findings(data)
        assert [f["severity"] for f in findings] == ["high", "medium", "low", "medium"]


# ── SARIF ───────────────────────────────────────────────────────────────────


class TestParseSarif:
    SARIF_BASE = {
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "CodeQL",
                        "rules": [
                            {"id": "js/sqli", "shortDescription": {"text": "SQL Injection"}},
                            {"id": "js/xss", "shortDescription": {"text": "XSS"}},
                        ],
                    }
                },
                "results": [],
            }
        ]
    }

    def test_basic(self, importer):
        data = {
            "runs": [
                {
                    "tool": {"driver": {"name": "CodeQL", "rules": [{"id": "js/sqli", "shortDescription": {"text": "SQL Inj"}}]}},
                    "results": [
                        {
                            "ruleId": "js/sqli",
                            "level": "error",
                            "message": {"text": "Query from user input"},
                            "locations": [
                                {
                                    "physicalLocation": {
                                        "artifactLocation": {"uri": "src/app.js"},
                                        "region": {"startLine": 55},
                                    }
                                }
                            ],
                        }
                    ],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["file_path"] == "src/app.js"
        assert f["line_number"] == 55
        assert f["severity"] == "high"

    def test_no_locations(self, importer):
        data = {
            "runs": [
                {
                    "tool": {"driver": {"name": "T", "rules": [], "results": []}},
                    "results": [{"ruleId": "r1", "level": "warning", "message": {"text": "issue"}}],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 1
        assert findings[0]["file_path"] == ""

    def test_empty_runs(self, importer):
        assert importer.import_findings({"runs": []}) == []

    def test_cwe_from_properties_tags(self, importer):
        data = {
            "runs": [
                {
                    "tool": {"driver": {"name": "T", "rules": [], "results": []}},
                    "results": [
                        {
                            "ruleId": "r1",
                            "level": "error",
                            "message": {"text": "xss"},
                            "properties": {"tags": ["CWE-79", "security"]},
                            "locations": [],
                        }
                    ],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert findings[0]["cwe"] == "CWE-79"

    def test_missing_rule_in_driver(self, importer):
        """Finding referencing a ruleId not in the rules map should still produce output."""
        data = {
            "runs": [
                {
                    "tool": {"driver": {"name": "T", "rules": []}},
                    "results": [{"ruleId": "unknown", "level": "error", "message": {"text": "something"}, "locations": []}],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 1


# ── Gitleaks ────────────────────────────────────────────────────────────────


class TestParseGitleaks:
    def test_basic(self, importer):
        data = [{"Description": "GitHub PAT", "File": ".env", "StartLine": 3, "Secret": "ghp_abc123", "RuleID": "github-pat"}]
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["vulnerability_type"] == "secret"
        assert f["severity"] == "high"
        assert f["file_path"] == ".env"
        assert f["line_number"] == 3
        assert "ghp_abc123" in f["code_snippet"]

    def test_empty(self, importer):
        assert importer.import_findings([]) == []

    def test_non_dict_items_skipped(self, importer):
        data = [{"Description": "real", "File": "f", "StartLine": 1, "Secret": "s", "RuleID": "r"}, None, "str"]
        findings = importer.import_findings(data)
        assert len(findings) == 1


# ── Trivy ───────────────────────────────────────────────────────────────────


class TestParseTrivy:
    def test_basic(self, importer):
        data = {
            "Results": [
                {
                    "Target": "requirements.txt",
                    "Vulnerabilities": [
                        {
                            "VulnerabilityID": "CVE-2023-1234",
                            "PkgName": "django",
                            "Severity": "HIGH",
                            "Title": "Django vuln",
                            "InstalledVersion": "3.2.0",
                            "FixedVersion": "3.2.18",
                        }
                    ],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["vulnerability_type"] == "dependency_cve"
        assert f["severity"] == "high"
        assert f["file_path"] == "requirements.txt"
        assert f["rule_id"] == "CVE-2023-1234"
        assert "3.2.18" in f["code_snippet"]

    def test_multiple_results(self, importer):
        data = {
            "Results": [
                {"Target": "req1.txt", "Vulnerabilities": [{"VulnerabilityID": "CVE-1", "PkgName": "pkg1", "Severity": "MEDIUM", "Title": "", "InstalledVersion": "1.0", "FixedVersion": ""}]},
                {"Target": "req2.txt", "Vulnerabilities": [{"VulnerabilityID": "CVE-2", "PkgName": "pkg2", "Severity": "CRITICAL", "Title": "Bad", "InstalledVersion": "2.0", "FixedVersion": "2.1"}]},
            ]
        }
        findings = importer.import_findings(data)
        assert len(findings) == 2

    def test_empty_vulns(self, importer):
        assert importer.import_findings({"Results": [{"Target": "f.txt", "Vulnerabilities": []}]}) == []

    def test_severity_mapping(self, importer):
        data = {
            "Results": [
                {
                    "Target": "f.txt",
                    "Vulnerabilities": [
                        {"VulnerabilityID": "C1", "PkgName": "p", "Severity": "CRITICAL", "Title": "", "InstalledVersion": "", "FixedVersion": ""},
                        {"VulnerabilityID": "C2", "PkgName": "p", "Severity": "HIGH", "Title": "", "InstalledVersion": "", "FixedVersion": ""},
                        {"VulnerabilityID": "C3", "PkgName": "p", "Severity": "MEDIUM", "Title": "", "InstalledVersion": "", "FixedVersion": ""},
                        {"VulnerabilityID": "C4", "PkgName": "p", "Severity": "LOW", "Title": "", "InstalledVersion": "", "FixedVersion": ""},
                        {"VulnerabilityID": "C5", "PkgName": "p", "Severity": "UNKNOWN", "Title": "", "InstalledVersion": "", "FixedVersion": ""},
                    ],
                }
            ]
        }
        findings = importer.import_findings(data)
        assert [f["severity"] for f in findings] == ["critical", "high", "medium", "low", "medium"]


# ── Noir ────────────────────────────────────────────────────────────────────


class TestParseNoir:
    def test_basic(self, importer):
        data = {"paths": [{"path": "/api/users", "method": "GET", "file": "routes/users.js"}]}
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["vulnerability_type"] == "route"
        assert f["severity"] == "info"
        assert f["endpoint"] == "/api/users"
        assert f.get("_noir_route") == {"path": "/api/users", "method": "GET", "file": "routes/users.js"}

    def test_multiple_paths(self, importer):
        data = {"paths": [
            {"path": "/api/users", "method": "GET", "file": "a.js"},
            {"path": "/api/items", "method": "POST", "file": "b.js"},
        ]}
        findings = importer.import_findings(data)
        assert len(findings) == 2
        assert all(f.get("_noir_route") for f in findings)

    def test_no_paths(self, importer):
        assert importer.import_findings({"paths": []}) == []

    def test_method_default_uppercase(self, importer):
        data = {"paths": [{"path": "/api", "method": "post", "file": "a.js"}]}
        findings = importer.import_findings(data)
        assert findings[0]["_noir_route"]["method"] == "POST"


# ── Generic ─────────────────────────────────────────────────────────────────


class TestParseGeneric:
    def test_single_dict(self, importer):
        data = {"title": "My Finding", "severity": "high", "vulnerability_type": "sqli"}
        findings = importer.import_findings(data)
        assert len(findings) == 1
        assert findings[0]["title"] == "My Finding"

    def test_list_of_dicts(self, importer):
        data = [
            {"title": "F1", "severity": "high"},
            {"title": "F2", "severity": "low"},
        ]
        findings = importer.import_findings(data)
        assert len(findings) == 2

    def test_empty_list(self, importer):
        assert importer.import_findings([]) == []

    def test_field_name_variants(self, importer):
        data = {"Title": "X", "Severity": "HIGH", "file": "/app.py", "CWE": "CWE-79"}
        findings = importer.import_findings(data)
        assert len(findings) == 1
        f = findings[0]
        assert f["title"] == "X"
        assert f["severity"] == "high"
        assert f["file_path"] == "/app.py"
        assert f["cwe"] == "CWE-79"


# ── import_from_file ────────────────────────────────────────────────────────


class TestImportFromFile:
    def test_basic(self, importer):
        data = {"results": [{"check_id": "r1", "path": "a.py", "start": {"line": 1}, "extra": {"severity": "ERROR", "metadata": {}}}]}
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            fname = f.name
        try:
            findings = ExternalFindingImporter.import_from_file(fname)
            assert len(findings) == 1
        finally:
            os.unlink(fname)

    def test_file_not_found(self):
        findings = ExternalFindingImporter.import_from_file("/nonexistent/path.json")
        assert findings == []

    def test_invalid_json(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("{{{invalid")
            fname = f.name
        try:
            findings = ExternalFindingImporter.import_from_file(fname)
            assert findings == []
        finally:
            os.unlink(fname)

    def test_explicit_format_override(self, importer):
        data = {"random": "data"}
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            fname = f.name
        try:
            # Explicit format should still parse via generic
            findings = ExternalFindingImporter.import_from_file(fname, format="generic")
            assert len(findings) == 1
        finally:
            os.unlink(fname)


# ── Conflict resolution (Semgrep results vs Trivy results) ─────────────────


class TestFormatConflictResolution:
    def test_semgrep_check_id_wins_detection_over_trivy_vulns(self, importer):
        """If both 'check_id' and 'Vulnerabilities' exist, Semgrep detection wins."""
        data = {
            "results": [
                {"check_id": "rules.xss", "path": "a.py", "start": {"line": 1}, "extra": {"severity": "ERROR", "metadata": {}}},
                {"Vulnerabilities": [{"VulnerabilityID": "CVE-1", "PkgName": "p", "Severity": "HIGH", "Title": "", "InstalledVersion": "", "FixedVersion": ""}]},
            ]
        }
        assert importer.detect_format(data) == "semgrep"
        # Both entries in the results array get processed by the Semgrep parser
        # (the second one produces an 'unknown' type finding since it has no check_id)
        findings = importer.import_findings(data)
        assert len(findings) == 2
        assert findings[0]["vulnerability_type"] == "xss"
