"""Tests for the fix generator."""
from app.remediation.fix_generator import FixGenerator


class TestFixGenerator:
    """Test code fix generation."""

    def setup_method(self):
        self.gen = FixGenerator()

    # --- Test with dict input ---

    def test_sqli_fix_fstring(self):
        finding = {
            "vulnerability_type": "sqli",
            "code_snippet": 'cursor.execute(f"SELECT * FROM users WHERE id={uid}")',
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "parameterized" in fix["remediation_text"].lower()
        assert fix["original_code"] != fix["fixed_code"]

    def test_xss_fix_render_template_string(self):
        finding = {
            "vulnerability_type": "xss",
            "code_snippet": "render_template_string(user_input)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "escape" in fix["remediation_text"].lower() or "escape" in fix["fixed_code"]

    def test_xss_fix_safe_filter(self):
        finding = {
            "vulnerability_type": "xss",
            "code_snippet": "{{ user_input | safe }}",
            "file_path": "template.html",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "| e" in fix["fixed_code"]

    def test_cmdi_fix_os_system(self):
        finding = {
            "vulnerability_type": "cmdi",
            "code_snippet": 'os.system(f"ping {host}")',
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "subprocess" in fix["fixed_code"].lower() or "subprocess" in fix["remediation_text"].lower()

    def test_cmdi_fix_shell_true(self):
        finding = {
            "vulnerability_type": "command_injection",
            "code_snippet": 'subprocess.call(f"ls {path}", shell=True)',
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "shell=False" in fix["fixed_code"] or "list" in fix["remediation_text"].lower()

    def test_secret_fix(self):
        finding = {
            "vulnerability_type": "secret",
            "code_snippet": 'API_KEY = "sk-abc123secret"',
            "file_path": "config.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "os.environ" in fix["fixed_code"]
        assert "environment" in fix["remediation_text"].lower()

    def test_path_traversal_fix(self):
        finding = {
            "vulnerability_type": "path_traversal",
            "code_snippet": "open(user_input)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "abspath" in fix["fixed_code"] or "traversal" in fix["remediation_text"].lower()

    def test_deserialization_fix_pickle(self):
        finding = {
            "vulnerability_type": "deserialization",
            "code_snippet": "data = pickle.loads(user_data)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "json" in fix["fixed_code"].lower()

    def test_deserialization_fix_yaml(self):
        finding = {
            "vulnerability_type": "deserialization",
            "code_snippet": "config = yaml.load(file_content)",
            "file_path": "config.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "safe_load" in fix["fixed_code"]

    def test_no_code_snippet_returns_none(self):
        finding = {
            "vulnerability_type": "sqli",
            "code_snippet": "",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is None

    def test_unknown_vuln_type_returns_generic(self):
        finding = {
            "vulnerability_type": "unknown_vuln_type",
            "code_snippet": "some_code()",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "Action Required" in fix["fixed_code"] or "Review" in fix["remediation_text"]

    # --- Test with mock SQLAlchemy model (object with attributes) ---

    def test_model_instance_input(self):
        """Ensure the fix works with objects that have attributes (not dicts)."""

        class MockFinding:
            vulnerability_type = "sqli"
            code_snippet = 'cursor.execute(f"SELECT * FROM users WHERE id={uid}")'
            file_path = "app.py"

        fix = self.gen.generate_fix(MockFinding())
        assert fix is not None
        assert fix["remediation_text"]

    def test_model_instance_empty_code_snippet(self):
        """Regression test for the .get() AttributeError bug."""

        class MockFinding:
            vulnerability_type = "sqli"
            code_snippet = ""
            file_path = "app.py"

        fix = self.gen.generate_fix(MockFinding())
        assert fix is None  # Should NOT crash

    def test_diff_generated(self):
        finding = {
            "vulnerability_type": "secret",
            "code_snippet": 'SECRET = "my-secret-value"',
            "file_path": "config.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert fix["diff"]
        assert "-" in fix["diff"]
        assert "+" in fix["diff"]

    # --- Additional tests for uncovered branches ---

    def test_sqli_fix_format_string(self):
        """Test SQL injection fix for %s format strings."""
        finding = {
            "vulnerability_type": "sql_injection",
            "code_snippet": 'cursor.execute("SELECT * FROM users WHERE id=%s" % uid)',
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert fix["original_code"] != fix["fixed_code"]

    def test_sqli_fix_concat(self):
        """Test SQL injection fix for string concatenation."""
        finding = {
            "vulnerability_type": "sqli",
            "code_snippet": 'cursor.execute("SELECT * FROM users WHERE id=" + uid)',
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        # Should produce some kind of fix
        assert fix["fixed_code"] != fix["original_code"]

    def test_sqli_fix_unfixable_pattern(self):
        """When no regex matches, should return guidance comment."""
        finding = {
            "vulnerability_type": "sqli",
            "code_snippet": "some_unknown_sql_call(data)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "FIXED" in fix["fixed_code"] or "parameterized" in fix["remediation_text"]

    def test_xss_fix_markup(self):
        """Test XSS fix for Markup() calls."""
        finding = {
            "vulnerability_type": "xss",
            "code_snippet": "output = Markup(user_input)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "escape" in fix["fixed_code"]

    def test_xss_fix_safe_filter_no_space(self):
        """Test XSS fix for |safe (without space)."""
        finding = {
            "vulnerability_type": "cross-site-scripting",
            "code_snippet": "{{ data|safe }}",
            "file_path": "template.html",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "|e" in fix["fixed_code"]

    def test_xss_fix_mark_safe(self):
        """Test XSS fix for Django mark_safe()."""
        finding = {
            "vulnerability_type": "xss",
            "code_snippet": "return mark_safe(user_html)",
            "file_path": "views.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "conditional_escape" in fix["fixed_code"]

    def test_xss_fix_no_known_pattern(self):
        """XSS with unrecognised pattern returns original with remediation."""
        finding = {
            "vulnerability_type": "xss",
            "code_snippet": "response.write(user_input)",
            "file_path": "views.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "escape" in fix["remediation_text"].lower()

    def test_cmdi_fix_os_popen(self):
        """Test command injection fix for os.popen()."""
        finding = {
            "vulnerability_type": "cmdi",
            "code_snippet": "result = os.popen(user_cmd)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "subprocess" in fix["fixed_code"]

    def test_cmdi_fix_unfixable(self):
        """Unknown cmdi pattern gets generic subprocess fix."""
        finding = {
            "vulnerability_type": "command_injection",
            "code_snippet": "run_command(user_input)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "subprocess" in fix["fixed_code"] or "subprocess" in fix["remediation_text"]

    def test_secret_fix_no_match(self):
        """Secret with no var=value pattern gives generic fix."""
        finding = {
            "vulnerability_type": "hardcoded-secret",
            "code_snippet": "use_token(12345)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "environment" in fix["fixed_code"].lower() or "environment" in fix["remediation_text"].lower()

    def test_deserialization_fix_yaml_unsafe(self):
        """Test deserialization fix for yaml.unsafe_load."""
        finding = {
            "vulnerability_type": "deserialization",
            "code_snippet": "data = yaml.unsafe_load(content)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "safe_load" in fix["fixed_code"]

    def test_deserialization_fix_unknown(self):
        """Unknown deserialization pattern gets json fallback."""
        finding = {
            "vulnerability_type": "deserialization",
            "code_snippet": "data = marshal.loads(raw)",
            "file_path": "app.py",
        }
        fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "json" in fix["fixed_code"]

    def test_generate_fix_exception_falls_back(self):
        """If fix method raises, should fall back to _generic_fix."""
        from unittest.mock import patch

        finding = {
            "vulnerability_type": "sqli",
            "code_snippet": "some code",
            "file_path": "app.py",
        }
        with patch.object(self.gen, "_fix_sqli", side_effect=RuntimeError("boom")):
            fix = self.gen.generate_fix(finding)
        assert fix is not None
        assert "Review" in fix["remediation_text"]
