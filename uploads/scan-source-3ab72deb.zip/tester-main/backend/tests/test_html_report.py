"""Tests for the HTML report generator."""
import tempfile

import pytest

from app.reports.html_report import HTMLReportGenerator


class TestHTMLReportGenerator:
    """Test HTML report generation."""

    def setup_method(self):
        self.generator = HTMLReportGenerator()

    def _sample_data(self):
        scan_data = {
            "id": "scan-001",
            "status": "completed",
            "routes_discovered": 15,
        }
        project_data = {"name": "test-project"}
        findings = [
            {
                "title": "SQL Injection",
                "severity": "critical",
                "confidence": "verified",
                "cwe": "CWE-89",
                "file_path": "app/views.py",
                "line_number": 42,
                "code_snippet": 'cursor.execute(f"SELECT...")',
                "endpoint": "/api/users",
                "http_method": "GET",
                "parameter": "uid",
                "data_flow": "request -> cursor.execute",
                "payload": "' OR 1=1 --",
                "response_evidence": "200 OK with all records",
                "remediation_text": "Use parameterized queries.",
                "scanner_source": "sast",
            },
            {
                "title": "XSS",
                "severity": "high",
                "confidence": "probable",
                "cwe": "CWE-79",
                "file_path": "app/templates.py",
                "line_number": 15,
                "code_snippet": "render_template_string(x)",
                "remediation_text": "Use auto-escaping.",
                "scanner_source": "sast",
            },
            {
                "title": "Debug Enabled",
                "severity": "medium",
                "confidence": "observed",
                "cwe": "CWE-215",
                "file_path": "settings.py",
                "line_number": 1,
                "code_snippet": "DEBUG = True",
                "remediation_text": "Disable debug.",
                "scanner_source": "sast",
            },
        ]
        return scan_data, project_data, findings

    @pytest.mark.asyncio
    async def test_generate_creates_file(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data, project_data, findings = self._sample_data()
        result_path = await self.generator.generate(scan_data, project_data, findings, output_dir)
        assert result_path.exists()
        assert result_path.name == "report.html"

    @pytest.mark.asyncio
    async def test_generate_contains_project_name(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data, project_data, findings = self._sample_data()
        result_path = await self.generator.generate(scan_data, project_data, findings, output_dir)
        content = result_path.read_text()
        assert "test-project" in content

    @pytest.mark.asyncio
    async def test_generate_contains_findings(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data, project_data, findings = self._sample_data()
        result_path = await self.generator.generate(scan_data, project_data, findings, output_dir)
        content = result_path.read_text()
        assert "SQL Injection" in content
        assert "XSS" in content

    @pytest.mark.asyncio
    async def test_generate_sorts_by_severity(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data, project_data, findings = self._sample_data()
        result_path = await self.generator.generate(scan_data, project_data, findings, output_dir)
        content = result_path.read_text()
        # Critical should come before medium
        sqli_pos = content.index("SQL Injection")
        debug_pos = content.index("Debug Enabled")
        assert sqli_pos < debug_pos

    @pytest.mark.asyncio
    async def test_generate_empty_findings(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"id": "scan-001", "status": "completed", "routes_discovered": 0}
        project_data = {"name": "empty-project"}
        result_path = await self.generator.generate(scan_data, project_data, [], output_dir)
        assert result_path.exists()
        content = result_path.read_text()
        assert "empty-project" in content

    @pytest.mark.asyncio
    async def test_generate_valid_html(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data, project_data, findings = self._sample_data()
        result_path = await self.generator.generate(scan_data, project_data, findings, output_dir)
        content = result_path.read_text()
        assert content.startswith("<!DOCTYPE html>")
        assert "</html>" in content
