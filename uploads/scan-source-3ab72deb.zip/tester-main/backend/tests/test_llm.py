"""Unit tests for LLM integration helpers."""

import pytest

from app.llm.client import LLMClient
from app.llm.planner import LLMPlanner
from app.llm.provider_config import (
    normalize_provider,
    resolve_llm_provider_config,
    resolve_llm_provider_config_async,
)
from app.llm.redaction import redact_text


def test_normalize_provider():
    assert normalize_provider("OpenAI") == "openai"
    assert normalize_provider("openrouter") == "openrouter"
    assert normalize_provider("copilot") == "github"  # Backward compat
    assert normalize_provider("github") == "github"
    assert normalize_provider("unknown") == ""


def test_resolve_provider_prefers_scan_override(monkeypatch):
    from app.core.config import settings

    monkeypatch.setattr(settings, "LLM_ENABLED", True)
    monkeypatch.setattr(settings, "LLM_PROVIDER", "anthropic")
    monkeypatch.setattr(settings, "OPENROUTER_API_KEY", "")

    cfg = resolve_llm_provider_config(
        project=None,
        scan_config={
            "llm_provider": "openrouter",
            "llm_model": "openai/gpt-4o-mini",
            "llm_api_key": "sk-test",
        },
    )
    assert cfg["enabled"] is True
    assert cfg["provider"] == "openrouter"
    assert cfg["model"] == "openai/gpt-4o-mini"
    assert cfg["api_key"] == "sk-test"


def test_planner_apply_scan_config_updates_bounds_values():
    updated = LLMPlanner.apply_scan_config_updates(
        {"scan_depth": 5},
        {
            "scan_depth": 999,
            "timeout": 1,
            "max_children": 9999,
            "ajax_spider": 1,
            "inscope_only": "",
            "sast_runtime_focus": 1,
        },
    )
    assert updated["scan_depth"] == 20
    assert updated["timeout"] == 30
    assert updated["max_children"] == 500
    assert updated["ajax_spider"] is True
    assert updated["inscope_only"] is False
    assert updated["sast_runtime_focus"] is True


def test_redact_text_hides_common_secrets():
    source = "api_key='sk-secret-value' password=supersecret Authorization: Bearer abcdef"
    out = redact_text(source)
    assert "sk-secret-value" not in out
    assert "supersecret" not in out
    assert "Bearer abcdef" not in out
    assert "<REDACTED>" in out


def test_llm_client_extract_json_with_wrapped_text():
    raw = "Here is JSON:\n{\"summary\":\"ok\",\"actions\":[]}\nThanks"
    parsed = LLMClient._extract_json(raw)
    assert parsed["summary"] == "ok"
    assert parsed["actions"] == []


@pytest.mark.asyncio
async def test_resolve_provider_async_uses_stored_credentials(db_session, monkeypatch):
    from app.models.llm_provider_credential import LLMProviderCredential
    from app.core.config import settings

    monkeypatch.setattr(settings, "LLM_ENABLED", True)
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "")

    db_session.add(
        LLMProviderCredential(
            provider="openai",
            encrypted_token="",
            default_model="gpt-4o-mini",
        )
    )
    await db_session.flush()

    from app.core.security import encrypt_token

    row = await db_session.get(LLMProviderCredential, ("", "openai"))
    row.encrypted_token = encrypt_token("sk-stored")
    await db_session.flush()

    cfg = await resolve_llm_provider_config_async(
        db_session,
        project=None,
        scan_config={"llm_provider": "openai"},
    )
    assert cfg["provider"] == "openai"
    assert cfg["model"] == "gpt-4o-mini"
    assert cfg["api_key"] == "sk-stored"


