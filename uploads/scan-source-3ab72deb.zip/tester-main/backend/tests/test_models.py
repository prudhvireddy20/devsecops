"""Integration tests for SQLAlchemy models (Project, Scan, Finding)."""
from sqlalchemy import select

from app.models.project import Project
from app.models.scan import Scan
from app.models.finding import Finding


# ---------- Project model ----------


class TestProjectModel:

    async def test_create_project(self, db_session):
        p = Project(name="Test App", source_type="local", source_path="/tmp/src")
        db_session.add(p)
        await db_session.flush()
        assert p.id is not None
        assert len(p.id) == 36  # UUID

    async def test_project_defaults(self, db_session):
        p = Project(name="Defaults", source_type="git")
        db_session.add(p)
        await db_session.flush()
        assert p.description == ""
        assert p.git_branch == "main"
        assert p.language == "python"
        assert p.llm_provider == ""
        assert p.llm_model == ""
        assert p.llm_api_key_encrypted == ""
        assert p.is_active is True
        assert p.created_at is not None
        assert p.updated_at is not None

    async def test_project_to_dict(self, db_session):
        p = Project(name="Dict Test", source_type="local", target_url="http://app:8000")
        db_session.add(p)
        await db_session.flush()
        d = p.to_dict()
        assert d["name"] == "Dict Test"
        assert d["source_type"] == "local"
        assert d["target_url"] == "http://app:8000"
        assert d["llm_provider"] == ""
        assert d["llm_model"] == ""
        assert d["has_llm_api_key"] is False
        assert "created_at" in d
        assert "id" in d
        # github_token_encrypted should NOT be in to_dict
        assert "github_token_encrypted" not in d

    async def test_project_relationships(self, db_session):
        p = Project(name="With Scans", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id, scan_type="full")
        db_session.add(s)
        await db_session.flush()
        # Refresh to load relationship
        await db_session.refresh(p, ["scans"])
        assert len(p.scans) == 1
        assert p.scans[0].id == s.id


# ---------- Scan model ----------


class TestScanModel:

    async def test_create_scan(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id)
        db_session.add(s)
        await db_session.flush()
        assert s.id is not None
        assert s.status == "pending"

    async def test_scan_defaults(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id)
        db_session.add(s)
        await db_session.flush()
        assert s.scan_type == "full"
        assert s.progress == 0
        assert s.current_phase == ""
        assert s.routes_discovered == 0
        assert s.coverage_percentage == 0
        assert isinstance(s.modules_enabled, dict)
        assert s.modules_enabled.get("dast") is True

    async def test_scan_to_dict(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id, scan_type="sast_only", status="running", progress=50)
        db_session.add(s)
        await db_session.flush()
        d = s.to_dict()
        assert d["scan_type"] == "sast_only"
        assert d["status"] == "running"
        assert d["progress"] == 50
        assert d["project_id"] == p.id
        assert "created_at" in d

    async def test_scan_to_dict_redacts_llm_secrets(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(
            project_id=p.id,
            scan_config={
                "scan_depth": 3,
                "llm_provider": "openai",
                "llm_api_key": "sk-plain",
                "llm_api_key_encrypted": "enc-value",
            },
        )
        db_session.add(s)
        await db_session.flush()
        d = s.to_dict()
        assert d["scan_config"]["llm_provider"] == "openai"
        assert "llm_api_key" not in d["scan_config"]
        assert "llm_api_key_encrypted" not in d["scan_config"]

    async def test_scan_json_columns(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        custom_config = {"scan_depth": 10, "timeout": 7200}
        s = Scan(project_id=p.id, scan_config=custom_config)
        db_session.add(s)
        await db_session.flush()
        # Re-read from DB
        result = await db_session.execute(select(Scan).where(Scan.id == s.id))
        loaded = result.scalar_one()
        assert loaded.scan_config["scan_depth"] == 10
        assert loaded.scan_config["timeout"] == 7200

    async def test_scan_finding_relationship(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id)
        db_session.add(s)
        await db_session.flush()
        f = Finding(
            scan_id=s.id, title="SQLi", vulnerability_type="sqli",
            severity="high", confidence="verified", scanner_source="semgrep",
        )
        db_session.add(f)
        await db_session.flush()
        await db_session.refresh(s, ["findings"])
        assert len(s.findings) == 1


# ---------- Finding model ----------


class TestFindingModel:

    async def _make_scan(self, db_session):
        p = Project(name="P", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id)
        db_session.add(s)
        await db_session.flush()
        return s

    async def test_create_finding(self, db_session):
        s = await self._make_scan(db_session)
        f = Finding(
            scan_id=s.id, title="XSS in /search", vulnerability_type="xss",
            severity="medium", confidence="probable", scanner_source="zap",
        )
        db_session.add(f)
        await db_session.flush()
        assert f.id is not None
        assert f.status == "open"
        assert f.fix_available is False

    async def test_finding_defaults(self, db_session):
        s = await self._make_scan(db_session)
        f = Finding(
            scan_id=s.id, title="T", vulnerability_type="sqli",
            severity="low", confidence="observed", scanner_source="custom",
        )
        db_session.add(f)
        await db_session.flush()
        assert f.endpoint == ""
        assert f.line_number == 0
        assert f.payload == ""
        assert f.response_code == 0
        assert f.fix_applied is False
        assert f.duplicate_of == ""
        assert f.notes == ""

    async def test_finding_to_dict(self, db_session):
        s = await self._make_scan(db_session)
        f = Finding(
            scan_id=s.id, title="Secret Key Exposed",
            vulnerability_type="secret", severity="critical",
            confidence="verified", scanner_source="detect-secrets",
            file_path="settings.py", line_number=42,
            cwe="CWE-798", endpoint="/api/admin",
        )
        db_session.add(f)
        await db_session.flush()
        d = f.to_dict()
        assert d["title"] == "Secret Key Exposed"
        assert d["severity"] == "critical"
        assert d["file_path"] == "settings.py"
        assert d["line_number"] == 42
        assert d["cwe"] == "CWE-798"
        assert "created_at" in d
        assert "updated_at" in d

    async def test_finding_update_status(self, db_session):
        s = await self._make_scan(db_session)
        f = Finding(
            scan_id=s.id, title="FP", vulnerability_type="xss",
            severity="low", confidence="observed", scanner_source="zap",
        )
        db_session.add(f)
        await db_session.flush()
        f.status = "false_positive"
        f.notes = "Not exploitable"
        await db_session.flush()
        result = await db_session.execute(select(Finding).where(Finding.id == f.id))
        reloaded = result.scalar_one()
        assert reloaded.status == "false_positive"
        assert reloaded.notes == "Not exploitable"

    async def test_cascade_delete(self, db_session):
        """Deleting a project cascades to scans and findings."""
        p = Project(name="Cascade", source_type="local")
        db_session.add(p)
        await db_session.flush()
        s = Scan(project_id=p.id)
        db_session.add(s)
        await db_session.flush()
        f = Finding(
            scan_id=s.id, title="T", vulnerability_type="xss",
            severity="low", confidence="observed", scanner_source="zap",
        )
        db_session.add(f)
        await db_session.flush()
        scan_id = s.id

        await db_session.delete(p)
        await db_session.flush()

        result = await db_session.execute(select(Scan).where(Scan.id == scan_id))
        assert result.scalar_one_or_none() is None
        result = await db_session.execute(select(Finding).where(Finding.scan_id == scan_id))
        assert result.scalar_one_or_none() is None
