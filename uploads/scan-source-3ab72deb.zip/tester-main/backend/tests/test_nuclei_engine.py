"""Tests for the Nuclei CLI wrapper."""
import asyncio
import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# _parse_nuclei_result
# ---------------------------------------------------------------------------


class TestParseNucleiResult:
    def _call(self, raw: dict):
        from app.scanners.nuclei_engine import _parse_nuclei_result
        return _parse_nuclei_result(raw)

    def test_skips_empty_template_id(self):
        assert self._call({}) is None
        assert self._call({"template-id": ""}) is None

    def test_basic_parse(self):
        raw = {
            "template-id": "cve-2023-1234",
            "name": "Test CVE",
            "host": "https://target.com",
            "matched-at": "/api/test",
            "info": {
                "severity": "high",
                "tags": ["cve", "rce"],
                "classification": {"cve-id": "CVE-2023-1234"},
            },
            "extracted-results": ["secret_key"],
        }
        result = self._call(raw)
        assert result is not None
        assert result["title"] == "[Nuclei] Test CVE"
        assert result["severity"] == "high"
        assert result["vulnerability_type"] == "cve"
        assert result["cve"] == "CVE-2023-1234"
        assert result["endpoint"] == "https://target.com"
        assert result["details"]["template_id"] == "cve-2023-1234"

    def test_severity_mapping(self):
        cases = [
            ("critical", "critical"),
            ("high", "high"),
            ("medium", "medium"),
            ("low", "low"),
            ("info", "info"),
            ("unknown", "medium"),
        ]
        for raw_sev, expected in cases:
            raw = {
                "template-id": "t-1",
                "name": "test",
                "info": {"severity": raw_sev, "tags": []},
            }
            assert self._call(raw)["severity"] == expected

    def test_vuln_type_from_tags(self):
        raw = {
            "template-id": "t-2",
            "name": "test",
            "info": {"severity": "high", "tags": ["misconfiguration", "cloud"]},
        }
        result = self._call(raw)
        assert result["vulnerability_type"] == "config"

    def test_fallback_vuln_type(self):
        raw = {
            "template-id": "t-3",
            "name": "test",
            "info": {"severity": "high", "tags": ["unknown-custom"]},
        }
        assert self._call(raw)["vulnerability_type"] == "generic"

    def test_missing_info(self):
        raw = {"template-id": "t-4", "name": "test"}
        result = self._call(raw)
        assert result["severity"] == "medium"
        assert result["vulnerability_type"] == "generic"


# ---------------------------------------------------------------------------
# run_nuclei
# ---------------------------------------------------------------------------


class TestRunNuclei:
    @pytest.mark.asyncio
    async def test_skips_when_cli_not_found(self):
        from app.scanners.nuclei_engine import run_nuclei
        with patch("app.scanners.nuclei_engine.shutil.which", return_value=None):
            result = await run_nuclei("https://target.com")
        assert result == []

    @pytest.mark.asyncio
    async def test_timeout_returns_empty(self):
        from app.scanners.nuclei_engine import run_nuclei

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(side_effect=asyncio.TimeoutError())
        mock_proc.kill = MagicMock()

        with (
            patch("app.scanners.nuclei_engine.shutil.which", return_value="/usr/bin/nuclei"),
            patch("app.scanners.nuclei_engine.asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            result = await run_nuclei("https://target.com", timeout=1)
        assert result == []

    @pytest.mark.asyncio
    async def test_parses_valid_json_lines(self):
        from app.scanners.nuclei_engine import run_nuclei

        findings = [
            {"template-id": "t-1", "name": "finding1", "info": {"severity": "high", "tags": ["cve"]}, "host": "https://a.com"},
            {"template-id": "t-2", "name": "finding2", "info": {"severity": "low", "tags": ["exposure"]}, "host": "https://b.com"},
        ]
        stdout = "\n".join(json.dumps(f) for f in findings).encode()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(stdout, b""))
        mock_proc.returncode = 0

        with (
            patch("app.scanners.nuclei_engine.shutil.which", return_value="/usr/bin/nuclei"),
            patch("app.scanners.nuclei_engine.asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            result = await run_nuclei("https://target.com")
        assert len(result) == 2
        assert result[0]["title"] == "[Nuclei] finding1"
        assert result[1]["title"] == "[Nuclei] finding2"

    @pytest.mark.asyncio
    async def test_skips_invalid_json_lines(self):
        from app.scanners.nuclei_engine import run_nuclei

        stdout = b'{"template-id": "t-1", "name": "good"}\nnot json\n{"template-id": "t-2", "name": "great"}\n'

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(stdout, b""))
        mock_proc.returncode = 0

        with (
            patch("app.scanners.nuclei_engine.shutil.which", return_value="/usr/bin/nuclei"),
            patch("app.scanners.nuclei_engine.asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            result = await run_nuclei("https://target.com")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_nonzero_returncode_still_parses_stdout(self):
        from app.scanners.nuclei_engine import run_nuclei

        stdout = b'{"template-id": "t-1", "name": "partial", "info": {"severity": "high", "tags": []}}'
        stderr = b"some errors\n"

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(stdout, stderr))
        mock_proc.returncode = 1

        with (
            patch("app.scanners.nuclei_engine.shutil.which", return_value="/usr/bin/nuclei"),
            patch("app.scanners.nuclei_engine.asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            result = await run_nuclei("https://target.com")
        assert len(result) == 1
