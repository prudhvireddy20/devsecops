"""Tests for the ScanOrchestrator enrichment and inference helpers."""
import asyncio
import re
from pathlib import PurePosixPath
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# We test the helpers indirectly by instantiating ScanOrchestrator
# with minimal mocks and calling the private methods directly.


# ---------- Helpers (copied from orchestrator for unit-level testing) ----------

def _enrich_sast_with_routes(sast_findings: list[dict], routes: list[dict]) -> int:
    """Reimplementation of the enrichment logic for isolated testing."""
    if not routes:
        return 0

    file_to_routes: dict[str, list[dict]] = {}
    for route in routes:
        file_path = route.get("file", "")
        if not file_path:
            continue
        norm = str(PurePosixPath(file_path.replace("\\", "/"))).lower()
        file_to_routes.setdefault(norm, []).append(route)
        basename = PurePosixPath(norm).name
        if basename:
            file_to_routes.setdefault(basename, []).append(route)

    enriched = 0
    for finding in sast_findings:
        if finding.get("endpoint"):
            continue
        fp = finding.get("file_path", "")
        if not fp:
            continue
        norm_fp = str(PurePosixPath(fp.replace("\\", "/"))).lower()
        candidates = file_to_routes.get(norm_fp, [])
        if not candidates:
            basename = PurePosixPath(norm_fp).name
            candidates = file_to_routes.get(basename, [])
        if not candidates:
            continue

        finding_line = finding.get("line_number", 0)
        best = min(candidates, key=lambda r: abs(r.get("line", 0) - finding_line))
        finding["endpoint"] = best.get("path", "")
        enriched += 1

    return enriched


def _infer_file_for_dynamic_routes(routes: list[dict]) -> int:
    """Reimplementation of the file inference logic for isolated testing."""
    _param_re = re.compile(r'[<{][^>}]+[>}]|:(\w+)')

    path_to_file: dict[str, str] = {}
    for route in routes:
        if route.get("file") and route.get("path"):
            norm = _param_re.sub('*', route["path"].strip().rstrip("/").lower() or "/")
            if norm not in path_to_file:
                path_to_file[norm] = route["file"]

    inferred = 0
    for route in routes:
        if route.get("file"):
            continue
        path = route.get("path", "")
        if not path:
            continue
        norm = _param_re.sub('*', path.strip().rstrip("/").lower() or "/")
        if norm in path_to_file:
            route["file"] = path_to_file[norm]
            inferred += 1

    return inferred


# ---------- Tests for _enrich_sast_with_routes ----------

class TestEnrichSastWithRoutes:
    """Test enrichment of SAST findings with endpoint data from routes."""

    def test_no_routes_skips(self):
        findings = [{"file_path": "app.py", "vulnerability_type": "sqli"}]
        count = _enrich_sast_with_routes(findings, [])
        assert count == 0
        assert "endpoint" not in findings[0]

    def test_basic_enrichment(self):
        routes = [
            {"file": "app/views.py", "path": "/api/users", "line": 10, "parameters": ["id"]},
        ]
        findings = [
            {"file_path": "app/views.py", "line_number": 12, "vulnerability_type": "sqli"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 1
        assert findings[0]["endpoint"] == "/api/users"
        assert "parameter" not in findings[0]

    def test_route_parameter_not_promoted_to_vuln_parameter(self):
        routes = [
            {"file": "app/views.py", "path": "/api/users/{id}", "line": 10, "parameters": ["id"]},
        ]
        findings = [
            {"file_path": "app/views.py", "line_number": 12, "vulnerability_type": "sqli", "cwe": "CWE-89"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 1
        assert findings[0]["endpoint"] == "/api/users/{id}"
        assert "parameter" not in findings[0]

    def test_skips_already_enriched(self):
        routes = [
            {"file": "app/views.py", "path": "/api/users", "line": 10},
        ]
        findings = [
            {"file_path": "app/views.py", "line_number": 12, "endpoint": "/existing"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 0
        assert findings[0]["endpoint"] == "/existing"

    def test_picks_closest_route_by_line(self):
        routes = [
            {"file": "app/views.py", "path": "/api/users", "line": 10},
            {"file": "app/views.py", "path": "/api/admin", "line": 50},
        ]
        findings = [
            {"file_path": "app/views.py", "line_number": 48, "vulnerability_type": "sqli"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 1
        assert findings[0]["endpoint"] == "/api/admin"

    def test_basename_fallback(self):
        """Routes with relative paths should match SAST findings with absolute paths via basename."""
        routes = [
            {"file": "views.py", "path": "/api/items", "line": 5, "parameters": []},
        ]
        findings = [
            {"file_path": "/home/user/project/views.py", "line_number": 6, "vulnerability_type": "xss"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 1
        assert findings[0]["endpoint"] == "/api/items"

    def test_no_file_path_in_finding(self):
        routes = [
            {"file": "app.py", "path": "/api/users", "line": 10},
        ]
        findings = [
            {"vulnerability_type": "sqli"},  # no file_path
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 0

    def test_no_matching_file(self):
        routes = [
            {"file": "other.py", "path": "/api/users", "line": 10},
        ]
        findings = [
            {"file_path": "app.py", "line_number": 5, "vulnerability_type": "sqli"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 0

    def test_routes_without_file_key_ignored(self):
        """Spider/OpenAPI routes that lack 'file' should be silently skipped."""
        routes = [
            {"path": "/api/users", "line": 10},  # no file key
        ]
        findings = [
            {"file_path": "app.py", "line_number": 5, "vulnerability_type": "sqli"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 0

    def test_parameter_not_overwritten(self):
        """If finding already has a parameter, don't overwrite it."""
        routes = [
            {"file": "app.py", "path": "/api/users", "line": 10, "parameters": ["id"]},
        ]
        findings = [
            {"file_path": "app.py", "line_number": 12, "vulnerability_type": "sqli", "parameter": "name"},
        ]
        count = _enrich_sast_with_routes(findings, routes)
        assert count == 1
        assert findings[0]["parameter"] == "name"  # not overwritten


# ---------- Tests for _infer_file_for_dynamic_routes ----------

class TestInferFileForDynamicRoutes:
    """Test file inference for spider/OpenAPI routes."""

    def test_basic_inference(self):
        routes = [
            {"file": "app/views.py", "path": "/api/users"},
            {"path": "/api/users"},  # no file, same path
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 1
        assert routes[1]["file"] == "app/views.py"

    def test_parameterized_path_matching(self):
        """Flask <int:id> should match FastAPI {id} after normalization."""
        routes = [
            {"file": "app/views.py", "path": "/api/users/<int:id>"},
            {"path": "/api/users/{id}"},  # no file
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 1
        assert routes[1]["file"] == "app/views.py"

    def test_express_colon_params(self):
        """Express :id should also normalize to * for matching."""
        routes = [
            {"file": "routes/users.js", "path": "/api/users/:id"},
            {"path": "/api/users/{userId}"},  # no file
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 1
        assert routes[1]["file"] == "routes/users.js"

    def test_no_file_routes_only(self):
        routes = [
            {"path": "/api/users"},
            {"path": "/api/items"},
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 0

    def test_no_path_skipped(self):
        routes = [
            {"file": "app.py", "path": "/api/users"},
            {"file": "", "path": ""},  # empty path
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 0

    def test_already_has_file_not_overwritten(self):
        routes = [
            {"file": "original.py", "path": "/api/users"},
            {"file": "existing.py", "path": "/api/users"},
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 0
        assert routes[1]["file"] == "existing.py"

    def test_trailing_slash_normalized(self):
        routes = [
            {"file": "app.py", "path": "/api/users/"},
            {"path": "/api/users"},  # no trailing slash, no file
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 1
        assert routes[1]["file"] == "app.py"

    def test_case_insensitive(self):
        routes = [
            {"file": "app.py", "path": "/API/Users"},
            {"path": "/api/users"},  # no file
        ]
        count = _infer_file_for_dynamic_routes(routes)
        assert count == 1
        assert routes[1]["file"] == "app.py"


def test_gitnexus_file_paths_match_strips_line_suffix():
    from app.integrations.gitnexus_client import file_paths_match

    assert file_paths_match("app/routes/users.py:42", "app/routes/users.py") is True
    assert file_paths_match("app/routes/users.py:42:9", "routes/users.py") is True
    assert file_paths_match("app/routes/users.py", "app/routes/users.py:42") is True


# ---------- Tests for ScanOrchestrator safe wrappers & phase warnings ----------

def _make_orchestrator():
    """Create a ScanOrchestrator with minimal mocks for unit testing."""
    from app.core.orchestrator import ScanOrchestrator

    scan = MagicMock()
    scan.id = "test-scan-id"
    scan.scan_config = {}
    scan.modules_enabled = {"sast": True, "secrets": True, "dependencies": True, "dast": False}
    scan.source_available = True
    scan.status = "running"
    scan.progress = 0
    scan.current_phase = ""
    scan.log = ""
    scan.results_summary = {}

    project = MagicMock()
    project.local_path = "/tmp/test-project"
    project.target_url = "http://test.local"

    db = AsyncMock()
    db.commit = AsyncMock()
    db.add = MagicMock()
    db_result = MagicMock()
    db_result.scalar_one_or_none.return_value = None
    db.execute = AsyncMock(return_value=db_result)

    ws = AsyncMock()
    ws.send_scan_progress = AsyncMock()
    ws.send_scan_log = AsyncMock()
    ws.send_scan_complete = AsyncMock()
    ws.send_finding = AsyncMock()
    ws.send_phase_warning = AsyncMock()

    orch = ScanOrchestrator(scan=scan, project=project, db=db, ws_manager=ws)
    return orch


class TestOrchestratorSafeWrappers:
    """Test that _safe wrappers catch exceptions and record phase warnings."""

    @pytest.mark.asyncio
    async def test_setup_auth_safe_catches_exception(self):
        orch = _make_orchestrator()
        with patch.object(orch, '_setup_auth', new=AsyncMock(side_effect=RuntimeError("playwright fail"))):
            await orch._setup_auth_safe()

        assert orch._auth_credentials is None
        assert len(orch._phase_warnings) == 1
        assert orch._phase_warnings[0]["phase"] == "auth"


class TestOrchestratorPhaseWarningsInSummary:
    """Test that _phase_warnings are included in the finalize summary."""

    @pytest.mark.asyncio
    async def test_finalize_includes_warnings(self):
        orch = _make_orchestrator()
        orch._phase_warnings = [
            {"phase": "sast", "error": "semgrep crash"},
            {"phase": "secrets", "error": "regex error"},
        ]
        orch.all_findings = []

        await orch._finalize()

        # summary should contain phase_warnings
        summary = orch.scan.results_summary
        assert "phase_warnings" in summary
        assert len(summary["phase_warnings"]) == 2

    @pytest.mark.asyncio
    async def test_finalize_no_warnings_key_when_empty(self):
        orch = _make_orchestrator()
        orch._phase_warnings = []
        orch.all_findings = []

        await orch._finalize()

        summary = orch.scan.results_summary
        assert "phase_warnings" not in summary


class TestOrchestratorTimeout:
    """Test overall scan timeout behavior."""

    @pytest.mark.asyncio
    async def test_timeout_sets_failed_status(self):
        orch = _make_orchestrator()
        orch.scan.scan_config = {"max_duration": 0.001}  # tiny timeout

        # Make _run_pipeline slow
        async def slow_pipeline():
            await asyncio.sleep(10)

        with patch.object(orch, '_run_pipeline', new=slow_pipeline):
            await orch.run()

        assert orch.scan.status == "failed"
        assert "timed out" in orch.scan.error_message

    @pytest.mark.asyncio
    async def test_run_catches_general_exception(self):
        orch = _make_orchestrator()

        with patch.object(orch, '_run_pipeline', new=AsyncMock(side_effect=RuntimeError("boom"))):
            await orch.run()

        assert orch.scan.status == "failed"
        assert "boom" in orch.scan.error_message


class TestOrchestratorLLMPlanner:
    """Test guarded LLM planner checkpoint behavior."""

    @pytest.mark.asyncio
    async def test_llm_planner_checkpoint_skips_when_disabled(self):
        orch = _make_orchestrator()
        orch.scan.scan_config = {"llm_planner_enabled": False}

        await orch._run_llm_planner_checkpoint("after_source_analysis")

        assert orch._llm_planner_summary["enabled"] is False
        assert orch._llm_planner_summary["decisions"] == []

    @pytest.mark.asyncio
    async def test_llm_planner_checkpoint_applies_updates(self):
        orch = _make_orchestrator()
        orch.scan.scan_config = {"llm_planner_enabled": True, "scan_depth": 3, "timeout": 600}

        fake_decision = MagicMock()
        fake_decision.summary = "increase depth"
        fake_decision.actions = [
            MagicMock(action="update_scan_config", params={"scan_depth": 8}, model_dump=lambda: {"action": "update_scan_config", "params": {"scan_depth": 8}}),
            MagicMock(action="prioritize_vuln_types", params={"types": ["sqli", "xss"]}, model_dump=lambda: {"action": "prioritize_vuln_types", "params": {"types": ["sqli", "xss"]}}),
        ]

        with patch("app.llm.provider_config.resolve_llm_provider_config_async", new=AsyncMock(return_value={"enabled": True, "provider": "openai", "model": "gpt-4o-mini", "api_key": "k"})):
            with patch("app.llm.client.LLMClient") as client_cls:
                client_instance = client_cls.return_value
                client_instance.is_available.return_value = True
                with patch("app.llm.context_builder.build_planner_context", return_value={"checkpoint": "after_source_analysis"}):
                    with patch("app.llm.planner.LLMPlanner") as planner_cls:
                        planner_instance = planner_cls.return_value
                        planner_instance.decide = AsyncMock(return_value=fake_decision)
                        planner_instance.apply_scan_config_updates.return_value = {
                            "llm_planner_enabled": True,
                            "scan_depth": 8,
                            "timeout": 600,
                        }
                        await orch._run_llm_planner_checkpoint("after_source_analysis")

        assert orch.scan.scan_config["scan_depth"] == 8
        assert orch.scan.scan_config["llm_prioritized_vuln_types"] == ["sqli", "xss"]
        assert len(orch._llm_planner_summary["decisions"]) == 1

    @pytest.mark.asyncio
    async def test_llm_planner_checkpoint_records_error(self):
        orch = _make_orchestrator()
        orch.scan.scan_config = {"llm_planner_enabled": True}

        with patch("app.llm.provider_config.resolve_llm_provider_config_async", new=AsyncMock(side_effect=RuntimeError("bad llm cfg"))):
            await orch._run_llm_planner_checkpoint("after_source_analysis")

        assert len(orch._llm_planner_summary["errors"]) == 1
        assert "bad llm cfg" in orch._llm_planner_summary["errors"][0]["error"]


class TestOrchestratorCoverageAnalysis:
    """Test route coverage calculation and normalization behavior."""

    @pytest.mark.asyncio
    async def test_coverage_marks_root_route_tested(self):
        orch = _make_orchestrator()
        orch.routes = [{"path": "/", "tested": False}]
        orch.dast_findings = [{"endpoint": "/"}]

        await orch._run_coverage_analysis()

        assert orch.scan.coverage_percentage == 100
        assert orch.routes[0]["tested"] is True

    @pytest.mark.asyncio
    async def test_coverage_does_not_overmatch_root_prefix(self):
        orch = _make_orchestrator()
        orch.routes = [
            {"path": "/", "tested": False},
            {"path": "/api/users", "tested": False},
        ]
        orch.dast_findings = [{"endpoint": "/api/users/1"}]

        await orch._run_coverage_analysis()

        assert orch.scan.coverage_percentage == 50
        assert orch.routes[0]["tested"] is False
        assert orch.routes[1]["tested"] is True


class TestOrchestratorBlackBoxMode:
    """Test black-box pipeline branching and _import_external_findings."""

    def _make_orchestrator(self):
        from app.core.orchestrator import ScanOrchestrator
        from unittest.mock import AsyncMock, MagicMock

        scan = MagicMock()
        scan.id = "bb-test-scan"
        scan.source_available = False
        scan.scan_config = {
            "external_findings_path": "",
            "external_findings_format": "",
        }
        scan.modules_enabled = {"sast": False, "secrets": False, "dependencies": False, "dast": True}
        scan.status = "running"
        scan.progress = 0
        scan.current_phase = ""
        scan.log = ""
        scan.results_summary = {}

        project = MagicMock()
        project.local_path = ""
        project.target_url = "http://test.local"
        project.trustscan_job_id = ""
        project.trustscan_token_encrypted = ""
        project.trustscan_url = ""

        db = AsyncMock()
        db.commit = AsyncMock()
        db.add = MagicMock()
        db_result = MagicMock()
        db_result.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=db_result)

        ws = AsyncMock()
        ws.send_scan_progress = AsyncMock()
        ws.send_scan_log = AsyncMock()
        ws.send_scan_complete = AsyncMock()
        ws.send_finding = AsyncMock()
        ws.send_phase_warning = AsyncMock()

        orch = ScanOrchestrator(scan=scan, project=project, db=db, ws_manager=ws)
        return orch

    @pytest.mark.asyncio
    async def test_import_external_findings_no_path(self):
        """When external_findings_path is empty, log and skip."""
        orch = self._make_orchestrator()
        orch.scan.scan_config = {"external_findings_path": "", "external_findings_format": ""}
        await orch._import_external_findings()
        orch.ws.send_scan_log.assert_called_once()
        msg = orch.ws.send_scan_log.call_args[0][1]
        assert "No external findings file configured" in msg

    @pytest.mark.asyncio
    async def test_import_external_findings_file_not_found(self, tmp_path):
        """When file does not exist, log and skip."""
        orch = self._make_orchestrator()
        orch.scan.scan_config = {
            "external_findings_path": str(tmp_path / "nonexistent.json"),
            "external_findings_format": "semgrep",
        }
        await orch._import_external_findings()
        logs = [call[0][1] for call in orch.ws.send_scan_log.call_args_list]
        assert any("not found" in msg for msg in logs)

    @pytest.mark.asyncio
    async def test_import_external_findings_vulns_only(self, tmp_path):
        """Vulnerability findings should be persisted as Finding ORM objects."""
        import json
        data = {
            "results": [{
                "check_id": "rules.xss",
                "path": "app.js",
                "start": {"line": 10},
                "extra": {"severity": "ERROR", "metadata": {"cwe": ["CWE-79"]}, "message": "XSS", "lines": "alert(1)"},
            }]
        }
        fpath = tmp_path / "findings.json"
        fpath.write_text(json.dumps(data))

        orch = self._make_orchestrator()
        orch.scan.scan_config = {
            "external_findings_path": str(fpath),
            "external_findings_format": "semgrep",
        }
        await orch._import_external_findings()

        assert len(orch.all_findings) == 1
        assert orch.all_findings[0].vulnerability_type == "xss"
        orch.db.commit.assert_called()
        orch.ws.send_finding.assert_called_once()

    @pytest.mark.asyncio
    async def test_import_external_findings_noir_routes(self, tmp_path):
        """Noir route findings should be added to orch.routes, not Findings."""
        import json
        data = {"paths": [{"path": "/api/users", "method": "GET", "file": "routes/users.js"}]}
        fpath = tmp_path / "noir.json"
        fpath.write_text(json.dumps(data))

        orch = self._make_orchestrator()
        orch.routes = []
        orch.scan.scan_config = {
            "external_findings_path": str(fpath),
            "external_findings_format": "noir",
        }
        await orch._import_external_findings()

        # Routes should be added, no Finding objects
        assert len(orch.routes) == 1
        assert orch.routes[0]["path"] == "/api/users"
        assert orch.routes[0]["method"] == "GET"
        assert len(orch.all_findings) == 0

    @pytest.mark.asyncio
    async def test_import_external_findings_mixed_vulns_and_routes(self, tmp_path):
        """With explicit format, only that parser is used, so only vulns extracted."""
        import json
        data = {
            "results": [{
                "check_id": "rules.sqli",
                "path": "db.py",
                "start": {"line": 5},
                "extra": {"severity": "ERROR", "metadata": {}, "message": "SQLi", "lines": "q"},
            }],
            "paths": [{"path": "/api/login", "method": "POST", "file": "routes/auth.js"}],
        }
        fpath = tmp_path / "mixed.json"
        fpath.write_text(json.dumps(data))

        orch = self._make_orchestrator()
        orch.routes = []
        orch.scan.scan_config = {
            "external_findings_path": str(fpath),
            "external_findings_format": "semgrep",
        }
        await orch._import_external_findings()

        # Only Semgrep results are parsed (explicit format). Noir "paths" ignored.
        assert len(orch.all_findings) == 1
        assert len(orch.routes) == 0

    @pytest.mark.asyncio
    async def test_import_external_findings_zero_parsed(self, tmp_path):
        """File with no parseable findings should log and skip."""
        import json
        fpath = tmp_path / "empty.json"
        fpath.write_text(json.dumps({"results": []}))

        orch = self._make_orchestrator()
        orch.scan.scan_config = {
            "external_findings_path": str(fpath),
            "external_findings_format": "semgrep",
        }
        await orch._import_external_findings()

        assert len(orch.all_findings) == 0
        logs = [call[0][1] for call in orch.ws.send_scan_log.call_args_list]
        assert any("0 findings" in msg for msg in logs)

    @pytest.mark.asyncio
    async def test_import_external_findings_skips_duplicate_routes(self, tmp_path):
        """Noir routes that already exist in orch.routes should not be duplicated."""
        import json
        data = {"paths": [{"path": "/api/users", "method": "GET", "file": "routes/users.js"}]}
        fpath = tmp_path / "noir.json"
        fpath.write_text(json.dumps(data))

        orch = self._make_orchestrator()
        orch.routes = [{"path": "/api/users", "method": "GET", "handler": "", "file": "", "line": 0}]
        orch.scan.scan_config = {
            "external_findings_path": str(fpath),
            "external_findings_format": "noir",
        }
        await orch._import_external_findings()

        assert len(orch.routes) == 1  # no duplicate

    @pytest.mark.asyncio
    async def test_black_box_pipeline_skips_import_runs_attack_surface(self):
        """Blackbox = pure DAST: no importing, but attack_surface analysis runs."""
        orch = self._make_orchestrator()
        orch.scan.scan_mode = "blackbox"
        orch.scan.scan_config["external_findings_path"] = ""
        # Disable recon tools so only the shared phases run
        orch.scan.modules_enabled = {
            "path_fuzzing": False, "feroxbuster": False,
            "server_audit": False, "testssl": False, "dast": False,
        }

        with (
            patch.object(orch, "_import_external_findings", new=AsyncMock()) as mock_import,
            patch.object(orch, "_run_attack_surface_analysis", new=AsyncMock()) as mock_asa,
            patch.object(orch, "_run_endpoint_discovery", new=AsyncMock()),
            patch.object(orch, "_run_tech_fingerprinting", new=AsyncMock()),
            patch.object(orch, "_check_cancel_requested", new=AsyncMock()),
            patch.object(orch, "_update_phase", new=AsyncMock()),
            patch.object(orch, "_infer_file_for_dynamic_routes"),
            patch.object(orch, "_run_correlation", new=AsyncMock()),
            patch.object(orch, "_finalize", new=AsyncMock()),
            patch.object(orch, "_run_llm_planner_checkpoint", new=AsyncMock()),
        ):
            await orch._run_pipeline()

        # Blackbox has NO importing — pure DAST
        mock_import.assert_not_called()
        # Attack surface analysis always runs
        mock_asa.assert_called_once()
