"""Tests for journey replay adapter safety behavior."""

import pytest

from app.scanners.replay_adapter import _build_request_url


def test_build_request_url_rejects_cross_host_absolute_step_url():
    with pytest.raises(ValueError, match="does not match target host"):
        _build_request_url("https://shop.example.com", "https://evil.example.net/admin")
