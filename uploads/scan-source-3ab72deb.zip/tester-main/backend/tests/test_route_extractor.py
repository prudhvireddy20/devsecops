"""Tests for the route extractor and framework parsers."""
import os
import tempfile

import pytest

from app.analyzers.route_extractor import RouteExtractor


class TestRouteExtractor:
    """Test route extraction from different frameworks."""

    def setup_method(self):
        self.extractor = RouteExtractor()

    def _create_source(self, files: dict[str, str]) -> str:
        """Create a temp dir with files and return the dir path."""
        tmpdir = tempfile.mkdtemp()
        for filename, content in files.items():
            filepath = os.path.join(tmpdir, filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, "w") as f:
                f.write(content)
        return tmpdir

    @pytest.mark.asyncio
    async def test_extract_flask_routes(self):
        source = self._create_source({
            "app.py": '''
from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return "hello"

@app.route("/users", methods=["GET"])
def list_users():
    return "users"

@app.route("/users/<int:user_id>", methods=["GET", "POST"])
def get_user(user_id):
    return f"user {user_id}"
''',
        })
        routes = await self.extractor.extract_routes(source)
        assert isinstance(routes, list)
        # Flask parser should find at least some routes
        if len(routes) > 0:
            paths = [r.get("path", r.get("url", "")) for r in routes]
            assert any("/" in p for p in paths)

    @pytest.mark.asyncio
    async def test_extract_fastapi_routes(self):
        source = self._create_source({
            "main.py": '''
from fastapi import FastAPI
app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "hello"}

@app.post("/items")
def create_item():
    return {"item": "created"}

@app.get("/items/{item_id}")
def read_item(item_id: int):
    return {"item_id": item_id}
''',
        })
        routes = await self.extractor.extract_routes(source)
        assert isinstance(routes, list)

    @pytest.mark.asyncio
    async def test_extract_django_routes(self):
        source = self._create_source({
            "urls.py": '''
from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("users/", views.list_users),
    path("users/<int:pk>/", views.user_detail),
]
''',
            "views.py": '''
from django.http import HttpResponse

def index(request):
    return HttpResponse("hello")
''',
        })
        routes = await self.extractor.extract_routes(source)
        assert isinstance(routes, list)

    @pytest.mark.asyncio
    async def test_extract_empty_dir(self):
        tmpdir = tempfile.mkdtemp()
        routes = await self.extractor.extract_routes(tmpdir)
        assert isinstance(routes, list)

    @pytest.mark.asyncio
    async def test_extract_unknown_framework(self):
        """When framework is unknown, all parsers are tried."""
        source = self._create_source({
            "app.py": "def hello(): pass\n",
        })
        routes = await self.extractor.extract_routes(source)
        assert isinstance(routes, list)
