"""Tests for the SARIF exporter."""
import json
import tempfile

import pytest

from app.reports.sarif_export import SARIFExporter, CWE_TAXONOMY


class TestSARIFExporter:
    """Test SARIF 2.1.0 export functionality."""

    def setup_method(self):
        self.exporter = SARIFExporter()

    def _sample_findings(self) -> list[dict]:
        return [
            {
                "title": "SQL Injection",
                "vulnerability_type": "sqli",
                "severity": "critical",
                "confidence": "verified",
                "cwe": "CWE-89",
                "file_path": "app/views.py",
                "line_number": 42,
                "code_snippet": 'cursor.execute(f"SELECT * FROM users WHERE id={uid}")',
                "endpoint": "/api/users",
                "http_method": "GET",
                "parameter": "uid",
                "data_flow": "request.args -> uid -> cursor.execute",
                "remediation_text": "Use parameterized queries.",
                "scanner_source": "sast",
                "scanner_rule_id": "python.sqli.raw-query",
            },
            {
                "title": "XSS",
                "vulnerability_type": "xss",
                "severity": "high",
                "confidence": "probable",
                "cwe": "CWE-79",
                "file_path": "app/templates.py",
                "line_number": 15,
                "code_snippet": "render_template_string(user_input)",
                "scanner_source": "sast",
            },
        ]

    @pytest.mark.asyncio
    async def test_export_creates_file(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"status": "completed", "started_at": "2024-01-01T00:00:00", "completed_at": "2024-01-01T00:05:00"}
        project_data = {"name": "test-project"}
        findings = self._sample_findings()

        result_path = await self.exporter.export(scan_data, project_data, findings, output_dir)
        assert result_path.exists()
        assert result_path.name == "report.sarif"

    @pytest.mark.asyncio
    async def test_export_valid_json(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"status": "completed", "started_at": "", "completed_at": ""}
        project_data = {"name": "test"}
        findings = self._sample_findings()

        result_path = await self.exporter.export(scan_data, project_data, findings, output_dir)
        with open(result_path) as f:
            sarif = json.load(f)
        assert sarif["version"] == "2.1.0"
        assert len(sarif["runs"]) == 1

    @pytest.mark.asyncio
    async def test_export_contains_results(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"status": "completed", "started_at": "", "completed_at": ""}
        project_data = {"name": "test"}
        findings = self._sample_findings()

        result_path = await self.exporter.export(scan_data, project_data, findings, output_dir)
        with open(result_path) as f:
            sarif = json.load(f)

        results = sarif["runs"][0]["results"]
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_export_contains_rules(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"status": "completed", "started_at": "", "completed_at": ""}
        project_data = {"name": "test"}
        findings = self._sample_findings()

        result_path = await self.exporter.export(scan_data, project_data, findings, output_dir)
        with open(result_path) as f:
            sarif = json.load(f)

        rules = sarif["runs"][0]["tool"]["driver"]["rules"]
        assert len(rules) >= 1

    @pytest.mark.asyncio
    async def test_export_empty_findings(self):
        from pathlib import Path

        output_dir = Path(tempfile.mkdtemp())
        scan_data = {"status": "completed", "started_at": "", "completed_at": ""}
        project_data = {"name": "test"}

        result_path = await self.exporter.export(scan_data, project_data, [], output_dir)
        with open(result_path) as f:
            sarif = json.load(f)

        assert sarif["runs"][0]["results"] == []
        assert sarif["runs"][0]["tool"]["driver"]["rules"] == []


class TestSARIFExporterHelpers:
    """Test SARIF helper/mapping methods."""

    def setup_method(self):
        self.exporter = SARIFExporter()

    def test_severity_to_sarif_level_critical(self):
        assert self.exporter._severity_to_sarif_level("critical") == "error"

    def test_severity_to_sarif_level_high(self):
        assert self.exporter._severity_to_sarif_level("high") == "error"

    def test_severity_to_sarif_level_medium(self):
        assert self.exporter._severity_to_sarif_level("medium") == "warning"

    def test_severity_to_sarif_level_low(self):
        assert self.exporter._severity_to_sarif_level("low") == "note"

    def test_severity_to_sarif_level_info(self):
        assert self.exporter._severity_to_sarif_level("info") == "note"

    def test_severity_to_sarif_level_unknown(self):
        assert self.exporter._severity_to_sarif_level("unknown") == "warning"

    def test_confidence_to_precision_verified(self):
        assert self.exporter._confidence_to_precision("verified") == "very-high"

    def test_confidence_to_precision_probable(self):
        assert self.exporter._confidence_to_precision("probable") == "high"

    def test_confidence_to_precision_observed(self):
        assert self.exporter._confidence_to_precision("observed") == "medium"

    def test_confidence_to_precision_unknown(self):
        assert self.exporter._confidence_to_precision("unknown") == "medium"

    def test_build_message_with_all_fields(self):
        finding = {
            "title": "SQL Injection",
            "confidence": "verified",
            "endpoint": "/api/users",
            "http_method": "GET",
            "parameter": "id",
            "cwe": "CWE-89",
        }
        message = self.exporter._build_message(finding)
        assert "SQL Injection" in message
        assert "VERIFIED" in message
        assert "/api/users" in message
        assert "id" in message
        assert "CWE-89" in message

    def test_build_message_minimal(self):
        finding = {"title": "Issue"}
        message = self.exporter._build_message(finding)
        assert message == "Issue"

    def test_build_artifacts(self):
        findings = [
            {"file_path": "a.py"},
            {"file_path": "b.py"},
            {"file_path": "a.py"},  # duplicate
        ]
        artifacts = self.exporter._build_artifacts(findings)
        assert len(artifacts) == 2
        uris = [a["location"]["uri"] for a in artifacts]
        assert "a.py" in uris
        assert "b.py" in uris

    def test_build_artifacts_no_file_path(self):
        findings = [{"endpoint": "/api/test"}]
        artifacts = self.exporter._build_artifacts(findings)
        assert len(artifacts) == 0

    def test_build_rules_deduplicates(self):
        findings = [
            {"vulnerability_type": "sqli", "title": "SQL Injection", "severity": "critical", "cwe": "CWE-89"},
            {"vulnerability_type": "sqli", "title": "SQL Injection 2", "severity": "critical", "cwe": "CWE-89"},
        ]
        rules = self.exporter._build_rules(findings)
        assert len(rules) == 1

    def test_build_results_with_endpoint(self):
        findings = [
            {
                "vulnerability_type": "sqli",
                "severity": "critical",
                "endpoint": "/api/users",
                "http_method": "GET",
                "title": "SQLi",
            }
        ]
        results = self.exporter._build_results(findings)
        assert len(results) == 1
        locations = results[0]["locations"]
        logical = [loc for loc in locations if "logicalLocations" in loc]
        assert len(logical) == 1

    def test_build_results_with_data_flow(self):
        findings = [
            {
                "vulnerability_type": "sqli",
                "severity": "critical",
                "title": "SQLi",
                "data_flow": "source -> sink",
            }
        ]
        results = self.exporter._build_results(findings)
        assert "codeFlows" in results[0]

    def test_build_results_with_fix(self):
        findings = [
            {
                "vulnerability_type": "sqli",
                "severity": "critical",
                "title": "SQLi",
                "remediation_text": "Use parameterized queries",
            }
        ]
        results = self.exporter._build_results(findings)
        assert "fixes" in results[0]


class TestCWETaxonomy:
    """Test that CWE taxonomy mappings are correct."""

    def test_sqli_mapping(self):
        assert CWE_TAXONOMY["CWE-89"] == "SQL Injection"

    def test_xss_mapping(self):
        assert CWE_TAXONOMY["CWE-79"] == "Cross-site Scripting (XSS)"

    def test_all_entries_have_values(self):
        for cwe, name in CWE_TAXONOMY.items():
            assert cwe.startswith("CWE-")
            assert len(name) > 0
