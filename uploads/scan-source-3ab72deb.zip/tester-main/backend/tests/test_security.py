"""Tests for the encryption/decryption security module."""
from app.core.security import encrypt_token, decrypt_token, _get_fernet


class TestGetFernet:
    """Test Fernet key derivation."""

    def test_returns_fernet_instance(self):
        f = _get_fernet()
        # Should return a Fernet object capable of encrypt/decrypt
        assert hasattr(f, "encrypt")
        assert hasattr(f, "decrypt")

    def test_deterministic(self):
        """Same settings.ENCRYPTION_KEY should produce same Fernet key."""
        f1 = _get_fernet()
        f2 = _get_fernet()
        # Encrypt with one, decrypt with other
        ct = f1.encrypt(b"test")
        assert f2.decrypt(ct) == b"test"


class TestEncryptToken:
    """Test token encryption."""

    def test_encrypt_returns_string(self):
        result = encrypt_token("my-secret-token")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_encrypt_empty_returns_empty(self):
        assert encrypt_token("") == ""

    def test_encrypt_produces_different_ciphertexts(self):
        """Fernet uses random IV, so two encryptions differ."""
        ct1 = encrypt_token("same-value")
        ct2 = encrypt_token("same-value")
        # Fernet adds a timestamp + random IV so ciphertexts should differ
        assert ct1 != ct2


class TestDecryptToken:
    """Test token decryption."""

    def test_decrypt_roundtrip(self):
        original = "super-secret-123"
        encrypted = encrypt_token(original)
        decrypted = decrypt_token(encrypted)
        assert decrypted == original

    def test_decrypt_empty_returns_empty(self):
        assert decrypt_token("") == ""

    def test_decrypt_invalid_returns_plaintext_fallback(self):
        """If decryption fails (e.g. plaintext stored before encryption was added),
        the function should return the input unchanged."""
        plaintext = "not-encrypted-at-all"
        result = decrypt_token(plaintext)
        assert result == plaintext

    def test_decrypt_fernet_cipher_with_wrong_key_returns_empty(self):
        """Unreadable encrypted payloads should not be used as tokens."""
        invalid_cipher = "gAAAAABk-invalid-ciphertext"
        assert decrypt_token(invalid_cipher) == ""

    def test_decrypt_unicode_roundtrip(self):
        original = "tökën-with-ünïcödé"
        encrypted = encrypt_token(original)
        assert decrypt_token(encrypted) == original
