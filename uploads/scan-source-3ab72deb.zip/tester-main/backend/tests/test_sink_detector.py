"""Tests for the sink detector."""
import os
import tempfile
import pytest
from app.analyzers.sink_detector import SinkDetector


class TestSinkDetector:
    """Test dangerous sink pattern detection."""

    def setup_method(self):
        self.detector = SinkDetector()

    def _write_temp_py(self, content: str) -> str:
        """Write a temp Python file and return its parent directory."""
        tmpdir = tempfile.mkdtemp()
        filepath = os.path.join(tmpdir, "test_app.py")
        with open(filepath, "w") as f:
            f.write(content)
        return tmpdir

    @pytest.mark.asyncio
    async def test_detect_sql_injection_fstring(self):
        code = '''
import sqlite3
conn = sqlite3.connect("db.sqlite")
cursor = conn.cursor()

def get_user(uid):
    cursor.execute(f"SELECT * FROM users WHERE id={uid}")
    return cursor.fetchone()
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        sql_sinks = [s for s in sinks if s["type"] == "sql_injection"]
        assert len(sql_sinks) >= 1
        assert sql_sinks[0]["cwe"] == "CWE-89"
        assert sql_sinks[0]["severity"] == "critical"

    @pytest.mark.asyncio
    async def test_detect_sql_injection_format_string(self):
        code = '''
def get_user(uid):
    cursor.execute("SELECT * FROM users WHERE id=%s" % uid)
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        sql_sinks = [s for s in sinks if s["type"] == "sql_injection"]
        assert len(sql_sinks) >= 1

    @pytest.mark.asyncio
    async def test_detect_command_injection(self):
        code = '''
import os

def run_cmd(user_input):
    os.system(user_input)
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        cmd_sinks = [s for s in sinks if s["type"] == "command_injection"]
        assert len(cmd_sinks) >= 1
        assert cmd_sinks[0]["cwe"] == "CWE-78"

    @pytest.mark.asyncio
    async def test_detect_xss_render_template_string(self):
        code = '''
from flask import render_template_string

def search(query):
    return render_template_string(query)
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        xss_sinks = [s for s in sinks if s["type"] == "xss"]
        assert len(xss_sinks) >= 1

    @pytest.mark.asyncio
    async def test_detect_deserialization(self):
        code = '''
import pickle

def load_data(data):
    return pickle.loads(data)
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        deser_sinks = [s for s in sinks if s["type"] == "deserialization"]
        assert len(deser_sinks) >= 1
        assert deser_sinks[0]["cwe"] == "CWE-502"

    @pytest.mark.asyncio
    async def test_detect_path_traversal(self):
        code = '''
def read_file(filename):
    with open(filename) as f:
        return f.read()
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        pt_sinks = [s for s in sinks if s["type"] == "path_traversal"]
        assert len(pt_sinks) >= 1

    @pytest.mark.asyncio
    async def test_detect_ssrf(self):
        code = '''
import requests

def fetch_url(url):
    return requests.get(url)
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        ssrf_sinks = [s for s in sinks if s["type"] == "ssrf"]
        assert len(ssrf_sinks) >= 1

    @pytest.mark.asyncio
    async def test_skip_comments(self):
        code = '''
# cursor.execute(f"SELECT * FROM users WHERE id={uid}")
'''
        tmpdir = self._write_temp_py(code)
        sinks = await self.detector.detect_sinks(tmpdir)
        assert len(sinks) == 0

    @pytest.mark.asyncio
    async def test_empty_directory(self):
        tmpdir = tempfile.mkdtemp()
        sinks = await self.detector.detect_sinks(tmpdir)
        assert sinks == []

    @pytest.mark.asyncio
    async def test_nonexistent_path(self):
        sinks = await self.detector.detect_sinks("/nonexistent/path")
        assert sinks == []

    def test_payload_suggestions_sqli(self):
        sink = {"type": "sql_injection"}
        payloads = self.detector.get_payload_suggestions(sink)
        assert len(payloads) > 0
        assert any("OR" in p for p in payloads)

    def test_payload_suggestions_unknown_type(self):
        sink = {"type": "unknown_vuln"}
        payloads = self.detector.get_payload_suggestions(sink)
        assert payloads == []
