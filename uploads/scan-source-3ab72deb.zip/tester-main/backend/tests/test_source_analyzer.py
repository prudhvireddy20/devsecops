"""Tests for the source analyzer."""
import os
import tempfile
import pytest
from app.analyzers.source_analyzer import SourceAnalyzer


class TestSourceAnalyzer:
    """Test source code analysis and framework detection."""

    def setup_method(self):
        self.analyzer = SourceAnalyzer()

    def _create_project(self, files: dict[str, str]) -> str:
        """Create a temp project directory with given files."""
        tmpdir = tempfile.mkdtemp()
        for rel_path, content in files.items():
            full_path = os.path.join(tmpdir, rel_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w") as f:
                f.write(content)
        return tmpdir

    @pytest.mark.asyncio
    async def test_detect_flask(self):
        project = self._create_project({
            "app.py": """
from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return "Hello"
""",
            "requirements.txt": "flask==3.0.0\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "flask"

    @pytest.mark.asyncio
    async def test_detect_django(self):
        project = self._create_project({
            "settings.py": """
INSTALLED_APPS = [
    'django.contrib.admin',
]
""",
            "urls.py": """
from django.urls import path
urlpatterns = [
    path('admin/', admin.site.urls),
]
""",
            "requirements.txt": "django==5.0.0\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "django"

    @pytest.mark.asyncio
    async def test_detect_fastapi(self):
        project = self._create_project({
            "main.py": """
from fastapi import FastAPI
app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello"}
""",
            "requirements.txt": "fastapi==0.109.0\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "fastapi"

    @pytest.mark.asyncio
    async def test_detect_unknown_framework(self):
        project = self._create_project({
            "script.py": "print('hello world')\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "unknown"

    @pytest.mark.asyncio
    async def test_detect_nonexistent_path(self):
        framework = await self.analyzer.detect_framework("/nonexistent/path/123")
        assert framework == "unknown"

    @pytest.mark.asyncio
    async def test_parse_file_with_ast(self):
        project = self._create_project({
            "app.py": """
import os
from pathlib import Path

class UserService:
    def get_user(self, user_id):
        return {"id": user_id}

    async def create_user(self, name):
        return {"name": name}

def helper():
    pass
""",
        })
        result = await self.analyzer.parse_file(os.path.join(project, "app.py"))
        assert result is not None
        assert len(result["imports"]) >= 2
        assert len(result["classes"]) >= 1
        assert len(result["functions"]) >= 3  # get_user, create_user, helper
        assert any(f["name"] == "helper" for f in result["functions"])

    @pytest.mark.asyncio
    async def test_parse_nonexistent_file(self):
        result = await self.analyzer.parse_file("/nonexistent/file.py")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_all_python_files(self):
        project = self._create_project({
            "app.py": "",
            "utils.py": "",
            "lib/helper.py": "",
            "__pycache__/cached.py": "",
            ".git/hooks/pre-commit.py": "",
        })
        files = await self.analyzer.get_all_python_files(project)
        filenames = [os.path.basename(f) for f in files]
        assert "app.py" in filenames
        assert "utils.py" in filenames
        assert "helper.py" in filenames
        # Excluded dirs
        assert "cached.py" not in filenames
        assert "pre-commit.py" not in filenames

    @pytest.mark.asyncio
    async def test_requirements_txt_boosts_framework(self):
        """requirements.txt match gives +5 score, should dominate over minimal code indicators."""
        project = self._create_project({
            "app.py": "print('hello')\n",
            "requirements.txt": "django==5.0.0\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "django"

    @pytest.mark.asyncio
    async def test_parse_file_syntax_error(self):
        """A Python file with a syntax error should still return a result (empty containers)."""
        project = self._create_project({
            "bad.py": "def broken(\n",
        })
        result = await self.analyzer.parse_file(os.path.join(project, "bad.py"))
        assert result is not None
        assert result["functions"] == []

    @pytest.mark.asyncio
    async def test_parse_file_with_decorators(self):
        """Decorators should be detected by the AST parser."""
        project = self._create_project({
            "views.py": """
from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return "hello"

@app.route("/users", methods=["GET", "POST"])
def users():
    return "users"
""",
        })
        result = await self.analyzer.parse_file(os.path.join(project, "views.py"))
        assert result is not None
        assert len(result["functions"]) >= 2
        func_names = [f["name"] for f in result["functions"]]
        assert "index" in func_names
        assert "users" in func_names

    @pytest.mark.asyncio
    async def test_parse_file_with_imports(self):
        """Both import and from...import styles should be detected."""
        project = self._create_project({
            "imports.py": """
import os
import sys
from pathlib import Path
from typing import Optional, List
""",
        })
        result = await self.analyzer.parse_file(os.path.join(project, "imports.py"))
        assert result is not None
        assert len(result["imports"]) >= 4

    @pytest.mark.asyncio
    async def test_parse_file_async_functions(self):
        """Async functions should be detected."""
        project = self._create_project({
            "async_code.py": """
async def fetch_data():
    pass

async def process_data():
    pass

def sync_func():
    pass
""",
        })
        result = await self.analyzer.parse_file(os.path.join(project, "async_code.py"))
        assert result is not None
        func_names = [f["name"] for f in result["functions"]]
        assert "fetch_data" in func_names
        assert "process_data" in func_names
        assert "sync_func" in func_names

    @pytest.mark.asyncio
    async def test_detect_framework_pipfile(self):
        """Pipfile should also boost framework detection."""
        project = self._create_project({
            "app.py": "print('hello')\n",
            "Pipfile": "[packages]\nflask = \"*\"\n",
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "flask"

    @pytest.mark.asyncio
    async def test_detect_framework_pyproject_toml(self):
        """pyproject.toml should also boost framework detection."""
        project = self._create_project({
            "app.py": "print('hello')\n",
            "pyproject.toml": '[tool.poetry.dependencies]\nfastapi = "^0.100.0"\n',
        })
        framework = await self.analyzer.detect_framework(project)
        assert framework == "fastapi"

    @pytest.mark.asyncio
    async def test_get_all_python_files_skips_venv(self):
        """Virtual environment dirs should be skipped."""
        project = self._create_project({
            "app.py": "",
            "venv/lib/site.py": "",
            ".venv/lib/site.py": "",
        })
        files = await self.analyzer.get_all_python_files(project)
        filenames = [os.path.basename(f) for f in files]
        assert "app.py" in filenames
        # venv files should be excluded
        assert filenames.count("site.py") == 0

    @pytest.mark.asyncio
    async def test_get_all_python_files_skips_migrations(self):
        """Migration dirs should be skipped."""
        project = self._create_project({
            "app.py": "",
            "migrations/0001_initial.py": "",
        })
        files = await self.analyzer.get_all_python_files(project)
        filenames = [os.path.basename(f) for f in files]
        assert "app.py" in filenames
        assert "0001_initial.py" not in filenames

    @pytest.mark.asyncio
    async def test_detect_framework_unreadable_file(self):
        """Files that fail to read should be skipped without crashing."""
        project = self._create_project({
            "app.py": "from flask import Flask\napp = Flask(__name__)\n",
            "requirements.txt": "flask==3.0.0\n",
        })
        # Create an unreadable file (directory named .py — can't be read as text)
        unreadable = os.path.join(project, "bad_dir.py")
        os.makedirs(unreadable)
        framework = await self.analyzer.detect_framework(project)
        assert framework == "flask"
