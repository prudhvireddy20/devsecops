"""Tests for TrustScan Platform HTTP client."""
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, patch, MagicMock
import httpx

from app.integrations.trustscan_client import TrustScanClient


class TestTrustScanClientValidateToken:
    """Test token validation."""

    @pytest.mark.asyncio
    async def test_validate_token_success(self):
        """Successfully validate a valid token."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)

        # httpx response methods (raise_for_status, json) are synchronous — use MagicMock
        with patch("httpx.AsyncClient.get", new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "owner_id": "gh:12345",
                "email": "user@example.com",
            }
            mock_get.return_value = mock_response

            result = await client.validate_token()
            assert result["owner_id"] == "gh:12345"
            assert result["email"] == "user@example.com"

        await client.close()

    @pytest.mark.asyncio
    async def test_validate_token_invalid(self):
        """Raise on invalid token (401)."""
        client = TrustScanClient("http://localhost:8085", "dsp_invalid", timeout=10)

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
                "Unauthorized", request=MagicMock(), response=mock_response
            )
            mock_get.return_value = mock_response

            with pytest.raises(httpx.HTTPStatusError):
                await client.validate_token()

        await client.close()


class TestTrustScanClientListJobs:
    """Test listing scan jobs."""

    @pytest.mark.asyncio
    async def test_list_jobs_success(self):
        """Successfully list jobs from TrustScan."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "jobs": [
                    {
                        "id": "job-1",
                        "status": "completed",
                        "repo_url": "https://github.com/user/repo",
                        "created_at": "2025-06-26T10:00:00",
                    },
                    {
                        "id": "job-2",
                        "status": "running",
                        "repo_url": "https://github.com/user/repo2",
                        "created_at": "2025-06-26T10:05:00",
                    },
                ]
            }
            mock_get.return_value = mock_response

            jobs = await client.list_jobs(limit=50)
            assert len(jobs) == 2
            assert jobs[0]["id"] == "job-1"
            assert jobs[1]["status"] == "running"

        await client.close()

    @pytest.mark.asyncio
    async def test_list_jobs_error(self):
        """Return empty list on error."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)

        with patch("httpx.AsyncClient.get") as mock_get:
            mock_get.side_effect = Exception("Connection failed")

            jobs = await client.list_jobs()
            assert jobs == []

        await client.close()


class TestTrustScanClientGetJob:
    """Test fetching a single job."""

    @pytest.mark.asyncio
    async def test_get_job_success(self):
        """Successfully fetch a job by ID."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "id": "job-1",
                "status": "completed",
                "repo_url": "https://github.com/user/repo",
            }
            mock_get.return_value = mock_response

            job = await client.get_job("job-1")
            assert job["id"] == "job-1"
            assert job["status"] == "completed"

        await client.close()

    @pytest.mark.asyncio
    async def test_get_job_not_found(self):
        """Return None when job not found."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)

        with patch("httpx.AsyncClient.get") as mock_get:
            mock_get.side_effect = Exception("Not found")

            job = await client.get_job("nonexistent")
            assert job is None

        await client.close()


class TestTrustScanClientTransformFindings:
    """Test NormalizedFinding format transformation."""

    def test_transform_empty_findings(self):
        """Transform empty findings list."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)
        job = {"id": "job-1", "repo_url": "https://github.com/user/repo"}
        raw_results = {"findings": []}

        result = client._transform_findings(job, raw_results)
        assert result["traceon_version"] == "1.0"
        assert result["findings"] == []
        assert result["scan_metadata"]["job_id"] == "job-1"

    def test_transform_single_finding(self):
        """Transform a single TrustScan finding."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)
        job = {"id": "job-1", "repo_url": "https://github.com/user/repo"}
        raw_results = {
            "tools": [{"type": "SAST"}],
            "findings": [
                {
                    "id": "finding-1",
                    "title": "SQL Injection",
                    "location": {
                        "file": "app.py",
                        "line_start": 42,
                    },
                    "severity": {
                        "normalized": "HIGH",
                    },
                    "confidence": {
                        "normalized": "VERIFIED",
                    },
                    "identifiers": {
                        "cwe": [89],
                    },
                    "evidence": {
                        "description": "SQL injection in query parameter",
                        "code_snippet": "query = f\"SELECT * FROM users WHERE id = {user_id}\"",
                    },
                    "endpoint": "/api/users",
                    "parameter": "id",
                    "rule_id": "rule-sqli-001",
                }
            ],
        }

        result = client._transform_findings(job, raw_results)
        assert result["traceon_version"] == "1.0"
        assert len(result["findings"]) == 1

        finding = result["findings"][0]
        assert finding["id"] == "finding-1"
        assert finding["title"] == "SQL Injection"
        assert finding["severity"] == "high"
        assert finding["confidence"] == "verified"
        assert finding["cwe"] == "CWE-89"
        assert finding["location"]["file_path"] == "app.py"
        assert finding["location"]["line_number"] == 42
        assert finding["endpoint"] == "/api/users"

    def test_transform_finding_with_string_cwe(self):
        """Handle CWE as string instead of list."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)
        job = {"id": "job-1", "repo_url": ""}
        raw_results = {
            "findings": [
                {
                    "id": "f1",
                    "title": "XSS",
                    "location": {"file": "index.html", "line_start": 10},
                    "severity": {"normalized": "MEDIUM"},
                    "confidence": {"normalized": "PROBABLE"},
                    "identifiers": {"cwe": "79"},
                    "evidence": {"description": "Reflected XSS"},
                }
            ],
        }

        result = client._transform_findings(job, raw_results)
        finding = result["findings"][0]
        assert finding["cwe"] == "CWE-79"

    def test_transform_finding_with_cwe_prefix(self):
        """Handle CWE that already has CWE- prefix."""
        client = TrustScanClient("http://localhost:8085", "dsp_test123", timeout=10)
        job = {"id": "job-1", "repo_url": ""}
        raw_results = {
            "findings": [
                {
                    "id": "f1",
                    "title": "Path Traversal",
                    "location": {"file": "file.py", "line_start": 5},
                    "severity": {"normalized": "MEDIUM"},
                    "confidence": {"normalized": "OBSERVED"},
                    "identifiers": {"cwe": "CWE-22"},
                    "evidence": {"description": "Path traversal vulnerability"},
                }
            ],
        }

        result = client._transform_findings(job, raw_results)
        finding = result["findings"][0]
        assert finding["cwe"] == "CWE-22"  # Should not double-prefix


class TestTrustScanClientInferVulnerabilityType:
    """Test vulnerability type inference from scanner type."""

    def test_infer_type_sast(self):
        """SAST maps to unknown (needs more specific analysis)."""
        result = TrustScanClient._infer_vulnerability_type("SAST")
        assert result == "unknown"

    def test_infer_type_sca(self):
        """SCA maps to dependency_cve."""
        result = TrustScanClient._infer_vulnerability_type("SCA")
        assert result == "dependency_cve"

    def test_infer_type_secret(self):
        """SECRET maps to secret."""
        result = TrustScanClient._infer_vulnerability_type("SECRET")
        assert result == "secret"

    def test_infer_type_sbom(self):
        """SBOM maps to dependency_cve."""
        result = TrustScanClient._infer_vulnerability_type("SBOM")
        assert result == "dependency_cve"

    def test_infer_type_unknown(self):
        """Unknown type maps to unknown."""
        result = TrustScanClient._infer_vulnerability_type("UNKNOWN_TYPE")
        assert result == "unknown"

    def test_infer_type_case_insensitive(self):
        """Tool type matching is case-insensitive."""
        assert TrustScanClient._infer_vulnerability_type("sast") == "unknown"
        assert TrustScanClient._infer_vulnerability_type("Sca") == "dependency_cve"
        assert TrustScanClient._infer_vulnerability_type("SECRET") == "secret"
