"""Tests for outbound URL safety validation."""

from app.core.url_safety import validate_external_target_url


def test_validate_external_target_url_allows_public_http_host():
    ok, err = validate_external_target_url("http://example.com")
    assert ok is True
    assert err == ""


def test_validate_external_target_url_rejects_unsupported_scheme():
    ok, err = validate_external_target_url("file:///etc/passwd")
    assert ok is False
    assert "http:// and https://" in err


def test_validate_external_target_url_allows_loopback_ip_with_port():
    ok, err = validate_external_target_url("http://127.0.0.1:8000")
    assert ok is True
    assert err == ""


def test_validate_external_target_url_rejects_cloud_metadata_ip():
    ok, err = validate_external_target_url("http://169.254.169.254/latest/meta-data")
    assert ok is False
    assert "not allowed" in err


def test_validate_external_target_url_allows_localhost_hostname():
    ok, err = validate_external_target_url("http://localhost:8080")
    assert ok is True
    assert err == ""
