"""Tests for websocket scan log persistence robustness."""

import asyncio
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from sqlalchemy.exc import OperationalError

from app.api.websocket import (
    ConnectionManager,
    _SQLITE_LOCK_RETRIES,
    _LOG_FLUSH_INTERVAL_SECONDS,
)


class _FakeResult:
    def __init__(self, scan_obj):
        self._scan_obj = scan_obj

    def scalar_one_or_none(self):
        return self._scan_obj


class _FakeSession:
    def __init__(self, store: dict, fail_commit: bool):
        self._store = store
        self._fail_commit = fail_commit
        self._scan = None
        self.commit_calls = 0

    async def execute(self, _query):
        self._scan = SimpleNamespace(log=self._store["log"])
        return _FakeResult(self._scan)

    async def commit(self):
        self.commit_calls += 1
        if self._fail_commit:
            raise OperationalError("UPDATE scans", {}, Exception("database is locked"))
        self._store["log"] = self._scan.log


class _SessionContext:
    def __init__(self, session):
        self._session = session

    async def __aenter__(self):
        return self._session

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _SessionFactory:
    def __init__(self, sessions):
        self._sessions = sessions
        self.calls = 0

    def __call__(self):
        session = self._sessions[self.calls]
        self.calls += 1
        return _SessionContext(session)


@pytest.mark.asyncio
async def test_persist_scan_log_lines_retries_and_succeeds_on_sqlite_lock():
    store = {"log": "first"}
    sessions = [
        _FakeSession(store, fail_commit=True),
        _FakeSession(store, fail_commit=True),
        _FakeSession(store, fail_commit=False),
    ]
    factory = _SessionFactory(sessions)

    manager = ConnectionManager()
    with patch("app.api.websocket.async_session_factory", factory):
        ok = await manager._persist_scan_log_lines("scan-1", ["second"])

    assert ok is True
    assert store["log"] == "first\nsecond"
    assert factory.calls == 3


@pytest.mark.asyncio
async def test_persist_scan_log_lines_stops_after_retry_budget_without_warning():
    store = {"log": ""}
    sessions = [_FakeSession(store, fail_commit=True) for _ in range(_SQLITE_LOCK_RETRIES)]
    factory = _SessionFactory(sessions)

    manager = ConnectionManager()
    with patch("app.api.websocket.async_session_factory", factory), patch(
        "app.api.websocket.logger.warning"
    ) as warn_mock:
        ok = await manager._persist_scan_log_lines("scan-1", ["line"])

    assert ok is False
    assert factory.calls == _SQLITE_LOCK_RETRIES
    warn_mock.assert_not_called()


@pytest.mark.asyncio
async def test_send_scan_log_buffers_and_flushes_batched_lines():
    store = {"log": "seed"}
    sessions = [_FakeSession(store, fail_commit=False)]
    factory = _SessionFactory(sessions)

    manager = ConnectionManager()
    with patch("app.api.websocket.async_session_factory", factory):
        await manager.send_scan_log("scan-1", "line-a")
        await manager.send_scan_log("scan-1", "line-b")
        await asyncio.sleep(_LOG_FLUSH_INTERVAL_SECONDS + 0.2)

    assert store["log"] == "seed\nline-a\nline-b"
    assert factory.calls == 1
