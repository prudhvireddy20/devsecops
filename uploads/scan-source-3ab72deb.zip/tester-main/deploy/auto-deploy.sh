#!/usr/bin/env bash
set -euo pipefail

# Auto-deploy script called by GitHub Actions
# Pulls latest code, rebuilds, and restarts containers

REPO_DIR="/home/anish/tester"
cd "$REPO_DIR"

echo "[deploy] Pulling latest code from main..."
git pull origin main

echo "[deploy] Rebuilding Docker image..."
sg docker -c "
  docker compose build --build-arg INCLUDE_SEMGREP=true --build-arg INCLUDE_PLAYWRIGHT=true
"

echo "[deploy] Restarting containers..."
sg docker -c "docker compose up -d"

echo "[deploy] Verifying health..."
sleep 5
HEALTH=$(curl -sf http://localhost:8000/api/health || echo "FAIL")
if [ "$HEALTH" = "FAIL" ]; then
  echo "[deploy] ERROR: Health check failed!"
  sg docker -c "docker compose logs --tail=20 backend"
  exit 1
fi
echo "[deploy] OK — $HEALTH"
