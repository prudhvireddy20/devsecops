# TraceON — Complete Technical Explanation

This document explains every major component of the TraceON security scanner: how it starts, how it scans, how every tool works, how SQL injection and XSS are found, how payloads are generated, how the LLM assists, how TrustScan OAuth works, and why every piece exists.

---

## Table of Contents

1. [What TraceON Is](#1-what-traceon-is)
2. [System Architecture & Request Flow](#2-system-architecture--request-flow)
3. [Database — Models & Migrations](#3-database--models--migrations)
4. [Authentication System](#4-authentication-system)
5. [Project Creation & Source Ingestion](#5-project-creation--source-ingestion)
6. [TrustScan OAuth Integration](#6-trustscan-oauth-integration)
7. [External Findings Upload](#7-external-findings-upload)
8. [Scan Pipeline — Phase-by-Phase](#8-scan-pipeline--phase-by-phase)
9. [Whitebox Mode — How SAST Import + DAST Works](#9-whitebox-mode--how-sast-import--dast-works)
10. [Blackbox Mode — How Pure DAST Works](#10-blackbox-mode--how-pure-dast-works)
11. [ZAP — The Core DAST Engine](#11-zap--the-core-dast-engine)
12. [Nuclei — CVE & Template Scanning](#12-nuclei--cve--template-scanning)
13. [SQLMap — How SQL Injection Is Found](#13-sqlmap--how-sql-injection-is-found)
14. [Dalfox — How XSS Is Found](#14-dalfox--how-xss-is-found)
15. [Wapiti — XXE, LDAP, CRLF & More](#15-wapiti--xxe-ldap-crlf--more)
16. [Nikto — Server Configuration Audit](#16-nikto--server-configuration-audit)
17. [ffuf — Fast Path Fuzzing](#17-ffuf--fast-path-fuzzing)
18. [feroxbuster — Recursive Directory Discovery](#18-feroxbuster--recursive-directory-discovery)
19. [testssl.sh — Deep TLS Audit](#19-testsslsh--deep-tls-audit)
20. [Why Every Tool Is Needed (No Overlap)](#20-why-every-tool-is-needed-no-overlap)
21. [LLM Orchestration — End to End](#21-llm-orchestration--end-to-end)
22. [Correlation Engine — Verified vs Probable vs Observed](#22-correlation-engine--verified-vs-probable-vs-observed)
23. [Auth Automation — Browser Login & Role Profiles](#23-auth-automation--browser-login--role-profiles)
24. [Journey Replay — Postman / OpenAPI / HAR](#24-journey-replay--postman--openapi--har)
25. [Frontend Architecture](#25-frontend-architecture)
26. [Security Measures in TraceON Itself](#26-security-measures-in-traceon-itself)
27. [Key File Map](#27-key-file-map)

---

## Recent Code Changes (June 2026)

### Bug fixes applied in this session
| Commit | What was fixed |
|--------|---------------|
| `36c0ac3` | Scan failure at 87% in dast_extended phase — wapiti engine was calling `.get()` on dict keys instead of iterating `{"Category": [vuln_list]}` format; `_run_wapiti/sqlmap/dalfox` had no try/except so any error killed the scan; `_enrich_sast_with_routes()` was referenced but never defined (would crash correlation) |
| `19de238` | File descriptor leak — `open(tmpfile).read()` without context manager in dalfox and testssl; fixed with `Path.read_text()`; dalfox tmpfile cleanup moved to outer finally block so it runs even on TimeoutError; sqlmap WARNING-level heuristic detection added (medium severity findings) |
| `03aa4fc` | Removed hybrid mode — only two modes now: whitebox (JSON import + DAST) and blackbox (pure DAST); orchestrator whitebox branch no longer runs source_analysis; scans.py auto-detection now sets "whitebox" when external findings JSON exists |
| `013d4a3` | Purged all stale source_available / source_analysis remnants — deleted dead `_run_source_analysis()` method; removed source_analysis from PHASES list; removed source_available from Pydantic API models, TypeScript interfaces, and to_dict() responses; removed TrustScan source ZIP download block; simplified ScanProgress.tsx to single PHASE_ORDER (no source mode branching) |
| `2f8bd36` | Fixed tests to match current behaviour — removed mocks of non-existent methods (_run_sast_safe, _run_secret_scan_safe, _run_dependency_scan_safe); updated dast_engine test to accept contextid kwarg in ZAP scan call; fixed test_scan_defaults to check dast key instead of missing sast key |
| `c0a80c6` | SAST-guided DAST — importing moved to position 1 in whitebox pipeline (was already first, confirmed correct); importing removed from blackbox entirely (blackbox = pure DAST, nothing to import); added `attack_surface` phase (28%) that classifies all endpoints into critical/high/medium/low tiers by URL patterns; `_extract_sast_guidance()` seeds ZAP routes and builds sqli/xss target lists from every imported SAST finding; sqlmap and dalfox now run targeted scans on SAST-flagged endpoints in addition to the base URL; both tools also fire in whitebox mode when SAST identified specific targets |

### Architecture decisions confirmed
- **Source code is never uploaded or read by TraceON.** The pipeline uses imported SAST JSON output (from TrustScan/Semgrep/SARIF) as the "static" half of the SAST+DAST correlation.
- **"Hybrid" mode was a mistake.** It has been deleted. There are now exactly two modes: whitebox (has SAST JSON) and blackbox (pure DAST).
- **source_available flag is always False.** The DB column is kept for schema backward-compatibility but plays no role in pipeline routing.
- **Blackbox has no importing phase.** If you have SAST findings, the scan is whitebox by definition. Importing in blackbox was logically incorrect and has been removed.
- **SAST findings guide DAST tools, not just correlation.** Importing runs first so that SAST-flagged endpoints are seeded into ZAP before spidering, and sqlmap/dalfox receive specific targets from SAST instead of blindly fuzzing everything.

---

## 1. What TraceON Is

TraceON is an automated security scanner that combines **imported SAST findings** (from TrustScan or any SAST tool via JSON) with **dynamic application testing (DAST)** and ties them together using a **correlation engine** and an **LLM planner**. The goal is to give security teams a single tool that:

- Imports SAST findings from TrustScan, Semgrep, SARIF, Gitleaks, Trivy, Noir etc. (whitebox) or just hits a live URL (blackbox)
- Runs every relevant automated security scanner against the live target
- Correlates imported SAST findings with live DAST evidence to produce "verified" vulnerabilities (not just theoretical)
- Uses an LLM to adapt the scan mid-flight, generate attack chains, and summarize results in plain English

**Source code is not needed.** TraceON does not clone or read source code. Instead it imports the structured output (JSON) of SAST tools that have already analysed the code, then validates those findings dynamically.

The production instance runs at `https://dtest.sc.deeptrustxai.com`. It integrates with a companion SAST platform called **TrustScan** at `https://trustscan.sc.deeptrustxai.com`.

---

## 2. System Architecture & Request Flow

```
Browser / API client
      │
      ▼  HTTP + WebSocket
FastAPI (port 8000)
  ├── Serves React SPA (static files from /app/static)
  ├── REST API  /api/v1/*
  │     ├── projects.py  — project CRUD, file upload, artifact management
  │     ├── scans.py     — scan creation, config normalisation
  │     ├── findings.py  — finding list / detail
  │     ├── reports.py   — report export
  │     ├── llm.py       — LLM provider config UI
  │     └── users.py     — user management
  ├── WebSocket  /ws/scan/{id}   — real-time scan log stream
  └── WebSocket  /ws/dashboard   — live dashboard updates
        │
        ▼
  ScanOrchestrator (background asyncio task)
        │
        ├── ExternalFindingImporter   (Semgrep, SARIF, Noir, TrustScan, Gitleaks, Trivy…)
        ├── ZAP  (port 8080 via python-owasp-zap-v2.4)
        ├── Nuclei, sqlmap, dalfox, wapiti, nikto, ffuf, feroxbuster, testssl
        ├── LLM Planner  (Anthropic / OpenAI / Google / OpenRouter)
        └── CorrelationEngine  (SAST ↔ DAST matching)
              │
              ▼
        SQLite / PostgreSQL  (SQLAlchemy async)
```

**How FastAPI starts** (`backend/app/main.py` lifespan, lines 190–212):

1. All SQLAlchemy models are imported so table definitions are discovered.
2. `init_db()` creates all tables if they don't exist.
3. `run_migrations()` adds any new columns (no Alembic — see §3).
4. `_seed_admin_user()` creates the admin user record from the `API_KEY` env var.
5. Any scans that were `running` when the process last crashed are recovered.
6. A scan-queue worker and a rate-limiter background task start.

**React SPA serving**: The built `dist/` folder is copied into `/app/static`. FastAPI mounts it and catches every unmatched path with a fallback to `index.html`, enabling client-side routing. For local deployments, the server injects `window.__DT_API_KEY__` into the HTML so the frontend can make authenticated requests without the user having to type their API key.

**Security headers middleware** adds `Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, and HSTS (only on non-localhost).

**Rate limiting middleware** limits requests per client IP, skips health-check endpoints and local/private network clients, returns HTTP 429 if exceeded.

---

## 3. Database — Models & Migrations

**Engine**: SQLAlchemy async with SQLite (default) or PostgreSQL (production). SQLite is configured with WAL journal mode, SYNCHRONOUS=NORMAL, and 5000ms busy timeout for concurrent access.

**No Alembic**: There is no migration framework. New columns are added to the `_SQLITE_COLUMN_MIGRATIONS` dict in `backend/app/core/database.py`. At startup, `run_migrations()` loops through the dict and runs `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` for any column that doesn't exist yet. Column and table names are validated against an allowlist before being used in SQL to prevent injection.

**Core Models**:

### Project
Stores everything about a target application. Key fields:
- `scan_mode`: "whitebox" or "blackbox" — controls what phases run
- `target_url`: the live URL to scan with DAST tools
- `github_token_encrypted`, `trustscan_token_encrypted`, `llm_api_key_encrypted`: all sensitive tokens are encrypted with Fernet AES-256 before storage (never plaintext in the DB)
- `external_findings_path`: path to an uploaded SAST findings JSON file
- `auth_config`: JSON dict describing how to log into the app (type, credentials, roles)
- `openapi_spec_files`, `postman_collection_files`, `journey_replay_files`: comma-separated paths to uploaded API specs
- `source_type`, `source_path`, `local_path`: legacy fields kept in schema for backward compatibility; source code is not used in the pipeline

### Scan
Each scan run is one Scan record. Key fields:
- `status`: pending → running → completed / failed / cancelled
- `progress`: 0–100 integer updated at each phase
- `current_phase`: name of the phase currently executing
- `modules_enabled`: JSON dict toggling which scanners run (`dast`, `nuclei`, `wapiti`, `sqlmap`, `dalfox`, etc.)
- `scan_config`: JSON dict with depth, timeout, ZAP settings, LLM settings, file paths — the "runtime configuration" for the scan
- `results_summary`: finding counts by severity and confidence level
- `plan_result`: output of the pre-scan LLM planner (focus areas, risk hypothesis)
- `attack_chains`: LLM-generated attack chain narratives
- `llm_summary`: 60-word executive summary from LLM post-scan analysis
- `detected_stack`: what framework, language, database was fingerprinted

### Finding
Each vulnerability is one Finding record. Key fields:
- `vulnerability_type`: canonical type (sqli, xss, cmdi, ssrf, path_traversal, idor, auth, secret, dependency_cve, config, tls, etc.)
- `severity`: critical / high / medium / low / info
- `confidence`: **verified** (SAST + DAST matched) / **probable** (SAST only) / **observed** (DAST only)
- `file_path`, `line_number`, `code_snippet`: source code location (whitebox)
- `endpoint`, `http_method`, `parameter`: HTTP context
- `payload`: the actual exploit payload that was sent
- `response_evidence`: what came back from the server proving the vulnerability
- `scanner_source`: which tool found it (zap, sqlmap, dalfox, wapiti, nuclei, semgrep, trustscan, etc.)
- `auth_role`: which login role triggered the finding (for multi-role scans)
- `risk_score`: 0–100 numeric score used for prioritisation

---

## 4. Authentication System

Every API request must carry an `X-API-Key` header. The key is hashed with SHA-256 and compared against the `api_key_hash` column in the `users` table. The plaintext key is never stored. If the hash matches an active user, the request proceeds; if not, HTTP 403 is returned.

**Admin seeding**: When the `API_KEY` environment variable is set, TraceON creates an admin user on startup with that key's SHA-256 hash. This is how the initial administrator account is bootstrapped.

**WebSocket tokens**: Before opening a WebSocket connection for scan progress, the frontend calls `POST /api/v1/auth/ws-token` to get a one-time HMAC-SHA256 token. The token has:
- A 120-second TTL
- The scope (scan or dashboard) and scan_id embedded in a base64 payload
- An HMAC-SHA256 signature over that payload using the API_KEY
- A nonce to prevent replay attacks

The token is consumed on first use; the same token cannot open a second connection.

---

## 5. Project Creation & Source Ingestion

When a user creates a project via `POST /api/v1/projects`:

1. The target URL is validated (format check, SSRF protection).
2. Sensitive tokens (GitHub PAT, TrustScan token, LLM API key) are encrypted with Fernet before being stored.
3. A project directory is created at `PROJECTS_DIR/{project_id}`.
4. `scan_mode` is set: "whitebox" (if TrustScan or uploaded findings are connected) or "blackbox" (pure DAST).
5. `source_type`, `git_url`, `local_path` are stored as reference fields only — source code is not read or cloned; the pipeline does not use it.
6. A `ProjectResponse` is returned with the project ID.

**Artifact upload** (`POST /projects/{id}/artifacts`): Users can upload OpenAPI specs (`.json`/`.yaml`), Postman collections, or HAR journey files. Each is stored under `.traceon_artifacts/{kind}/` inside the project source directory. The artifact is also parsed into `WorkflowGraph` + `WorkflowStep` records so the correlation engine can map DAST findings to specific user journeys.

**ZIP security**: Zip-slip attacks are prevented by resolving each extracted path and verifying it stays within the destination directory before writing.

---

## 6. TrustScan OAuth Integration

TrustScan is a separate SAST platform. TraceON lets users import TrustScan findings via OAuth before even creating a project. The flow is:

```
User clicks "Connect TrustScan"
       │
       ▼
POST /trustscan/oauth/initiate
  → Generates random state UUID
  → Stores {status: "pending", expires_at: now+300s} in _OAUTH_STATES dict
  → Returns {state, authorize_url}
       │
       ▼
Frontend opens authorize_url in popup
  → URL: https://trustscan.sc.deeptrustxai.com/api/auth/traceon-authorize
         ?state={state}&redirect_uri={callback_url}
       │
       ▼  User clicks "Authorize" on TrustScan
GET /trustscan/oauth/callback?code={code}&state={state}
  → Validates state exists, not expired
  → POSTs to TrustScan: POST /api/auth/token {"code": code}
  → Receives PAT token
  → Stores {status: "completed", token: PAT, base_url} in _OAUTH_STATES
  → Returns HTML with close button (popup closes itself)
       │
       ▼
Frontend polls GET /trustscan/oauth/status/{state}
  → Returns {status: "completed", token, base_url} when done
       │
       ▼
Frontend calls GET /trustscan/oauth/jobs?state={state}
  → TrustScanClient.list_jobs() → GET {trustscan}/api/jobs?limit=50
  → Returns list of available scan jobs
       │
       ▼
User selects a job → creates project
POST /trustscan/projects/{project_id}/import
  → Decrypts trustscan_token
  → TrustScanClient.get_job(job_id)      → GET /api/jobs/{job_id}
  → TrustScanClient.get_findings(job_id) → GET /api/results/{job_id}
  → Parses findings via ExternalFindingImporter (format="trustscan")
  → Creates Scan + Finding records
  → Returns {scan_id, findings_imported}
```

**Token security**: The code-to-token exchange happens server-side. The frontend never sees the auth code or the PAT token directly — it only polls for a status result. This prevents the PAT from being exposed to JavaScript.

**Token storage**: The PAT is encrypted with Fernet and stored in `project.trustscan_token_encrypted`. During active scans, if `trustscan_job_id` and `trustscan_token_encrypted` are present, the orchestrator can also fetch live findings directly from TrustScan.

**TrustScan finding format**: TrustScan sends findings in a `NormalizedFinding v2.0.0` format. The `_transform_findings()` method in `trustscan_client.py` maps this to TraceON's internal schema:
- `severity.normalized` → severity
- `confidence.normalized` → confidence
- `identifiers.cwe` → CWE formatted as "CWE-###"
- `location.file`, `location.line_start` → file_path, line_number
- `evidence.code_snippet` → code_snippet
- `tool.type` → inferred vulnerability_type via keyword matching

---

## 7. External Findings Upload

Users can upload SAST scan results from any of 7 tools without using TrustScan OAuth. The file is uploaded via `POST /projects/{id}/upload-findings`.

**Auto-detection**: `ExternalFindingImporter.detect_format()` reads the JSON structure:
- `results[0].check_id` → **Semgrep**
- `Results[0].Vulnerabilities` → **Trivy** (dependency CVEs)
- `runs[].tool.driver` → **SARIF** (CodeQL, Bandit, etc.)
- `paths[]` array → **Noir** (API route discovery)
- `traceon_version` + `findings` → **TrustScan** normalized format
- `Description` / `RuleID` in array items → **Gitleaks** (secret detection)
- Anything else → **Generic** fallback

**What each parser extracts**:

| Format | Primary use | Key fields mapped |
|--------|-------------|-------------------|
| Semgrep | Python/JS/Go SAST | check_id, path, line, message, severity, metadata |
| SARIF | Universal SAST output | ruleId, level, location.uri, region.startLine |
| Gitleaks | Secret scanning | Description, File, StartLine, Secret → severity=high, cwe=CWE-798 |
| Trivy | Dependency CVEs | Target, Vulnerability.VulnerabilityID, InstalledVersion, FixedVersion |
| Noir | Route discovery | paths[].path, method, file → Finding type="route", used for route seeding |
| TrustScan | Normalized findings | Full field mapping (see §6) |
| Generic | Fallback | Tries common field names flexibly |

After parsing, the file is saved at `UPLOADS_DIR/{project_id}/external_findings.json` and the project record is updated. When a scan is created, `scans.py` copies this path into `scan_config["external_findings_path"]` so the orchestrator picks it up during the `importing` phase.

---

## 8. Scan Pipeline — Phase-by-Phase

When `POST /api/v1/scans` is called, a Scan record is created with `status="pending"` and a background asyncio task runs `ScanOrchestrator.run()`.

The pipeline is defined in the `PHASES` list at the top of `orchestrator.py`:

| # | Phase | Progress | Runs in |  What Happens |
|---|-------|----------|---------|---------------|
| 1 | importing | 8% | whitebox only | Load SAST findings from TrustScan API or uploaded JSON file **first**, so they guide everything that follows |
| 2 | path_fuzzing | 12% | blackbox only | ffuf + feroxbuster wordlist fuzzing to find hidden paths |
| 3 | server_audit | 16% | blackbox only | Nikto misconfig audit + testssl.sh TLS weaknesses |
| 4 | endpoint_discovery | 20% | both | GraphQL introspection, OpenAPI/Swagger probes, spec file loading |
| 5 | fingerprinting | 24% | both | HTTP header + body tech stack detection (framework, server, language) |
| 6 | attack_surface | 28% | both | Classify all discovered endpoints into critical/high/medium/low tiers; merge SAST targets into high-risk focus list |
| 7 | auth | 45% | both | Playwright browser login, REST API login, or token/cookie injection |
| 8 | spider | 55% | both | ZAP crawls the application; site tree pre-seeded with SAST-flagged endpoints |
| 9 | waf_detection | 60% | both | Probe for WAF presence, apply rate limiting if detected |
| 10 | active_scan | 75% | both | ZAP active scanner runs all attack rules |
| 11 | dast_extended | 85% | both* | Nuclei (CVEs), Wapiti (blackbox), SQLMap, Dalfox |
| 12 | correlation | 95% | both | SAST ↔ DAST matching, confidence assignment |
| 13 | complete | 100% | both | LLM synthesis, results summary, notifications |

\* SQLMap fires in whitebox only when SAST flagged SQLi targets; Dalfox fires in whitebox only when SAST flagged XSS targets; Wapiti is blackbox-only.

**Mode routing** — there are exactly two modes:

- **Whitebox**: Has SAST JSON findings (from TrustScan OAuth or uploaded file). Pipeline: **importing (8%) → endpoint_discovery → fingerprinting → attack_surface → DAST → correlation**. Importing runs FIRST so every SAST-flagged endpoint is seeded into ZAP's site tree before spidering, and sqlmap/dalfox receive specific high-confidence targets from SAST analysis.
- **Blackbox**: Pure DAST, no SAST JSON available. Pipeline: **path_fuzzing → server_audit → endpoint_discovery → fingerprinting → attack_surface → DAST → correlation**. No importing phase — if you have findings to import, the scan is whitebox by definition.

**Auto-detection** (`scans.py`): If no explicit `scan_mode` is provided, the system checks whether `UPLOADS_DIR/{project_id}/external_findings.json` exists. If so → whitebox; otherwise → blackbox.

**Phase updates**: `_update_phase(name, progress)` updates the Scan DB record, commits, and broadcasts a WebSocket message so the frontend progress bar updates in real time. It also calls `_check_cancel_requested()` which raises `CancelledError` if the user clicked Cancel.

---

## 9. Whitebox Mode — How SAST Import + DAST Works

In whitebox mode the `importing` phase runs **first** (8% progress) before any DAST tool touches the target. This ordering is intentional: SAST findings tell the DAST engine exactly where to look, making every subsequent phase smarter.

**What "whitebox" means in TraceON**: No source code is read. "Whitebox" means the scan has access to static analysis results (from TrustScan, Semgrep, SARIF etc.) that describe what vulnerabilities likely exist in the code. The DAST tools then try to confirm those findings against the live target.

**Importing phase** (`_import_external_findings()`): Checks two sources in order:
1. **TrustScan live pull** — if `project.trustscan_job_id` + `project.trustscan_token_encrypted` are set, calls `GET {trustscan}/api/results/{job_id}` and streams NormalizedFinding v2.0 results
2. **Uploaded JSON file** — reads `scan_config["external_findings_path"]` (set when user uploaded a file)

All findings pass through `ExternalFindingImporter` for format normalisation (§7).

**SAST guidance extraction** (`_extract_sast_guidance()`): Called for every single imported finding. Two actions per finding:

1. **Route seeding** — if the finding has a non-empty `endpoint` field (e.g. `/api/v1/users`), that path is added to `self.routes` so ZAP's site tree is seeded with it before the spider runs. This extends the existing Noir route seeding to ALL SAST formats (Semgrep, SARIF, TrustScan, etc.).
2. **Vulnerability targeting** — findings with `vulnerability_type == "sqli"` are added to `self.sast_sqli_targets` (full URLs). XSS findings go into `self.sast_xss_targets`. These lists are consumed by sqlmap and dalfox later in the pipeline.

After all findings are loaded, a summary is logged:
```
SAST flagged 3 SQLi endpoint(s) — sqlmap will target these
SAST flagged 2 XSS endpoint(s) — dalfox will target these
```

**Attack Surface Analysis phase** (28%, runs after fingerprinting in both modes): `_run_attack_surface_analysis()` classifies all routes in `self.routes` into four risk tiers using URL pattern matching:

| Tier | Patterns | Why |
|------|----------|-----|
| critical | /login, /signin, /auth, /oauth, /token, /password, /forgot, /reset, /api/key, /secret | Authentication bypass, credential theft |
| high | /admin, /manage, /dashboard, /upload, /graphql, /api/user, /api/account | Privilege escalation, file upload RCE |
| medium | /api/, /v1/, /v2/ | Business logic endpoints |
| low | /static, /assets, /css, /js, /health, /ping | Minimal attack value |

File upload endpoints (`/upload`, `/file`, `/attachment`, `/media`) are always promoted to at least `high` (potential RCE, especially on PHP targets). The result is stored in `self.attack_surface` and `self.high_risk_endpoints` (critical + high + SAST-flagged URLs merged). Future phases can use this list to prioritize scanning effort.

**How SAST guides sqlmap and dalfox**: After ZAP's active scan completes, both tools run targeted scans:
```
sqlmap → base target URL (blackbox always; whitebox only if sast_sqli_targets is non-empty)
sqlmap → SAST-flagged SQLi URL 1  ← specific endpoint SAST identified
sqlmap → SAST-flagged SQLi URL 2
...
dalfox → base target URL (same logic)
dalfox → SAST-flagged XSS URL 1
...
```

**Concrete example**: SAST says `POST /api/v1/login` → SQL Injection. TraceON:
1. Imports finding → adds `/api/v1/login` to `self.routes` (ZAP spiders it)
2. Adds `https://target.com/api/v1/login` to `sast_sqli_targets`
3. Attack surface classifies `/api/v1/login` as **critical**
4. ZAP active scans `/api/v1/login` (already in site tree from step 1)
5. sqlmap runs `sqlmap -u https://target.com/api/v1/login ...` (targeted, not just base URL)
6. If sqlmap confirms → correlation engine marks the finding as **confidence = "verified"**

**Whitebox value chain**:
1. SAST finds theoretical vulnerabilities in code → imported as `probable` findings
2. SAST endpoints seed ZAP's site tree → better spider coverage
3. SAST vuln types target sqlmap/dalfox precisely → higher true-positive rate
4. DAST confirms SAST findings → `verified` confidence
5. Unconfirmed SAST findings stay `probable`; unmatched DAST findings stay `observed`

---

## 10. Blackbox Mode — How Pure DAST Works

Blackbox mode is used when only a live URL is available — no SAST JSON, no uploaded findings file. The scanner must discover everything dynamically. There is **no importing phase** in blackbox mode; if you have findings to import, the scan is whitebox.

**Path fuzzing (ffuf + feroxbuster)**: Before any authenticated scanning, both tools run wordlist-based fuzzing to find hidden paths the main spider might miss. Details in §17 and §18.

**Server audit (Nikto + testssl)**: Checks for server-level misconfigurations and TLS weaknesses that are independent of the application logic. Details in §16 and §19.

**Endpoint discovery**: Probes standard OpenAPI/Swagger spec paths (`/openapi.json`, `/swagger.json`, `/api-docs`, etc.) to import the API schema if available. If found, it's loaded into ZAP so the active scanner knows all API endpoints. Also probes for GraphQL introspection at `/graphql`, `/api/graphql`, etc.

**Fingerprinting**: HTTP response headers (`Server`, `X-Powered-By`, `X-Generator`) and body patterns are matched against known tech signatures to detect the framework, language, and database. Results are stored in `scan.detected_stack` and used to inform LLM recommendations.

**Attack Surface Analysis**: Runs the same classification as whitebox (§9) — all paths discovered by path fuzzing and endpoint discovery are classified into critical/high/medium/low tiers. In blackbox mode, `sast_sqli_targets` and `sast_xss_targets` are always empty (no SAST data), so sqlmap and dalfox only scan the base target URL (not targeted per-endpoint). Wapiti also runs in blackbox mode for XXE, LDAP injection, and CRLF injection — attack types ZAP tends to miss.

**Correlation in blackbox**: Without SAST findings to match against, all DAST findings have confidence `"observed"` (not `"verified"`). The correlation engine can still deduplicate alerts from different DAST tools if they hit the same endpoint with the same vulnerability type.

---

## 11. ZAP — The Core DAST Engine

OWASP ZAP is the main dynamic scanner. It runs as the `traceon-zap` Docker container on port 8080. TraceON communicates with it via the `python-owasp-zap-v2.4` library.

**Spider** (`_run_spider()`): ZAP's spider crawls the application starting from the target URL. It:
- Follows all `<a>` links, form actions, redirects
- Submits forms with test values to discover POST endpoints
- Optionally runs the AJAX spider (Selenium-based) for JavaScript-rendered routes
- Respects `max_children` (default 10 links per page) and `scan_depth` (default 5 levels)

Additional route seeding: Before the spider runs, any routes extracted from source analysis, OpenAPI specs, Postman collections, or ffuf/feroxbuster fuzzing are injected into ZAP's site tree via `zap.urlopen()`. This ensures the active scanner attacks endpoints the spider might have missed.

**WAF detection**: ZAP sends probe requests and measures response variation. For private targets (no WAF detected), it runs with:
- 20 threads per host (`ZAP_NO_WAF_THREADS = 20`)
- 0ms delay between requests (`ZAP_NO_WAF_DELAY_MS = 0`)

For remote targets where a WAF may be present:
- 2 threads per host
- "Low" attack strength
- 50ms delay between requests

**Active scan** (`_run_active_scan()`): ZAP's active scanner sends malicious payloads to every discovered endpoint. It:
1. Verifies the target is accessible in ZAP's site tree
2. Creates a ZAP context for in-scope-only scanning if requested (domain pattern `scheme://host.*`)
3. Calls `zap.ascan.scan()` with the target URL, context ID, and attack policy
4. Polls every 5 seconds for progress updates
5. Implements adaptive timeout: base 30s + 6s per discovered route, capped at 2400s
6. Has stall recovery: if no new alerts for 300 seconds but progress is ≥30%, collects early

**Attack types**: ZAP's default policy covers:
- SQL injection (error-based, blind, time-based) — rules 40018–40022
- XSS reflected, stored, DOM-based — rules 40012, 40014, 40016, 40017
- OS command injection — rules 90019, 90020
- Path traversal — rules 6, 40003, 40032
- SSRF — rule 40034
- CSRF — rule 10017
- Missing security headers — rules 10020, 10021, 10035, 10036, 10038
- Cookie security (HttpOnly, Secure) — rules 10010, 10011
- Information disclosure — rules 10023, 10024, 10027, 10104
- TLS misconfiguration — rule 10096

**Alert parsing**: ZAP returns JSON "alerts" with riskcode (0–3), confidence, pluginId, attack payload, and evidence. TraceON maps these to findings:
- riskcode 3 → high; 2 → medium; 1 → low; 0 → info
- vuln_type in {sqli, cmdi, code_injection, ssrf, path_traversal} AND severity==high → promoted to critical
- High/Confirmed ZAP confidence → TraceON "probable" (DAST alone cannot be "verified" without source match)

**In-Scope Only**: When enabled, creates a ZAP context with the pattern `scheme://host.*` before the active scan, and passes `contextid` to `zap.ascan.scan()`. Without the context, the `inscopeonly` parameter is silently ignored by ZAP.

---

## 12. Nuclei — CVE & Template Scanning

Nuclei is a template-based scanner that checks for known vulnerabilities, exposed files, CVEs, and CMS-specific issues.

**Command**:
```bash
nuclei -u <target_url> -json -severity medium,high,critical -rate-limit <N> -no-color
```

**What it finds**: Nuclei's template library covers:
- **CVEs**: Specific CVE exploits for known software versions (e.g., CVE-2021-44228 Log4Shell, CVE-2022-21907 IIS, etc.)
- **CMS vulnerabilities**: WordPress plugin exploits, Drupal issues, Joomla misconfigs
- **Exposures**: Exposed `.env` files, API keys in responses, `/.git/config`, `/actuator/env`, admin panels, backup files
- **Generic misconfigurations**: Directory listing, debug endpoints, default credentials
- **OSINT**: DNS records, tech detection, version disclosure

**WAF throttling**: If `waf_detected=True`, the rate limit is reduced from the default (150 req/s for private targets) to 10 req/s to avoid triggering blocking.

**Finding parsing**: Nuclei outputs one JSON object per line. Each line has:
- `info.name`: template name
- `info.severity`: critical/high/medium/low/info
- `info.tags`: list like ["cve", "cve2021", "log4j"]
- `matched-at`: URL where the template matched
- `matcher-name`: which part of the template triggered
- `extracted-results`: captured strings (e.g., version numbers, leaked keys)

The vulnerability type is inferred from tags: "cve" → "cve", "exposure" → "exposure", "cms" → "cms", "misconfiguration" → "config".

---

## 13. SQLMap — How SQL Injection Is Found

SQLMap is a dedicated SQL injection detection and exploitation tool. It is far more thorough than ZAP for SQLi because it implements multiple attack techniques and can crawl forms automatically.

**Command** (exact flags used by TraceON):
```bash
sqlmap \
  -u <target_url> \   # Starting URL to test
  --batch \           # Never prompt the user; use defaults everywhere
  --level=2 \         # Level 1 = URL params only; Level 2 = also cookies, User-Agent, Referer
  --risk=1 \          # Risk 1 = safe (no UPDATE/DELETE); Risk 2/3 would modify data
  --crawl=2 \         # Follow links 2 levels deep from the starting URL
  --forms \           # Detect and test HTML forms
  --flush-session \   # Ignore any cached test results from previous runs
  --smart \           # Only test parameters that look plausible (filter noise)
  --output-dir <tmp>  # Store session data in a temp directory (cleaned up after)
```

**How SQLMap finds SQL injection**:

1. **Discovery**: SQLMap crawls the target URL (2 levels deep), collecting parameters from:
   - URL query strings (`?id=1`)
   - POST form fields
   - Cookies (level 2)
   - HTTP headers like User-Agent and Referer (level 2)

2. **Heuristic pre-check**: Before full testing, SQLMap sends simple payloads (like `'`, `"`, `` ` ``) and looks for:
   - Database error messages in the response ("SQL syntax error", "ORA-", "mysql_num_rows")
   - Significant response length changes
   - If this quick test suggests a parameter might be injectable, it proceeds; otherwise it skips (this is what `--smart` enables)

3. **Injection technique testing**: For each candidate parameter, SQLMap tests multiple techniques:
   - **Error-based**: Sends payloads designed to trigger database error messages that leak data. Example: `' AND EXTRACTVALUE(1,CONCAT(0x7e,@@version))-- -` causes MySQL to return the version in an error.
   - **Union-based**: Adds a `UNION SELECT` to the original query to retrieve additional data in the same response. Example: `' UNION SELECT NULL,NULL,@@version-- -`.
   - **Boolean-based blind**: Sends pairs of payloads — one that's always true (`AND 1=1`) and one that's always false (`AND 1=2`). If the responses differ, the parameter is injectable even though no error is shown.
   - **Time-based blind**: Sends a payload that causes the database to sleep (e.g., `'; WAITFOR DELAY '0:0:5'-- -` for MSSQL or `'; SELECT SLEEP(5)-- -` for MySQL). If the response takes 5+ extra seconds, the parameter is injectable even when responses look identical.
   - **Stacked queries**: Injects a second SQL statement after a semicolon to test if multiple queries can be run.

4. **Payload generation**: SQLMap generates payloads internally based on the target DBMS. It auto-detects the database type (MySQL, PostgreSQL, MSSQL, Oracle, SQLite, etc.) from error messages or version disclosure, then applies DBMS-specific payloads.

**What TraceON parses from SQLMap output**:

TraceON reads SQLMap's stdout line by line using two regex patterns:

- **`[CRITICAL]` pattern**: `\[CRITICAL\]\s+(.+?)\s+appears to be\s+'(.+?)'\s+injectable`
  - Matches lines like: `[CRITICAL] GET parameter 'id' appears to be 'MySQL >= 5.0 AND error-based' injectable`
  - Captured groups: param name + injection type
  - Stored as `severity="high"` finding (confirmed injection)

- **`[WARNING]` pattern**: `\[WARNING\]\s+heuristic.*?parameter\s+'(.+?)'\s+might be injectable`
  - Matches: `[WARNING] heuristic (basic) test shows that GET parameter 'id' might be injectable`
  - This is the pre-check heuristic result
  - Stored as `severity="medium"` finding with label "Possible SQL Injection" (needs manual confirmation)

**Why SQLMap is needed alongside ZAP**: ZAP tests SQLi with fixed rule sets and may miss blind injection because it doesn't implement time-based or multi-technique testing. SQLMap crawls forms (`--forms`) and follows links (`--crawl=2`), often finding parameters ZAP missed. A target with no visible SQLi errors can still be vulnerable to time-based blind injection that only SQLMap detects.

---

## 14. Dalfox — How XSS Is Found

Dalfox is a purpose-built XSS scanner. It's faster and more thorough than ZAP's XSS rules because it was designed only for XSS.

**Command**:
```bash
dalfox url <target_url> \
  --format json \   # Output findings as JSON
  --output <file> \ # Write to temp file
  --skip-bav \      # Skip "Blind After Verification" — no callback server needed
  --no-color \      # Clean output
  --silence         # No progress bars
```

**`--skip-bav` explained**: BAV (Blind After Verification) is a mode that sets up an external callback server and sends payloads containing a unique URL to detect stored/blind XSS. Skipping it makes the scan much faster and still catches reflected and DOM-based XSS. TraceON skips it because it would require an internet-reachable callback domain.

**How Dalfox detects XSS**:

1. **Parameter discovery**: Analyzes the target URL's query parameters and form fields.
2. **Payload injection**: Injects XSS payloads into each parameter. Payloads include:
   - Simple tags: `<script>alert(1)</script>`
   - Event handlers: `"><img src=x onerror=alert(1)>`
   - SVG vectors: `<svg/onload=alert(1)>`
   - Encoded variants for filter bypass: `%3Cscript%3E`, `&#x3C;script&#x3E;`
   - Double-encoded, Unicode, and mixed-case variants
3. **Response analysis**: Checks if the injected payload appears in the response body in an executable context (not just reflected as text inside HTML attributes with proper encoding).

**XSS types detected**:
- **R — Reflected**: Payload is sent in a request and immediately returned in the same response. Classic example: `?search=<script>alert(1)</script>` reflected in the page.
- **S — Stored**: Payload is sent, stored in the database, and appears in a later response (e.g., a comment is submitted and appears in the comments page). Dalfox detects this by submitting then requesting the storage location.
- **D — DOM-based**: The payload never reaches the server; instead JavaScript code in the page takes user input (from URL fragment, `document.location`, etc.) and inserts it into the DOM unsafely.

**JSON output format** (what TraceON reads):
```json
[{"param": "q", "poc": "<img src=x onerror=alert(1)>", "type": "R", "data": "http://target.com/search?q=..."}]
```

Fields mapped: `param` → parameter, `poc` → code_snippet (proof-of-concept), `type` → R/S/D distinguishes Reflected/Stored/DOM, `data` → endpoint.

**Why Dalfox is needed alongside ZAP**: ZAP's XSS rules use fixed signature patterns. Dalfox generates context-aware payloads per parameter (e.g., if the parameter is inside a JavaScript string, it generates payloads that break out of strings) and distinguishes DOM XSS from server-reflected XSS. Dalfox has consistently higher XSS detection rates than ZAP in comparative studies.

---

## 15. Wapiti — XXE, LDAP, CRLF & More

Wapiti is the only tool in the stack that tests for XXE, LDAP injection, and CRLF injection. ZAP does not cover these attack types by default.

**Command**:
```bash
wapiti -u <target_url> \
  -m xxe,ldapi,crlf,redirect,ssrf,sql,xss,file \
  -f json \
  -o <output_file> \
  --no-bugreport
```

**Modules and what each tests**:

| Module | Vulnerability | How it works |
|--------|--------------|--------------|
| `xxe` | XML External Entity injection | Submits XML payloads with `<!DOCTYPE x [<!ENTITY ext SYSTEM "file:///etc/passwd">]>` and checks if the entity content appears in the response |
| `ldapi` | LDAP injection | Injects LDAP metacharacters (`*`, `)(`, `&`) into parameters that might feed an LDAP query (e.g., login forms) |
| `crlf` | CRLF injection / HTTP response splitting | Injects `%0d%0a` (carriage return + line feed) into URL parameters and headers; if reflected, it can split HTTP responses and inject new headers |
| `redirect` | Open redirect | Tests redirect parameters (`?next=`, `?url=`, `?return=`) with off-domain values to detect unchecked redirects |
| `ssrf` | Server-Side Request Forgery | Injects internal IP addresses and internal URLs into parameters that might trigger server-side HTTP requests |
| `sql` | SQL injection | Basic SQLi detection (supplements sqlmap) |
| `xss` | Cross-site scripting | Basic XSS detection (supplements dalfox) |
| `file` | File inclusion (LFI/path traversal) | Tests for `../` traversal, `/etc/passwd` inclusion, PHP wrappers like `php://input` |

**Wapiti3 JSON output format**: The output is `{"vulnerabilities": {"Category Name": [vuln_dict, ...]}}`. Each vuln_dict has:
- `info`: description of the specific finding
- `level`: 1 (low), 2 (medium), or 3 (high)
- `module`: which wapiti module detected it
- `url`: the vulnerable URL
- `parameter`: the vulnerable parameter
- `http_request`: the raw HTTP request that triggered the finding

TraceON maps `level 1→low`, `level 2→medium`, `level 3→high`.

**Why Wapiti is needed**: ZAP has no XXE module, no LDAP injection module, and no CRLF injection module. These are real vulnerability classes that affect applications using XML parsers, LDAP directories, and servers with improper HTTP response handling. Wapiti fills these gaps specifically.

---

## 16. Nikto — Server Configuration Audit

Nikto tests the web server itself, not the application logic.

**Command**:
```bash
nikto -h <target_url> -Format json -nointeractive -maxtime 240
```

**What Nikto checks**:
- Outdated server software with known CVEs (e.g., Apache 2.2.x, IIS 6.0)
- Default files and directories (admin panels, test scripts, backup files like `.bak`, `.old`)
- Dangerous HTTP methods enabled (PUT, DELETE, TRACE, CONNECT)
- Missing security headers (X-Frame-Options, X-Content-Type-Options, X-XSS-Protection)
- Directory listing enabled
- Sensitive files exposed (`.env`, `/config.php`, `web.config`, `.git/HEAD`)
- SSL certificate issues (expired, self-signed, weak cipher in use)
- Default credentials for common web applications
- Cookie flags missing (Secure, HttpOnly, SameSite)

**Severity mapping**: Uses OSVDB IDs:
- OSVDB ID < 5000 → high severity (older, more severe vulnerabilities)
- OSVDB ID ≥ 5000 → medium severity
- No OSVDB ID → low severity

**Why Nikto is needed**: ZAP's active scanner focuses on application-layer vulnerabilities. Nikto focuses on the server layer — outdated Apache versions, dangerous HTTP methods, exposed backup files. These are completely different attack surfaces with minimal overlap.

---

## 17. ffuf — Fast Path Fuzzing

ffuf discovers hidden paths by trying every entry in a wordlist.

**Command**:
```bash
ffuf \
  -u <base_url>/FUZZ \   # FUZZ is the placeholder where wordlist entries go
  -w <wordlist> \        # Wordlist file
  -ac \                  # Auto-calibrate: learn what "not found" looks like and filter it
  -t 50 \                # 50 parallel threads (fast, appropriate for private targets)
  -p 0 \                 # 0 second delay between requests
  -of json \             # JSON output
  -o <tmpfile> \         # Output file
  -s                     # Silent mode (no progress bar)
```

**Wordlists used**:
1. `/usr/share/seclists/Discovery/Web-Content/common.txt` — common web paths like `/admin`, `/login`, `/api`, `/config`, `/backup`, `/debug`, `/swagger`, `/.env`, `/.git/config`
2. `/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt` — API-specific paths like `/api/v1/users`, `/api/v2/products`

**Two-pass strategy**:
- First pass: fuzzes `{base_url}/FUZZ` for root-level paths
- Second pass: fuzzes `{base_url}/api/FUZZ` with the API wordlist to find versioned API endpoints

**`-ac` (auto-calibrate)**: ffuf sends a few requests to nonexistent paths and learns the "baseline" response characteristics (status code, response length, word count). It then filters out any future responses matching this baseline, avoiding false positives where the server returns 200 OK for every path.

**What ffuf discovers**: Paths that are not linked from any page, not in the sitemap, and not in the API docs — things like `/admin`, `/debug`, `/backup/2024-01.sql`, `/.env`, `/config.json`.

**Difference from feroxbuster**: ffuf uses flat wordlists and runs in two targeted passes. It does not recurse into discovered directories. Best for quickly finding top-level paths.

---

## 18. feroxbuster — Recursive Directory Discovery

feroxbuster discovers the full directory tree by automatically recursing into each found directory.

**Command**:
```bash
feroxbuster \
  --url <target_url> \     # Starting URL
  --wordlist <wordlist> \  # Dictionary file
  --json \                 # JSON lines output
  --output <tmpfile> \     # Output file
  --depth 3 \              # Recurse 3 levels deep
  --threads 50 \           # Parallel threads
  --no-state \             # Don't save scan state
  --silent \               # No progress output
  --filter-status 404      # Don't show 404s
```

**Wordlist**: `/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt` — a high-quality curated list of 30,000 directory names commonly found in web applications.

**Recursive discovery**: When feroxbuster finds `/admin/`, it automatically starts a new sub-scan for `/admin/FUZZ`, then `/admin/settings/FUZZ`, etc., up to depth 3. This reveals nested structures like `/admin/settings/users`, `/api/v1/internal/config`, `/backup/2024/january/` that a flat scan misses entirely.

**Difference from ffuf**: feroxbuster uses a directory-name focused wordlist and automatically recurses. ffuf uses common paths + API endpoints and does not recurse. Together they cover complementary ground:
- ffuf finds `/api/v1/users` (API endpoint wordlist)
- feroxbuster finds `/admin/settings/profile` (recursive directory structure)

---

## 19. testssl.sh — Deep TLS Audit

testssl.sh performs a comprehensive analysis of the TLS configuration of the server — something no other tool in the stack does.

**Command**:
```bash
testssl --quiet --jsonfile <tmpfile> --color 0 --warnings off <host>
```

**What testssl checks**:

- **Protocol versions**: Is SSLv2/SSLv3 (ancient, broken) still enabled? Which TLS versions (1.0, 1.1, 1.2, 1.3) are supported?
- **Cipher suites**: Are weak ciphers (RC4, DES, 3DES, NULL, EXPORT) enabled? Is there forward secrecy (ECDHE/DHE key exchange)?
- **Key exchange**: DH parameter size (Logjam attack), ECDH curves
- **Vulnerabilities**:
  - **BEAST** (TLS 1.0 + CBC cipher): CBC cipher mode in TLS 1.0 is vulnerable to chosen-plaintext attacks
  - **POODLE** (SSL 3.0): SSL 3.0 padding oracle attack — server should not support SSL 3.0 at all
  - **CRIME** (TLS compression): HTTP compression leaks session tokens
  - **SWEET32**: 64-bit block ciphers (3DES, Blowfish) are vulnerable to birthday attacks in long-lived sessions
  - **DROWN**: Server shares a private key with a server that still supports SSLv2
  - **Logjam**: Weak DH parameters (512-bit or 768-bit keys) allow downgrade attacks
  - **FREAK**: Export-grade RSA cipher suites still enabled
  - **RC4**: RC4 stream cipher is cryptographically broken
- **Certificate**: Self-signed? Expired? Does hostname match? Is the chain complete? Is the CA trusted?
- **HTTP headers**: Is HSTS (HTTP Strict Transport Security) set with a reasonable max-age? Is HPKP set?
- **Session resumption**: Ticket validity, session resumption support

**Severity mapping**: testssl output uses CRITICAL, HIGH, MEDIUM, LOW, INFO, WARN, OK. TraceON filters out OK/INFO/NOT applicable and maps the rest to critical/high/medium/low.

**CWE mapping**: Per test ID (e.g., BEAST → CWE-311 "Missing Encryption of Sensitive Data", POODLE_SSL → CWE-310).

**Why testssl is needed**: Neither ZAP nor nikto perform deep TLS analysis. ZAP has one TLS rule (rule 10096) that checks for basic HTTPS issues. Nikto checks for SSL certificates but not protocol-level weaknesses. testssl is the only tool that checks BEAST, POODLE, SWEET32, DROWN, Logjam, FREAK — historically important TLS vulnerabilities that still affect many internal applications.

---

## 20. Why Every Tool Is Needed (No Overlap)

The tool selection is deliberately designed so each fills a unique gap:

| Tool | Unique capability | What it replaces |
|------|------------------|------------------|
| **ZAP** | Broad DAST: covers 40+ attack types, session management, CSRF, header checks, evidence collection | The base scanner — everything else supplements it |
| **Nuclei** | Pre-built CVE templates, CMS exploits, exposed files (`.env`, API keys), very fast | Nothing else checks for CVE-2021-44228 or exposed backup files |
| **SQLMap** | Blind SQLi: time-based, union-based, multi-form crawling (`--crawl --forms`) | ZAP's SQLi rules are shallow; SQLMap finds blind injection ZAP misses |
| **Dalfox** | Context-aware XSS payloads, Reflected/Stored/DOM distinction, PoC output | ZAP's XSS rules are generic; Dalfox generates parameter-specific payloads |
| **Wapiti** | XXE, LDAP injection, CRLF injection, open redirect — gaps ZAP doesn't cover | Nothing else in the stack tests XXE or LDAP injection |
| **Nikto** | Server layer: outdated versions, dangerous HTTP methods, default files | ZAP does not test server-level misconfigs |
| **ffuf** | Fast flat fuzzing of common paths + API endpoints | Spider only follows linked paths; ffuf finds unlisted ones |
| **feroxbuster** | Recursive directory tree discovery | ffuf doesn't recurse; feroxbuster finds nested admin areas |
| **testssl** | Deep TLS: BEAST, POODLE, SWEET32, DROWN, cipher order, certificate chain | Nothing else in the stack does TLS protocol analysis |

**The "defense in depth" principle**: Multiple tools finding the same vulnerability class (e.g., both ZAP and SQLMap test SQL injection) is intentional. ZAP will miss time-based blind SQLi that SQLMap catches. SQLMap will miss a stored XSS that Dalfox catches. Running both gives higher coverage, not redundancy.

---

## 21. LLM Orchestration — End to End

TraceON uses an LLM at three points in the scan lifecycle.

### Provider Configuration

Supported providers (configured in `backend/app/llm/catalog.py`):
- **Anthropic**: claude-sonnet-4-6 (default), claude-opus-4-8, claude-haiku-4-5-20251001
- **OpenAI**: gpt-4o-mini, gpt-4.1, gpt-4.1-mini, o3-mini
- **Google**: gemini-2.5-pro (default), gemini-2.0-flash, gemini-1.5-pro/flash
- **OpenRouter**: Free-tier access to Llama 3.3 70B, Qwen, Gemma
- **GitHub Copilot**: gpt-4o-mini, gpt-4, gpt-3.5-turbo

**API key resolution** (`resolve_llm_provider_config_async()`, `backend/app/llm/provider_config.py`):
Priority order:
1. `scan_config` overrides (per-scan explicit key/provider/model)
2. DB-stored global provider credentials (`LLMProviderCredential` table, per-user, encrypted with Fernet)
3. Project-level LLM settings (legacy)
4. Environment variable (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, etc.)

If `user_id` is passed, it fetches that user's stored credentials from the DB. This was a critical bug fixed earlier — passing the wrong user ID caused "Provider not connected" errors even when the API key was stored.

### Stage 1: Pre-Scan Planning

**When**: Before any scanning starts, if the project description is ≥15 characters.

**What it does** (`backend/app/llm/pre_scan_planner.py`):
- Sends the project description, scan_mode, and any existing finding types to the LLM
- Asks: "Given this application, what should we focus on? What can we skip?"
- LLM returns:
  - `focus_areas`: 2–4 specific paths or endpoints to prioritize (e.g., `["/api/admin/users", "/login"]`)
  - `skip_hint`: patterns to deprioritize (e.g., `["/static", "/assets"]`)
  - `risk_hypothesis`: one-sentence prediction (e.g., "Django admin panel may be exposed with weak credentials")

**Caching**: Results are cached for 24 hours by SHA-256(description + mode) to avoid identical LLM calls on repeated scans.

**Effect on scan**: The planner output is stored in `scan.plan_result` and is visible in the Reports UI under "Pre-Scan Intelligence". The ZAP scanner prioritizes `focus_areas` endpoints and may use `skip_hint` to configure scope.

### Stage 2: Mid-Scan Checkpoints

**When**: At three points during the scan — after source analysis, after active scan, after correlation.

**What it does** (`_run_llm_planner_checkpoint()`):
- Builds a compact context: routes discovered, sink type counts, finding type distribution, SAST and DAST finding counts
- Sends to the LLM planner with the current checkpoint name
- LLM chooses one action from an allowlist:
  - `no_change`: scan is proceeding well, continue
  - `update_scan_config`: adjust bounded parameters (depth, timeout, max_children, ajax_spider, inscope_only)
  - `prioritize_vuln_types`: tell active scanner to focus on specific vulnerability types
  - `recommend_targeted_retry`: suggest re-scanning specific endpoints with higher intensity

**Action application**: If the LLM recommends `update_scan_config`, only a safe subset of keys can be modified (depth 1–20, timeout 30–14400s, etc.) to prevent prompt injection from affecting dangerous settings.

**Targeted retry** (`_run_targeted_retry_if_requested()`): If the LLM recommends a retry with specific endpoints, after the main active scan, those endpoints are extracted from the route list and ZAP re-scans them with an extended timeout.

### Stage 3: Post-Scan Synthesis

**When**: After all scanning and correlation complete.

**What it does** (`backend/app/llm/post_scan_synthesizer.py`):
- **Input compression**: All findings are compressed to one-line format (ID, type, severity, endpoint, parameter) to fit within context limits
- **False positive review** (whitebox only): Probable findings (code sinks without DAST confirmation) are reviewed by the LLM for likely false positives
- **Attack chain detection**: The LLM identifies which findings chain together into a complete attack path. Example: "XSS in `/search` parameter `q` (Finding #3) combined with CSRF token bypass (Finding #7) enables stored XSS that steals admin sessions."
- **Executive summary**: A ≤60-word summary in plain English for non-technical stakeholders

**Output stored in**:
- `scan.attack_chains`: JSON list of `{finding_ids: [], severity: "critical", narrative: "..."}`
- `scan.llm_summary`: 60-word executive summary
- `scan.llm_status`: "ok", "skipped", or "failed"

**Error isolation**: The synthesis never causes the scan to fail. If the LLM call errors, it logs the error in `scan.llm_error` and the scan still completes.

**Visible in UI**: Reports page shows an "LLM Insights" section with the executive summary, pre-scan risk hypothesis, and attack chains with severity badges.

---

## 22. Correlation Engine — Verified vs Probable vs Observed

The correlation engine (`backend/app/correlation/`) is what distinguishes TraceON from a pure DAST tool. It combines static and dynamic findings to produce confidence-rated results.

### The Three Confidence Levels

**Verified** — Both a static code finding (SAST) and a dynamic proof (DAST) exist for the same vulnerability at the same endpoint. The vulnerability is real and exploitable. Example: SQLMap found SQL injection at `/api/users?id=1`, AND source analysis found `cursor.execute(f"SELECT * FROM users WHERE id={id}")` in `users.py:47`. The endpoint matches. This is verified.

**Probable** — A SAST finding exists (dangerous code pattern) but DAST testing did not confirm exploitation. The code looks vulnerable but the scanner didn't prove it dynamically. Example: Source code has `eval(request.args.get('code'))` but the ZAP active scan didn't trigger it (perhaps due to auth). It's probably real but not confirmed.

**Observed** — A DAST finding exists but there is no source code to match against. Pure blackbox observation. Example: ZAP found an SQL error response from `/api/users?id=1'`. No source code is available to confirm the code path. The finding is real but unconfirmed against source.

### How Matching Works (`correlation_engine.py`)

For a SAST finding and a DAST finding to match:
1. **Type matching**: Both must have the same canonical vulnerability type (sqli, xss, cmdi, etc.)
2. **Endpoint matching**: The DAST endpoint path must match the SAST finding's route. URL parameters are normalised: `{id}`, `<int:id>`, `:id` all become `*`. If a source file has multiple routes, all routes from that file are considered.
3. **Parameter matching** (optional): If both have parameter names, they must fuzzy-match (≥0.80 similarity). If one or both have no parameter data, this check is skipped.
4. **CWE matching** (optional): If both have CWE IDs, they must match. If one is missing, this is skipped.

The confidence scorer assigns a numeric score:
- SAST + DAST match base: 80 points
- Parameter match bonus: +10
- Endpoint exact match bonus: +10
- CWE match bonus: +5
- Sink detected bonus: +5
- Score ≥ 70 → verified

### IDOR and Role-Aware Correlation

For multi-role scans (admin + user + guest), the correlation engine has additional logic:

**IDOR verification**: If SAST found an IDOR pattern and two different auth roles (e.g., "user" and "admin") both accessed the same endpoint with the same parameter, the IDOR is verified. This proves that one role can access another role's data.

**Auth logic verification**: If SAST found a privilege escalation pattern and a lower-privilege role accessed a high-privilege endpoint (guest level 0 → admin level 2), the auth bypass is verified.

### Deduplication (`deduplicator.py`)

After correlation, findings are deduplicated by grouping on (vuln_type + endpoint + parameter + file). When duplicates are found, the "best" is kept using priority: verified > probable > observed. Duplicates are marked `status="duplicate"` with a `duplicate_of` reference.

### Risk Scoring (`risk_ranker.py`)

Each finding gets a 0–100 risk score:
- Base: severity (critical 90, high 70, medium 50, low 30, info 10)
- Confidence bonus: +15 verified, +8 probable, +3 observed
- Extra bonuses: payload evidence (+6), response evidence (+6), accessible without auth (+6), found during authenticated journey (+4)

---

## 23. Auth Automation — Browser Login & Role Profiles

### Auth Config

Auth settings flow from three sources (priority order):
1. `scan_config["auth_config"]` — per-scan override
2. `scan.auth_config` — set at scan creation time
3. `project.auth_config` — default for the project

The `auth_config` dict has fields:
- `auth_type`: "none", "basic", "form", "playwright", "token", "cookie"
- `username`, `password`: credentials
- `login_url`: where the login form is (for form-based login)
- `token`: pre-supplied Bearer token (skips login flow entirely)
- `cookies`: pre-supplied session cookies
- `playwright_script`: custom Playwright automation script (async function)
- `role_profiles`: list of dicts, each describing one role (enables multi-role scanning)

### Login Flow (`_setup_auth()`)

1. **HTTP Basic**: If `auth_type == "basic"`, base64-encodes `username:password` and injects as `Authorization: Basic ...` header in ZAP. No login page visit needed.

2. **Pre-supplied token/cookies**: If a token or cookies are already in the config, reuse them directly without any login flow.

3. **REST API login**: Attempts to log in via JSON POST to the login endpoint. Returns JWT if successful. Designed for API-first apps (like VAmPI) where HTML forms don't exist.

4. **Playwright browser login**: Opens a real browser (Chromium via Playwright), navigates to the login URL, fills in the username/password fields, and submits. Before doing this, checks for CAPTCHA (`recaptcha`, `hcaptcha`, `cf-turnstile`) and warns the user if detected.
   - If `playwright_script` is provided, the custom script runs instead of the automatic fill-and-submit logic. This handles apps with MFA, non-standard login flows, or JavaScript-heavy auth.
   - The resulting session cookies/tokens are extracted from the browser and injected into ZAP via replacer rules.

5. **Auto-detection from source** (whitebox only): `AuthDetector.detect_auth()` scans the source code for login endpoint patterns and suggests auth configuration automatically.

### Multi-Role Scanning

`_build_role_profiles()` normalises role profiles from `auth_config.role_profiles` or `auth_config.roles`. Each role is a separate auth profile with its own username/password/token.

The orchestrator then runs the full DAST pipeline (auth → spider → WAF detection → active scan) separately for **each role**. This enables:
- Finding IDOR vulnerabilities (role A can access role B's data)
- Finding privilege escalation (user role can reach admin endpoints)
- Finding authentication bypass (unauthenticated access to protected resources)

Per-role findings are tracked in `_dast_findings_by_role` and the correlation engine uses role context for IDOR verification.

---

## 24. Journey Replay — Postman / OpenAPI / HAR

### What These Files Are For

When a web application has complex multi-step workflows (checkout flow, account creation, file upload wizard), a simple spider and active scan may not exercise these paths deeply. Journey files teach TraceON which API calls belong to each workflow step, so the scanner can:
- Warm up ZAP's session state by replaying real business flows
- Discover API endpoints that are only reachable via specific sequences of requests
- Correlate DAST findings to specific user journeys

### Supported Formats

**OpenAPI/Swagger**: JSON or YAML API schema file. TraceON extracts all `paths` entries with their HTTP methods and parameters. These are imported into ZAP via `zap.openapi.import_url()` which teaches ZAP the full API surface without requiring spider discovery.

**Postman Collections**: JSON export from Postman. TraceON recursively walks the `item` array, extracts all request nodes, converts Postman URL objects to paths, and returns them as routes for ZAP seeding.

**Journey replay files (HAR/custom)**: Step-by-step HTTP request sequences. Each step has a method, URL, headers, body, and optional assertions.

### How Journey Replay Works

Before the active scan runs, `_run_journey_replay_warmup()` replays all journey steps (capped at `journey_replay_max_steps`, default 200):
- Sends each HTTP request through ZAP's proxy so ZAP learns the full request/response
- Auth credentials are injected into replayed requests
- Stats are tracked: executed, failed, proxied, sample_errors

The effect: ZAP's site tree is populated with all API endpoints from the real business flows, so the active scanner has complete coverage of the application's actual attack surface.

---

## 25. Frontend Architecture

The frontend is a React SPA built with Vite + Tailwind CSS. It has no router library — navigation is pure state management in `App.tsx`.

**Navigation model**: A `currentPage` state variable determines which page component renders. The sidebar links update this state. URL paths are not used for routing (though the backend catch-all serves `index.html` for any path).

**Pages**:
- `Dashboard`: Overview metrics, recent scans, quick actions
- `Projects`: Project list + creation modal (TrustScan OAuth flow, JSON upload, auth config)
- `Findings`: Finding list with filters; Finding detail with code context, payload, evidence
- `Reports`: Scan summary report with LLM Insights section (executive summary, pre-scan intelligence, attack chains)
- `Scans`: Real-time scan progress monitor (WebSocket-connected)
- `Coverage`: Code coverage visualization
- `LLM Providers`: Connect Anthropic/OpenAI/Google/OpenRouter accounts

**API layer** (`frontend/src/services/api.ts`): All API calls go through an Axios instance at base URL `/api/v1`. The `X-API-Key` header is injected by an interceptor from `window.__DT_API_KEY__` (injected by backend for local) or `localStorage["dt_api_key"]` (saved by user).

**Project creation modal**: Handles the full TrustScan OAuth flow inline:
1. User clicks "Connect TrustScan" → `TrustScanConnectModal` opens as a popup
2. Modal polls `/trustscan/oauth/status/{state}` until `status="completed"`
3. Then loads jobs from `/trustscan/oauth/jobs?state={state}`
4. User selects a job → stores `trustscan_job_id` and `trustscan_token` in the project creation payload

Also handles auth config: collapsible section with auth type selector, credential fields, and a Playwright script textarea with a template `async function login(page) { ... }`.

---

## 26. Security Measures in TraceON Itself

TraceON's own security posture:

**Encryption**: All sensitive tokens (GitHub PAT, TrustScan PAT, LLM API keys, OpenAI keys) are encrypted with Fernet AES-256 (symmetric authenticated encryption) before being stored in the database. The encryption key is derived from `ENCRYPTION_KEY` env var via PBKDF2-SHA256 with 100,000 iterations. Decryption falls back to a legacy salt for backward compatibility.

**API key storage**: Only SHA-256 hashes of API keys are stored in the database. If the database is stolen, API keys cannot be recovered.

**WebSocket tokens**: HMAC-SHA256 signed, 120-second TTL, one-time use, scope-bound.

**No SQL injection in TraceON itself**: All database queries use SQLAlchemy ORM parameterized statements. The only raw SQL used is in migrations, where table and column names are validated against allowlists before use.

**SSRF protection**: Target URLs are validated via `validate_external_target_url()` which blocks private/internal IP addresses (10.x, 172.16.x, 192.168.x, 127.x, ::1) to prevent the scanner from being used to probe internal networks.

**Path traversal protection**: ZIP extraction validates that all paths resolve within the destination directory before writing. The catch-all static file route validates `.resolve().relative_to()` to prevent `../` traversal.

**Data isolation**: Non-admin users can only access their own projects and scans. Every endpoint checks `project.owner_id == current_user.id` before returning data.

**Security headers on every response**: CSP, X-Frame-Options DENY, X-Content-Type-Options nosniff, Referrer-Policy, HSTS (HTTPS only).

**LLM prompt injection protection**: The LLM planner only accepts actions from a hardcoded allowlist (`ALLOWED_ACTIONS`). Even if the LLM is manipulated to suggest dangerous actions, only bounded config changes from a safe key list (`ALLOWED_SCAN_CONFIG_KEYS`) are applied.

---

## 27. Key File Map

| File | What it does |
|------|-------------|
| `backend/app/main.py` | FastAPI app creation, middleware, WebSocket endpoints, SPA serving |
| `backend/app/core/orchestrator.py` | All scan logic — 3000+ lines — start here for any scan behaviour |
| `backend/app/core/database.py` | DB engine, migrations dict, `run_migrations()` |
| `backend/app/core/config.py` | All settings (env vars, feature flags, tool paths, rate limits) |
| `backend/app/core/security.py` | `encrypt_token` / `decrypt_token` (Fernet AES-256) |
| `backend/app/models/project.py` | Project ORM model |
| `backend/app/models/scan.py` | Scan ORM model |
| `backend/app/models/finding.py` | Finding ORM model |
| `backend/app/api/projects.py` | Project CRUD, upload, artifact management |
| `backend/app/api/scans.py` | Scan creation, config normalisation, goal compilation |
| `backend/app/api/trustscan_connector.py` | TrustScan OAuth flow (initiate → callback → status → import) |
| `backend/app/integrations/trustscan_client.py` | TrustScan HTTP client (Bearer token, job/findings endpoints) |
| `backend/app/scanners/external_importer.py` | Multi-format SAST parser (Semgrep/SARIF/Gitleaks/Trivy/Noir/TrustScan) |
| `backend/app/scanners/dast_engine.py` | ZAP integration (spider, WAF detection, active scan, alert parsing) |
| `backend/app/scanners/nuclei_engine.py` | Nuclei template scanner |
| `backend/app/scanners/sqlmap_engine.py` | SQLMap SQL injection scanner |
| `backend/app/scanners/dalfox_engine.py` | Dalfox XSS scanner |
| `backend/app/scanners/wapiti_engine.py` | Wapiti multi-vector DAST (XXE, LDAP, CRLF, redirect, SSRF) |
| `backend/app/scanners/nikto_engine.py` | Nikto server audit scanner |
| `backend/app/scanners/ffuf_engine.py` | ffuf path fuzzer |
| `backend/app/scanners/feroxbuster_engine.py` | feroxbuster recursive directory scanner |
| `backend/app/scanners/testssl_engine.py` | testssl.sh TLS/SSL auditor |
| `backend/app/llm/catalog.py` | Provider registry (Anthropic, OpenAI, Google, OpenRouter, GitHub) |
| `backend/app/llm/provider_config.py` | LLM API key resolution with priority chain |
| `backend/app/llm/planner.py` | Mid-scan planner (decision maker with action allowlist) |
| `backend/app/llm/pre_scan_planner.py` | Pre-scan planning (focus areas, risk hypothesis, 24h cache) |
| `backend/app/llm/post_scan_synthesizer.py` | Post-scan synthesis (attack chains, FP review, executive summary) |
| `backend/app/llm/prompts.py` | All LLM prompt templates |
| `backend/app/correlation/correlation_engine.py` | SAST ↔ DAST matching, verified/probable/observed assignment |
| `backend/app/correlation/confidence_scorer.py` | Numeric scoring for correlation matches |
| `backend/app/correlation/deduplicator.py` | Deduplication across scanner sources |
| `frontend/src/App.tsx` | React app, state-based navigation, layout |
| `frontend/src/services/api.ts` | All frontend API calls, TypeScript interfaces for all models |
| `frontend/src/pages/Projects.tsx` | Project creation modal + TrustScan OAuth flow |
| `frontend/src/pages/Reports.tsx` | Report view with LLM Insights section |
| `docker-compose.yml` | Backend + ZAP service definitions |
