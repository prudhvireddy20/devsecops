import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { lazy, Suspense, useEffect, useState } from 'react';
import {
  LayoutDashboard,
  FolderGit2,
  AlertTriangle,
  Eye,
  BarChart3,
  FileText,
  Bot,
  Blocks,
  Lightbulb,
  Menu,
  Moon,
  Sun,
  UserCircle2,
} from 'lucide-react';
import ApiKeyGate from './components/ApiKeyGate';
import { getCurrentUser, type CurrentUser } from './services/api';

// ---------------------------------------------------------------------------
// Brand mark — a "trace" routed through a node. Custom SVG, not a stock glyph.
// ---------------------------------------------------------------------------

function BrandMark({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M4 22 L11.5 22 L16 9 L20.5 22 L28 22"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="9" r="2.6" fill="currentColor" />
      <circle cx="4" cy="22" r="1.7" fill="currentColor" opacity="0.55" />
      <circle cx="28" cy="22" r="1.7" fill="currentColor" opacity="0.55" />
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Lazy-loaded pages — explicit imports for proper Vite code-splitting
// ---------------------------------------------------------------------------

const Dashboard = lazy(() => import('./pages/Dashboard'));
const Projects = lazy(() => import('./pages/Projects'));
const ScanConfig = lazy(() => import('./pages/ScanConfig'));
const ScanProgress = lazy(() => import('./pages/ScanProgress'));
const Scans = lazy(() => import('./pages/Scans'));
const Findings = lazy(() => import('./pages/Findings'));
const FindingDetail = lazy(() => import('./pages/FindingDetail'));
const Coverage = lazy(() => import('./pages/Coverage'));
const Reports = lazy(() => import('./pages/Reports'));
const LLMProviders = lazy(() => import('./pages/LLMProviders'));
const Insights = lazy(() => import('./pages/Insights'));
const Integrations = lazy(() => import('./pages/Integrations'));
const EmailIntegration = lazy(() => import('./pages/EmailIntegration'));

// ---------------------------------------------------------------------------
// Navigation definition
// ---------------------------------------------------------------------------

interface NavItem {
  label: string;
  to: string;
  icon: React.ElementType;
  end?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard', to: '/', icon: LayoutDashboard, end: true },
  { label: 'Projects', to: '/projects', icon: FolderGit2 },
  { label: 'Findings', to: '/findings', icon: AlertTriangle },
  { label: 'Reports', to: '/reports', icon: FileText },
  { label: 'Insights', to: '/insights', icon: Lightbulb },
];

// ---------------------------------------------------------------------------
// Sidebar
// ---------------------------------------------------------------------------

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

function Sidebar({ mobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <aside
      className={`glass-panel fixed inset-y-0 left-0 z-40 flex w-72 md:w-64 flex-col border-r border-border transform transition-transform duration-200 ease-out md:translate-x-0 ${
        mobileOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
      aria-label="Primary"
    >
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 px-5 border-b border-border">
        <div className="flex h-9 w-9 items-center justify-center rounded-md border border-accent/30 bg-accent/10 text-accent">
          <BrandMark className="h-5 w-5" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="text-sm font-bold text-text-primary tracking-tight">
            Trace<span className="text-accent">ON</span>
          </span>
          <span className="text-[10px] uppercase tracking-[0.16em] text-text-secondary font-mono">
            Security Scanner
          </span>
        </div>
      </div>

      {/* Primary nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <p className="nav-label">Main</p>
        {NAV_ITEMS.map(({ label, to, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            onClick={onCloseMobile}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? 'active' : ''}`
            }
          >
            <Icon className="h-[18px] w-[18px] flex-shrink-0" />
            <span className="text-sm">{label}</span>
          </NavLink>
        ))}

        <div className="my-4 border-t border-border" />

        <p className="nav-label">Tools</p>

        <NavLink
          to="/scans"
          onClick={onCloseMobile}
          className={({ isActive }) =>
            `sidebar-link ${isActive ? 'active' : ''}`
          }
        >
          <Eye className="h-[18px] w-[18px] flex-shrink-0" />
          <span className="text-sm">Scan Monitor</span>
        </NavLink>

        <NavLink
          to="/coverage"
          onClick={onCloseMobile}
          className={({ isActive }) =>
            `sidebar-link ${isActive ? 'active' : ''}`
          }
        >
          <BarChart3 className="h-[18px] w-[18px] flex-shrink-0" />
          <span className="text-sm">Coverage</span>
        </NavLink>

        <NavLink
          to="/tools/llm"
          onClick={onCloseMobile}
          className={({ isActive }) =>
            `sidebar-link ${isActive ? 'active' : ''}`
          }
        >
          <Bot className="h-[18px] w-[18px] flex-shrink-0" />
          <span className="text-sm">LLM</span>
        </NavLink>

        <NavLink
          to="/tools/integrations"
          onClick={onCloseMobile}
          className={({ isActive }) =>
            `sidebar-link ${isActive ? 'active' : ''}`
          }
        >
          <Blocks className="h-[18px] w-[18px] flex-shrink-0" />
          <span className="text-sm">Integrations</span>
        </NavLink>
      </nav>

      {/* Footer */}
      <div className="flex items-center gap-2 border-t border-border px-5 py-3">
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-accent" />
        </span>
        <p className="font-mono text-[10px] tracking-wide text-text-secondary">
          v1.0.0 · online
        </p>
      </div>
    </aside>
  );
}

// ---------------------------------------------------------------------------
// Page loading spinner
// ---------------------------------------------------------------------------

function PageLoader() {
  return (
    <div className="flex items-center justify-center h-full">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-accent border-t-transparent" />
    </div>
  );
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------

export default function App() {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [isDark, setIsDark] = useState(true);
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);

  useEffect(() => {
    getCurrentUser()
      .then(setCurrentUser)
      .catch(() => setCurrentUser(null));
  }, []);

  // Prefer the CP identity (email), fall back to the user label/id.
  const userDisplay =
    currentUser?.cp_email || currentUser?.label || currentUser?.id || '';

  useEffect(() => {
    const stored = window.localStorage.getItem('dt_theme');
    // Dark glassmorphism is the default; only honour an explicit 'light' choice.
    const shouldUseDark = stored ? stored === 'dark' : true;
    document.documentElement.classList.toggle('dark', shouldUseDark);
    setIsDark(shouldUseDark);
  }, []);

  const toggleTheme = () => {
    const nextDark = !isDark;
    document.documentElement.classList.toggle('dark', nextDark);
    window.localStorage.setItem('dt_theme', nextDark ? 'dark' : 'light');
    setIsDark(nextDark);
  };

  return (
    <ApiKeyGate>
    <BrowserRouter>
      <div className="flex min-h-screen bg-background overflow-x-hidden">
        {mobileSidebarOpen && (
          <button
            className="fixed inset-0 z-30 bg-black/50 backdrop-blur-[1px] md:hidden"
            aria-label="Close navigation menu"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}

        <Sidebar
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        {/* Main content area offset by sidebar width */}
        <main className="flex-1 min-w-0 w-full flex flex-col min-h-screen md:ml-64">
          <header className="glass-panel sticky top-0 z-20 flex h-14 items-center justify-between border-b border-border px-4 md:hidden">
            <button
              type="button"
              className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover"
              aria-label="Open navigation menu"
              onClick={() => setMobileSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </button>
            <span className="flex items-center gap-2 text-sm font-bold tracking-tight text-text-primary">
              <span className="text-accent">
                <BrandMark className="h-5 w-5" />
              </span>
              Trace<span className="text-accent">ON</span>
            </span>
            <button
              type="button"
              className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover"
              aria-label={isDark ? 'Switch to light theme' : 'Switch to dark theme'}
              onClick={toggleTheme}
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </header>

          <div className="mx-auto hidden w-full max-w-7xl items-center justify-end gap-2 px-6 pt-4 md:flex">
            {userDisplay && (
              <span
                className="inline-flex h-9 max-w-[16rem] items-center gap-2 rounded-md border border-border px-3 text-xs font-medium text-text-secondary"
                title={userDisplay}
              >
                <UserCircle2 className="h-4 w-4 shrink-0 text-accent" />
                <span className="truncate">{userDisplay}</span>
              </span>
            )}
            <button
              type="button"
              className="inline-flex h-9 items-center gap-2 rounded-md border border-border px-3 text-xs font-medium text-text-secondary hover:text-text-primary hover:bg-surface-hover"
              aria-label={isDark ? 'Switch to light theme' : 'Switch to dark theme'}
              onClick={toggleTheme}
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              {isDark ? 'Light' : 'Dark'}
            </button>
          </div>

          <div className="mx-auto w-full max-w-7xl flex-1 p-4 md:p-6">
            <Suspense fallback={<PageLoader />}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/projects" element={<Projects />} />
                <Route path="/projects/:projectId/scan" element={<ScanConfig />} />
                <Route path="/scans" element={<Scans />} />
                <Route
                  path="/scans/:scanId"
                  element={<ScanProgress />}
                />
                <Route
                  path="/scans/:scanId/progress"
                  element={<ScanProgress />}
                />
                <Route path="/findings" element={<Findings />} />
                <Route path="/findings/:findingId" element={<FindingDetail />} />
                <Route
                  path="/coverage"
                  element={<Coverage />}
                />
                <Route path="/tools/llm" element={<LLMProviders />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/insights" element={<Insights />} />
                <Route path="/tools/integrations" element={<Integrations />} />
                <Route path="/tools/integrations/email" element={<EmailIntegration />} />

                {/* Catch-all */}
                <Route
                  path="*"
                  element={
                    <div className="flex flex-col items-center justify-center h-full gap-2">
                      <h1 className="text-2xl font-bold text-text-primary">
                        404
                      </h1>
                      <p className="text-text-secondary text-sm">
                        Page not found
                      </p>
                    </div>
                  }
                />
              </Routes>
            </Suspense>
          </div>
        </main>
      </div>
    </BrowserRouter>
    </ApiKeyGate>
  );
}
