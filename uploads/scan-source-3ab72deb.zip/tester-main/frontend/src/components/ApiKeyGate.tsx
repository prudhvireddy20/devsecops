import { useState, type ReactNode, useEffect } from 'react';
import { KeyRound, AlertCircle, Loader2 } from 'lucide-react';
import { getApiKey, setApiKey } from '../services/api';

function BrandMark({ className = 'h-7 w-7' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M4 22 L11.5 22 L16 9 L20.5 22 L28 22"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="9" r="2.6" fill="currentColor" />
      <circle cx="4" cy="22" r="1.7" fill="currentColor" opacity="0.55" />
      <circle cx="28" cy="22" r="1.7" fill="currentColor" opacity="0.55" />
    </svg>
  );
}

interface ApiKeyGateProps {
  children: ReactNode;
}

export default function ApiKeyGate({ children }: ApiKeyGateProps) {
  const [hasKey, setHasKey] = useState(() => !!getApiKey());
  const [checking, setChecking] = useState(true);
  const [input, setInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (hasKey) {
      setChecking(false);
      return;
    }
    fetch('/api/v1/users/me', { credentials: 'include' })
      .then((r) => { if (r.ok) setHasKey(true); })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, [hasKey]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  if (hasKey) {
    return <>{children}</>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) {
      setError('Please enter an API key.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/v1/dashboard/stats', {
        headers: { 'X-API-Key': trimmed },
      });

      if (res.ok) {
        setApiKey(trimmed);
        setHasKey(true);
      } else if (res.status === 401 || res.status === 403) {
        setError('Invalid API key. Check the key and try again.');
      } else {
        setError(`Unexpected response (HTTP ${res.status}). Is the backend running?`);
      }
    } catch {
      setError('Cannot reach the backend. Is the server running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-accent/30 bg-accent/10 text-accent">
            <BrandMark className="h-8 w-8" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-text-primary">
            Trace<span className="text-accent">ON</span>
          </h1>
          <p className="text-sm text-text-secondary text-center max-w-xs">
            Enter your API key to access the dashboard. You can find it in the
            backend startup logs.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card space-y-4">
          <label className="block">
            <span className="text-sm font-medium text-text-primary flex items-center gap-2">
              <KeyRound className="h-4 w-4" />
              API Key
            </span>
            <input
              type="password"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Paste your API key here"
              autoFocus
              className="mt-2 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
            />
          </label>

          {error && (
            <div className="flex items-start gap-2 rounded-md bg-critical/10 px-3 py-2 text-sm text-critical">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Validating...
              </>
            ) : (
              'Connect'
            )}
          </button>
        </form>

        <p className="text-xs text-text-secondary text-center">
          Check the server logs for the auto-generated key.
        </p>
      </div>
    </div>
  );
}
