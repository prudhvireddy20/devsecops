import { useRef, useCallback, useEffect } from "react";
import Editor, { type OnMount } from "@monaco-editor/react";
import type { editor } from "monaco-editor";

export interface CodeFinding {
  line: number;
  severity: "critical" | "high" | "medium" | "low" | "info";
  message: string;
}

interface CodeViewerProps {
  code: string;
  language: string;
  findings?: CodeFinding[];
}

const SEVERITY_COLORS: Record<string, { glyph: string; lineClass: string }> = {
  critical: {
    glyph: "finding-glyph-critical",
    lineClass: "finding-line-critical",
  },
  high: {
    glyph: "finding-glyph-high",
    lineClass: "finding-line-high",
  },
  medium: {
    glyph: "finding-glyph-medium",
    lineClass: "finding-line-medium",
  },
  low: {
    glyph: "finding-glyph-low",
    lineClass: "finding-line-low",
  },
  info: {
    glyph: "finding-glyph-info",
    lineClass: "finding-line-info",
  },
};

/** Inject CSS rules for glyph margin markers and line highlights. */
function injectDecorationStyles(): void {
  const styleId = "code-viewer-finding-styles";
  if (document.getElementById(styleId)) return;

  const style = document.createElement("style");
  style.id = styleId;
  style.textContent = `
    /* Critical / High – red tones */
    .finding-glyph-critical,
    .finding-glyph-high {
      background-color: #ef4444;
      border-radius: 50%;
      margin-left: 5px;
      width: 10px !important;
      height: 10px !important;
      margin-top: 5px;
    }
    .finding-line-critical,
    .finding-line-high {
      background-color: rgba(239, 68, 68, 0.12);
    }

    /* Medium – yellow / amber */
    .finding-glyph-medium {
      background-color: #f59e0b;
      border-radius: 50%;
      margin-left: 5px;
      width: 10px !important;
      height: 10px !important;
      margin-top: 5px;
    }
    .finding-line-medium {
      background-color: rgba(245, 158, 11, 0.10);
    }

    /* Low – orange */
    .finding-glyph-low {
      background-color: #fb923c;
      border-radius: 50%;
      margin-left: 5px;
      width: 10px !important;
      height: 10px !important;
      margin-top: 5px;
    }
    .finding-line-low {
      background-color: rgba(251, 146, 60, 0.08);
    }

    /* Info – blue */
    .finding-glyph-info {
      background-color: #3b82f6;
      border-radius: 50%;
      margin-left: 5px;
      width: 10px !important;
      height: 10px !important;
      margin-top: 5px;
    }
    .finding-line-info {
      background-color: rgba(59, 130, 246, 0.08);
    }
  `;
  document.head.appendChild(style);
}

export default function CodeViewer({
  code,
  language,
  findings = [],
}: CodeViewerProps) {
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  const decorationsRef = useRef<editor.IEditorDecorationsCollection | null>(
    null
  );

  const applyDecorations = useCallback(
    (ed: editor.IStandaloneCodeEditor) => {
      if (!findings.length) {
        decorationsRef.current?.clear();
        return;
      }

      const decorations: editor.IModelDeltaDecoration[] = findings.map((f) => {
        const severity = SEVERITY_COLORS[f.severity] ?? SEVERITY_COLORS.info;
        return {
          range: {
            startLineNumber: f.line,
            startColumn: 1,
            endLineNumber: f.line,
            endColumn: 1,
          },
          options: {
            isWholeLine: true,
            glyphMarginClassName: severity.glyph,
            className: severity.lineClass,
            glyphMarginHoverMessage: { value: `**[${f.severity.toUpperCase()}]** ${f.message}` },
            hoverMessage: { value: f.message },
          },
        };
      });

      if (decorationsRef.current) {
        decorationsRef.current.clear();
      }
      decorationsRef.current = ed.createDecorationsCollection(decorations);
    },
    [findings]
  );

  const handleMount: OnMount = (editor) => {
    injectDecorationStyles();
    editorRef.current = editor;
    applyDecorations(editor);
  };

  // Re-apply decorations when findings change after mount
  useEffect(() => {
    if (editorRef.current) {
      applyDecorations(editorRef.current);
    }
  }, [applyDecorations]);

  return (
    <div className="w-full h-full min-h-[300px] rounded-lg overflow-hidden border border-gray-700">
      <Editor
        value={code}
        language={language}
        theme="vs-dark"
        options={{
          readOnly: true,
          lineNumbers: "on",
          minimap: { enabled: true },
          glyphMargin: true,
          scrollBeyondLastLine: false,
          fontSize: 13,
          fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Menlo, monospace",
          renderLineHighlight: "all",
          wordWrap: "on",
          padding: { top: 8 },
          domReadOnly: true,
          contextmenu: false,
        }}
        onMount={handleMount}
      />
    </div>
  );
}
