import { useMemo } from "react";

interface DataFlowDiagramProps {
  /**
   * A textual data-flow description such as:
   *   "request.form['id'] -> user_id -> db.execute()"
   *
   * Nodes are separated by " -> ". The first node is the source,
   * the last is the sink, and everything in between is intermediate.
   */
  dataFlow: string;
}

interface FlowNode {
  label: string;
  role: "source" | "intermediate" | "sink";
}

const ROLE_STYLES: Record<FlowNode["role"], string> = {
  source:
    "bg-green-500/10 border-green-500/40 text-green-300 shadow-green-500/5",
  intermediate:
    "bg-gray-500/10 border-gray-500/30 text-gray-300 shadow-gray-500/5",
  sink:
    "bg-red-500/10 border-red-500/40 text-red-300 shadow-red-500/5",
};

const ROLE_LABELS: Record<FlowNode["role"], string> = {
  source: "Source",
  intermediate: "Transform",
  sink: "Sink",
};

const ROLE_DOT: Record<FlowNode["role"], string> = {
  source: "bg-green-400",
  intermediate: "bg-gray-400",
  sink: "bg-red-400",
};

function parseFlow(dataFlow: string): FlowNode[] | null {
  if (!dataFlow || typeof dataFlow !== "string") return null;

  const parts = dataFlow
    .split(/\s*->\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (parts.length < 2) return null;

  return parts.map((label, idx) => {
    let role: FlowNode["role"] = "intermediate";
    if (idx === 0) role = "source";
    else if (idx === parts.length - 1) role = "sink";
    return { label, role };
  });
}

function Arrow() {
  return (
    <div className="flex flex-col items-center justify-center px-1 text-gray-600 select-none shrink-0">
      {/* Horizontal arrow using SVG for crisp rendering */}
      <svg
        width="40"
        height="16"
        viewBox="0 0 40 16"
        fill="none"
        className="text-gray-500"
      >
        <path
          d="M0 8H34M34 8L28 2M34 8L28 14"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}

function NodeBox({ node }: { node: FlowNode }) {
  const style = ROLE_STYLES[node.role];
  const dot = ROLE_DOT[node.role];
  const roleLabel = ROLE_LABELS[node.role];

  return (
    <div
      className={`relative flex flex-col items-start rounded-lg border px-4 py-3 shadow-md min-w-[120px] max-w-[260px] ${style}`}
    >
      {/* Role pill */}
      <span className="mb-1.5 inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider opacity-70">
        <span className={`inline-block h-1.5 w-1.5 rounded-full ${dot}`} />
        {roleLabel}
      </span>

      {/* Node label */}
      <span className="break-all font-mono text-sm leading-snug">
        {node.label}
      </span>
    </div>
  );
}

export default function DataFlowDiagram({ dataFlow }: DataFlowDiagramProps) {
  const nodes = useMemo(() => parseFlow(dataFlow), [dataFlow]);

  // Fallback: display raw text when parsing fails
  if (!nodes) {
    return (
      <div className="rounded-lg border border-gray-700 bg-gray-800/50 px-4 py-3">
        <p className="mb-1 text-xs font-medium uppercase tracking-wider text-gray-500">
          Data Flow
        </p>
        <pre className="whitespace-pre-wrap break-all font-mono text-sm text-gray-300">
          {dataFlow || "No data flow information available."}
        </pre>
      </div>
    );
  }

  return (
    <div className="w-full space-y-2">
      <p className="text-xs font-medium uppercase tracking-wider text-gray-500">
        Data Flow
      </p>

      {/* Horizontal layout */}
      <div className="flex items-center gap-0 overflow-x-auto py-2">
        {nodes.map((node, idx) => (
          <div key={idx} className="flex items-center shrink-0">
            {idx > 0 && <Arrow />}
            <NodeBox node={node} />
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 pt-1 text-[11px] text-gray-500">
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-green-400" />
          Source
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-gray-400" />
          Transform
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-red-400" />
          Sink
        </span>
      </div>
    </div>
  );
}
