import type { Confidence } from '../services/api';

interface FindingConfidenceBadgeProps {
  confidence: Confidence | string;
}

const CONFIDENCE_CLASS: Record<string, string> = {
  verified: 'badge-verified',
  probable: 'badge-probable',
  observed: 'badge-observed',
};

export default function FindingConfidenceBadge({ confidence }: FindingConfidenceBadgeProps) {
  const label = String(confidence).replace(/_/g, ' ');
  return <span className={CONFIDENCE_CLASS[confidence] ?? 'badge-observed'}>{label}</span>;
}
