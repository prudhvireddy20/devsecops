import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';

interface PageHeaderProps {
  icon: LucideIcon;
  title: string;
  subtitle?: ReactNode;
  /** Optional item count shown as a pill next to the title. */
  count?: number;
  /** Right-aligned actions (buttons, selects). Stack full-width on mobile. */
  actions?: ReactNode;
}

/**
 * Standard page header: brand-tinted icon chip (echoes the sidebar logo),
 * title + optional count pill, subtitle, and a responsive actions slot.
 */
export default function PageHeader({ icon: Icon, title, subtitle, count, actions }: PageHeaderProps) {
  return (
    <div className="animate-enter flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-accent/25 bg-accent/10 text-accent">
          <Icon className="h-5 w-5" aria-hidden="true" />
        </div>
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-text-primary">{title}</h1>
            {typeof count === 'number' && (
              <span className="rounded-full border border-border bg-surface px-2 py-0.5 font-mono text-xs tabular-nums text-text-secondary">
                {count}
              </span>
            )}
          </div>
          {subtitle && <p className="mt-0.5 text-sm text-text-secondary">{subtitle}</p>}
        </div>
      </div>
      {actions && (
        <div className="flex w-full flex-col items-stretch gap-2 sm:w-auto sm:flex-row sm:items-center sm:gap-3">
          {actions}
        </div>
      )}
    </div>
  );
}
