import { useState, useMemo } from "react";
import { Lock, Unlock, Search, ArrowUpDown } from "lucide-react";

export interface RouteEntry {
  path: string;
  method: "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | string;
  auth_required: boolean;
  function: string;
  file: string;
}

interface RouteGraphProps {
  routes: RouteEntry[];
}

type SortField = "path" | "method" | "auth_required" | "function" | "file";
type SortDir = "asc" | "desc";

const METHOD_BADGE: Record<string, string> = {
  GET: "bg-green-500/15 text-green-400 border-green-500/30",
  POST: "bg-blue-500/15 text-blue-400 border-blue-500/30",
  PUT: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
  DELETE: "bg-red-500/15 text-red-400 border-red-500/30",
  PATCH: "bg-purple-500/15 text-purple-400 border-purple-500/30",
};

function methodBadgeClass(method: string): string {
  return METHOD_BADGE[method.toUpperCase()] ?? "bg-gray-500/15 text-gray-400 border-gray-500/30";
}

export default function RouteGraph({ routes }: RouteGraphProps) {
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<SortField>("path");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    let result = routes;

    if (q) {
      result = routes.filter(
        (r) =>
          r.path.toLowerCase().includes(q) ||
          r.method.toLowerCase().includes(q) ||
          r.function.toLowerCase().includes(q) ||
          r.file.toLowerCase().includes(q)
      );
    }

    const sorted = [...result].sort((a, b) => {
      let cmp = 0;
      const fa = a[sortField];
      const fb = b[sortField];

      if (typeof fa === "boolean" && typeof fb === "boolean") {
        cmp = fa === fb ? 0 : fa ? -1 : 1;
      } else {
        cmp = String(fa).localeCompare(String(fb));
      }

      return sortDir === "asc" ? cmp : -cmp;
    });

    return sorted;
  }, [routes, search, sortField, sortDir]);

  const columnHeaders: { label: string; field: SortField }[] = [
    { label: "Method", field: "method" },
    { label: "Path", field: "path" },
    { label: "Auth", field: "auth_required" },
    { label: "Function", field: "function" },
    { label: "File", field: "file" },
  ];

  return (
    <div className="w-full space-y-3">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
        <input
          type="text"
          placeholder="Filter routes…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-lg border border-gray-700 bg-gray-800 py-2 pl-9 pr-3 text-sm text-gray-200 placeholder-gray-500 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-gray-700">
        <table className="min-w-full divide-y divide-gray-700 text-sm">
          <thead className="bg-gray-800/60">
            <tr>
              {columnHeaders.map((col) => (
                <th
                  key={col.field}
                  className="px-4 py-3 text-left font-medium text-gray-400 select-none cursor-pointer hover:text-gray-200 transition-colors"
                  onClick={() => toggleSort(col.field)}
                >
                  <span className="inline-flex items-center gap-1">
                    {col.label}
                    <ArrowUpDown
                      className={`h-3 w-3 ${
                        sortField === col.field
                          ? "text-blue-400"
                          : "text-gray-600"
                      }`}
                    />
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700/50 bg-gray-900/40">
            {filtered.length === 0 ? (
              <tr>
                <td
                  colSpan={5}
                  className="px-4 py-8 text-center text-gray-500"
                >
                  {search ? "No routes match the filter." : "No routes available."}
                </td>
              </tr>
            ) : (
              filtered.map((route, idx) => (
                <tr
                  key={`${route.method}-${route.path}-${idx}`}
                  className="hover:bg-gray-800/40 transition-colors"
                >
                  {/* Method */}
                  <td className="whitespace-nowrap px-4 py-2.5">
                    <span
                      className={`inline-block rounded border px-2 py-0.5 text-xs font-bold uppercase tracking-wide ${methodBadgeClass(
                        route.method
                      )}`}
                    >
                      {route.method.toUpperCase()}
                    </span>
                  </td>

                  {/* Path */}
                  <td className="px-4 py-2.5 font-mono text-gray-200">
                    {route.path}
                  </td>

                  {/* Auth */}
                  <td className="px-4 py-2.5">
                    {route.auth_required ? (
                      <span className="inline-flex items-center gap-1 text-yellow-400">
                        <Lock className="h-3.5 w-3.5" />
                        <span className="text-xs">Required</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-gray-500">
                        <Unlock className="h-3.5 w-3.5" />
                        <span className="text-xs">Open</span>
                      </span>
                    )}
                  </td>

                  {/* Function */}
                  <td className="px-4 py-2.5 font-mono text-sm text-blue-400">
                    {route.function}
                  </td>

                  {/* File */}
                  <td className="px-4 py-2.5 text-gray-400 truncate max-w-[240px]" title={route.file}>
                    {route.file}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer count */}
      <p className="text-xs text-gray-500">
        Showing {filtered.length} of {routes.length} route{routes.length !== 1 ? "s" : ""}
      </p>
    </div>
  );
}
