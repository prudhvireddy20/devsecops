import type { Severity } from '../services/api';

interface SeverityBadgeProps {
  severity: Severity | string;
}

const SEVERITY_CLASS: Record<string, string> = {
  critical: 'badge-critical',
  high: 'badge-high',
  medium: 'badge-medium',
  low: 'badge-low',
  info: 'badge-info',
};

export default function SeverityBadge({ severity }: SeverityBadgeProps) {
  const label = String(severity).replace(/_/g, ' ');
  return <span className={SEVERITY_CLASS[severity] ?? 'badge-info'}>{label}</span>;
}
