import { CheckCircle2, Clock, Loader2, XCircle } from 'lucide-react';
import type { ReactNode } from 'react';

type ScanStatusLike = 'completed' | 'running' | 'pending' | 'failed' | 'cancelled' | string;

interface StatusBadgeProps {
  status: ScanStatusLike;
}

const STATUS_CLASS: Record<string, string> = {
  completed: 'badge-low',
  running: 'badge-info',
  pending: 'badge-medium',
  failed: 'badge-critical',
  cancelled: 'badge-high',
};

const STATUS_ICON: Record<string, ReactNode> = {
  completed: <CheckCircle2 size={12} />,
  running: <Loader2 size={12} className="animate-spin" />,
  pending: <Clock size={12} />,
  failed: <XCircle size={12} />,
  cancelled: <XCircle size={12} />,
};

export default function StatusBadge({ status }: StatusBadgeProps) {
  const label = String(status).replace(/_/g, ' ');
  return (
    <span className={`${STATUS_CLASS[status] ?? 'badge-info'} flex items-center gap-1`}>
      {STATUS_ICON[status]}
      {label}
    </span>
  );
}
