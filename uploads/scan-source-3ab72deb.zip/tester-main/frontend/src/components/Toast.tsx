import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
import { useEffect } from 'react';

export type ToastTone = 'success' | 'error' | 'info';

interface ToastProps {
  open: boolean;
  message: string;
  tone?: ToastTone;
  onClose: () => void;
  autoHideMs?: number;
}

const TONE_CLASS: Record<ToastTone, string> = {
  success: 'border-low/50 text-low bg-low/10',
  error: 'border-critical/50 text-critical bg-critical/10',
  info: 'border-info/50 text-info bg-info/10',
};

const TONE_ICON = {
  success: CheckCircle2,
  error: AlertTriangle,
  info: Info,
};

export default function Toast({
  open,
  message,
  tone = 'info',
  onClose,
  autoHideMs = 3500,
}: ToastProps) {
  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(onClose, autoHideMs);
    return () => window.clearTimeout(timer);
  }, [open, autoHideMs, onClose]);

  if (!open) return null;

  const Icon = TONE_ICON[tone];
  return (
    <div className="fixed right-4 top-4 z-[100] max-w-sm">
      <div
        className={`rounded-xl border px-3 py-2 shadow-lg backdrop-blur ${TONE_CLASS[tone]}`}
        role="status"
        aria-live="polite"
      >
        <div className="flex items-start gap-2">
          <Icon className="h-4 w-4 shrink-0 mt-0.5" />
          <p className="text-sm leading-snug flex-1">{message}</p>
          <button
            type="button"
            className="text-current/80 hover:text-current"
            onClick={onClose}
            aria-label="Close notification"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
