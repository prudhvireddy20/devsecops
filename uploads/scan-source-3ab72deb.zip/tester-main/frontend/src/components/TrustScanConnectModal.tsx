import { useState, useEffect } from 'react';
import { Loader2, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { getApiKey } from '../services/api';

interface TrustScanConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnected?: (token: string, baseUrl: string, state: string) => void;
}

/**
 * Modal that handles OAuth connection to TrustScan Platform.
 *
 * Flow:
 * 1. Modal opens → calls POST /api/v1/trustscan/oauth/initiate (no project needed)
 * 2. Opens TrustScan authorize page in a popup
 * 3. User approves access
 * 4. OAuth callback closes the popup and stores token in server memory
 * 5. Frontend polls GET /oauth/status/{state} until completed
 * 6. Calls onConnected(token, baseUrl, state) so parent can list jobs / create project
 */
export default function TrustScanConnectModal({
  isOpen,
  onClose,
  onConnected,
}: TrustScanConnectModalProps) {
  const [status, setStatus] = useState<'idle' | 'initiating' | 'authorizing' | 'completed' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const apiKey = getApiKey();

  useEffect(() => {
    if (!isOpen) {
      setStatus('idle');
      setError(null);
      return;
    }

    const initiate = async () => {
      setStatus('initiating');
      setError(null);

      try {
        const res = await fetch('/api/v1/trustscan/oauth/initiate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': apiKey || '',
          },
          body: JSON.stringify({}),
        });

        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData.detail || `HTTP ${res.status}`);
        }

        const data = await res.json();
        setStatus('authorizing');

        const popup = window.open(data.authorize_url, '_blank', 'width=600,height=700,noopener');
        if (!popup) {
          throw new Error('Popup blocked. Please enable popups for this page and try again.');
        }

        pollStatus(data.state);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Connection failed');
        setStatus('error');
      }
    };

    initiate();
  }, [isOpen]);

  const pollStatus = (state: string) => {
    const maxAttempts = 150;
    let attempts = 0;

    const poll = async () => {
      try {
        const res = await fetch(`/api/v1/trustscan/oauth/status/${state}`, {
          headers: { 'X-API-Key': apiKey || '' },
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();

        if (data.status === 'completed') {
          setStatus('completed');
          setTimeout(() => {
            onConnected?.(data.token || '', data.base_url || '', state);
            onClose();
          }, 1200);
          return;
        }

        if (data.status === 'failed') {
          throw new Error(data.error || 'Authorization failed');
        }

        attempts += 1;
        if (attempts < maxAttempts) {
          setTimeout(poll, 2000);
        } else {
          throw new Error('Authorization timed out. Please try again.');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Status check failed');
        setStatus('error');
      }
    };

    poll();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4">
      <div className="card w-full max-w-md space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-text-primary">Connect TrustScan Platform</h2>
          <button
            onClick={onClose}
            className="text-text-secondary hover:text-text-primary"
            disabled={status === 'authorizing'}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="min-h-[120px] flex flex-col items-center justify-center gap-3">
          {(status === 'initiating' || status === 'idle') && (
            <>
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
              <p className="text-sm text-text-secondary text-center">Initializing connection...</p>
            </>
          )}

          {status === 'authorizing' && (
            <>
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
              <p className="text-sm text-text-secondary text-center">
                Authorize in the popup window.
              </p>
              <p className="text-xs text-text-tertiary text-center">
                If no popup appeared, check your browser's popup settings.
              </p>
            </>
          )}

          {status === 'completed' && (
            <>
              <CheckCircle2 className="h-8 w-8 text-accent" />
              <p className="text-sm text-text-secondary text-center">Connected successfully!</p>
            </>
          )}

          {status === 'error' && (
            <>
              <AlertCircle className="h-8 w-8 text-critical" />
              <div className="text-center">
                <p className="text-sm font-medium text-critical">{error}</p>
                <button
                  onClick={() => {
                    setStatus('idle');
                    setError(null);
                  }}
                  className="text-xs text-accent hover:underline mt-2"
                >
                  Try again
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
