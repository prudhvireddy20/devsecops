import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// Self-hosted fonts — bundled to same-origin assets so they pass the
// backend Content-Security-Policy (font-src 'self'); no external requests.
import '@fontsource-variable/inter';
import '@fontsource-variable/jetbrains-mono';
import './styles/globals.css';

// TEMP DEBUG (remove after testing): surface the CP launch identity from the
// SSO redirect fragment, then clear it from the URL.
try {
  const _m = /__cp_debug=([^&]+)/.exec(window.location.hash);
  if (_m) {
    const _b64 = decodeURIComponent(_m[1]).replace(/-/g, '+').replace(/_/g, '/');
    // eslint-disable-next-line no-console
    console.log('[CP DEBUG] TrustMatrix launch identity:', JSON.parse(atob(_b64)));
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
  }
} catch { /* ignore */ }

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
