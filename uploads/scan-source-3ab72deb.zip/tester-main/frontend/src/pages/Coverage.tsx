import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Route,
} from 'lucide-react';
import {
  getScanRoutes,
  getScans,
  getFindings,
  type Scan,
  type ScanRoute,
  type Finding,
} from '../services/api';
import PageHeader from '../components/PageHeader';
import { formatDate } from '../utils/datetime';

// ── Component ───────────────────────────────────────────────────────────────

const Coverage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const scanIdParam = searchParams.get('scan_id');

  // Scan selector
  const [scans, setScans] = useState<Scan[]>([]);
  const [selectedScanId, setSelectedScanId] = useState(scanIdParam || '');
  const isInitialMount = useRef(true);

  // Coverage data
  const [routes, setRoutes] = useState<ScanRoute[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch available scans for the selector
  useEffect(() => {
    getScans({ status: 'completed', page_size: 50 })
      .then((res) => {
        setScans(res.items);
        if (!selectedScanId && res.items.length > 0) {
          setSelectedScanId(res.items[0].id);
        }
      })
      .catch(() => {
        setError('Failed to load completed scans.');
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync selectedScanId to URL
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }
    if (selectedScanId) {
      setSearchParams({ scan_id: selectedScanId }, { replace: true });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedScanId]);

  // Fetch routes / coverage for selected scan
  const fetchCoverage = useCallback(async () => {
    if (!selectedScanId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await getScanRoutes(selectedScanId, { page_size: 500 });
      let loadedRoutes = res.items || [];
      
      // Smart Fallback: If no routes were found by the backend's static analyzer,
      // extract routes dynamically from the scan's findings
      if (loadedRoutes.length === 0) {
        try {
          const findingsRes = await getFindings({ scan_id: selectedScanId, page_size: 1000 });
          const routeMap = new Map<string, ScanRoute>();
          
          findingsRes.items.forEach((f: Finding) => {
            if (!f.endpoint || !f.http_method) return;
            // Clean up the URL to just get the path if it's an absolute URL
            let path = f.endpoint;
            try {
              if (path.startsWith('http')) {
                path = new URL(path).pathname;
              }
            } catch { /* ignore */ }
            
            const method = f.http_method.toUpperCase();
            const key = `${method} ${path}`;
            
            if (!routeMap.has(key)) {
              routeMap.set(key, {
                method,
                path,
                handler: f.vulnerability_type || 'Unknown Handler',
                tested: true, // If we found a finding, it was tested
                finding_count: 1
              });
            } else {
              const route = routeMap.get(key)!;
              route.finding_count++;
            }
          });
          
          loadedRoutes = Array.from(routeMap.values());
        } catch {
          // ignore error in fallback
        }
      }
      
      setRoutes(loadedRoutes);
    } catch {
      setError('Failed to load coverage data');
    } finally {
      setLoading(false);
    }
  }, [selectedScanId]);

  useEffect(() => {
    fetchCoverage();
  }, [fetchCoverage]);

  // Computed stats
  const totalRoutes = routes.length;
  const testedRoutes = routes.filter((r) => r.tested).length;
  const coveragePercent = totalRoutes > 0 ? Math.round((testedRoutes / totalRoutes) * 100) : 0;

  const untestedCritical = routes.filter(
    (r) => !r.tested && r.finding_count > 0,
  );

  // Risk level based on finding count
  const riskLevel = (r: ScanRoute): 'high' | 'medium' | 'low' => {
    if (r.finding_count >= 3) return 'high';
    if (r.finding_count >= 1) return 'medium';
    return 'low';
  };

  const riskBadge = (level: 'high' | 'medium' | 'low') => {
    const map = {
      high: 'badge-critical',
      medium: 'badge-medium',
      low: 'badge-low',
    };
    return <span className={map[level]}>{level}</span>;
  };

  return (
    <div className="space-y-6">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <PageHeader
        icon={ShieldCheck}
        title="Coverage"
        subtitle="Route and endpoint coverage per scan."
        actions={
          <select
            className="select w-full sm:w-64"
            value={selectedScanId}
            onChange={(e) => setSelectedScanId(e.target.value)}
            aria-label="Select scan"
          >
            <option value="" disabled>Select a scan...</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>
                {s.project_name ?? 'Unknown'} — {s.started_at ? formatDate(s.started_at) : 'N/A'}
              </option>
            ))}
          </select>
        }
      />

      {loading ? (
        <div className="space-y-6" aria-busy="true" aria-label="Loading coverage">
          <div className="skeleton h-32 rounded-lg" />
          <div className="skeleton h-72 rounded-lg" />
        </div>
      ) : error ? (
        <div className="card flex items-center gap-3 text-critical">
          <AlertTriangle className="w-5 h-5" />
          <span className="flex-1">{error}</span>
          {selectedScanId && (
            <button type="button" className="btn-secondary text-xs" onClick={fetchCoverage}>
              Retry
            </button>
          )}
        </div>
      ) : !selectedScanId ? (
        <div className="card text-center py-16">
          <Route className="w-12 h-12 text-text-secondary mx-auto mb-4" />
          <p className="text-text-secondary">Select a scan to view coverage data.</p>
        </div>
      ) : (
        <>
          {/* ── Coverage percentage bar ────────────────────────────────── */}
          <div className="card">
            <div className="flex items-end justify-between mb-4">
              <div>
                <p className="text-sm text-text-secondary">Route Coverage</p>
                <p className="text-4xl font-bold text-text-primary mt-1">
                  {coveragePercent}%
                </p>
              </div>
              <p className="text-sm text-text-secondary">
                {testedRoutes} / {totalRoutes} routes tested
              </p>
            </div>
            <div className="w-full h-6 bg-background rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-accent transition-all duration-1000 ease-out"
                style={{ width: `${coveragePercent}%` }}
              />
            </div>
          </div>

          {/* ── Untested critical paths ────────────────────────────────── */}
          {untestedCritical.length > 0 && (
            <div className="card border-critical/30">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-critical uppercase tracking-wider mb-4">
                <AlertTriangle className="w-4 h-4" />
                Untested Critical Code Paths ({untestedCritical.length})
              </h2>
              <div className="space-y-2">
                {untestedCritical.map((r) => (
                  <div
                    key={`${r.method}-${r.path}`}
                    className="flex items-center justify-between p-3 bg-background rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold text-critical">{r.method}</span>
                      <span className="font-mono text-sm text-text-primary">{r.path}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-text-secondary">
                        {r.finding_count} finding{r.finding_count > 1 ? 's' : ''}
                      </span>
                      {riskBadge('high')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Routes table ──────────────────────────────────────────── */}
          <div className="card p-0 overflow-hidden">
            <div className="px-6 py-4 border-b border-border">
              <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
                All Routes
              </h2>
            </div>

            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Method</th>
                    <th>Path</th>
                    <th>Handler</th>
                    <th>Tested</th>
                    <th>Risk Level</th>
                    <th className="text-right">Findings</th>
                  </tr>
                </thead>
                <tbody>
                  {routes.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-12 text-text-secondary">
                        No routes discovered.
                      </td>
                    </tr>
                  ) : (
                    routes.map((r) => (
                      <tr key={`${r.method}-${r.path}`}>
                        <td>
                          <span className="font-mono text-xs font-bold text-accent">
                            {r.method}
                          </span>
                        </td>
                        <td className="font-mono text-xs">{r.path}</td>
                        <td className="text-xs text-text-secondary truncate max-w-[200px]">
                          {r.handler}
                        </td>
                        <td>
                          {r.tested ? (
                            <CheckCircle2 className="w-4 h-4 text-accent" aria-label="Tested" />
                          ) : (
                            <XCircle className="w-4 h-4 text-text-secondary/50" aria-label="Not tested" />
                          )}
                        </td>
                        <td>{riskBadge(riskLevel(r))}</td>
                        <td className="text-right font-mono text-xs">
                          {r.finding_count > 0 ? (
                            <span className="text-critical">{r.finding_count}</span>
                          ) : (
                            <span className="text-text-secondary">0</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </>
      )}
    </div>
  );
};

export default Coverage;
