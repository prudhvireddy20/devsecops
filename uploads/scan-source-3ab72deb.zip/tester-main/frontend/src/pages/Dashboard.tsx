import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderOpen,
  ScanSearch,
  AlertTriangle,
  AlertCircle,
  Info,
  ShieldAlert,
  Plus,
  Zap,
  ArrowRight,
} from 'lucide-react';
import {
  getDashboardStats,
  type DashboardStats,
  type Scan,
} from '../services/api';
import StatusBadge from '../components/StatusBadge';
import PageHeader from '../components/PageHeader';
import { formatDateTime } from '../utils/datetime';

// ---------------------------------------------------------------------------
// Severity stat card — links to the filtered view it summarizes
// ---------------------------------------------------------------------------

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  to: string;
}

function StatCard({ label, value, icon, color, bgColor, to }: StatCardProps) {
  return (
    <Link
      to={to}
      className="card card-interactive animate-enter flex items-center gap-4"
      aria-label={`${label}: ${value}`}
    >
      <div className={`flex items-center justify-center w-12 h-12 rounded-lg ring-1 ring-inset ring-black/5 dark:ring-white/5 ${bgColor}`}>
        <span className={color}>{icon}</span>
      </div>
      <div>
        <p className="text-text-secondary text-sm">{label}</p>
        <p className={`text-2xl font-bold tabular-nums ${color}`}>{value}</p>
      </div>
    </Link>
  );
}

// ---------------------------------------------------------------------------
// Loading skeleton mirroring the page layout (header, stat grid, table)
// ---------------------------------------------------------------------------

function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
      <div className="flex items-center gap-3">
        <div className="skeleton h-10 w-10 rounded-md" />
        <div className="space-y-2">
          <div className="skeleton h-6 w-40" />
          <div className="skeleton h-3.5 w-72" />
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton h-[88px] rounded-lg" />
        ))}
      </div>
      <div className="skeleton h-80 rounded-lg" />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Dashboard page
// ---------------------------------------------------------------------------

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = async () => {
    try {
      const data = await getDashboardStats();
      setStats(data);
      setError(null);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to load dashboard';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      try {
        const data = await getDashboardStats();
        if (cancelled) return;
        setStats(data);
        setError(null);
      } catch (err: unknown) {
        if (cancelled) return;
        const message = err instanceof Error ? err.message : 'Failed to load dashboard';
        setError(message);
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void run();
    return () => { cancelled = true; };
  }, []);

  const retryLoad = () => {
    setLoading(true);
    void loadDashboard();
  };

  if (loading) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-32 gap-4">
        <AlertCircle size={48} className="text-critical" />
        <p className="text-text-secondary">{error}</p>
        <button className="btn-primary" onClick={retryLoad}>
          Retry
        </button>
      </div>
    );
  }

  if (!stats) return null;

  const severity = stats.finding_summary ?? {
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    info: 0,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        icon={LayoutDashboard}
        title="Dashboard"
        subtitle="Security posture across your projects at a glance."
        actions={
          <>
            <button
              className="btn-primary flex w-full items-center justify-center gap-2 sm:w-auto"
              onClick={() => navigate('/projects?new=1')}
            >
              <Plus size={16} />
              New Project
            </button>
            <button
              className="btn-secondary flex w-full items-center justify-center gap-2 sm:w-auto"
              onClick={() => navigate('/scans')}
            >
              <Zap size={16} />
              View Scans
            </button>
          </>
        }
      />

      {/* Top-level stat cards — each links to its filtered view */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          label="Total Projects"
          value={stats.total_projects}
          icon={<FolderOpen size={24} />}
          color="text-accent"
          bgColor="bg-accent/10"
          to="/projects"
        />
        <StatCard
          label="Total Scans"
          value={stats.total_scans}
          icon={<ScanSearch size={24} />}
          color="text-info"
          bgColor="bg-info/10"
          to="/scans"
        />
        <StatCard
          label="Critical"
          value={severity.critical ?? 0}
          icon={<ShieldAlert size={24} />}
          color="text-critical"
          bgColor="bg-critical/10"
          to="/findings?severity=critical"
        />
        <StatCard
          label="High"
          value={severity.high ?? 0}
          icon={<AlertTriangle size={24} />}
          color="text-high"
          bgColor="bg-high/10"
          to="/findings?severity=high"
        />
        <StatCard
          label="Medium"
          value={severity.medium ?? 0}
          icon={<AlertCircle size={24} />}
          color="text-medium"
          bgColor="bg-medium/10"
          to="/findings?severity=medium"
        />
        <StatCard
          label="Low"
          value={severity.low ?? 0}
          icon={<Info size={24} />}
          color="text-low"
          bgColor="bg-low/10"
          to="/findings?severity=low"
        />
      </div>

      {/* Recent scans table */}
      <div className="card animate-enter">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-text-primary">Recent Scans</h2>
          <Link to="/scans" className="text-accent hover:text-accent-hover text-sm flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>

        {stats.recent_scans.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-4 py-12">
            <ScanSearch size={40} className="text-text-secondary/50" />
            <p className="text-text-secondary text-sm text-center">
              No scans yet. Start by creating a project and running a scan.
            </p>
            <button
              className="btn-primary flex items-center gap-2"
              onClick={() => navigate('/projects?new=1')}
            >
              <Plus size={16} />
              New Project
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Progress</th>
                  <th>Findings</th>
                  <th>Routes</th>
                  <th>Started</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {stats.recent_scans.map((scan: Scan) => (
                  <tr key={scan.id}>
                    <td className="font-medium text-text-primary">
                      {scan.project_name || scan.project_id.slice(0, 8)}
                    </td>
                    <td>
                      <span className="badge-info">{scan.scan_type}</span>
                    </td>
                    <td>
                      <StatusBadge status={scan.status} />
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-background rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent rounded-full transition-all duration-500"
                            style={{ width: `${scan.progress}%` }}
                          />
                        </div>
                        <span className="text-text-secondary text-xs">{scan.progress}%</span>
                      </div>
                    </td>
                    <td className="text-text-primary">
                      <div>
                        <div>{(scan.results_summary as Record<string, number> | undefined)?.total_findings ?? 0}</div>
                        {scan.scan_mode !== 'blackbox' && (
                          <div className="text-[11px] text-text-secondary">
                            {(scan.results_summary as Record<string, number> | undefined)?.verified ?? 0} verified
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="text-text-primary">{scan.routes_discovered ?? 0}</td>
                    <td className="text-text-secondary text-xs whitespace-nowrap">
                      {formatDateTime(scan.started_at)}
                    </td>
                    <td>
                      <Link
                        to={`/scans/${scan.id}`}
                        className="text-accent hover:text-accent-hover text-sm"
                      >
                        Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
