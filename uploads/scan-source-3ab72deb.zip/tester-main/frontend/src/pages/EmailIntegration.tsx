import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, AlertTriangle, Send, Loader2, Mail } from 'lucide-react';
import Toast, { type ToastTone } from '../components/Toast';
import {
  getEmailIntegration,
  updateEmailIntegration,
  testEmailIntegration,
  type EmailIntegrationConfig,
} from '../services/api';

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function parseRecipients(text: string): { valid: string[]; invalid: string[] } {
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  return {
    valid: lines.filter((l) => EMAIL_RE.test(l)),
    invalid: lines.filter((l) => !EMAIL_RE.test(l)),
  };
}

export default function EmailIntegrationPage() {
  const navigate = useNavigate();
  const [config, setConfig] = useState<EmailIntegrationConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [emailText, setEmailText] = useState('');
  const [enabled, setEnabled] = useState(false);
  const [toast, setToast] = useState<{ message: string; tone: ToastTone } | null>(null);

  useEffect(() => {
    getEmailIntegration()
      .then((cfg) => {
        setConfig(cfg);
        setEmailText(cfg.recipients.join('\n'));
        setEnabled(cfg.enabled);
      })
      .catch((err: unknown) =>
        setToast({
          message: err instanceof Error ? err.message : 'Failed to load email integration',
          tone: 'error',
        }),
      )
      .finally(() => setLoading(false));
  }, []);

  const { valid, invalid } = useMemo(() => parseRecipients(emailText), [emailText]);

  const dirty =
    config !== null &&
    (enabled !== config.enabled || valid.join('\n') !== config.recipients.join('\n'));

  const handleSave = async () => {
    if (invalid.length > 0) {
      setToast({ message: `Invalid email address(es): ${invalid.join(', ')}`, tone: 'error' });
      return;
    }
    setSaving(true);
    try {
      const updated = await updateEmailIntegration({ enabled, recipients: valid });
      setConfig(updated);
      setEmailText(updated.recipients.join('\n'));
      setEnabled(updated.enabled);
      setToast({ message: 'Email integration saved', tone: 'success' });
    } catch (err: unknown) {
      setToast({
        message: err instanceof Error ? err.message : 'Failed to save',
        tone: 'error',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    try {
      const res = await testEmailIntegration();
      setToast({
        message: `Test email sent to ${res.recipients.length} recipient(s)`,
        tone: 'success',
      });
    } catch (err: unknown) {
      setToast({
        message: err instanceof Error ? err.message : 'Test email failed',
        tone: 'error',
      });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6" aria-busy="true">
        <div className="skeleton h-14 w-96 rounded-lg" />
        <div className="skeleton h-72 max-w-2xl rounded-lg" />
      </div>
    );
  }

  const smtpMissing = config !== null && !config.smtp_configured;

  return (
    <div className="space-y-6">
      {toast && (
        <Toast open message={toast.message} tone={toast.tone} onClose={() => setToast(null)} />
      )}

      {/* Header */}
      <div className="flex items-start gap-3">
        <button
          type="button"
          className="flex items-center justify-center w-9 h-9 rounded-full bg-surface ring-1 ring-inset ring-border text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors shrink-0 mt-1"
          onClick={() => navigate('/tools/integrations')}
          aria-label="Back to integrations"
        >
          <ArrowLeft size={16} />
        </button>
        <div className="flex items-center justify-center w-11 h-11 rounded-lg bg-accent/10 text-accent ring-1 ring-inset ring-accent/20 shrink-0">
          <Mail size={20} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Email Integration</h1>
          <p className="text-sm text-text-secondary mt-1">
            Deliver the scan report to your team's inbox after every completed scan.
          </p>
        </div>
      </div>

      {/* SMTP warning */}
      {smtpMissing && (
        <div className="max-w-2xl flex items-start gap-3 rounded-lg border border-medium/40 bg-medium/10 px-4 py-3">
          <AlertTriangle size={18} className="text-medium shrink-0 mt-0.5" />
          <p className="text-sm text-text-secondary">
            <span className="font-medium text-text-primary">SMTP is not configured.</span>{' '}
            Set <code className="font-mono text-xs">SMTP_HOST</code>,{' '}
            <code className="font-mono text-xs">SMTP_USERNAME</code> and{' '}
            <code className="font-mono text-xs">SMTP_PASSWORD</code> environment variables on
            the backend, then restart it. Recipients can be saved now; delivery starts once
            SMTP is configured.
          </p>
        </div>
      )}

      {/* Settings card */}
      <div className="card max-w-2xl p-0 overflow-hidden">
        <div className="p-6 space-y-2">
          <div>
            <label htmlFor="email-list" className="text-sm font-semibold text-text-primary">
              Email List
            </label>
            <p className="text-xs text-text-secondary mt-0.5">Line separated email addresses.</p>
          </div>
          <textarea
            id="email-list"
            className="input min-h-28 font-mono text-sm resize-y"
            placeholder={'security-team@example.com\nlead@example.com'}
            value={emailText}
            onChange={(e) => setEmailText(e.target.value)}
            spellCheck={false}
            autoComplete="off"
          />
          {invalid.length > 0 ? (
            <p className="text-xs text-critical" role="alert">
              Invalid: {invalid.join(', ')}
            </p>
          ) : valid.length > 0 ? (
            <p className="text-xs text-text-tertiary tabular-nums">
              {valid.length} recipient{valid.length === 1 ? '' : 's'}
            </p>
          ) : null}
        </div>

        <div className="border-t border-border px-6 py-5 flex items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-text-primary">Scan Report</h3>
            <p className="text-xs text-text-secondary mt-0.5">
              Email the report to the list above after every scan completes.
            </p>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <span
              className={`font-mono text-[11px] font-semibold uppercase tracking-wider ${
                enabled ? 'text-accent' : 'text-text-tertiary'
              }`}
            >
              {enabled ? 'On' : 'Off'}
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={enabled}
              aria-label="Toggle scan report emails"
              onClick={() => setEnabled((v) => !v)}
              className={`relative inline-flex w-11 h-6 items-center rounded-full transition-colors duration-200 ${
                enabled
                  ? 'bg-accent'
                  : 'bg-surface-hover ring-1 ring-inset ring-border'
              }`}
            >
              <span
                aria-hidden="true"
                className={`pointer-events-none absolute left-0 top-1/2 -translate-y-1/2 h-5 w-5 rounded-full bg-white shadow ring-1 ring-black/5 transition-transform duration-200 ${
                  enabled ? 'translate-x-[22px]' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="border-t border-border px-6 py-4 flex items-center gap-3 bg-background/40">
          <button
            type="button"
            className="btn-secondary"
            onClick={() => navigate('/tools/integrations')}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn-primary disabled:opacity-50"
            disabled={!dirty || saving}
            onClick={handleSave}
          >
            {saving ? <Loader2 size={16} className="animate-spin mr-1.5" /> : null}
            Save Changes
          </button>
          <button
            type="button"
            className="btn-secondary ml-auto flex items-center gap-1.5"
            disabled={testing || smtpMissing || (config?.recipients.length ?? 0) === 0}
            title={
              smtpMissing
                ? 'Configure SMTP first'
                : (config?.recipients.length ?? 0) === 0
                  ? 'Save at least one recipient first'
                  : 'Send a test email to the saved recipients'
            }
            onClick={handleTest}
          >
            {testing ? <Loader2 size={16} className="animate-spin" /> : <Send size={15} />}
            Send test email
          </button>
        </div>
      </div>
    </div>
  );
}
