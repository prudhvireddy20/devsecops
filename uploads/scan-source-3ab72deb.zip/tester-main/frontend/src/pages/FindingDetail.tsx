import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ExternalLink,
  CheckCircle2,
  Code2,
  Shield,
  AlertTriangle,
  Loader2,
  Copy,
  ArrowRight,
  Wrench,
} from 'lucide-react';
import {
  getFinding,
  getScan,
  getProject,
  generateFix,
  updateFinding,
  type Finding,
  type GeneratedFix,
  type Project,
} from '../services/api';
import SeverityBadge from '../components/SeverityBadge';
import FindingConfidenceBadge from '../components/FindingConfidenceBadge';

// ── Correlation visualization ────────────────────────────────────────────────

function CorrelationVisualization({ finding }: { finding: Finding }) {
  const hasSAST = !!(finding.file_path || finding.code_snippet || finding.data_flow);
  const hasDAST = !!(finding.payload || finding.response_evidence);
  const hasFlowEvidence = Boolean(finding.flow_evidence && typeof finding.flow_evidence === 'object');
  const isVerified = finding.confidence === 'verified';

  // Determine the explanation text for the confidence level
  let explanation: string;
  let stepsLabel: string;
  if (finding.confidence === 'verified') {
    explanation =
      'This finding was confirmed by both static analysis (SAST) and dynamic testing (DAST). ' +
      'The vulnerable code path identified in source code was exercised at runtime and produced observable evidence of exploitation.' +
      (hasFlowEvidence
        ? ' GitNexus flow evidence confirms the endpoint-to-handler mapping.'
        : '');
    stepsLabel = 'SAST + DAST correlated';
  } else if (finding.confidence === 'probable') {
    explanation =
      'This finding was identified by static analysis (SAST) only. ' +
      'The vulnerable code pattern was detected in source code, but no dynamic test was able to trigger or confirm it at runtime.' +
      (hasFlowEvidence
        ? ' GitNexus flow evidence indicates the endpoint is reachable from the handler.'
        : '');
    stepsLabel = 'SAST only';
  } else {
    explanation =
      'This finding was detected during dynamic testing (DAST) only. ' +
      'The scanner observed suspicious behavior at runtime, but no corresponding vulnerable code pattern was found in the source.' +
      (hasFlowEvidence
        ? ' GitNexus flow evidence maps the endpoint to a handler, but no static match was found.'
        : '');
    stepsLabel = 'DAST only';
  }

  return (
    <div className="space-y-4">
      {/* Confidence explanation */}
      <div className="flex items-start gap-3 p-3 rounded-lg bg-background">
        <div className="shrink-0 mt-0.5">
          {finding.confidence === 'verified' ? (
            <CheckCircle2 className="w-5 h-5 text-accent" />
          ) : finding.confidence === 'probable' ? (
            <Shield className="w-5 h-5 text-probable" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-observed" />
          )}
        </div>
        <div>
          <p className="text-sm font-medium text-text-primary mb-1">
            <FindingConfidenceBadge confidence={finding.confidence} />{' '}
            <span className="text-text-secondary font-normal ml-1">({stepsLabel})</span>
          </p>
          <p className="text-xs text-text-secondary leading-relaxed">{explanation}</p>
        </div>
      </div>

        {/* Visual flow: SAST → Correlation → DAST */}
        <div className="flex items-center gap-2 overflow-x-auto py-2">
        {/* SAST box */}
        <div
          className={`flex flex-col items-center p-3 rounded-lg border min-w-[120px] ${
            hasSAST
              ? 'border-accent/40 bg-accent/5 text-text-primary'
              : 'border-border bg-surface text-text-secondary opacity-50'
          }`}
        >
          <Code2 className="w-5 h-5 mb-1" />
          <span className="text-xs font-semibold">SAST</span>
          <span className="text-[10px] mt-0.5">{hasSAST ? 'Detected' : 'No match'}</span>
        </div>

        {/* Arrow */}
        <ArrowRight className={`w-4 h-4 shrink-0 ${isVerified ? 'text-accent' : 'text-text-secondary/30'}`} />

        {/* Correlation box */}
        <div
          className={`flex flex-col items-center p-3 rounded-lg border min-w-[120px] ${
            isVerified
              ? 'border-accent/40 bg-accent/5 text-accent'
              : 'border-border bg-surface text-text-secondary'
          }`}
        >
          <Shield className="w-5 h-5 mb-1" />
          <span className="text-xs font-semibold">Correlated</span>
          <span className="text-[10px] mt-0.5">{isVerified ? 'Verified' : 'Not verified'}</span>
        </div>

        {/* Arrow */}
        <ArrowRight className={`w-4 h-4 shrink-0 ${isVerified ? 'text-accent' : 'text-text-secondary/30'}`} />

        {/* DAST box */}
        <div
          className={`flex flex-col items-center p-3 rounded-lg border min-w-[120px] ${
            hasDAST
              ? 'border-accent/40 bg-accent/5 text-text-primary'
              : 'border-border bg-surface text-text-secondary opacity-50'
          }`}
        >
          <ExternalLink className="w-5 h-5 mb-1" />
          <span className="text-xs font-semibold">DAST</span>
          <span className="text-[10px] mt-0.5">{hasDAST ? 'Confirmed' : 'No proof'}</span>
        </div>
      </div>

      {hasFlowEvidence && (
        <div className="p-2 rounded bg-background text-xs">
          <span className="font-semibold text-text-secondary uppercase">GitNexus Flow</span>
          <div className="mt-1 text-text-primary">
            {(() => {
              const evidence = finding.flow_evidence as Record<string, unknown>;
              const status = String(evidence?.status || 'unknown');
              const route = String(evidence?.matched_route || '');
              const handler = String(evidence?.matched_handler || '');
              if (status === 'confirmed') {
                return `Confirmed route ${route || '—'} → handler ${handler || '—'}`;
              }
              if (status === 'route_only') {
                return `Route match found (${route || '—'}) but handler not confirmed`;
              }
              if (status === 'no_match') {
                return 'No matching route found in GitNexus index';
              }
              if (status === 'unavailable') {
                return `GitNexus unavailable: ${String(evidence?.reason || 'unknown')}`;
              }
              return 'GitNexus evidence unavailable';
            })()}
          </div>
        </div>
      )}

      {/* Evidence summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div className="p-2 rounded bg-background">
          <span className="font-semibold text-text-secondary uppercase">Static Evidence</span>
          <ul className="mt-1 space-y-0.5 text-text-primary">
            <li>Source file: {finding.file_path ? <code className="text-accent">{finding.file_path}:{finding.line_number}</code> : <span className="text-text-secondary">none</span>}</li>
            <li>Code snippet: {finding.code_snippet ? 'present' : <span className="text-text-secondary">none</span>}</li>
            <li>Data flow: {finding.data_flow ? 'traced' : <span className="text-text-secondary">none</span>}</li>
          </ul>
        </div>
        <div className="p-2 rounded bg-background">
          <span className="font-semibold text-text-secondary uppercase">Dynamic Evidence</span>
          <ul className="mt-1 space-y-0.5 text-text-primary">
            <li>Endpoint: {finding.endpoint ? <code className="text-accent">{finding.endpoint}</code> : <span className="text-text-secondary">none</span>}</li>
            <li>Payload: {finding.payload ? 'sent' : <span className="text-text-secondary">none</span>}</li>
            <li>Response: {finding.response_evidence ? 'evidence captured' : <span className="text-text-secondary">none</span>}</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

// ── Component ───────────────────────────────────────────────────────────────

const FindingDetail: React.FC = () => {
  const { findingId } = useParams<{ findingId: string }>();
  const navigate = useNavigate();

  const [finding, setFinding] = useState<Finding | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fix generation
  const [fix, setFix] = useState<GeneratedFix | null>(null);
  const [fixLoading, setFixLoading] = useState(false);
  const [fixError, setFixError] = useState<string | null>(null);
  const [fixStrategy, setFixStrategy] = useState<'auto' | 'template' | 'llm'>('auto');

  // Project ID resolved from scan for "View in Code" link
  const [projectId, setProjectId] = useState<string | null>(null);
  const [project, setProject] = useState<Project | null>(null);

  // Mark resolved
  const [resolving, setResolving] = useState(false);

  // Fetch finding and resolve project ID for source links
  useEffect(() => {
    if (!findingId) return;
    setLoading(true);
    getFinding(findingId)
      .then((data) => {
        setFinding(data);
        setError(null);
        // Auto-load existing fix from stored payload (defaults to {} — skip empty)
        if (
          data.fix_available &&
          data.generated_fix_payload &&
          Object.keys(data.generated_fix_payload).length > 0
        ) {
          const payload = data.generated_fix_payload as Record<string, unknown>;
          setFix({
            finding_id: data.id,
            fix_available: true,
            // strategy_used not stored — key presence mirrors backend inference
            strategy_used: 'triage' in payload ? 'llm' : 'template',
            fix: payload as GeneratedFix['fix'],
          });
        }
        // Resolve project ID from scan
        if (data.scan_id) {
          getScan(data.scan_id)
            .then((scan) => {
              setProjectId(scan.project_id);
              return getProject(scan.project_id);
            })
            .then((proj) => setProject(proj))
            .catch(() => {}); // non-critical
        }
      })
      .catch(() => setError('Failed to load finding'))
      .finally(() => setLoading(false));
  }, [findingId]);

  // Generate fix handler
  const handleGenerateFix = useCallback(async () => {
    if (!findingId || fixLoading) return;
    setFixLoading(true);
    setFixError(null);
    try {
      const result = await generateFix(findingId, fixStrategy);
      setFix(result);
    } catch {
      setFixError('Failed to generate fix suggestion');
    } finally {
      setFixLoading(false);
    }
  }, [findingId, fixLoading, fixStrategy]);

  // Mark as resolved
  const handleResolve = useCallback(async () => {
    if (!findingId || !finding || resolving) return;
    setResolving(true);
    try {
      const updated = await updateFinding(findingId, { status: 'resolved' });
      setFinding(updated);
    } catch {
      // silent fail
    } finally {
      setResolving(false);
    }
  }, [findingId, finding, resolving]);

  if (loading) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading finding">
        <div className="skeleton h-5 w-36" />
        <div className="skeleton h-36 rounded-lg" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="skeleton h-80 rounded-lg lg:col-span-2" />
          <div className="skeleton h-80 rounded-lg" />
        </div>
      </div>
    );
  }

  if (error || !finding) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <AlertTriangle className="w-12 h-12 text-critical" />
        <p className="text-text-secondary">{error || 'Finding not found'}</p>
        <button className="btn-secondary" onClick={() => navigate(-1)}>Go Back</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ── Back nav ────────────────────────────────────────────────────── */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Findings
      </button>

      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className="card">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-text-primary">{finding.title}</h1>
            <div className="flex items-center gap-2">
              <SeverityBadge severity={finding.severity} />
              <FindingConfidenceBadge confidence={finding.confidence} />
              {finding.status && (
                <span className="badge bg-surface-hover text-text-secondary">
                  {finding.status.replace(/_/g, ' ')}
                </span>
              )}
              {finding.duplicate_of && (
                <Link
                  to={`/findings/${finding.duplicate_of}`}
                  className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-medium/15 text-medium hover:bg-medium/25 transition-colors"
                >
                  Duplicate
                </Link>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap gap-2">
            <select
              className="select"
              value={fixStrategy}
              onChange={(e) => setFixStrategy(e.target.value as 'auto' | 'template' | 'llm')}
              disabled={fixLoading}
              title="Fix generation strategy"
            >
              <option value="auto">Auto</option>
              <option value="llm">LLM</option>
              <option value="template">Template</option>
            </select>
            <button
              className="btn-primary flex items-center gap-2"
              onClick={handleGenerateFix}
              disabled={fixLoading}
            >
              {fixLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
              Generate Fix
            </button>
            <button
              className="btn-secondary flex items-center gap-2"
              onClick={handleResolve}
              disabled={resolving || finding.status === 'resolved'}
            >
              {resolving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              {finding.status === 'resolved' ? 'Resolved' : 'Mark as Resolved'}
            </button>
          </div>
        </div>
      </div>

      {/* ── Details grid ────────────────────────────────────────────────── */}
      <div className="card">
        <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
          Details
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <DetailItem label="CWE" value={finding.cwe || '—'} />
          <DetailItem label="Category" value={finding.vulnerability_type || '—'} />
          <DetailItem
            label="Endpoint"
            value={finding.endpoint || '—'}
          />
          <DetailItem
            label="Parameter"
            value={finding.parameter || '—'}
          />
          <DetailItem
            label="File : Line"
            value={
              finding.file_path
                ? `${finding.file_path}:${finding.line_number}`
                : '—'
            }
            mono
          />
          <DetailItem
            label="Scanner"
            value={finding.scanner_source || finding.vulnerability_type || '—'}
          />
          <DetailItem
            label="Auth Role"
            value={finding.auth_role || 'default'}
          />
          <DetailItem
            label="Journey Source"
            value={finding.journey_source || 'standard'}
          />
          <DetailItem
            label="Risk"
            value={finding.risk_level ? `${finding.risk_level} (${finding.risk_score ?? 0})` : '—'}
          />
          <DetailItem
            label="Workflow Step"
            value={finding.workflow_step_id || '—'}
          />
          {finding.duplicate_of && (
            <div className="space-y-1">
              <dt className="text-xs font-medium text-text-secondary uppercase tracking-wider">
                Duplicate Of
              </dt>
              <dd>
                <Link
                  to={`/findings/${finding.duplicate_of}`}
                  className="text-sm font-mono text-accent hover:underline"
                >
                  {finding.duplicate_of}
                </Link>
              </dd>
            </div>
          )}
        </div>
      </div>

      {/* ── Description / Vulnerability Type ─────────────────────────────── */}
      {finding.vulnerability_type && (
        <div className="card">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
            Vulnerability Type
          </h2>
          <p className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap">
            {finding.vulnerability_type}
          </p>
        </div>
      )}

      {/* ── Source Code ──────────────────────────────────────────────────── */}
      {finding.code_snippet && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
              Source Code
            </h2>
            <button
              className="text-text-secondary hover:text-text-primary transition-colors"
              onClick={() => navigator.clipboard.writeText(finding.code_snippet)}
              title="Copy code"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
          <div className="bg-background rounded-lg overflow-hidden">
            <pre className="p-4 text-sm font-mono text-text-primary overflow-x-hidden leading-relaxed whitespace-pre-wrap break-all">
              {finding.code_snippet.split('\n').map((line, i) => {
                const lineNum = (finding.line_number ?? 1) + i;
                const isHighlighted = lineNum === finding.line_number;
                return (
                  <div
                    key={i}
                    className={`flex ${
                      isHighlighted
                        ? 'bg-critical/10 border-l-2 border-critical'
                        : ''
                    }`}
                  >
                    <span className="select-none text-text-secondary/50 w-12 text-right pr-4 shrink-0">
                      {lineNum}
                    </span>
                    <span className="flex-1 min-w-0 whitespace-pre-wrap break-all">{line}</span>
                  </div>
                );
              })}
            </pre>
          </div>
        </div>
      )}

      {/* ── Data Flow ───────────────────────────────────────────────────── */}
      {finding.data_flow && (
        <div className="card">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
            Data Flow
          </h2>
          <pre className="bg-background rounded-lg p-4 text-sm font-mono text-text-primary overflow-x-auto whitespace-pre-wrap">
            {typeof finding.data_flow === 'string' ? finding.data_flow : JSON.stringify(finding.data_flow, null, 2)}
          </pre>
        </div>
      )}

      {/* ── Correlation Analysis ─────────────────────────────────────── */}
      <div className="card">
        <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
          Correlation Analysis
        </h2>
        <CorrelationVisualization finding={finding} />
      </div>

      {/* ── Dynamic Proof ───────────────────────────────────────────────── */}
      {(finding.payload || finding.response_evidence) && (
        <div className="card">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
            Dynamic Proof
          </h2>
          <div className="space-y-4">
            {finding.payload && (
              <div>
                <span className="text-xs font-semibold uppercase text-text-secondary">Payload</span>
                <pre className="mt-1 bg-background rounded-lg p-3 text-sm font-mono text-critical overflow-x-auto">
                  {finding.payload}
                </pre>
              </div>
            )}
            {finding.response_code != null && (
              <div>
                <span className="text-xs font-semibold uppercase text-text-secondary">Response Code</span>
                <p className="mt-1 text-sm font-mono text-text-primary">{finding.response_code}</p>
              </div>
            )}
            {finding.response_evidence && (
              <div>
                <span className="text-xs font-semibold uppercase text-text-secondary">Evidence</span>
                <pre className="mt-1 bg-background rounded-lg p-3 text-sm font-mono text-text-primary overflow-x-auto whitespace-pre-wrap">
                  {finding.response_evidence}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Remediation ─────────────────────────────────────────────────── */}
      {finding.remediation_text && (
        <div className="card">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
            Remediation
          </h2>
          <p className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap">
            {finding.remediation_text}
          </p>
        </div>
      )}

      {/* ── OWASP Category ───────────────────────────────────────────────── */}
      {finding.owasp_category && (
        <div className="card">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
            OWASP Category
          </h2>
          <p className="text-sm text-text-primary">
            {finding.owasp_category}
          </p>
        </div>
      )}

      {/* ── Generated Fix (before/after diff) ───────────────────────────── */}
      {fixError && (
        <div className="card border-critical/50">
          <p className="text-sm text-critical">{fixError}</p>
        </div>
      )}

      {fix && !fix.fix && !fixError && (
        <div className="card border-accent/30 bg-accent/5">
          <p className="text-sm text-text-primary">
            No automated fix could be generated for this vulnerability. Please review the remediation instructions.
          </p>
        </div>
      )}

      {fix && fix.fix && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
              Generated Fix
            </h2>
            <div className="flex items-center gap-2">
              {fix.strategy_used && (
                <span className="badge bg-accent/10 text-accent">
                  strategy: {fix.strategy_used}
                </span>
              )}
              {fix.fix?.fixed_code && (
                <button
                  className="btn-secondary text-xs flex items-center gap-1.5"
                  onClick={() => navigator.clipboard.writeText(fix.fix?.fixed_code || '')}
                  title="Copy fixed code"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Copy Fix
                </button>
              )}
            </div>
          </div>

          {(fix.fix?.triage || fix.fix?.triage_confidence || fix.fix?.reasoning) && (
            <div className="mb-4 p-3 rounded-lg bg-background border border-border">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                {fix.fix?.triage && (
                  <span className="badge bg-surface-hover text-text-primary">
                    triage: {fix.fix.triage.replace(/_/g, ' ')}
                  </span>
                )}
                {fix.fix?.triage_confidence && (
                  <span className="badge bg-surface-hover text-text-primary">
                    confidence: {fix.fix.triage_confidence}
                  </span>
                )}
              </div>
              {fix.fix?.reasoning && (
                <p className="text-sm text-text-secondary mt-2 whitespace-pre-wrap">
                  {fix.fix.reasoning}
                </p>
              )}
              {fix.fix?.tests_to_add && fix.fix.tests_to_add.length > 0 && (
                <p className="text-xs text-text-secondary mt-2">
                  Tests: {fix.fix.tests_to_add.join(' | ')}
                </p>
              )}
            </div>
          )}

          {fix.fix?.explanation && (
            <p className="text-sm text-text-primary mb-4">{fix.fix.explanation}</p>
          )}
          {fix.fix?.remediation_text && (
            <p className="text-sm text-text-secondary mb-4 whitespace-pre-wrap">
              {fix.fix.remediation_text}
            </p>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Original */}
            {fix.fix?.original_code && (
              <div>
                <span className="text-xs font-semibold uppercase text-critical mb-2 block">
                  Before
                </span>
                <pre className="bg-critical/5 border border-critical/20 rounded-lg p-4 text-sm font-mono text-text-primary overflow-x-auto whitespace-pre-wrap">
                  {fix.fix.original_code}
                </pre>
              </div>
            )}
            {/* Fixed */}
            {fix.fix?.fixed_code && (
              <div>
                <span className="text-xs font-semibold uppercase text-accent mb-2 block">
                  After
                </span>
                <pre className="bg-accent/5 border border-accent/20 rounded-lg p-4 text-sm font-mono text-text-primary overflow-x-auto whitespace-pre-wrap">
                  {fix.fix.fixed_code}
                </pre>
              </div>
            )}
          </div>

          {fix.fix?.diff && (
            <div className="mt-4">
              <span className="text-xs font-semibold uppercase text-text-secondary mb-2 block">
                Unified Diff
              </span>
              <pre className="bg-background rounded-lg p-4 text-sm font-mono overflow-x-auto whitespace-pre-wrap">
                {fix.fix!.diff!.split('\n').map((line, i) => (
                  <div
                    key={i}
                    className={
                      line.startsWith('+')
                        ? 'text-accent'
                        : line.startsWith('-')
                          ? 'text-critical'
                          : line.startsWith('@')
                            ? 'text-accent'
                            : 'text-text-secondary'
                    }
                  >
                    {line}
                  </div>
                ))}
              </pre>
            </div>
          )}
        </div>
      )}

    </div>
  );
};

// ── Detail Item helper ──────────────────────────────────────────────────────

interface DetailItemProps {
  label: string;
  value: string;
  mono?: boolean;
}

const DetailItem: React.FC<DetailItemProps> = ({ label, value, mono }) => (
  <div>
    <dt className="text-xs font-semibold uppercase text-text-secondary mb-1">{label}</dt>
    <dd className={`text-sm text-text-primary ${mono ? 'font-mono' : ''}`}>{value}</dd>
  </div>
);

export default FindingDetail;
