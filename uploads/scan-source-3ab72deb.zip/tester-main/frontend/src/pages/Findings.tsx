import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Filter,
  AlertTriangle,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  ChevronLeft,
  ChevronRight,
  Search,
  X,
  Wrench,
} from 'lucide-react';
import {
  getFindings,
  getFindingSummary,
  getScans,
  type Scan,
  type Finding,
  type Severity,
  type Confidence,
  type FindingStatus,
  type FindingSummary,
} from '../services/api';
import SeverityBadge from '../components/SeverityBadge';
import FindingConfidenceBadge from '../components/FindingConfidenceBadge';
import PageHeader from '../components/PageHeader';
import { formatDate } from '../utils/datetime';

// ── Constants ───────────────────────────────────────────────────────────────

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low', 'info'];
const CONFIDENCES = ['verified', 'probable', 'observed'] as const;
const STATUSES: FindingStatus[] = ['open', 'confirmed', 'false_positive', 'resolved'];
const PAGE_SIZE = 20;

type SortDir = 'asc' | 'desc';

interface SortState {
  key: string;
  dir: SortDir;
}

// ── Badge helpers ───────────────────────────────────────────────────────────

function statusBadge(status: FindingStatus) {
  const map: Record<FindingStatus, string> = {
    open: 'bg-accent/20 text-accent',
    confirmed: 'bg-critical/20 text-critical',
    false_positive: 'bg-surface-hover text-text-secondary',
    resolved: 'bg-low/15 text-low',
  };
  return (
    <span className={`badge ${map[status]}`}>
      {status.replace(/_/g, ' ')}
    </span>
  );
}

// ── Component ───────────────────────────────────────────────────────────────

const Findings: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Filters
  const [severity, setSeverity] = useState<Severity | ''>((searchParams.get('severity') as Severity) || '');
  const [confidence, setConfidence] = useState<Confidence | ''>((searchParams.get('confidence') as Confidence) || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [scanner, setScanner] = useState(searchParams.get('scanner') || '');
  const [status, setStatus] = useState<FindingStatus | ''>((searchParams.get('status') as FindingStatus) || '');
  const [searchText, setSearchText] = useState(searchParams.get('search') || '');

  // Scan selector
  const [scans, setScans] = useState<Scan[]>([]);
  const [selectedScanId, setSelectedScanId] = useState(searchParams.get('scan_id') || '');

  useEffect(() => {
    getScans({ page_size: 50 })
      .then((res) => {
        setScans(res.items);
      })
      .catch(() => {});
  }, []);

  // Data
  const [findings, setFindings] = useState<Finding[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<FindingSummary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(true);

  // Sort
  const [sort, setSort] = useState<SortState>({
    key: searchParams.get('sort_by') || 'severity',
    dir: (searchParams.get('sort_order') as SortDir) || 'desc',
  });
  // Fetch findings
  const fetchFindings = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, unknown> = {
        page,
        page_size: PAGE_SIZE,
        sort_by: sort.key,
        sort_order: sort.dir,
      };
      if (severity) params.severity = severity;
      if (confidence) params.confidence = confidence;
      if (category) params.vulnerability_type = category;
      if (scanner) params.scanner_source = scanner;
      if (status) params.status = status;
      if (searchText) params.search = searchText;
      if (selectedScanId) params.scan_id = selectedScanId;

      const res = await getFindings(params as Parameters<typeof getFindings>[0]);
      setFindings(res.items);
      setTotal(res.total);
      setTotalPages(res.pages);
      setError(null);
    } catch {
      setFindings([]);
      setError('Failed to load findings. Please retry or adjust filters.');
    } finally {
      setLoading(false);
    }
  }, [page, sort, severity, confidence, category, scanner, status, searchText, selectedScanId]);

  const handleRetry = () => {
    fetchFindings();
  };

  useEffect(() => {
    fetchFindings();
  }, [fetchFindings]);

  const fetchSummary = useCallback(async () => {
    setSummaryLoading(true);
    try {
      const params: Record<string, unknown> = {};
      if (severity) params.severity = severity;
      if (category) params.vulnerability_type = category;
      if (scanner) params.scanner_source = scanner;
      if (status) params.status = status;
      if (searchText) params.search = searchText;
      if (selectedScanId) params.scan_id = selectedScanId;

      const res = await getFindingSummary(params);
      setSummary(res);
    } catch {
      setSummary(null);
    } finally {
      setSummaryLoading(false);
    }
  }, [severity, category, scanner, status, searchText, selectedScanId]);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  // Sync filters to URL (only when user-driven state changes, not from URL parsing)
  const isInitialMount = useRef(true);
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }
    const p = new URLSearchParams();
    if (severity) p.set('severity', severity);
    if (confidence) p.set('confidence', confidence);
    if (category) p.set('category', category);
    if (scanner) p.set('scanner', scanner);
    if (status) p.set('status', status);
    if (searchText) p.set('search', searchText);
    if (page > 1) p.set('page', String(page));
    if (sort.key !== 'severity') p.set('sort_by', sort.key);
    if (sort.dir !== 'desc') p.set('sort_order', sort.dir);
    if (selectedScanId) p.set('scan_id', selectedScanId);
    setSearchParams(p, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [severity, confidence, category, scanner, status, searchText, page, sort, selectedScanId]);

  // Column sort toggle
  const handleSort = (key: string) => {
    setSort((prev) =>
      prev.key === key
        ? { key, dir: prev.dir === 'asc' ? 'desc' : 'asc' }
        : { key, dir: 'asc' },
    );
    setPage(1);
  };

  const sortIcon = (key: string) => {
    if (sort.key !== key) return <ChevronsUpDown className="w-3.5 h-3.5 text-text-secondary/50" />;
    return sort.dir === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 text-accent" />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 text-accent" />
    );
  };

  const clearFilters = () => {
    setSeverity('');
    setConfidence('');
    setCategory('');
    setScanner('');
    setStatus('');
    setSearchText('');
    setPage(1);
  };

  const hasFilters = severity || confidence || category || scanner || status || searchText;
  const selectedScan = scans.find(s => s.id === selectedScanId);
  const isBlackbox = selectedScan?.scan_mode === 'blackbox';
  const confidenceCards: Confidence[] = isBlackbox
    ? ['probable', 'observed']
    : ['verified', 'probable', 'observed'];
  const displayedConfidences = isBlackbox
    ? CONFIDENCES.filter(c => c !== 'verified')
    : CONFIDENCES;

  // ── Columns config ──────────────────────────────────────────────────────
  const columns: { key: string; label: string; sortable: boolean }[] = [
    { key: 'title', label: 'Title', sortable: true },
    { key: 'severity', label: 'Severity', sortable: true },
    { key: 'confidence', label: 'Confidence', sortable: true },
    { key: 'cwe', label: 'CWE', sortable: true },
    { key: 'file_path', label: 'File', sortable: true },
    { key: 'vulnerability_type', label: 'Type', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: 'fix', label: 'Fix', sortable: false },
  ];

  const handleRowKeyDown = (e: React.KeyboardEvent<HTMLTableRowElement>, findingId: string) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      navigate(`/findings/${findingId}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <PageHeader
        icon={Search}
        title="Findings"
        count={total}
        subtitle="Vulnerabilities discovered and verified across scans."
        actions={
          <select
            className="select w-full sm:w-64"
            value={selectedScanId}
            onChange={(e) => {
              const newScan = scans.find(s => s.id === e.target.value);
              if (newScan?.scan_mode === 'blackbox' && confidence === 'verified') {
                setConfidence('');
              }
              setSelectedScanId(e.target.value);
              setPage(1);
            }}
            aria-label="Filter by scan"
          >
            <option value="">All Scans</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>
                {s.project_name ?? 'Unknown'} — {s.started_at ? formatDate(s.started_at) : 'N/A'}
              </option>
            ))}
          </select>
        }
      />

      {/* ── Filter bar ──────────────────────────────────────────────────── */}
      {error && (
        <div className="card flex items-center gap-2 border-critical/30 text-critical">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span className="text-sm flex-1">{error}</span>
          <button type="button" className="btn-secondary text-xs" onClick={handleRetry}>
            Retry
          </button>
        </div>
      )}

      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-text-secondary" />
          <span className="text-sm font-medium text-text-secondary">Filters</span>
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="ml-auto flex items-center gap-1 text-xs text-text-secondary hover:text-text-primary"
            >
              <X className="w-3 h-3" />
              Clear all
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          {/* Severity */}
          <select
            className="select w-40"
            value={severity}
            onChange={(e) => { setSeverity(e.target.value as Severity | ''); setPage(1); }}
          >
            <option value="">All Severities</option>
            {SEVERITIES.map((s) => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>

          {/* Confidence */}
          <select
            className="select w-40"
            value={confidence}
            onChange={(e) => { setConfidence(e.target.value as Confidence | ''); setPage(1); }}
          >
            <option value="">All Confidence</option>
            {displayedConfidences.map((c) => (
              <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
            ))}
          </select>

          {/* Vuln type */}
          <input
            className="input w-48"
            placeholder="Vulnerability type..."
            value={category}
            onChange={(e) => { setCategory(e.target.value); setPage(1); }}
          />

          {/* Scanner source */}
          <input
            className="input w-40"
            placeholder="Scanner..."
            value={scanner}
            onChange={(e) => { setScanner(e.target.value); setPage(1); }}
          />

          {/* Status */}
          <select
            className="select w-40"
            value={status}
            onChange={(e) => { setStatus(e.target.value as FindingStatus | ''); setPage(1); }}
          >
            <option value="">All Statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>{s.replace('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>
            ))}
          </select>

          {/* Text search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-secondary" />
            <input
              className="input pl-9"
              placeholder="Search findings..."
              value={searchText}
              onChange={(e) => { setSearchText(e.target.value); setPage(1); }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {confidenceCards.map((level) => {
          const value = summary?.[level] ?? 0;
          const active = confidence === level;
          return (
            <button
              key={level}
              type="button"
              className={`card text-left transition-colors border ${
                active ? 'border-accent bg-accent/5' : 'border-border hover:bg-surface-hover/40'
              }`}
              onClick={() => {
                setConfidence((prev) => (prev === level ? '' : level));
                setPage(1);
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <FindingConfidenceBadge confidence={level} />
                  <p className="text-xs text-text-secondary mt-2">
                    Scope before confidence filter
                  </p>
                </div>
                <span className="text-2xl font-bold text-text-primary">
                  {summaryLoading ? '—' : value}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* ── Table ───────────────────────────────────────────────────────── */}
      <div className="card p-0 overflow-hidden">
        <div className="md:hidden divide-y divide-border">
          {loading ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 4 }).map((_, idx) => (
                <div key={idx} className="rounded-xl border border-border p-4 space-y-3">
                  <div className="skeleton h-4 w-5/6" />
                  <div className="flex gap-2">
                    <div className="skeleton h-5 w-16 rounded-full" />
                    <div className="skeleton h-5 w-20 rounded-full" />
                    <div className="skeleton h-5 w-24 rounded-full" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="skeleton h-8" />
                    <div className="skeleton h-8" />
                    <div className="skeleton h-8 col-span-2" />
                  </div>
                </div>
              ))}
            </div>
          ) : findings.length === 0 ? (
            <div className="py-12 text-center text-text-secondary">
              No findings match the current filters.
            </div>
          ) : (
            findings.map((f) => (
              <button
                key={f.id}
                type="button"
                className="w-full text-left p-4 space-y-3 hover:bg-surface-hover/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                onClick={() => navigate(`/findings/${f.id}`)}
                aria-label={`Open finding ${f.title}`}
              >
                <p className="font-medium text-text-primary text-sm leading-5">{f.title}</p>
                <div className="flex items-center gap-2">
                  <SeverityBadge severity={f.severity} />
                  <FindingConfidenceBadge confidence={f.confidence} />
                  {statusBadge(f.status)}
                  {f.fix_available && (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-accent/15 text-accent uppercase">
                      <Wrench className="w-3 h-3 mr-0.5" /> fix
                    </span>
                  )}
                  {f.duplicate_of && (
                    <span className="px-1.5 py-0.5 text-[10px] font-semibold rounded bg-yellow-500/15 text-yellow-400 uppercase">dup</span>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-text-secondary">Type</p>
                    <p className="text-text-primary truncate">{f.vulnerability_type || '—'}</p>
                  </div>
                  <div>
                    <p className="text-text-secondary">CWE</p>
                    <p className="text-text-primary font-mono">{f.cwe || '—'}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-text-secondary">File</p>
                    <p className="text-text-primary font-mono truncate">
                      {f.file_path ? `${f.file_path}:${f.line_number}` : '—'}
                    </p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>

        <div className="hidden md:block overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                {columns.map((col) => (
                  <th key={col.key}>
                    {col.sortable ? (
                      <button
                        type="button"
                        className="cursor-pointer select-none inline-flex items-center gap-1"
                        onClick={() => handleSort(col.key)}
                        aria-label={`Sort by ${col.label}`}
                      >
                        {col.label}
                        {sortIcon(col.key)}
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1">{col.label}</span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, idx) => (
                  <tr key={`finding-skeleton-${idx}`}>
                    <td colSpan={columns.length} className="py-3">
                      <div className="skeleton h-6 w-full" />
                    </td>
                  </tr>
                ))
              ) : findings.length === 0 ? (
                <tr>
                  <td colSpan={columns.length} className="text-center py-12 text-text-secondary">
                    No findings match the current filters.
                  </td>
                </tr>
              ) : (
                findings.map((f) => (
                  <tr
                    key={f.id}
                    className="cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    onClick={() => navigate(`/findings/${f.id}`)}
                    onKeyDown={(e) => handleRowKeyDown(e, f.id)}
                    tabIndex={0}
                    role="button"
                    aria-label={`Open finding ${f.title}`}
                  >
                    <td className="max-w-xs truncate font-medium text-text-primary">
                      {f.title}
                    </td>
                    <td><SeverityBadge severity={f.severity} /></td>
                    <td><FindingConfidenceBadge confidence={f.confidence} /></td>
                    <td className="font-mono text-xs text-text-secondary">
                      {f.cwe || '—'}
                    </td>
                    <td className="font-mono text-xs text-text-secondary max-w-[200px] truncate">
                      {f.file_path ? `${f.file_path}:${f.line_number}` : '—'}
                    </td>
                    <td className="text-sm text-text-secondary">{f.vulnerability_type || '—'}</td>
                    <td>
                      <div className="flex items-center gap-1">
                        {statusBadge(f.status)}
                        {f.duplicate_of && (
                          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-yellow-500/15 text-yellow-400" title={`Duplicate of ${f.duplicate_of}`}>
                            dup
                          </span>
                        )}
                      </div>
                    </td>
                    <td>
                      {f.fix_available ? (
                        <span title="Fix available"><Wrench className="w-4 h-4 text-accent" /></span>
                      ) : (
                        <span className="text-text-tertiary/40">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* ── Pagination ──────────────────────────────────────────────── */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-sm text-text-secondary">
              Page {page} of {totalPages} ({total} results)
            </span>
            <div className="flex items-center gap-1">
              <button
                className="btn-secondary h-9 w-9 p-0"
                aria-label="Previous page"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                let pageNum: number;
                if (totalPages <= 7) {
                  pageNum = i + 1;
                } else if (page <= 4) {
                  pageNum = i + 1;
                } else if (page >= totalPages - 3) {
                  pageNum = totalPages - 6 + i;
                } else {
                  pageNum = page - 3 + i;
                }
                return (
                  <button
                    key={pageNum}
                    onClick={() => setPage(pageNum)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      pageNum === page
                        ? 'bg-accent text-white'
                        : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
              <button
                className="btn-secondary h-9 w-9 p-0"
                aria-label="Next page"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Findings;
