import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Lightbulb, ScanSearch, BadgeCheck, AlertCircle, Flame, Network,
} from 'lucide-react';
import PageHeader from '../components/PageHeader';
import SeverityBadge from '../components/SeverityBadge';
import {
  getInsightsData,
  getProjects,
  type InsightsData,
  type Project,
  type Finding,
} from '../services/api';

// ---------------------------------------------------------------------------
// Color maps
// ---------------------------------------------------------------------------

const SEVERITY_COLORS: Record<string, string> = {
  critical: 'rgb(var(--color-critical))',
  high: 'rgb(var(--color-high))',
  medium: 'rgb(var(--color-medium))',
  low: 'rgb(var(--color-low))',
  info: 'rgb(var(--color-info))',
};

const CONFIDENCE_COLORS: Record<string, string> = {
  verified: 'rgb(var(--color-verified))',
  probable: 'rgb(var(--color-probable))',
  observed: 'rgb(var(--color-observed))',
};

const STATUS_COLORS: Record<string, string> = {
  open: 'rgb(var(--color-high))',
  confirmed: 'rgb(var(--color-info))',
  resolved: 'rgb(var(--color-low))',
  false_positive: 'rgb(var(--color-text-tertiary))',
  duplicate: 'rgb(var(--color-border))',
};

const STATUS_LABELS: Record<string, string> = {
  open: 'Open',
  confirmed: 'Confirmed',
  resolved: 'Resolved',
  false_positive: 'False Positive',
  duplicate: 'Duplicate',
};

const SEVERITY_RANK: Record<string, number> = {
  critical: 0, high: 1, medium: 2, low: 3, info: 4,
};

const VULN_TYPE_PALETTE = [
  'rgb(var(--color-critical))',
  'rgb(var(--color-high))',
  'rgb(var(--color-medium))',
  'rgb(var(--color-info))',
  'rgb(var(--color-low))',
  'rgb(var(--color-observed))',
  'rgb(var(--color-probable))',
  'rgb(var(--color-verified))',
];

function vulnTypeColor(index: number): string {
  return VULN_TYPE_PALETTE[index % VULN_TYPE_PALETTE.length];
}

/** "info_disclosure" → "Info Disclosure" for display; raw key kept for links */
function prettyLabel(s: string): string {
  return s
    .replace(/[_-]+/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Bucket per-finding values by creation day (UTC); invalid dates skipped. */
function bucketByDay(findings: Finding[], valueOf: (f: Finding) => number): Map<string, number> {
  const map = new Map<string, number>();
  for (const f of findings) {
    if (!f.created_at) continue;
    const date = new Date(f.created_at);
    if (isNaN(date.getTime())) continue;
    const day = date.toISOString().split('T')[0];
    map.set(day, (map.get(day) || 0) + valueOf(f));
  }
  return map;
}

/** Expand a day→value map into a contiguous daily series (gap days count 0),
 *  so sparklines keep real time spacing instead of collapsing quiet days. */
function fillDaySeries(byDay: Map<string, number>, cumulative: boolean): number[] {
  if (byDay.size === 0) return [];
  const days = [...byDay.keys()].sort();
  const start = new Date(`${days[0]}T00:00:00Z`).getTime();
  const end = new Date(`${days[days.length - 1]}T00:00:00Z`).getTime();
  const out: number[] = [];
  let sum = 0;
  for (let t = start; t <= end; t += 86_400_000) {
    const v = byDay.get(new Date(t).toISOString().split('T')[0]) || 0;
    sum += v;
    out.push(cumulative ? sum : v);
  }
  return out;
}

function scannerColor(_source: string, index: number): string {
  const sourceLower = _source.toLowerCase();
  if (sourceLower === 'semgrep') return 'rgb(var(--color-info))';
  if (sourceLower === 'zap') return 'rgb(var(--color-critical))';
  if (sourceLower === 'nuclei') return 'rgb(var(--color-high))';
  if (sourceLower === 'dalfox') return 'rgb(var(--color-high))';
  if (sourceLower === 'sqlmap') return 'rgb(var(--color-critical))';
  if (sourceLower === 'correlation') return 'rgb(var(--color-verified))';
  if (sourceLower === 'pip-audit' || sourceLower === 'pip_audit') return 'rgb(var(--color-medium))';
  if (sourceLower === 'detect-secrets' || sourceLower === 'secrets') return 'rgb(var(--color-medium))';
  return VULN_TYPE_PALETTE[index % VULN_TYPE_PALETTE.length];
}

// ---------------------------------------------------------------------------
// Shared mono-uppercase label style (mirrors .nav-label in globals.css)
// ---------------------------------------------------------------------------

const MONO_LABEL = 'font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-text-secondary';

// ---------------------------------------------------------------------------
// Pure SVG Doughnut Chart — no library
// ---------------------------------------------------------------------------

interface DoughnutSegment {
  value: number;
  color: string;
  label: string;
  /** Raw filter value for drill-down links (e.g. severity key) */
  key?: string;
}

function DoughnutChart({ segments, size = 120, strokeWidth = 22, showCenterText = true }: {
  segments: DoughnutSegment[]; size?: number; strokeWidth?: number; showCenterText?: boolean;
}) {
  const total = segments.reduce((s, seg) => s + seg.value, 0);
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  if (total === 0) {
    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgb(var(--color-border))" strokeWidth={strokeWidth} />
        {showCenterText && (
          <>
            <text x={size / 2} y={size / 2 - 4} textAnchor="middle" dominantBaseline="central"
              className="fill-text-secondary text-lg font-bold tabular-nums">0</text>
            <text x={size / 2} y={size / 2 + 14} textAnchor="middle" dominantBaseline="central"
              className="fill-text-secondary text-[10px]">total</text>
          </>
        )}
      </svg>
    );
  }

  let cumulative = 0;
  const paths = segments.map((seg) => {
    const len = (seg.value / total) * circumference;
    const p = {
      ...seg,
      dasharray: `${len} ${circumference - len}`,
      dashoffset: -cumulative,
    };
    cumulative += len;
    return p;
  });

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgb(var(--color-border))" strokeWidth={strokeWidth} />
      {paths.map((p, i) => (
        <circle key={i} cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke={p.color} strokeWidth={strokeWidth}
          strokeDasharray={p.dasharray} strokeDashoffset={p.dashoffset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          className="transition-all duration-700 ease-out"
        />
      ))}
      {showCenterText && (
        <>
          <text x={size / 2} y={size / 2 - 4} textAnchor="middle" dominantBaseline="central"
            className="fill-text-primary text-lg font-bold tabular-nums">{total}</text>
          <text x={size / 2} y={size / 2 + 14} textAnchor="middle" dominantBaseline="central"
            className="fill-text-secondary text-[10px]">total</text>
        </>
      )}
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Pure SVG Sparkline
// ---------------------------------------------------------------------------

function Sparkline({ points, color, height = 48 }: {
  points: number[]; color: string; height?: number;
}) {
  if (points.length < 2) {
    return <p className="text-text-secondary text-sm py-4 text-center">No data</p>;
  }

  const width = 300;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const yScale = (height - 8) / range;
  const xStep = width / (points.length - 1);

  const polylinePoints = points
    .map((p, i) => `${i * xStep},${height - 4 - (p - min) * yScale}`)
    .join(' ');

  const polygonPoints = `0,${height} ${polylinePoints} ${width},${height}`;

  // url(#id) breaks on "(" / ")" from the raw rgb() color string — sanitize.
  // Same-color duplicates share one id, but their defs are identical so the
  // first-wins resolution is harmless.
  const gradId = `spark-${color.replace(/[^a-zA-Z0-9-]/g, '')}`;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="w-full">
      <defs>
        <linearGradient id={gradId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: color, stopOpacity: 0.3 }} />
          <stop offset="100%" style={{ stopColor: color, stopOpacity: 0 }} />
        </linearGradient>
      </defs>
      <polygon points={polygonPoints} fill={`url(#${gradId})`} />
      <polyline points={polylinePoints} fill="none" stroke={color} strokeWidth="2" className="transition-all duration-700 ease-out" />
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Stat Card — mockup row-1 style: mono label, huge colored number, underline
// ---------------------------------------------------------------------------

function StatCard({ label, value, caption, icon, color }: {
  label: string; value: number | string; caption: string;
  icon: React.ReactNode; color: string;
}) {
  return (
    <div className="card animate-enter">
      <div className={`flex items-center gap-2 ${MONO_LABEL}`}>
        <span className={color}>{icon}</span>
        {label}
      </div>
      <div className={color}>
        <p className="mt-3 text-4xl font-bold tabular-nums leading-none">{value}</p>
        <div className="mt-3 h-0.5 w-10 rounded-full bg-current opacity-80" />
      </div>
      <p className="mt-3 text-sm text-text-secondary">{caption}</p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Trend Card — mockup bottom-row style: label, big number, edge-to-edge spark
// ---------------------------------------------------------------------------

function TrendCard({ label, value, color, stroke, points, caption }: {
  label: string; value: number | string; color: string;
  stroke: string; points?: number[]; caption?: string;
}) {
  return (
    <div className="card animate-enter h-44 flex flex-col overflow-hidden">
      <p className={MONO_LABEL}>{label}</p>
      <p className={`mt-2 text-3xl font-bold tabular-nums ${color}`}>{value}</p>
      {caption && <p className="mt-1 text-xs text-text-secondary truncate">{caption}</p>}
      <div className="mt-auto -mx-6 -mb-6">
        {points && points.length >= 2 ? (
          <Sparkline points={points} color={stroke} height={56} />
        ) : (
          <div className="h-1 w-full opacity-70" style={{ backgroundColor: stroke }} />
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Horizontal Distribution Bar
// ---------------------------------------------------------------------------

interface DistItem {
  label: string;
  value: number;
  color: string;
  /** Raw filter value for drill-down links; falls back to label */
  key?: string;
}

function DistBar({ items, total, emptyMessage = 'No data', linkFor }: {
  items: DistItem[];
  total: number;
  emptyMessage?: string;
  linkFor?: (key: string) => string | null;
}) {
  if (items.length === 0 || total === 0) {
    return <p className="text-text-secondary text-sm py-4 text-center">{emptyMessage}</p>;
  }

  const top = items.length > 8 ? items.slice(0, 8) : items;
  const others = items.length > 8 ? items.slice(8).reduce((s, i) => s + i.value, 0) : 0;

  return (
    <div className="space-y-1">
      {top.map((item) => {
        const href = linkFor ? linkFor(item.key ?? item.label) : null;
        const row = (
          <>
            <span className="shrink-0 max-w-[45%] truncate text-sm text-text-secondary" title={item.label}>
              {item.label}
            </span>
            <div className="flex-1 h-5 bg-background rounded overflow-hidden ring-1 ring-inset ring-black/5 dark:ring-white/5">
              <div className="h-full rounded transition-all duration-500"
                style={{ width: `${Math.max((item.value / total) * 100, 1.5)}%`, backgroundColor: item.color }}
              />
            </div>
            <span className="w-10 shrink-0 text-right text-sm tabular-nums text-text-primary">{item.value}</span>
          </>
        );
        return href ? (
          <Link key={item.key ?? item.label} to={href}
            className="flex items-center gap-3 rounded px-1 py-0.5 -mx-1 hover:bg-surface-hover transition-colors">
            {row}
          </Link>
        ) : (
          <div key={item.key ?? item.label} className="flex items-center gap-3 px-1 py-0.5 -mx-1">
            {row}
          </div>
        );
      })}
      {others > 0 && (
        <div className="flex items-center gap-3 px-1 py-0.5 -mx-1">
          <span className="shrink-0 text-sm text-text-tertiary">Others</span>
          <div className="flex-1 h-5 bg-background rounded overflow-hidden ring-1 ring-inset ring-black/5 dark:ring-white/5">
            <div className="h-full rounded bg-border transition-all duration-500"
              style={{ width: `${Math.max((others / total) * 100, 1.5)}%` }}
            />
          </div>
          <span className="w-10 shrink-0 text-right text-sm tabular-nums text-text-tertiary">{others}</span>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Chart card — big colored number, mono label, donut left + vertical legend
// ---------------------------------------------------------------------------

function ChartCard({ title, number, numberColor, segments, linkFor }: {
  title: string; number: number | string; numberColor: string;
  segments: DoughnutSegment[];
  linkFor?: (key: string) => string | null;
}) {
  return (
    <div className="card animate-enter">
      <p className={`text-3xl font-bold tabular-nums ${numberColor}`}>{number}</p>
      <p className={`${MONO_LABEL} mt-1 mb-5`}>{title}</p>
      <div className="flex items-center gap-6">
        <DoughnutChart segments={segments} showCenterText={false} />
        <div className="flex flex-col gap-1 flex-1 min-w-0">
          {segments.length === 0 ? (
            <p className="text-sm text-text-secondary">No data</p>
          ) : (
            segments.map((seg) => {
              const href = linkFor && seg.key ? linkFor(seg.key) : null;
              const row = (
                <>
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: seg.color }} />
                  <span className="text-sm text-text-secondary truncate">{seg.label}</span>
                  <span className="ml-auto pl-2 text-sm font-semibold tabular-nums text-text-primary">{seg.value}</span>
                </>
              );
              return href ? (
                <Link key={seg.label} to={href}
                  className="flex items-center gap-2 rounded px-1 py-0.5 -mx-1 hover:bg-surface-hover transition-colors">
                  {row}
                </Link>
              ) : (
                <div key={seg.label} className="flex items-center gap-2 px-1 py-0.5 -mx-1">
                  {row}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Loading skeleton
// ---------------------------------------------------------------------------

function InsightsSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading insights">
      <div className="flex items-center gap-3">
        <div className="skeleton h-10 w-10 rounded-md" />
        <div className="space-y-2">
          <div className="skeleton h-6 w-36" />
          <div className="skeleton h-3.5 w-64" />
        </div>
      </div>
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton h-36 rounded-lg" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="skeleton h-60 rounded-lg" />
        ))}
      </div>
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton h-44 rounded-lg" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton h-52 rounded-lg" />
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main Insights Page
// ---------------------------------------------------------------------------

export default function InsightsPage() {
  const [data, setData] = useState<InsightsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState('');

  useEffect(() => {
    getProjects({ page_size: 100 }).then((res) => setProjects(res.items)).catch(() => {});
  }, []);

  const load = async (projectId?: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await getInsightsData(projectId || undefined);
      setData(result);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load insights');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(selectedProjectId || undefined); }, [selectedProjectId]);

  // ── Aggregations ────────────────────────────────────────────────

  const vulnTypeEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      const key = f.vulnerability_type || 'unknown';
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([key, value], idx) => ({ key, label: prettyLabel(key), value, color: vulnTypeColor(idx) }));
  }, [data]);

  const scannerEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      const key = f.scanner_source || 'unknown';
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([label, value], idx) => ({ label, value, color: scannerColor(label, idx) }));
  }, [data]);

  const owaspEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      const key = f.owasp_category || 'unknown';
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([key, value], idx) => ({
        key,
        label: key === 'unknown' ? 'Unknown' : key,
        value,
        color: vulnTypeColor(idx),
      }));
  }, [data]);

  const cweEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      const key = f.cwe || 'unknown';
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([label, value], idx) => ({ label, value, color: vulnTypeColor(idx) }));
  }, [data]);

  const endpointEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      if (f.endpoint && f.endpoint.trim()) {
        map.set(f.endpoint, (map.get(f.endpoint) || 0) + 1);
      }
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([label, value], idx) => ({ label, value, color: vulnTypeColor(idx) }));
  }, [data]);

  const fileEntries = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      if (f.file_path && f.file_path.trim()) {
        map.set(f.file_path, (map.get(f.file_path) || 0) + 1);
      }
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([label, value], idx) => ({ label, value, color: vulnTypeColor(idx) }));
  }, [data]);

  const findingsOverTime = useMemo(() => {
    if (!data) return [];
    return fillDaySeries(bucketByDay(data.findings, () => 1), false);
  }, [data]);

  const riskTrend = useMemo(() => {
    if (!data) return [];
    return fillDaySeries(bucketByDay(data.findings, (f) => f.risk_score || 0), true);
  }, [data]);

  const riskExposure = useMemo(() => {
    if (!data) return 0;
    return Math.round(data.findings.reduce((s, f) => s + (f.risk_score || 0), 0));
  }, [data]);

  const fixedCount = useMemo(() => {
    if (!data) return 0;
    return data.findings.filter(f => f.fix_applied).length;
  }, [data]);

  const uniqueEndpoints = useMemo(() => {
    if (!data) return 0;
    const set = new Set<string>();
    for (const f of data.findings) {
      if (f.endpoint && f.endpoint.trim()) set.add(f.endpoint);
    }
    return set.size;
  }, [data]);

  const topRiskFindings = useMemo(() => {
    if (!data) return [];
    // Only actionable findings belong in a "fix first" queue
    return data.findings
      .filter((f) => f.status === 'open' || f.status === 'confirmed')
      .sort((a, b) =>
        (b.risk_score ?? 0) - (a.risk_score ?? 0) ||
        (SEVERITY_RANK[a.severity] ?? 5) - (SEVERITY_RANK[b.severity] ?? 5),
      )
      .slice(0, 5);
  }, [data]);

  const fixAvailableCount = useMemo(() => {
    if (!data) return 0;
    return data.findings.filter((f) => f.fix_available).length;
  }, [data]);

  const mttrDays = useMemo(() => {
    if (!data) return null;
    const diffs: number[] = [];
    for (const f of data.findings) {
      if (f.status !== 'resolved' || !f.created_at || !f.updated_at) continue;
      const created = new Date(f.created_at).getTime();
      const updated = new Date(f.updated_at).getTime();
      if (isNaN(created) || isNaN(updated)) continue;
      diffs.push(updated - created);
    }
    if (diffs.length === 0) return null;
    const days = diffs.reduce((s, d) => s + d, 0) / diffs.length / 86_400_000;
    return Math.round(days * 10) / 10;
  }, [data]);

  // ── Severity segments ───────────────────────────────────────────

  const severitySegments: DoughnutSegment[] = useMemo(() => {
    if (!data) return [];
    const s = data.findingSummary;
    const items: { key: string; label: string }[] = [
      { key: 'critical', label: 'Critical' },
      { key: 'high', label: 'High' },
      { key: 'medium', label: 'Medium' },
      { key: 'low', label: 'Low' },
      { key: 'info', label: 'Info' },
    ];
    return items
      .map(({ key, label }) => ({
        key,
        value: (s as unknown as Record<string, number>)[key] || 0,
        color: SEVERITY_COLORS[key] || 'rgb(var(--color-border))',
        label,
      }))
      .filter((seg) => seg.value > 0);
  }, [data]);

  const confidenceSegments: DoughnutSegment[] = useMemo(() => {
    if (!data) return [];
    const s = data.findingSummary;
    return [
      { key: 'verified', label: 'Verified' },
      { key: 'probable', label: 'Probable' },
      { key: 'observed', label: 'Observed' },
    ]
      .map(({ key, label }) => ({
        key,
        value: (s as unknown as Record<string, number>)[key] || 0,
        color: CONFIDENCE_COLORS[key] || 'rgb(var(--color-border))',
        label,
      }))
      .filter((seg) => seg.value > 0);
  }, [data]);

  // ── Status segments — from loaded findings so every status shows ──

  const statusSegments: DoughnutSegment[] = useMemo(() => {
    if (!data) return [];
    const map = new Map<string, number>();
    for (const f of data.findings) {
      const key = f.status || 'open';
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([key, value]) => ({
        key,
        value,
        color: STATUS_COLORS[key] || 'rgb(var(--color-border))',
        label: STATUS_LABELS[key] || key,
      }));
  }, [data]);

  // ── Derived KPIs ────────────────────────────────────────────────

  const activeVulns = data ? data.findingSummary.open : 0;
  const totalFindings = data ? data.findingSummary.total : 0;
  const verifiedCount = data ? data.findingSummary.verified : 0;
  const resolvedCount = data ? data.findingSummary.resolved : 0;
  const loadedFindings = data ? data.findings.length : 0;
  const severityTotal = severitySegments.reduce((s, seg) => s + seg.value, 0);

  const funnelRows = [
    { label: 'Total findings', value: loadedFindings, color: 'rgb(var(--color-accent))' },
    { label: 'Fix available', value: fixAvailableCount, color: 'rgb(var(--color-info))' },
    { label: 'Fix applied', value: fixedCount, color: 'rgb(var(--color-medium))' },
    { label: 'Resolved', value: resolvedCount, color: 'rgb(var(--color-low))' },
  ];

  // ── Empty state ─────────────────────────────────────────────────

  const isEmpty = data && totalFindings === 0;

  // ── Render ──────────────────────────────────────────────────────

  if (loading) return <InsightsSkeleton />;

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-32 gap-4">
        <AlertCircle size={48} className="text-critical" />
        <p className="text-text-secondary">{error}</p>
        <button className="btn-primary" onClick={() => load(selectedProjectId || undefined)}>Retry</button>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Lightbulb}
        title="Insights"
        subtitle="Aggregated vulnerability analytics across all projects and scans."
        actions={
          <select
            className="select w-full sm:w-64"
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            aria-label="Filter by project"
          >
            <option value="">All Projects</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        }
      />

      {isEmpty ? (
        <div className="flex flex-col items-center justify-center gap-4 py-24">
          <Lightbulb size={48} className="text-text-secondary/50" />
          <p className="text-text-secondary text-sm text-center">
            No findings yet. Start a scan to generate data for insights.
          </p>
        </div>
      ) : (
        <>
          {/* ── Top Stat Cards ─────────────────────────────────── */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard
              label="Total Findings"
              value={totalFindings}
              caption="Across all scans"
              icon={<ScanSearch size={14} />}
              color="text-accent"
            />
            <StatCard
              label="Endpoints Affected"
              value={uniqueEndpoints}
              caption="Unique endpoints with findings"
              icon={<Network size={14} />}
              color="text-info"
            />
            <StatCard
              label="Verified"
              value={verifiedCount}
              caption="Confirmed exploitable findings"
              icon={<BadgeCheck size={14} />}
              color="text-verified"
            />
            <StatCard
              label="Risk Exposure"
              value={riskExposure}
              caption="Cumulative risk score"
              icon={<Flame size={14} />}
              color="text-high"
            />
          </div>

          {/* ── Doughnut Charts Row ───────────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <ChartCard
              title="Vulnerabilities by Severity"
              number={severityTotal}
              numberColor="text-critical"
              segments={severitySegments}
              linkFor={(k) => `/findings?severity=${k}`}
            />
            <ChartCard
              title="Confidence Distribution"
              number={verifiedCount}
              numberColor="text-verified"
              segments={confidenceSegments}
              linkFor={(k) => `/findings?confidence=${k}`}
            />
            <ChartCard
              title="Status Breakdown"
              number={activeVulns}
              numberColor="text-high"
              segments={statusSegments}
              linkFor={(k) => (k === 'duplicate' ? null : `/findings?status=${k}`)}
            />
          </div>

          {/* ── Trends Row ────────────────────────────────────── */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            <TrendCard
              label="Fixed Issues"
              value={fixedCount}
              color="text-accent"
              stroke="rgb(var(--color-accent))"
              caption="Fixes applied to findings"
            />
            <TrendCard
              label="Findings Over Time"
              value={findingsOverTime.length > 0 ? findingsOverTime[findingsOverTime.length - 1] : 0}
              color="text-info"
              stroke="rgb(var(--color-info))"
              points={findingsOverTime}
            />
            <TrendCard
              label="Risk Exposure Trend"
              value={riskTrend.length > 0 ? riskTrend[riskTrend.length - 1] : 0}
              color="text-medium"
              stroke="rgb(var(--color-medium))"
              points={riskTrend}
            />
            <TrendCard
              label="Mean Time to Remediate"
              value={mttrDays !== null ? `${mttrDays} days` : '—'}
              color="text-low"
              stroke="rgb(var(--color-low))"
              caption={mttrDays !== null ? 'Avg detection → resolution' : 'No resolved findings yet'}
            />
          </div>

          {/* ── Fix First + Remediation Funnel ────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Fix First — Highest Risk</h3>
              {topRiskFindings.length === 0 ? (
                <p className="text-text-secondary text-sm py-4 text-center">No findings loaded</p>
              ) : (
                <div className="space-y-1">
                  {topRiskFindings.map((f) => (
                    <Link key={f.id} to={`/findings/${f.id}`}
                      className="flex items-center gap-3 rounded px-2 py-1.5 -mx-2 hover:bg-surface-hover transition-colors">
                      <SeverityBadge severity={f.severity} />
                      <span className="flex-1 text-sm text-text-primary truncate" title={f.title}>{f.title}</span>
                      {f.endpoint && (
                        <span className="hidden sm:block max-w-[30%] truncate font-mono text-xs text-text-tertiary">{f.endpoint}</span>
                      )}
                      <span className="shrink-0 text-sm font-semibold tabular-nums text-high">{f.risk_score ?? 0}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Remediation Funnel</h3>
              <div className="space-y-3">
                {funnelRows.map((r) => (
                  <div key={r.label} className="flex items-center gap-3">
                    <span className="w-28 shrink-0 text-sm text-text-secondary">{r.label}</span>
                    <div className="flex-1 h-5 bg-background rounded overflow-hidden ring-1 ring-inset ring-black/5 dark:ring-white/5">
                      <div className="h-full rounded transition-all duration-500"
                        style={{
                          width: `${Math.max(loadedFindings > 0 ? (r.value / loadedFindings) * 100 : 0, 1.5)}%`,
                          backgroundColor: r.color,
                        }}
                      />
                    </div>
                    <span className="w-10 shrink-0 text-right text-sm tabular-nums text-text-primary">{r.value}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-xs text-text-secondary">
                Pipeline from detection to resolution — generate and apply fixes to move findings down the funnel.
              </p>
            </div>
          </div>

          {/* ── Distribution Bars Row 1 ───────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Vulnerability Types</h3>
              <DistBar
                items={vulnTypeEntries}
                total={loadedFindings}
                linkFor={(k) => `/findings?category=${encodeURIComponent(k)}`}
              />
            </div>
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Scanner Sources</h3>
              <DistBar
                items={scannerEntries}
                total={loadedFindings}
                linkFor={(k) => `/findings?scanner=${encodeURIComponent(k)}`}
              />
            </div>
          </div>

          {/* ── Distribution Bars Row 2 ───────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>OWASP Categories</h3>
              <DistBar
                items={owaspEntries}
                total={loadedFindings}
                linkFor={(k) => (k === 'unknown' ? null : `/findings?search=${encodeURIComponent(k)}`)}
              />
            </div>
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Top CWEs</h3>
              <DistBar
                items={cweEntries}
                total={loadedFindings}
                linkFor={(k) => (k === 'unknown' ? null : `/findings?search=${encodeURIComponent(k)}`)}
              />
            </div>
          </div>

          {/* ── Distribution Bars Row 3 ───────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Most Affected Endpoints <span className="text-text-tertiary font-normal">· {uniqueEndpoints} unique</span></h3>
              <DistBar
                items={endpointEntries}
                total={loadedFindings}
                emptyMessage="No endpoint-level findings — populated by dynamic scans (ZAP, nuclei)"
                linkFor={(k) => `/findings?search=${encodeURIComponent(k)}`}
              />
            </div>
            <div className="card animate-enter">
              <h3 className={`${MONO_LABEL} mb-4`}>Most Affected Files</h3>
              <DistBar
                items={fileEntries}
                total={loadedFindings}
                emptyMessage="No file-level findings — populated by static analysis (Semgrep, pip-audit, secrets)"
                linkFor={(k) => `/findings?search=${encodeURIComponent(k)}`}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}
