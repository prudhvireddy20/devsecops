import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Blocks, Mail, ChevronRight, AlertCircle } from 'lucide-react';
import PageHeader from '../components/PageHeader';
import { getIntegrations, type IntegrationSummary } from '../services/api';

const MONO_LABEL =
  'font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-text-secondary';

const INTEGRATION_ICONS: Record<string, React.ReactNode> = {
  email: <Mail size={22} />,
};

const INTEGRATION_ROUTES: Record<string, string> = {
  email: '/tools/integrations/email',
};

function IntegrationCard({ integration }: { integration: IntegrationSummary }) {
  const navigate = useNavigate();
  const route = INTEGRATION_ROUTES[integration.key];
  const connected = integration.connected && integration.enabled;

  return (
    <div
      className="card card-interactive animate-enter flex flex-col"
      role="button"
      tabIndex={0}
      onClick={() => route && navigate(route)}
      onKeyDown={(e) => {
        if (route && (e.key === 'Enter' || e.key === ' ')) navigate(route);
      }}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={`flex items-center justify-center w-11 h-11 rounded-lg ring-1 ring-inset transition-colors ${
            connected
              ? 'bg-accent/10 text-accent ring-accent/20'
              : 'bg-surface-hover text-text-primary ring-black/5 dark:ring-white/5'
          }`}
        >
          {INTEGRATION_ICONS[integration.key] ?? <Blocks size={22} />}
        </div>
        {connected ? (
          <span className="badge bg-accent/10 text-accent ring-accent/30">Connected</span>
        ) : integration.connected ? (
          <span className="badge bg-medium/10 text-medium ring-medium/30">Disabled</span>
        ) : (
          <span className="badge bg-surface-hover text-text-tertiary ring-border">
            Not configured
          </span>
        )}
      </div>
      <h3 className="text-base font-semibold text-text-primary mb-1.5">{integration.name}</h3>
      <p className="text-sm text-text-secondary leading-relaxed flex-1">
        {integration.description}
      </p>
      <div className="flex items-center justify-between mt-5 pt-4 border-t border-border">
        <span className="font-mono text-xs text-text-tertiary">{integration.auth_label}</span>
        <span className="flex items-center gap-0.5 text-sm font-medium text-accent">
          Manage <ChevronRight size={16} />
        </span>
      </div>
    </div>
  );
}

export default function IntegrationsPage() {
  const [integrations, setIntegrations] = useState<IntegrationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<'all' | 'connected'>('all');

  const load = () => {
    setLoading(true);
    setError(null);
    getIntegrations()
      .then(setIntegrations)
      .catch((err: unknown) =>
        setError(err instanceof Error ? err.message : 'Failed to load integrations'),
      )
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const connectedCount = integrations.filter((i) => i.connected && i.enabled).length;
  const visible =
    tab === 'connected'
      ? integrations.filter((i) => i.connected && i.enabled)
      : integrations;

  const categories = [...new Set(visible.map((i) => i.category))];

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-32 gap-4">
        <AlertCircle size={48} className="text-critical" />
        <p className="text-text-secondary">{error}</p>
        <button className="btn-primary" onClick={load}>Retry</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Blocks}
        title="Integrations"
        subtitle="Connect TraceON to the services your team already uses."
      />

      {/* Tabs */}
      <div className="inline-flex items-center gap-1 rounded-lg bg-surface p-1 ring-1 ring-inset ring-border">
        <button
          className={`px-3.5 py-1.5 rounded-md text-sm font-medium transition-colors ${
            tab === 'all'
              ? 'bg-surface-hover text-text-primary'
              : 'text-text-secondary hover:text-text-primary'
          }`}
          onClick={() => setTab('all')}
        >
          All integrations
        </button>
        <button
          className={`px-3.5 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1.5 ${
            tab === 'connected'
              ? 'bg-surface-hover text-text-primary'
              : 'text-text-secondary hover:text-text-primary'
          }`}
          onClick={() => setTab('connected')}
        >
          Connected
          <span className="px-1.5 py-0.5 rounded text-[11px] tabular-nums bg-surface-hover ring-1 ring-inset ring-border text-text-secondary">
            {connectedCount}
          </span>
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="skeleton h-56 rounded-lg" />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <p className="text-text-secondary text-sm py-16 text-center">
          No connected integrations yet — configure one from the “All integrations” tab.
        </p>
      ) : (
        categories.map((category) => {
          const items = visible.filter((i) => i.category === category);
          return (
            <section key={category} className="space-y-3">
              <p className={MONO_LABEL}>
                {category}{' '}
                <span className="ml-1 px-1.5 py-0.5 rounded bg-surface-hover ring-1 ring-inset ring-border tabular-nums">
                  {items.length}
                </span>
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {items.map((integration) => (
                  <IntegrationCard key={integration.key} integration={integration} />
                ))}
              </div>
            </section>
          );
        })
      )}
    </div>
  );
}
