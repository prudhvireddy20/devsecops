import { useCallback, useEffect, useMemo, useState } from 'react';
import { Bot, KeyRound, Link as LinkIcon, Loader2, Trash2, AlertCircle } from 'lucide-react';
import PageHeader from '../components/PageHeader';
import {
  connectLLMProvider,
  disconnectLLMProvider,
  getLLMProviders,
  type LLMProviderInfo,
} from '../services/api';
import Toast, { type ToastTone } from '../components/Toast';

function sourceText(source: LLMProviderInfo['source']): string {
  if (source === 'stored') return 'Connected via Tools';
  if (source === 'env') return 'Connected via environment';
  return 'Not connected';
}

function connectErrorMessage(err: unknown): string {
  const raw = err instanceof Error ? err.message : 'Failed to connect provider';
  const message = raw.toLowerCase();

  if (message.includes('invalid api key')) {
    return 'Invalid API key. Please check it and try again.';
  }

  if (message.includes('rejected model')) {
    return 'Key is valid, but this model is not available for your account. Choose another model and retry.';
  }

  if (
    message.includes('could not reach provider')
    || message.includes('timed out while validating')
    || message.includes('rate limiting')
    || message.includes('validation request failed')
  ) {
    return 'Could not verify with provider right now. Please try again in a moment.';
  }

  return raw;
}

export default function LLMProvidersPage() {
  const [providers, setProviders] = useState<LLMProviderInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [modelInput, setModelInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [disconnecting, setDisconnecting] = useState<string>('');
  const [toast, setToast] = useState<{ message: string; tone: ToastTone } | null>(null);

  const current = useMemo(
    () => providers.find((p) => p.provider === selectedProvider) || null,
    [providers, selectedProvider],
  );

  const loadProviders = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getLLMProviders();
      setProviders(data.providers || []);
      setError(null);
      if (!selectedProvider && data.providers.length > 0) {
        setSelectedProvider(data.providers[0].provider);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load LLM providers');
    } finally {
      setLoading(false);
    }
  }, [selectedProvider]);

  useEffect(() => {
    loadProviders();
  }, [loadProviders]);

  useEffect(() => {
    if (current) {
      setModelInput(current.default_model || '');
      setApiKeyInput('');
    }
  }, [current?.provider]);

  async function handleConnect() {
    if (!current) return;
    if (!apiKeyInput.trim()) {
      setToast({ message: 'API key is required to connect provider', tone: 'error' });
      return;
    }
    setSaving(true);
    try {
      await connectLLMProvider(current.provider, {
        api_key: apiKeyInput.trim(),
        default_model: modelInput || undefined,
      });
      setToast({ message: `${current.label} key verified and connected`, tone: 'success' });
      await loadProviders();
      setApiKeyInput('');
    } catch (err: unknown) {
      const message = connectErrorMessage(err);
      setToast({ message, tone: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function handleUpdateModel() {
    if (!current) return;
    setSaving(true);
    try {
      await connectLLMProvider(current.provider, {
        default_model: modelInput || undefined,
      });
      setToast({ message: `${current.label} model updated`, tone: 'success' });
      await loadProviders();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to update model';
      setToast({ message, tone: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function handleDisconnect(provider: string) {
    setDisconnecting(provider);
    try {
      await disconnectLLMProvider(provider);
      setToast({ message: `${provider} disconnected`, tone: 'success' });
      await loadProviders();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to disconnect provider';
      setToast({ message, tone: 'error' });
    } finally {
      setDisconnecting('');
    }
  }

  if (loading) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading providers">
        <div className="flex items-center gap-3">
          <div className="skeleton h-10 w-10 rounded-md" />
          <div className="space-y-2">
            <div className="skeleton h-6 w-44" />
            <div className="skeleton h-3.5 w-80" />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="skeleton h-64 rounded-lg" />
          <div className="skeleton h-64 rounded-lg lg:col-span-2" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Bot}
        title="LLM Providers"
        subtitle="Connect API keys once, then select provider and model at scan time."
      />

      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card lg:col-span-1 space-y-2">
          <h2 className="text-sm font-semibold text-text-primary">Providers</h2>
          {providers.map((p) => (
            <button
              key={p.provider}
              type="button"
              className={`w-full text-left p-3 rounded-lg border transition-colors ${
                selectedProvider === p.provider
                  ? 'border-accent bg-accent/10'
                  : 'border-border bg-background hover:border-text-secondary'
              }`}
              onClick={() => setSelectedProvider(p.provider)}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-text-primary text-sm">{p.label}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${p.connected ? 'bg-accent/20 text-accent' : 'bg-surface text-text-secondary'}`}>
                  {p.connected ? 'Connected' : 'Not connected'}
                </span>
              </div>
              <p className="text-xs text-text-secondary mt-1">{sourceText(p.source)}</p>
              {p.needs_reconnect && (
                <p className="text-[11px] text-critical mt-1">
                  Key cannot be decrypted after restart. Reconnect required.
                </p>
              )}
            </button>
          ))}
        </div>

        <div className="card lg:col-span-2">
          {!current ? (
            <p className="text-text-secondary text-sm">Select a provider to configure it.</p>
          ) : (
             <div className="space-y-4">
               <div className="flex items-center gap-2">
                 <LinkIcon size={16} className="text-accent" />
                 <h2 className="text-lg font-semibold text-text-primary">{current.label}</h2>
               </div>

                <div>
                    <label className="block text-sm font-medium text-text-secondary mb-1.5">
                      Default Model
                    </label>
                    <select
                      className="select"
                      value={modelInput}
                      onChange={(e) => setModelInput(e.target.value)}
                    >
                      {current.models.map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                    <p className="text-xs text-text-secondary mt-1">
                      This model is preselected when you choose {current.label} during scan config.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-secondary mb-1.5">
                      API Key
                    </label>
                    <input
                      type="password"
                      className="input"
                      placeholder="Paste API key"
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                    />
                    <p className="text-xs text-text-secondary mt-1">
                      Key is validated with provider before saving. Keys are encrypted at rest and never shown.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <button
                      type="button"
                      className="btn-primary"
                      disabled={saving || !apiKeyInput.trim()}
                      onClick={handleConnect}
                    >
                      {saving ? (
                        <span className="flex items-center gap-2">
                          <Loader2 size={16} className="animate-spin" />
                          Saving...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <KeyRound size={16} />
                          Connect / Update Key
                        </span>
                      )}
                    </button>

                    <p className="text-xs text-text-secondary">
                      Entering a key always performs a live verification before it is saved.
                    </p>

                    <button
                      type="button"
                      className="btn-secondary"
                      disabled={saving}
                      onClick={handleUpdateModel}
                    >
                      Save Model Only
                    </button>

                    <button
                      type="button"
                      className="btn-danger"
                      disabled={disconnecting === current.provider || current.source === 'env'}
                      onClick={() => handleDisconnect(current.provider)}
                    >
                      {disconnecting === current.provider ? (
                        <span className="flex items-center gap-2">
                          <Loader2 size={16} className="animate-spin" />
                          Disconnecting...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Trash2 size={16} />
                          Disconnect Stored Key
                        </span>
                      )}
                    </button>
                  </div>

                  {current.source === 'env' && (
                    <p className="text-xs text-text-secondary">
                      This provider is connected via environment variable. To remove it, clear the env key in backend config.
                    </p>
                  )}
            </div>
          )}
        </div>
      </div>

      <Toast
        open={Boolean(toast)}
        message={toast?.message ?? ''}
        tone={toast?.tone ?? 'info'}
        onClose={() => setToast(null)}
      />
    </div>
  );
}
