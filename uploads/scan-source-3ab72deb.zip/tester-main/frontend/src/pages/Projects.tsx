import { useState, useEffect, useCallback } from 'react';
import TrustScanConnectModal from '../components/TrustScanConnectModal';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Plus,
  Trash2,
  FolderOpen,
  GitBranch,
  Upload,
  HardDrive,
  KeyRound,
  Pencil,
  X,
  Loader2,
  AlertCircle,
  Calendar,
  Code2,
  ExternalLink,
  ScanSearch,
  ChevronDown,
} from 'lucide-react';
import {
  getProjects,
  createProject,
  deleteProject,
  updateProject,
  uploadProjectFindings,
  uploadProjectArtifact,
  type Project,
  type CreateProjectPayload,
} from '../services/api';
import { formatDate } from '../utils/datetime';
import Toast, { type ToastTone } from '../components/Toast';
import PageHeader from '../components/PageHeader';

// ---------------------------------------------------------------------------
// Source type icon
// ---------------------------------------------------------------------------

function SourceTypeIcon({ type }: { type: string }) {
  switch (type) {
    case 'git':
      return <GitBranch size={16} className="text-accent" />;
    case 'zip':
      return <Upload size={16} className="text-medium" />;
    case 'local':
      return <HardDrive size={16} className="text-low" />;
    case 'url':
      return <ScanSearch size={16} className="text-text-secondary" />;
    default:
      return <Code2 size={16} className="text-text-secondary" />;
  }
}

// ---------------------------------------------------------------------------
// Create Project Modal
// ---------------------------------------------------------------------------

type ScanMode = 'whitebox' | 'blackbox';

interface CreateModalProps {
  open: boolean;
  onClose: () => void;
  onCreated: (p: Project) => void;
}

interface ModeCard {
  mode: ScanMode;
  label: string;
  desc: string;
  icon: React.ReactNode;
  longDesc: string;
}

const MODE_CARDS: ModeCard[] = [
  {
    mode: 'whitebox',
    label: 'White-box',
    desc: 'Import static results from TrustScan, then DAST',
    longDesc: 'Connect to your TrustScan platform to import static findings. TraceON enriches with DAST and correlation.',
    icon: <ExternalLink size={20} className="text-amber-500" />
  },
  {
    mode: 'blackbox',
    label: 'Black-box',
    desc: 'Live app only. Full discovery pipeline. No source, no JSON.',
    longDesc: 'No source code needed. ZAP, Nuclei, FFUF, and other discovery tools run against the live target.',
    icon: <ScanSearch size={20} className="text-purple-500" />
  },
];

function CreateProjectModal({ open, onClose, onCreated }: CreateModalProps) {
  const [scanMode, setScanMode] = useState<ScanMode>('whitebox');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [gitUrl, setGitUrl] = useState('');
  const [branch, setBranch] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [trustscanConnected, setTrustscanConnected] = useState(false);
  const [trustscanToken, setTrustscanToken] = useState('');
  const [trustscanBaseUrl, setTrustscanBaseUrl] = useState('');
  const [trustscanOauthState, setTrustscanOauthState] = useState('');
  const [showTrustScanModal, setShowTrustScanModal] = useState(false);
  const [trustscanJobs, setTrustscanJobs] = useState<Array<{id: string; status: string; repo_url?: string; created_at?: string}>>([]);
  const [trustscanJobId, setTrustscanJobId] = useState('');
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [findingsSource, setFindingsSource] = useState<'trustscan' | 'upload'>('trustscan');
  const [findingsFile, setFindingsFile] = useState<File | null>(null);
  const [findingsFileName, setFindingsFileName] = useState('');
  const [uploadingFindings, setUploadingFindings] = useState(false);
  const [authEnabled, setAuthEnabled] = useState(false);
  const [authType, setAuthType] = useState<'none' | 'basic' | 'form' | 'playwright'>('none');
  const [authUsername, setAuthUsername] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authLoginUrl, setAuthLoginUrl] = useState('');
  const [authScript, setAuthScript] = useState('');
  const [roles, setRoles] = useState<string[]>([]);
  const [roleInput, setRoleInput] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [animClass, setAnimClass] = useState('opacity-100');

  function reset() {
    setScanMode('whitebox');
    setName('');
    setDescription('');
    setTargetUrl('');
    setTrustscanConnected(false);
    setTrustscanToken('');
    setTrustscanBaseUrl('');
    setTrustscanOauthState('');
    setShowTrustScanModal(false);
    setTrustscanJobs([]);
    setTrustscanJobId('');
    setLoadingJobs(false);
    setFindingsSource('trustscan');
    setFindingsFile(null);
    setFindingsFileName('');
    setUploadingFindings(false);
    setAuthEnabled(false);
    setAuthType('none');
    setAuthUsername('');
    setAuthPassword('');
    setAuthLoginUrl('');
    setAuthScript('');
    setRoles([]);
    setRoleInput('');
    setError(null);
    setAnimClass('opacity-100');
  }

  function addRole() {
    const trimmed = roleInput.trim();
    if (trimmed && !roles.includes(trimmed)) {
      setRoles((prev) => [...prev, trimmed]);
      setRoleInput('');
    }
  }

  function removeRole(role: string) {
    setRoles((prev) => prev.filter((r) => r !== role));
  }

  function switchMode(mode: ScanMode) {
    setAnimClass('opacity-0 translate-y-1');
    setTimeout(() => {
      setScanMode(mode);
      setAnimClass('opacity-100 translate-y-0');
    }, 120);
  }

  async function loadTrustScanJobs(state?: string) {
    const s = state || trustscanOauthState;
    if (!s) return;
    setLoadingJobs(true);
    try {
      const { getApiKey } = await import('../services/api');
      const apiKey = getApiKey();
      const res = await fetch(`/api/v1/trustscan/oauth/jobs?state=${encodeURIComponent(s)}`, {
        headers: { 'X-API-Key': apiKey || '' },
      });
      if (res.ok) {
        const data = await res.json();
        setTrustscanJobs(data.jobs || []);
      }
    } catch {
      // silently fail — user can retry
    } finally {
      setLoadingJobs(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setError('Project name is required'); return; }
    if (!targetUrl.trim()) { setError('Target URL is required'); return; }

    setSubmitting(true);
    setError(null);
    try {
      const payload: CreateProjectPayload = {
        name: name.trim(),
        description: description.trim(),
        scan_mode: scanMode,
        source_type: 'url',
        target_url: targetUrl.trim(),
      };
      if (scanMode === 'whitebox' && trustscanConnected) {
        if (trustscanToken) payload.trustscan_token = trustscanToken;
        if (trustscanBaseUrl) payload.trustscan_url = trustscanBaseUrl;
        if (trustscanJobId) payload.trustscan_job_id = trustscanJobId;
        if (trustscanOauthState) payload.trustscan_oauth_project_id = trustscanOauthState;
      }
      if (authEnabled && authType !== 'none') {
        payload.auth_config = {
          auth_type: authType,
          ...(authUsername ? { username: authUsername } : {}),
          ...(authPassword ? { password: authPassword } : {}),
          ...(authLoginUrl && authType === 'form' ? { login_url: authLoginUrl } : {}),
          ...(authScript && authType === 'playwright' ? { playwright_script: authScript } : {}),
          ...(roles.length > 0 ? { roles } : {}),
        };
      }

      const project = await createProject(payload);

      // Upload findings JSON if manual upload mode was selected
      if (findingsSource === 'upload' && findingsFile && project?.id) {
        setUploadingFindings(true);
        try {
          await uploadProjectFindings(project.id, findingsFile);
        } catch (err) {
          console.error('Findings upload failed:', err);
          // Non-fatal — project is created, findings can be re-uploaded later
        } finally {
          setUploadingFindings(false);
        }
      }

      onCreated(project);
      reset();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to create project');
    } finally {
      setSubmitting(false);
    }
  }

  if (!open) return null;

  return (
    <>
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface border border-border rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4">
        <div className="sticky top-0 flex items-center justify-between p-6 border-b border-border bg-surface">
          <div>
            <h2 className="text-lg font-semibold text-text-primary">New project</h2>
            <p className="text-xs text-text-secondary mt-1">Choose a scan mode — each mode runs a different pipeline.</p>
          </div>
          <button onClick={onClose} className="text-text-secondary hover:text-text-primary transition-colors shrink-0"><X size={20} /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm">
              <AlertCircle size={16} />{error}
            </div>
          )}

          {/* Mode cards */}
          <div className="grid grid-cols-2 gap-3">
            {MODE_CARDS.map((m) => {
              const active = scanMode === m.mode;
              return (
                <button
                  key={m.mode}
                  type="button"
                  className={`flex flex-col gap-2 p-4 rounded-lg border transition-all text-left ${
                    active
                      ? 'border-accent/50 bg-accent/10 shadow-md'
                      : 'border-border bg-surface hover:border-border/80 hover:bg-background'
                  }`}
                  onClick={() => switchMode(m.mode)}
                >
                  <div className="flex items-center gap-2.5">
                    {m.icon}
                    <span className={`text-sm font-semibold ${active ? 'text-accent' : 'text-text-primary'}`}>
                      {m.label}
                    </span>
                  </div>
                  <span className="text-xs text-text-secondary leading-relaxed">{m.desc}</span>
                </button>
              );
            })}
          </div>

          {/* Name + Description row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <label className="text-xs font-semibold text-text-secondary">Project name</label>
                <span className="text-critical text-[10px]">required</span>
              </div>
              <input type="text" className="input" placeholder="e.g. my-api-staging" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <label className="text-xs font-semibold text-text-secondary">Description</label>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full border border-border text-text-tertiary">optional</span>
              </div>
              <input type="text" className="input" placeholder="Brief description" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
          </div>

          {/* ── MODE-SPECIFIC FIELDS ── */}
          <div className={`transition-all duration-200 ${animClass}`}>
            {/* ── WHITEBOX ── */}
            {scanMode === 'whitebox' && (
              <div className="space-y-4">
                <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <AlertCircle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-amber-700">
                    TraceON imports static analysis findings from your TrustScan platform. Combined with dynamic scanning (DAST), this provides full code and runtime coverage.
                  </p>
                </div>

                <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-wider text-text-tertiary">
                  <span>Static findings source</span>
                  <div className="flex-1 h-px bg-border" />
                </div>

                {/* Source toggle */}
                <div className="flex rounded-lg border border-border overflow-hidden text-xs font-medium">
                  <button
                    type="button"
                    className={`flex-1 py-1.5 transition-colors ${findingsSource === 'trustscan' ? 'bg-accent text-white' : 'bg-surface text-text-secondary hover:bg-border'}`}
                    onClick={() => setFindingsSource('trustscan')}
                  >
                    Connect TrustScan
                  </button>
                  <button
                    type="button"
                    className={`flex-1 py-1.5 transition-colors ${findingsSource === 'upload' ? 'bg-accent text-white' : 'bg-surface text-text-secondary hover:bg-border'}`}
                    onClick={() => setFindingsSource('upload')}
                  >
                    Upload JSON
                  </button>
                </div>

                {findingsSource === 'upload' ? (
                  <div className="border border-border rounded-lg overflow-hidden">
                    <div className="flex items-center gap-3 px-4 py-3 bg-surface border-b border-border">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${findingsFile ? 'bg-accent/10 text-accent' : 'bg-border text-text-tertiary'}`}>
                        {findingsFile ? '✓' : <Upload size={13} />}
                      </div>
                      <div className="flex-1">
                        <div className="text-xs font-semibold text-text-primary">Upload findings JSON</div>
                        <div className="text-[10px] text-text-tertiary">Semgrep · SARIF · Gitleaks · Trivy · TrustScan</div>
                      </div>
                      <span className={`text-[10px] px-2 py-1 rounded-full font-medium ${findingsFile ? 'bg-accent/10 text-accent' : 'bg-border text-text-tertiary'}`}>
                        {findingsFile ? 'Ready' : 'No file'}
                      </span>
                    </div>
                    <div className="p-4">
                      <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-accent transition-colors">
                        <input
                          type="file"
                          accept=".json"
                          className="hidden"
                          onChange={(e) => {
                            const f = e.target.files?.[0] || null;
                            setFindingsFile(f);
                            setFindingsFileName(f?.name || '');
                          }}
                        />
                        {findingsFileName ? (
                          <span className="text-xs text-text-primary font-medium">{findingsFileName}</span>
                        ) : (
                          <>
                            <Upload size={16} className="text-text-tertiary mb-1" />
                            <span className="text-xs text-text-tertiary">Click to browse or drop a JSON file here</span>
                            <span className="text-[10px] text-text-tertiary mt-0.5">Auto-detects Semgrep, SARIF, Gitleaks, Trivy, TrustScan formats</span>
                          </>
                        )}
                      </label>
                    </div>
                  </div>
                ) : (
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="flex items-center gap-3 px-4 py-3 bg-surface border-b border-border">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${
                      trustscanConnected ? 'bg-accent/10 text-accent' : 'bg-border text-text-tertiary'
                    }`}>
                      {trustscanConnected ? '✓' : '⊘'}
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-semibold text-text-primary">TrustScan platform</div>
                      <div className="text-[10px] text-text-tertiary">Scan job import</div>
                    </div>
                    <span className={`text-[10px] px-2 py-1 rounded-full font-medium ${
                      trustscanConnected ? 'bg-accent/10 text-accent' : 'bg-border text-text-tertiary'
                    }`}>
                      {trustscanConnected ? 'Connected' : 'Disconnected'}
                    </span>
                  </div>
                  <div className="p-4 space-y-3">
                    {!trustscanConnected ? (
                      <div className="text-center py-6">
                        <div className="text-[10px] text-text-tertiary mb-3">
                          <p className="mb-2">TrustScan platform not configured</p>
                          <p>Authorize TraceON to access your TrustScan scan jobs</p>
                        </div>
                        <button
                          type="button"
                          className="btn-secondary text-xs px-3 py-1.5"
                          onClick={() => setShowTrustScanModal(true)}
                        >
                          Connect TrustScan ↗
                        </button>
                      </div>
                    ) : (
                      <div>
                        {trustscanJobs.length > 0 ? (
                          <>
                            <div className="flex items-center gap-2 mb-1.5">
                              <label className="text-xs font-semibold text-text-secondary">Select scan job</label>
                              <span className="text-[10px] text-text-tertiary">(optional)</span>
                            </div>
                            <div className="flex gap-2">
                              <select
                                className="input flex-1 text-xs"
                                value={trustscanJobId}
                                onChange={(e) => setTrustscanJobId(e.target.value)}
                              >
                                <option value="">— choose a completed scan job —</option>
                                {trustscanJobs.map((job) => (
                                  <option key={job.id} value={job.id}>
                                    {job.repo_url ? job.repo_url.replace('https://github.com/', '') : job.id}
                                    {job.status ? ` · ${job.status}` : ''}
                                  </option>
                                ))}
                              </select>
                              <button
                                type="button"
                                className="btn-secondary px-3 shrink-0 text-xs"
                                onClick={() => loadTrustScanJobs()}
                                disabled={loadingJobs}
                              >
                                {loadingJobs ? 'Loading…' : 'Refresh'}
                              </button>
                            </div>
                            <p className="text-[10px] text-text-tertiary mt-2">TraceON fetches findings and repo metadata automatically from TrustScan.</p>
                          </>
                        ) : (
                          <>
                            <div className="rounded-lg border border-info/30 bg-info/10 p-3 space-y-2">
                              <p className="text-xs font-semibold text-info">No scans found on TrustScan</p>
                              <p className="text-[11px] text-text-secondary">
                                Run a static scan on TrustScan first, then return here and click Refresh.
                              </p>
                              <a
                                href={trustscanBaseUrl || 'https://trustscan.sc.deeptrustxai.com'}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-[11px] text-info underline hover:text-accent"
                              >
                                Open TrustScan dashboard ↗
                              </a>
                            </div>
                            <div className="flex justify-end mt-2">
                              <button
                                type="button"
                                className="btn-secondary px-3 shrink-0 text-xs"
                                onClick={() => loadTrustScanJobs()}
                                disabled={loadingJobs}
                              >
                                {loadingJobs ? 'Loading…' : 'Refresh'}
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                )}

                <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-wider text-text-tertiary pt-2">
                  <span>Live target</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <label className="text-xs font-semibold text-text-secondary">Target URL</label>
                    <span className="text-critical text-[10px]">required</span>
                  </div>
                  <input type="url" className="input" placeholder="https://staging.myapp.com" value={targetUrl} onChange={(e) => setTargetUrl(e.target.value)} />
                  <p className="text-[10px] text-text-tertiary mt-2">The running application that ZAP will spider and test for vulnerabilities.</p>
                </div>
              </div>
            )}

            {/* ── BLACKBOX ── */}
            {scanMode === 'blackbox' && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-wider text-text-tertiary">
                  <span>Target</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <label className="text-xs font-semibold text-text-secondary">Target URL</label>
                    <span className="text-critical text-[10px]">required</span>
                  </div>
                  <input type="url" className="input" placeholder="https://target.example.com" value={targetUrl} onChange={(e) => setTargetUrl(e.target.value)} />
                  <p className="text-[10px] text-text-tertiary mt-2">The live application that discovery tools will enumerate and scan.</p>
                </div>

              </div>
            )}
          </div>

          {/* Auth config — optional for all modes */}
          <div className="border-t border-border pt-4">
            <button type="button"
              onClick={() => setAuthEnabled(!authEnabled)}
              className="flex items-center justify-between w-full hover:opacity-80 transition-opacity"
            >
              <div className="flex items-center gap-2">
                <KeyRound size={14} className="text-text-secondary" />
                <span className="text-xs font-semibold text-text-secondary">Authentication config</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full border border-border text-text-tertiary">optional</span>
              </div>
              <span className={`text-text-tertiary transition-transform ${authEnabled ? 'rotate-180' : ''}`}>
                <ChevronDown size={14} />
              </span>
            </button>
            {authEnabled && (
              <div className="mt-4 space-y-4">
                {/* Auth type */}
                <div>
                  <label className="text-xs font-semibold text-text-secondary mb-1.5 block">Auth Type</label>
                  <select className="input" value={authType} onChange={(e) => setAuthType(e.target.value as typeof authType)}>
                    <option value="none">None (unauthenticated scan)</option>
                    <option value="basic">HTTP Basic Auth</option>
                    <option value="form">Form-based Login</option>
                    <option value="playwright">Playwright Script</option>
                  </select>
                </div>

                {/* Username & Password (for basic and form auth) */}
                {(authType === 'basic' || authType === 'form') && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-text-secondary mb-1.5 block">Username</label>
                      <input type="text" className="input" placeholder="admin" value={authUsername} onChange={(e) => setAuthUsername(e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-text-secondary mb-1.5 block">Password</label>
                      <input type="password" className="input" placeholder="password" value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} />
                    </div>
                  </div>
                )}

                {/* Login URL (form login only) */}
                {authType === 'form' && (
                  <div>
                    <label className="text-xs font-semibold text-text-secondary mb-1.5 block">
                      Login URL <span className="font-normal text-text-tertiary">(optional — leave blank for auto-detection)</span>
                    </label>
                    <input
                      type="url"
                      className="input"
                      placeholder="https://yourapp.com/api/login"
                      value={authLoginUrl}
                      onChange={(e) => setAuthLoginUrl(e.target.value)}
                    />
                  </div>
                )}

                {/* Playwright script textarea */}
                {authType === 'playwright' && (
                  <div>
                    <label className="text-xs font-semibold text-text-secondary mb-1.5 block">Playwright Script</label>
                    <textarea
                      className="input font-mono text-xs resize-y"
                      rows={8}
                      placeholder={`async ({ page, username, password, loginUrl }) => {\n  await page.goto(loginUrl);\n  await page.fill('[name=username]', username);\n  await page.fill('[name=password]', password);\n  await page.click('[type=submit]');\n  await page.waitForNavigation();\n}`}
                      value={authScript}
                      onChange={(e) => setAuthScript(e.target.value)}
                    />
                    <p className="text-[10px] text-text-tertiary mt-1">
                      Async function receiving page, username, password, loginUrl. Cookies are extracted after execution.
                    </p>
                  </div>
                )}

                {/* Roles */}
                <div>
                  <label className="text-xs font-semibold text-text-secondary mb-1.5 block">Roles to Test</label>
                  <div className="flex gap-2 mb-2">
                    <input type="text" className="input flex-1 text-xs" placeholder="e.g. admin, user, moderator" value={roleInput} onChange={(e) => setRoleInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addRole(); } }} />
                    <button type="button" className="btn-secondary px-3 text-xs" onClick={addRole} disabled={!roleInput.trim()}>
                      <Plus size={12} /> Add
                    </button>
                  </div>
                  {roles.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {roles.map((role) => (
                        <span key={role} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-background border border-border text-xs text-text-primary">
                          {role}
                          <button type="button" className="text-text-secondary hover:text-critical" onClick={() => removeRole(role)}>
                            <X size={10} />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                  <p className="text-[10px] text-text-tertiary mt-1.5">Each role will be tested independently for authorization flaws.</p>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between gap-3 pt-4 border-t border-border">
            <button type="submit" className="btn-primary flex-1" disabled={submitting || uploadingFindings}>
              {uploadingFindings ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 size={14} className="animate-spin" />
                  Uploading findings…
                </span>
              ) : submitting ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 size={14} className="animate-spin" />
                  Creating...
                </span>
              ) : (
                'Create project and start scan'
              )}
            </button>
            <button type="button" className="btn-secondary" onClick={() => { reset(); onClose(); }} disabled={submitting}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>

    <TrustScanConnectModal
      isOpen={showTrustScanModal}
      onClose={() => setShowTrustScanModal(false)}
      onConnected={(token, baseUrl, state) => {
        setTrustscanConnected(true);
        setTrustscanToken(token);
        setTrustscanBaseUrl(baseUrl);
        setTrustscanOauthState(state);
        setShowTrustScanModal(false);
        loadTrustScanJobs(state);
      }}
    />
    </>
  );
}

// ---------------------------------------------------------------------------
// Delete confirmation dialog
// ---------------------------------------------------------------------------

interface DeleteDialogProps {
  project: Project | null;
  onClose: () => void;
  onConfirm: () => void;
  deleting: boolean;
}


// ---------------------------------------------------------------------------
// Edit Project Modal
// ---------------------------------------------------------------------------

interface EditModalProps {
  project: Project | null;
  onClose: () => void;
  onSaved: (p: Project) => void;
}

function EditProjectModal({ project, onClose, onSaved }: EditModalProps) {
  const [name, setName] = useState(project?.name ?? '');
  const [description, setDescription] = useState(project?.description ?? '');
  const [targetUrl, setTargetUrl] = useState(project?.target_url ?? '');
  const [findingsFile, setFindingsFile] = useState<File | null>(null);
  const [openapiFile, setOpenapiFile] = useState<File | null>(null);
  const [postmanFile, setPostmanFile] = useState<File | null>(null);
  const [journeyFile, setJourneyFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (project) {
      setName(project.name);
      setDescription(project.description ?? '');
      setTargetUrl(project.target_url ?? '');
      setFindingsFile(null);
      setOpenapiFile(null);
      setPostmanFile(null);
      setJourneyFile(null);
      setError(null);
    }
  }, [project]);

  if (!project) return null;

  async function handleSave() {
    if (!project || !name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const updated = await updateProject(project.id, {
        name: name.trim(),
        description: description.trim(),
        target_url: targetUrl.trim(),
      });
      if (findingsFile) await uploadProjectFindings(project.id, findingsFile);
      if (openapiFile) await uploadProjectArtifact(project.id, 'openapi', openapiFile);
      if (postmanFile) await uploadProjectArtifact(project.id, 'postman', postmanFile);
      if (journeyFile) await uploadProjectArtifact(project.id, 'journey', journeyFile);
      onSaved(updated);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save project');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface border border-border rounded-xl shadow-2xl w-full max-w-lg mx-4 p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent/10">
              <Pencil size={20} className="text-accent" />
            </div>
            <h3 className="text-lg font-semibold text-text-primary">Edit Project</h3>
          </div>
          <button className="text-text-secondary hover:text-text-primary" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm mb-4">
            <AlertCircle size={14} />
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="label">Project Name *</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea className="input min-h-[72px] resize-none" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <label className="label">Target URL</label>
            <input className="input" value={targetUrl} onChange={(e) => setTargetUrl(e.target.value)} placeholder="https://target.example.com" />
          </div>

          <div className="border-t border-border pt-4 space-y-3">
            <p className="text-xs font-semibold text-text-secondary uppercase tracking-wider">Replace Files (optional)</p>
            <div>
              <label className="label">External Findings (JSON)</label>
              <input type="file" accept=".json" className="input text-sm" onChange={(e) => setFindingsFile(e.target.files?.[0] ?? null)} />
            </div>
            <div>
              <label className="label">OpenAPI Spec (.json / .yaml)</label>
              <input type="file" accept=".json,.yaml,.yml" className="input text-sm" onChange={(e) => setOpenapiFile(e.target.files?.[0] ?? null)} />
            </div>
            <div>
              <label className="label">Postman Collection (.json)</label>
              <input type="file" accept=".json" className="input text-sm" onChange={(e) => setPostmanFile(e.target.files?.[0] ?? null)} />
            </div>
            <div>
              <label className="label">Journey / HAR File</label>
              <input type="file" accept=".json,.har" className="input text-sm" onChange={(e) => setJourneyFile(e.target.files?.[0] ?? null)} />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 mt-6">
          <button className="btn-secondary" onClick={onClose} disabled={saving}>Cancel</button>
          <button className="btn-primary" onClick={handleSave} disabled={saving || !name.trim()}>
            {saving ? (
              <span className="flex items-center gap-2"><Loader2 size={16} className="animate-spin" />Saving…</span>
            ) : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

function DeleteConfirmDialog({ project, onClose, onConfirm, deleting }: DeleteDialogProps) {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface border border-border rounded-xl shadow-2xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-critical/10">
            <Trash2 size={20} className="text-critical" />
          </div>
          <h3 className="text-lg font-semibold text-text-primary">Delete Project</h3>
        </div>
        <p className="text-text-secondary text-sm mb-6">
          Are you sure you want to delete <strong className="text-text-primary">{project.name}</strong>?
          This will permanently remove all associated scans, findings, and files. This action cannot be undone.
        </p>
        <div className="flex items-center justify-end gap-3">
          <button className="btn-secondary" onClick={onClose} disabled={deleting}>
            Cancel
          </button>
          <button className="btn-danger" onClick={onConfirm} disabled={deleting}>
            {deleting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Deleting...
              </span>
            ) : (
              'Delete'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Projects page
// ---------------------------------------------------------------------------

export default function Projects() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(searchParams.get('new') === '1');
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [editTarget, setEditTarget] = useState<Project | null>(null);
  const [toast, setToast] = useState<{ message: string; tone: ToastTone } | null>(null);

  const loadProjects = useCallback(async () => {
    try {
      setLoading(true);
      const resp = await getProjects({ page_size: 100 });
      // Handle both array and paginated response shapes
      const list = Array.isArray(resp) ? resp : resp.items ?? [];
      setProjects(list);
      setError(null);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to load projects';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  function openModal() {
    setModalOpen(true);
    setSearchParams({});
  }

  function handleCreated(project: Project) {
    setProjects((prev) => [project, ...prev]);
    setToast({ message: `Project ${project.name} created`, tone: 'success' });
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteProject(deleteTarget.id);
      setProjects((prev) => prev.filter((p) => p.id !== deleteTarget.id));
      setToast({ message: `Deleted project ${deleteTarget.name}`, tone: 'success' });
      setDeleteTarget(null);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to delete project';
      setError(message);
      setToast({ message, tone: 'error' });
    } finally {
      setDeleting(false);
    }
  }

  function handleSaved(updated: Project) {
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    setToast({ message: `Project "${updated.name}" updated`, tone: 'success' });
    setEditTarget(null);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full py-32">
        <Loader2 size={32} className="animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        icon={FolderOpen}
        title="Projects"
        count={projects.length}
        subtitle="Scan targets — local source, Git repos, or live URLs."
        actions={
          <button className="btn-primary flex w-full items-center justify-center gap-2 sm:w-auto" onClick={openModal}>
            <Plus size={16} />
            Create Project
          </button>
        }
      />

      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      {/* Project cards grid */}
      {projects.length === 0 ? (
        <div className="card animate-enter flex flex-col items-center justify-center py-16 gap-4">
          <FolderOpen size={48} className="text-text-secondary" />
          <p className="text-text-secondary text-center">
            No projects yet. Create one to get started.
          </p>
          <button className="btn-primary flex items-center gap-2" onClick={openModal}>
            <Plus size={16} />
            Create Project
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project) => (
            <article
              key={project.id}
              className="card hover:border-accent/50 transition-colors cursor-pointer group relative text-left w-full"
              onClick={() => navigate(`/projects/${project.id}/scan`)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  navigate(`/projects/${project.id}/scan`);
                }
              }}
              aria-label={`Open project ${project.name}`}
              role="button"
              tabIndex={0}
            >
              {/* Action buttons */}
              <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  className="text-text-secondary hover:text-accent p-1 rounded hover:bg-accent/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/projects/${project.id}/scan`);
                  }}
                  title="Start scan"
                  aria-label={`Start scan for ${project.name}`}
                >
                  <ScanSearch size={16} />
                </button>
                <button
                  className="text-text-secondary hover:text-accent p-1 rounded hover:bg-accent/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditTarget(project);
                  }}
                  title="Edit project"
                  aria-label={`Edit project ${project.name}`}
                >
                  <Pencil size={16} />
                </button>
                <button
                  className="text-text-secondary hover:text-critical p-1 rounded hover:bg-critical/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    setDeleteTarget(project);
                  }}
                  title="Delete project"
                  aria-label={`Delete project ${project.name}`}
                >
                  <Trash2 size={16} />
                </button>
              </div>

              {/* Card content */}
              <div className="flex items-start gap-3 mb-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent/10 shrink-0">
                  <FolderOpen size={20} className="text-accent" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-semibold text-text-primary truncate pr-8">
                    {project.name}
                  </h3>
                  {project.description && (
                    <p className="text-text-secondary text-sm mt-0.5 line-clamp-2">
                      {project.description}
                    </p>
                  )}
                </div>
              </div>

              {/* Meta pills */}
              <div className="flex flex-wrap items-center gap-2 mt-4">
                {project.language && (
                  <span className="badge-info">
                    <Code2 size={10} className="mr-1" />
                    {project.language}
                  </span>
                )}
                {project.source_type && (
                  <span className="inline-flex items-center gap-1 text-xs text-text-secondary bg-background px-2 py-0.5 rounded-full">
                    <SourceTypeIcon type={project.source_type} />
                    {project.source_type}
                  </span>
                )}
                {project.framework && (
                  <span className="badge-observed">
                    {project.framework}
                  </span>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                <span className="text-text-secondary text-xs flex items-center gap-1">
                  <Calendar size={12} />
                  {project.created_at ? formatDate(project.created_at) : 'Unknown'}
                </span>
                {project.git_url && (
                  <a
                    href={project.git_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-accent text-xs flex items-center gap-1 hover:text-accent-hover"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink size={12} />
                    Repo
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Modals */}
      <CreateProjectModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onCreated={handleCreated}
      />
      <DeleteConfirmDialog
        project={deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        deleting={deleting}
      />
      <EditProjectModal
        project={editTarget}
        onClose={() => setEditTarget(null)}
        onSaved={handleSaved}
      />
      <Toast
        open={Boolean(toast)}
        message={toast?.message ?? ''}
        tone={toast?.tone ?? 'info'}
        onClose={() => setToast(null)}
      />
    </div>
  );
}
