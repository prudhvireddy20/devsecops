import React, { useState, useEffect, useCallback } from 'react';
import {
  FileText,
  Download,
  Loader2,
  FileJson,
  Globe,
  File,
  CheckCircle2,
  AlertTriangle,
  Eye,
  Sparkles,
  Target,
  Link2,
} from 'lucide-react';
import {
  generateReport,
  downloadReport,
  getReportPreview,
  generateComplianceReport,
  getScans,
  getApiKey,
  type Scan,
  type Report,
  type ReportPreview,
  type Confidence,
} from '../services/api';
import FindingConfidenceBadge from '../components/FindingConfidenceBadge';
import PageHeader from '../components/PageHeader';
import Toast, { type ToastTone } from '../components/Toast';
import { formatDate } from '../utils/datetime';

// ── Types ───────────────────────────────────────────────────────────────────

type ReportFormat = 'html' | 'pdf' | 'sarif' | 'json';

interface FormatOption {
  value: ReportFormat;
  label: string;
  description: string;
  icon: React.ReactNode;
}

const FORMAT_OPTIONS: FormatOption[] = [
  {
    value: 'html',
    label: 'HTML',
    description: 'Interactive report viewable in any browser',
    icon: <Globe className="w-5 h-5" />,
  },
  {
    value: 'pdf',
    label: 'PDF',
    description: 'Print-ready document for stakeholders',
    icon: <FileText className="w-5 h-5" />,
  },
  {
    value: 'sarif',
    label: 'SARIF',
    description: 'Static Analysis Results Interchange Format',
    icon: <File className="w-5 h-5" />,
  },
  {
    value: 'json',
    label: 'JSON',
    description: 'Machine-readable raw findings data',
    icon: <FileJson className="w-5 h-5" />,
  },
];

// ── Component ───────────────────────────────────────────────────────────────

const Reports: React.FC = () => {
  // Scan selector
  const [scans, setScans] = useState<Scan[]>([]);
  const [selectedScanId, setSelectedScanId] = useState('');

  // Format
  const [format, setFormat] = useState<ReportFormat>('html');

  // Report generation
  const [report, setReport] = useState<Report | null>(null);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);

  // Preview
  const [preview, setPreview] = useState<ReportPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [jsonPreview, setJsonPreview] = useState<string | null>(null);

  // Download
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  // Compliance
  const [complianceFramework, setComplianceFramework] = useState('pci-dss');
  const [generatingCompliance, setGeneratingCompliance] = useState(false);

  const [toast, setToast] = useState<{ message: string; tone: ToastTone } | null>(null);

  const previewConfidenceCounts: Record<Confidence, number> = {
    verified: 0,
    probable: 0,
    observed: 0,
  };
  for (const finding of preview?.findings ?? []) {
    if (finding.confidence in previewConfidenceCounts) {
      previewConfidenceCounts[finding.confidence as Confidence] += 1;
    }
  }

  const fetchTextFromDownload = useCallback(async (downloadUrl: string): Promise<string> => {
    const normalizedUrl = downloadUrl.startsWith('http')
      ? downloadUrl
      : `${window.location.origin}${downloadUrl}`;

    const key = getApiKey();
    const resp = await fetch(normalizedUrl, {
      headers: key ? { 'X-API-Key': key } : undefined,
    });
    if (!resp.ok) {
      throw new Error(`Failed to fetch report preview (${resp.status})`);
    }
    return await resp.text();
  }, []);

  // Fetch available scans
  useEffect(() => {
    getScans({ status: 'completed', page_size: 50 })
      .then((res) => {
        setScans(res.items);
        if (res.items.length > 0) {
          setSelectedScanId(res.items[0].id);
        }
      })
      .catch(() => {
        setGenError('Failed to load completed scans.');
        setToast({ message: 'Failed to load completed scans', tone: 'error' });
      });
  }, []);

  // Fetch preview when scan changes
  useEffect(() => {
    if (!selectedScanId) return;
    setPreviewLoading(true);
    getReportPreview(selectedScanId)
      .then((data) => setPreview(data))
      .catch(() => setPreview(null))
      .finally(() => setPreviewLoading(false));
  }, [selectedScanId]);

  // Generate report
  const handleGenerate = useCallback(async () => {
    if (!selectedScanId || generating) return;
    setGenerating(true);
    setGenError(null);
    setReport(null);
    setJsonPreview(null);
    try {
      const result = await generateReport({
        scan_id: selectedScanId,
        format,
      });
      setReport(result);
      setToast({ message: `Report generated in ${format.toUpperCase()} format`, tone: 'success' });

      // For JSON/SARIF, try to load content for preview
      if ((format === 'json' || format === 'sarif') && result.download_url) {
        try {
          const text = await fetchTextFromDownload(result.download_url);
          setJsonPreview(text);
        } catch {
          // Preview not available for download-only
        }
      }
    } catch {
      setGenError('Failed to generate report. Please try again.');
      setToast({ message: 'Report generation failed', tone: 'error' });
    } finally {
      setGenerating(false);
    }
  }, [selectedScanId, format, generating, fetchTextFromDownload]);

  // Compliance report handler
  const handleGenerateCompliance = useCallback(async () => {
    if (!selectedScanId || generatingCompliance) return;
    setGeneratingCompliance(true);
    try {
      const result = await generateComplianceReport(selectedScanId, complianceFramework);
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `compliance-${complianceFramework}-${selectedScanId}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setToast({ message: `${complianceFramework.toUpperCase()} compliance report downloaded`, tone: 'success' });
    } catch (err: unknown) {
      setToast({ message: err instanceof Error ? err.message : 'Failed to generate compliance report', tone: 'error' });
    } finally {
      setGeneratingCompliance(false);
    }
  }, [selectedScanId, complianceFramework, generatingCompliance]);

  // Download handler
  const handleDownload = useCallback(async () => {
    if (!report || downloading) return;
    setDownloading(true);
    setDownloadError(null);
    try {
      const blob = await downloadReport(report.scan_id, report.format as ReportFormat);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report-${report.scan_id}.${report.format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setToast({ message: `Downloaded ${format.toUpperCase()} report`, tone: 'success' });
    } catch {
      setDownloadError('Failed to download report. Please try again.');
      setToast({ message: 'Report download failed', tone: 'error' });
    } finally {
      setDownloading(false);
    }
  }, [report, downloading, format]);

  return (
    <div className="space-y-6">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <PageHeader
        icon={FileText}
        title="Reports"
        subtitle="Generate and export scan reports."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── Left panel: configuration ────────────────────────────────── */}
        <div className="space-y-6">
          {/* Scan selector */}
          <div className="card">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
              Select Scan
            </h2>
            <select
              className="select"
              value={selectedScanId}
              onChange={(e) => {
                setSelectedScanId(e.target.value);
                setReport(null);
                setJsonPreview(null);
              }}
            >
              <option value="" disabled>Choose a scan...</option>
              {scans.map((s) => {
                const summary = s.results_summary as Record<string, number> | undefined;
                const totalF = summary?.total_findings ?? 0;
                const verifiedF = summary?.verified ?? 0;
                const verifiedText = s.scan_mode !== 'blackbox' ? `, ${verifiedF} verified` : '';
                return (
                  <option key={s.id} value={s.id}>
                    {s.project_name ?? 'Unknown'} — {s.started_at ? formatDate(s.started_at) : 'N/A'} ({totalF} findings{verifiedText})
                  </option>
                );
              })}
            </select>
          </div>

          {/* Format selection */}
          <div className="card">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
              Report Format
            </h2>
            <div className="space-y-2">
              {FORMAT_OPTIONS.map((opt) => (
                <label
                  key={opt.value}
                  className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors border ${
                    format === opt.value
                      ? 'border-accent bg-accent/5'
                      : 'border-transparent hover:bg-surface-hover'
                  }`}
                >
                  <input
                    type="radio"
                    name="format"
                    value={opt.value}
                    checked={format === opt.value}
                    onChange={(e) => setFormat(e.target.value as ReportFormat)}
                    className="sr-only"
                  />
                  <div className={`mt-0.5 ${format === opt.value ? 'text-accent' : 'text-text-secondary'}`}>
                    {opt.icon}
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${format === opt.value ? 'text-accent' : 'text-text-primary'}`}>
                      {opt.label}
                    </p>
                    <p className="text-xs text-text-secondary mt-0.5">{opt.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Generate button */}
          <button
            className="btn-primary w-full flex items-center justify-center gap-2 py-3"
            onClick={handleGenerate}
            disabled={!selectedScanId || generating}
          >
            {generating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <FileText className="w-5 h-5" />
                Generate Report
              </>
            )}
          </button>

          {genError && (
            <div className="flex items-center gap-2 text-sm text-critical">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span className="flex-1">{genError}</span>
              <button type="button" className="btn-secondary text-xs" onClick={handleGenerate} disabled={!selectedScanId || generating}>
                Retry
              </button>
            </div>
          )}

          {/* Download button */}
          {report && (
            <button
              className="btn-secondary w-full flex items-center justify-center gap-2 py-3"
              onClick={handleDownload}
              disabled={downloading}
            >
              {downloading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              Download {format.toUpperCase()}
            </button>
          )}

          {downloadError && (
            <div className="flex items-center gap-2 text-sm text-critical">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span className="flex-1">{downloadError}</span>
              <button type="button" className="btn-secondary text-xs" onClick={handleDownload} disabled={!report || downloading}>
                Retry
              </button>
            </div>
          )}

          {report && (
            <div className="flex items-center gap-2 text-sm text-accent">
              <CheckCircle2 className="w-4 h-4" />
              Report generated successfully
            </div>
          )}

          {/* Compliance report */}
          <div className="card">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-3">
              Compliance Report
            </h2>
            <div className="flex gap-2">
              <select
                className="select flex-1"
                value={complianceFramework}
                onChange={(e) => setComplianceFramework(e.target.value)}
              >
                <option value="pci-dss">PCI-DSS</option>
                <option value="gdpr">GDPR</option>
                <option value="hipaa">HIPAA</option>
              </select>
              <button
                type="button"
                className="btn-secondary flex items-center gap-2"
                onClick={handleGenerateCompliance}
                disabled={!selectedScanId || generatingCompliance}
              >
                {generatingCompliance ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                Export
              </button>
            </div>
            <p className="text-xs text-text-secondary mt-2">
              Maps findings to compliance requirements and downloads a gap report as JSON.
            </p>
          </div>
        </div>

        {/* ── Right panel: preview ─────────────────────────────────────── */}
        <div className="lg:col-span-2">
          <div className="card h-full min-h-[600px] flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <Eye className="w-4 h-4 text-text-secondary" />
              <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
                Preview
              </h2>
            </div>

            <div className="flex-1 bg-background rounded-lg overflow-hidden">
              {previewLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="w-8 h-8 text-accent animate-spin" />
                </div>
              ) : report && (format === 'json' || format === 'sarif') && jsonPreview ? (
                /* JSON/SARIF viewer */
                <pre className="p-4 text-sm font-mono text-text-primary overflow-auto h-full max-h-[560px] whitespace-pre-wrap">
                  {tryFormatJson(jsonPreview)}
                </pre>
              ) : report && format === 'pdf' ? (
                /* PDF notice */
                <div className="flex flex-col items-center justify-center h-full gap-4">
                  <FileText className="w-16 h-16 text-text-secondary/30" />
                  <p className="text-text-secondary text-sm">
                    PDF preview is not available in-browser.
                  </p>
                  <button className="btn-secondary flex items-center gap-2" onClick={handleDownload}>
                    <Download className="w-4 h-4" />
                    Download PDF
                  </button>
                </div>
              ) : preview && preview.findings ? (
                /* Preview from scan data — show findings summary */
                <div className="p-4 overflow-auto max-h-[560px]">
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-text-primary mb-2">
                      Scan Summary
                    </h3>
                    <p className="text-xs text-text-secondary">
                      {preview.findings.length} finding(s) discovered
                    </p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {(['verified', 'probable', 'observed'] as Confidence[])
                        .filter(level => level !== 'verified' || scans.find(s => s.id === selectedScanId)?.scan_mode !== 'blackbox')
                        .map((level) => (
                          <div key={level} className="flex items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2">
                            <FindingConfidenceBadge confidence={level} />
                            <span className="text-sm font-semibold text-text-primary">
                              {previewConfidenceCounts[level]}
                            </span>
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* ── LLM Insights ──────────────────────────────────────── */}
                  {(() => {
                    const sel = scans.find(s => s.id === selectedScanId);
                    const rs = (sel?.results_summary ?? {}) as Record<string, unknown>;
                    const llmSummary = typeof rs.llm_summary === 'string' ? rs.llm_summary : '';
                    const attackChains = Array.isArray(rs.attack_chains) ? rs.attack_chains as Array<Record<string, unknown>> : [];
                    const planResult = sel?.plan_result ?? {};
                    const focusAreas = Array.isArray(planResult.focus_areas) ? planResult.focus_areas as string[] : [];
                    const riskHypothesis = typeof planResult.risk_hypothesis === 'string' ? planResult.risk_hypothesis : '';
                    const hasInsights = llmSummary || attackChains.length > 0 || focusAreas.length > 0;
                    if (!hasInsights) return null;
                    return (
                      <div className="mb-5 space-y-3">
                        <div className="flex items-center gap-2 text-accent">
                          <Sparkles className="w-4 h-4" />
                          <span className="text-xs font-semibold uppercase tracking-wider">LLM Insights</span>
                        </div>

                        {llmSummary && (
                          <div className="rounded-lg border border-accent/20 bg-accent/5 p-3">
                            <p className="text-xs font-semibold text-accent mb-1">Executive Summary</p>
                            <p className="text-sm text-text-primary leading-relaxed">{llmSummary}</p>
                          </div>
                        )}

                        {focusAreas.length > 0 && (
                          <div className="rounded-lg border border-border bg-surface p-3">
                            <div className="flex items-center gap-1.5 mb-2">
                              <Target className="w-3.5 h-3.5 text-text-secondary" />
                              <p className="text-xs font-semibold text-text-secondary">Pre-Scan Intelligence</p>
                            </div>
                            <ul className="space-y-1 mb-2">
                              {focusAreas.map((area, i) => (
                                <li key={i} className="text-xs text-text-primary flex gap-2">
                                  <span className="text-accent mt-0.5">›</span>
                                  <span>{area}</span>
                                </li>
                              ))}
                            </ul>
                            {riskHypothesis && (
                              <p className="text-xs text-text-secondary italic">{riskHypothesis}</p>
                            )}
                          </div>
                        )}

                        {attackChains.length > 0 && (
                          <div className="rounded-lg border border-border bg-surface p-3">
                            <div className="flex items-center gap-1.5 mb-2">
                              <Link2 className="w-3.5 h-3.5 text-text-secondary" />
                              <p className="text-xs font-semibold text-text-secondary">Attack Chains ({attackChains.length})</p>
                            </div>
                            <div className="space-y-2">
                              {attackChains.map((chain, i) => {
                                const sev = typeof chain.severity === 'string' ? chain.severity : 'medium';
                                const narrative = typeof chain.narrative === 'string' ? chain.narrative : '';
                                const sevColor: Record<string, string> = {
                                  critical: 'text-red-400 bg-red-400/10 border-red-400/30',
                                  high: 'text-orange-400 bg-orange-400/10 border-orange-400/30',
                                  medium: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30',
                                  low: 'text-blue-400 bg-blue-400/10 border-blue-400/30',
                                };
                                return (
                                  <div key={i} className="flex gap-2 items-start">
                                    <span className={`text-xs font-semibold px-1.5 py-0.5 rounded border capitalize shrink-0 ${sevColor[sev] ?? sevColor.medium}`}>
                                      {sev}
                                    </span>
                                    <p className="text-xs text-text-primary leading-relaxed">{narrative}</p>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {preview.findings.length > 0 ? (
                    <table className="table text-xs">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Severity</th>
                          <th>Confidence</th>
                          <th>Type</th>
                          <th>File</th>
                        </tr>
                      </thead>
                      <tbody>
                        {preview.findings.slice(0, 50).map((f) => (
                          <tr key={f.id}>
                            <td className="text-text-primary truncate max-w-[200px]">{f.title}</td>
                            <td><span className={severityBadgeClass(f.severity)}>{f.severity}</span></td>
                            <td><FindingConfidenceBadge confidence={f.confidence} /></td>
                            <td className="text-text-secondary">{f.vulnerability_type || '—'}</td>
                            <td className="text-text-secondary font-mono truncate max-w-[150px]">
                              {f.file_path ? `${f.file_path}:${f.line_number}` : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <p className="text-text-secondary text-sm text-center py-8">No findings to display.</p>
                  )}
                </div>
              ) : (
                /* Empty state */
                <div className="flex flex-col items-center justify-center h-full gap-4 min-h-[560px]">
                  <FileText className="w-16 h-16 text-text-secondary/20" />
                  <p className="text-text-secondary text-sm">
                    {selectedScanId
                      ? 'Click "Generate Report" to create a report.'
                      : 'Select a scan to get started.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Toast
        open={Boolean(toast)}
        message={toast?.message ?? ''}
        tone={toast?.tone ?? 'info'}
        onClose={() => setToast(null)}
      />
    </div>
  );
};

// ── Helpers ─────────────────────────────────────────────────────────────────

function tryFormatJson(raw: string): string {
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}

function severityBadgeClass(severity: string): string {
  const map: Record<string, string> = {
    critical: 'badge-critical',
    high: 'badge-high',
    medium: 'badge-medium',
    low: 'badge-low',
    info: 'badge-info',
  };
  return map[severity] ?? 'badge-info';
}

export default Reports;
