import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ScanSearch,
  Shield,
  Bug,
  BarChart3,
  Settings,
  Bot,
  Play,
  Loader2,
  AlertCircle,
  Plus,
  X,
  ChevronDown,
  Lock,
  Unlock,
  Globe,
  Search,
  Database,
  Code,
  ShieldCheck,
} from 'lucide-react';
import PageHeader from '../components/PageHeader';
import {
  getProject,
  getLLMProviders,
  startScan,
  type LLMProviderInfo,
  type Project,
  type ScanConfig,
} from '../services/api';

// ---------------------------------------------------------------------------
// Module toggle card
// ---------------------------------------------------------------------------

interface ModuleToggleProps {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  enabled: boolean;
  onToggle: (id: string) => void;
}

function ModuleToggle({ id, label, description, icon, enabled, onToggle }: ModuleToggleProps) {
  return (
    <button
      type="button"
      className={`flex items-start gap-3 p-4 rounded-lg border text-left transition-colors ${
        enabled
          ? 'border-accent bg-accent/5 ring-1 ring-accent/30'
          : 'border-border bg-background hover:border-text-secondary'
      }`}
      onClick={() => onToggle(id)}
    >
      <div
        className={`flex items-center justify-center w-10 h-10 rounded-lg shrink-0 ${
          enabled ? 'bg-accent/20 text-accent' : 'bg-surface text-text-secondary'
        }`}
      >
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className={`font-medium text-sm ${enabled ? 'text-text-primary' : 'text-text-secondary'}`}>
            {label}
          </span>
          {/* Toggle switch */}
          <div
            className={`relative w-9 h-5 rounded-full transition-colors ${
              enabled ? 'bg-accent' : 'bg-surface-hover'
            }`}
          >
            <div
              className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                enabled ? 'translate-x-4' : 'translate-x-0.5'
              }`}
            />
          </div>
        </div>
        <p className="text-xs text-text-secondary mt-1">{description}</p>
      </div>
    </button>
  );
}

// ---------------------------------------------------------------------------
// Scan profile defaults (must match backend SCAN_PROFILE_DEFAULTS)
// ---------------------------------------------------------------------------

const SCAN_PROFILES = {
  balanced: { label: 'Balanced — General Purpose', scan_depth: 5, timeout: 1800, max_children: 20, ajax_spider: false, inscope_only: false },
  api:      { label: 'API — REST API Optimized',   scan_depth: 4, timeout: 1200, max_children: 30, ajax_spider: false, inscope_only: true  },
  spa:      { label: 'SPA — Single-Page App',       scan_depth: 6, timeout: 2400, max_children: 80, ajax_spider: true,  inscope_only: false },
  auth_heavy: { label: 'Auth-Heavy — Auth-Heavy App', scan_depth: 5, timeout: 3000, max_children: 40, ajax_spider: true,  inscope_only: false },
} as const;

type ProfileKey = keyof typeof SCAN_PROFILES;

// ---------------------------------------------------------------------------
// ScanConfig page
// ---------------------------------------------------------------------------

export default function ScanConfigPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  // Project info
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [scanMode, setScanMode] = useState<string>('whitebox');

  // Module toggles — SAST/Secrets/Dependencies always off (provided by TrustScan)
  const [modules, setModules] = useState<Record<string, boolean>>({
    dast: true, nuclei: true, coverage: false, wapiti: false,
    path_fuzzing: false, feroxbuster: false, server_audit: false,
    testssl: false, sqlmap: false, dalfox: false,
  });

  // Scan profile
  const [scanProfile, setScanProfile] = useState<ProfileKey>('balanced');
  const [scanGoalsText, setScanGoalsText] = useState('');

  // Scan settings
  const [scanDepth, setScanDepth] = useState(5);
  const [timeout, setTimeout_] = useState(1800);
  const [contextAwarePayloads, setContextAwarePayloads] = useState(true);

  // Advanced settings
  const [maxChildren, setMaxChildren] = useState(20);
  const [ajaxSpider, setAjaxSpider] = useState(false);
  const [inscopeOnly, setInscopeOnly] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [llmPlannerEnabled, setLlmPlannerEnabled] = useState(false);
  const [llmProvider, setLlmProvider] = useState('');
  const [llmModel, setLlmModel] = useState('');
  const [llmProviders, setLlmProviders] = useState<LLMProviderInfo[]>([]);

  // Optional adapters/replay artifacts (project-local paths)

  // Load project
  useEffect(() => {
    if (!projectId) return;
    let cancelled = false;

    async function load() {
      try {
        const proj = await getProject(projectId!);
        if (!cancelled) {
          setProject(proj);
          const mode = (proj as unknown as Record<string, string>).scan_mode || 'whitebox';
          setScanMode(mode);
          if (mode === 'whitebox') {
            setModules({ dast: true, nuclei: true, coverage: false, wapiti: false, path_fuzzing: false, feroxbuster: false, server_audit: false, testssl: false, sqlmap: false, dalfox: false });
          } else {
            setModules({ dast: true, nuclei: true, coverage: false, wapiti: true, path_fuzzing: true, feroxbuster: true, server_audit: true, testssl: true, sqlmap: true, dalfox: true });
          }
          setError(null);
        }
      } catch (err: unknown) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to load project');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [projectId]);

  useEffect(() => {
    let cancelled = false;
    async function loadProviders() {
      try {
        const data = await getLLMProviders();
        if (cancelled) return;
        const connected = (data.providers || []).filter((p) => p.connected && !p.needs_reconnect);
        setLlmProviders(connected);
        if (!llmProvider && connected.length > 0) {
          setLlmProvider(connected[0].provider);
          setLlmModel(connected[0].default_model || connected[0].models[0] || '');
        }
      } catch {
        if (!cancelled) {
          setLlmProviders([]);
        }
      }
    }
    loadProviders();
    return () => {
      cancelled = true;
    };
  }, [llmProvider]);

  const selectedLlmProvider = llmProviders.find((p) => p.provider === llmProvider) || null;

  useEffect(() => {
    if (!selectedLlmProvider) return;
    if (!llmModel || !selectedLlmProvider.models.includes(llmModel)) {
      setLlmModel(selectedLlmProvider.default_model || selectedLlmProvider.models[0] || '');
    }
  }, [selectedLlmProvider?.provider]);

  // Toggle a module
  function toggleModule(id: string) {
    setModules((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  // Apply scan profile defaults
  function applyProfile(key: ProfileKey) {
    setScanProfile(key);
    const p = SCAN_PROFILES[key];
    setScanDepth(p.scan_depth);
    setTimeout_(p.timeout);
    setMaxChildren(p.max_children);
    setAjaxSpider(p.ajax_spider);
    setInscopeOnly(p.inscope_only);
  }

  // Submit scan
  async function handleStartScan(e: React.FormEvent) {
    e.preventDefault();
    if (!projectId) return;

    if (llmPlannerEnabled) {
      if (llmProviders.length === 0) {
        setError('No connected LLM providers. Connect one in Tools -> LLM first.');
        return;
      }
      if (!llmProvider) {
        setError('Please select a connected LLM provider for planner checkpoints.');
        return;
      }
      const selected = llmProviders.find((p) => p.provider === llmProvider);
      if (!selected) {
        setError('Selected LLM provider is not connected.');
        return;
      }
      if (!llmModel || !selected.models.includes(llmModel)) {
        setError('Please choose a valid model from the provider list.');
        return;
      }
    }

    // Auth config is now configured in Create Project modal
    const config: ScanConfig = {
      project_id: projectId,
      scan_type: 'full',
      modules_enabled: modules,
      auth_config: undefined,
      scan_goals: scanGoalsText
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean),
        scan_config: {
          profile: scanProfile,
          scan_depth: scanDepth,
          timeout: timeout,
          max_children: maxChildren,
          context_aware_payloads: contextAwarePayloads,
          ajax_spider: ajaxSpider,
          inscope_only: inscopeOnly,
          adaptive_timeout: true,
          journey_replay_max_steps: 200,
          journey_replay_timeout: 12,
          llm_planner_enabled: llmPlannerEnabled,
          llm_provider: llmProvider || undefined,
          llm_model: llmModel.trim() || undefined,
        },
      };

    setSubmitting(true);
    setError(null);
    try {
      const scan = await startScan(config);
      navigate(`/scans/${scan.id}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to start scan');
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-8" aria-busy="true" aria-label="Loading scan configuration">
        <div className="flex items-center gap-3">
          <div className="skeleton h-10 w-10 rounded-md" />
          <div className="space-y-2">
            <div className="skeleton h-6 w-48" />
            <div className="skeleton h-3.5 w-64" />
          </div>
        </div>
        <div className="skeleton h-40 rounded-lg" />
        <div className="skeleton h-64 rounded-lg" />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <PageHeader
        icon={ScanSearch}
        title="Configure Scan"
        subtitle={
          project && (
            <>
              Project: <strong className="text-text-primary">{project.name}</strong>
            </>
          )
        }
      />

      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <form onSubmit={handleStartScan} className="space-y-8">
        {/* ---- Scan Modules ---- */}
        <section className="card">
          <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center gap-2">
            <Settings size={18} className="text-accent" />
            Scan Modules
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {scanMode === 'whitebox' && (
              <div className="col-span-full flex items-start gap-3 p-4 rounded-lg border border-border bg-surface/30">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg shrink-0 bg-low/10 text-low">
                  <Shield size={20} />
                </div>
                <div>
                  <p className="text-sm font-medium text-text-primary">External Static Findings</p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    Findings are imported automatically from your TrustScan integration or uploaded TrustScan report.
                  </p>
                </div>
              </div>
            )}
            <ModuleToggle id="dast" label="DAST" description="Dynamic testing against the running application" icon={<Bug size={20} />} enabled={modules.dast} onToggle={toggleModule} />
            <ModuleToggle id="coverage" label="Coverage" description="Track endpoint and code coverage during DAST" icon={<BarChart3 size={20} />} enabled={modules.coverage} onToggle={toggleModule} />
            <ModuleToggle id="nuclei" label="Nuclei" description="6000+ templates for exposures, CVEs, and misconfigurations" icon={<ScanSearch size={20} />} enabled={modules.nuclei} onToggle={toggleModule} />
            {scanMode !== 'whitebox' && (
              <>
                <ModuleToggle id="path_fuzzing" label="Path Fuzzing" description="ffuf — discover hidden endpoints and admin panels" icon={<Search size={20} />} enabled={modules.path_fuzzing} onToggle={toggleModule} />
                <ModuleToggle id="feroxbuster" label="Recursive Fuzzing" description="feroxbuster — recurses into found directories; catches nested paths ffuf misses" icon={<Search size={20} />} enabled={modules.feroxbuster} onToggle={toggleModule} />
                <ModuleToggle id="server_audit" label="Server Audit" description="Nikto — detect misconfigs, outdated software, dangerous files" icon={<Shield size={20} />} enabled={modules.server_audit} onToggle={toggleModule} />
                <ModuleToggle id="testssl" label="TLS Audit" description="testssl.sh — weak ciphers, BEAST, POODLE, SWEET32, certificate chain issues" icon={<ShieldCheck size={20} />} enabled={modules.testssl} onToggle={toggleModule} />
                <ModuleToggle id="wapiti" label="Wapiti" description="Covers XXE, LDAP injection, CRLF, open redirect, and SSRF that ZAP misses" icon={<Globe size={20} />} enabled={modules.wapiti} onToggle={toggleModule} />
                <ModuleToggle id="sqlmap" label="SQLMap" description="Blind, time-based, and out-of-band SQL injection — deeper than ZAP's SQLi rules" icon={<Database size={20} />} enabled={modules.sqlmap} onToggle={toggleModule} />
                <ModuleToggle id="dalfox" label="dalfox" description="Dedicated XSS scanner — faster and more accurate than ZAP for reflected/DOM XSS" icon={<Code size={20} />} enabled={modules.dalfox} onToggle={toggleModule} />
              </>
            )}
          </div>

          {/* Mode badge + source availability */}
          <div className="flex items-center gap-2 mt-3 p-3 rounded-lg border border-border bg-surface/30">
            {scanMode === 'whitebox' ? <Unlock size={16} className="text-low" /> : <Lock size={16} className="text-medium" />}
            <span className="text-xs text-text-secondary">
              <strong className="text-text-primary">Mode:</strong> {scanMode === 'whitebox' ? 'White-box' : 'Black-box'}
              <span className="ml-2 text-text-tertiary">
                {scanMode === 'whitebox'
                  ? '— External static findings from TrustScan + DAST'
                  : '— DAST-only, discovery pipeline + active scan'}
              </span>
            </span>
          </div>
        </section>

        {/* ---- LLM Planner ---- */}
        <section className="card">
          <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center gap-2">
            <Bot size={18} className="text-accent" />
            LLM Planner
          </h2>

          <button
            type="button"
            className={`flex items-center gap-3 p-3 rounded-lg border w-full text-left transition-colors ${
              llmPlannerEnabled ? 'border-accent bg-accent/5' : 'border-border bg-background'
            }`}
            onClick={() => setLlmPlannerEnabled(!llmPlannerEnabled)}
          >
            <div
              className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${
                llmPlannerEnabled ? 'bg-accent' : 'bg-surface-hover'
              }`}
            >
              <div
                className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                  llmPlannerEnabled ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </div>
            <div>
              <span className="font-medium text-sm text-text-primary">Enable planner checkpoints</span>
              <p className="text-xs text-text-secondary mt-0.5">
                Uses LLM suggestions to safely tune scan settings during execution.
              </p>
            </div>
          </button>

          {llmPlannerEnabled && (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {llmProviders.length === 0 && (
                <div className="sm:col-span-2 flex items-start gap-2 p-3 rounded-lg bg-critical/10 text-critical text-sm">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <div>
                    No LLM providers connected. Go to <strong>Tools -&gt; LLM</strong> to connect a provider first.
                  </div>
                </div>
              )}
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-text-secondary mb-1.5">
                  Provider
                </label>
                <select
                  className="select"
                  value={llmProvider}
                  onChange={(e) => setLlmProvider(e.target.value)}
                  disabled={llmProviders.length === 0}
                >
                  {llmProviders.length === 0 ? (
                    <option value="">No providers connected</option>
                  ) : (
                    llmProviders.map((p) => (
                      <option key={p.provider} value={p.provider}>{p.label}</option>
                    ))
                  )}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-1.5">
                  Model
                </label>
                <select
                  className="select"
                  value={llmModel}
                  onChange={(e) => setLlmModel(e.target.value)}
                  disabled={!selectedLlmProvider}
                >
                  {!selectedLlmProvider ? (
                    <option value="">Select provider first</option>
                  ) : (
                    selectedLlmProvider.models.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))
                  )}
                </select>
              </div>
            </div>
          )}
        </section>

        {/* ---- Scan Settings ---- */}
        <section className="card">
          <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center gap-2">
            <Settings size={18} className="text-accent" />
            Scan Settings
          </h2>

          {/* Scan profile selector */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-text-secondary mb-1.5">
              Scan Profile
            </label>
            <div className="relative">
              <select
                className="select pr-10"
                value={scanProfile}
                onChange={(e) => applyProfile(e.target.value as ProfileKey)}
              >
                {Object.entries(SCAN_PROFILES).map(([key, p]) => (
                  <option key={key} value={key}>{p.label}</option>
                ))}
              </select>
              <ChevronDown
                size={16}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-secondary pointer-events-none"
              />
            </div>
            <p className="text-xs text-text-secondary mt-1">
              Profile auto-configures scan settings. You can override individual values below.
            </p>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-text-secondary mb-1.5">
              Natural-language Scan Goals (optional, one per line)
            </label>
            <textarea
              className="input resize-y"
              rows={4}
              value={scanGoalsText}
              onChange={(e) => setScanGoalsText(e.target.value)}
              placeholder={
                'Focus on checkout abuse and privilege escalation\nPrioritize SQLi/XSS on cart and order flows\nCompare admin vs guest exposure'
              }
            />
            <p className="text-xs text-text-secondary mt-1">
              Goals are compiled into a bounded plan intent and merged into safe scan priorities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Depth */}
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">
                Scan Depth
              </label>
              <input
                type="number"
                className="input"
                min={1}
                max={20}
                value={scanDepth}
                onChange={(e) => setScanDepth(parseInt(e.target.value) || 5)}
              />
              <p className="text-xs text-text-secondary mt-1">
                Maximum spider depth for DAST crawling (1-20)
              </p>
            </div>

            {/* Timeout */}
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">
                Timeout (seconds)
              </label>
              <input
                type="number"
                className="input"
                min={60}
                max={7200}
                value={timeout}
                onChange={(e) => setTimeout_(parseInt(e.target.value) || 3600)}
              />
              <p className="text-xs text-text-secondary mt-1">
                Maximum scan duration before auto-cancel (max 7200s / 2 hours)
              </p>
            </div>
          </div>

          {/* Context-aware payloads */}
          <div className="mt-4">
            <button
              type="button"
              className={`flex items-center gap-3 p-3 rounded-lg border w-full text-left transition-colors ${
                contextAwarePayloads
                  ? 'border-accent bg-accent/5'
                  : 'border-border bg-background'
              }`}
              onClick={() => setContextAwarePayloads(!contextAwarePayloads)}
            >
              <div
                className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${
                  contextAwarePayloads ? 'bg-accent' : 'bg-surface-hover'
                }`}
              >
                <div
                  className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                    contextAwarePayloads ? 'translate-x-4' : 'translate-x-0.5'
                  }`}
                />
              </div>
              <div>
                <span className="font-medium text-sm text-text-primary">
                  Context-Aware Payloads
                </span>
                <p className="text-xs text-text-secondary mt-0.5">
                  Generate payloads based on SAST analysis of source code context (sinks, data types, frameworks)
                </p>
              </div>
            </button>
          </div>

          {/* Advanced Settings (collapsible) */}
          <div className="mt-4">
            <button
              type="button"
              className="flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-colors"
              onClick={() => setShowAdvanced(!showAdvanced)}
            >
              <ChevronDown
                size={16}
                className={`transition-transform ${showAdvanced ? 'rotate-180' : ''}`}
              />
              Advanced Settings
            </button>

            {showAdvanced && (
              <div className="mt-3 space-y-3">
                {/* Max Children */}
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-1.5">
                    Max URLs per Page
                  </label>
                  <input
                    type="number"
                    className="input"
                    min={1}
                    max={500}
                    value={maxChildren}
                    onChange={(e) => setMaxChildren(parseInt(e.target.value) || 20)}
                  />
                  <p className="text-xs text-text-secondary mt-1">
                    Maximum child URLs to follow per page during crawling (1-500)
                  </p>
                </div>

                {/* AJAX Spider toggle */}
                <button
                  type="button"
                  className={`flex items-center gap-3 p-3 rounded-lg border w-full text-left transition-colors ${
                    ajaxSpider
                      ? 'border-accent bg-accent/5'
                      : 'border-border bg-background'
                  }`}
                  onClick={() => setAjaxSpider(!ajaxSpider)}
                >
                  <div
                    className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${
                      ajaxSpider ? 'bg-accent' : 'bg-surface-hover'
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                        ajaxSpider ? 'translate-x-4' : 'translate-x-0.5'
                      }`}
                    />
                  </div>
                  <div>
                    <span className="font-medium text-sm text-text-primary">AJAX Spider</span>
                    <p className="text-xs text-text-secondary mt-0.5">
                      Enable JavaScript-aware crawling (required for SPAs)
                    </p>
                  </div>
                </button>

                {/* In-Scope Only toggle */}
                <button
                  type="button"
                  className={`flex items-center gap-3 p-3 rounded-lg border w-full text-left transition-colors ${
                    inscopeOnly
                      ? 'border-accent bg-accent/5'
                      : 'border-border bg-background'
                  }`}
                  onClick={() => setInscopeOnly(!inscopeOnly)}
                >
                  <div
                    className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${
                      inscopeOnly ? 'bg-accent' : 'bg-surface-hover'
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                        inscopeOnly ? 'translate-x-4' : 'translate-x-0.5'
                      }`}
                    />
                  </div>
                  <div>
                    <span className="font-medium text-sm text-text-primary">In-Scope Only</span>
                    <p className="text-xs text-text-secondary mt-0.5">
                      Restrict active scan to target domain only
                    </p>
                  </div>
                </button>

              </div>
            )}
          </div>
        </section>

        {/* ---- Submit ---- */}
        <div className="flex items-center justify-end gap-3 pb-8">
          <button
            type="button"
            className="btn-secondary"
            onClick={() => navigate(-1)}
            disabled={submitting}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary flex items-center gap-2 text-base px-6 py-3"
            disabled={submitting}
          >
            {submitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Starting Scan...
              </>
            ) : (
              <>
                <Play size={18} />
                Start Scan
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
