import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Activity,
  XCircle,
  Wifi,
  WifiOff,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Loader2,
  ArrowRight,
  TerminalSquare,
} from 'lucide-react';
import {
  getScan,
  cancelScan,
  getScanRoutes,
  useWebSocket,
  type WebSocketMessage,
} from '../services/api';
import Toast, { type ToastTone } from '../components/Toast';
import PageHeader from '../components/PageHeader';

// ── Local types derived from WS messages ────────────────────────────────────

interface PhaseInfo {
  name: string;
  status: 'pending' | 'in_progress' | 'complete' | 'failed';
  progress: number;
}

interface EndpointInfo {
  path: string;
  method: string;
  status: 'pending' | 'testing' | 'complete' | 'failed';
  findings_count: number;
}

const PHASE_NAME_MAP: Record<string, string> = {
  importing: 'Import Findings',
  endpoint_discovery: 'Endpoint Discovery',
  fingerprinting: 'Fingerprinting',
  attack_surface: 'Attack Surface',
  auth: 'Auth',
  spider: 'Spider',
  waf_detection: 'WAF Detection',
  active_scan: 'Active Scan',
  dast_extended: 'Extended DAST',
  correlation: 'Correlation',
  complete: 'Complete',
};

const PHASE_ORDER = [
  'Import Findings',
  'Endpoint Discovery',
  'Fingerprinting',
  'Attack Surface',
  'Auth',
  'Spider',
  'WAF Detection',
  'Active Scan',
  'Extended DAST',
  'Correlation',
];

function getDefaultPhases(): PhaseInfo[] {
  return PHASE_ORDER.map((name) => ({
    name,
    status: 'pending' as const,
    progress: 0,
  }));
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function phaseBarColor(status: PhaseInfo['status']): string {
  switch (status) {
    case 'complete':
      return 'bg-accent';
    case 'in_progress':
      return 'bg-accent';
    case 'failed':
      return 'bg-critical';
    default:
      return 'bg-surface-hover';
  }
}

function phaseIcon(status: PhaseInfo['status']) {
  switch (status) {
    case 'complete':
      return <CheckCircle2 className="w-4 h-4 text-accent" />;
    case 'in_progress':
      return <Loader2 className="w-4 h-4 text-accent animate-spin" />;
    case 'failed':
      return <AlertTriangle className="w-4 h-4 text-critical" />;
    default:
      return <Clock className="w-4 h-4 text-text-secondary" />;
  }
}

function methodBadge(method: string) {
  const colors: Record<string, string> = {
    GET: 'text-info',
    POST: 'text-accent',
    PUT: 'text-medium',
    PATCH: 'text-probable',
    DELETE: 'text-critical',
  };
  return (
    <span className={`font-mono text-xs font-bold ${colors[method] ?? 'text-text-secondary'}`}>
      {method}
    </span>
  );
}

function endpointStatusBadge(status: EndpointInfo['status']) {
  switch (status) {
    case 'complete':
      return <span className="badge bg-accent/20 text-accent">Complete</span>;
    case 'testing':
      return <span className="badge bg-accent/20 text-accent">Testing</span>;
    case 'failed':
      return <span className="badge-critical">Failed</span>;
    default:
      return <span className="badge bg-surface-hover text-text-secondary">Pending</span>;
  }
}

// ── Helper: colourise a terminal log line by its [LEVEL] prefix ─────────────
function logLineColor(line: string): string {
  const upper = line.toUpperCase();
  if (upper.includes('[ERROR]') || upper.includes('[FATAL]')) return 'text-red-400';
  if (upper.includes('[FINDING]')) return 'text-amber-300';
  if (upper.includes('[WARN]') || upper.includes('[WARNING]')) return 'text-yellow-300';
  if (upper.includes('[SYSTEM]')) return 'text-cyan-400';
  if (upper.includes('[INFO]')) return 'text-sky-300';
  if (upper.includes('[SUCCESS]') || upper.includes('[DONE]')) return 'text-emerald-400';
  return 'text-slate-300';
}

// ── Helper: derive phase states from the current_phase of a scan ────────────

function derivePhases(
  currentPhase: string,
  scanStatus: string,
): PhaseInfo[] {
  const phaseOrder = PHASE_ORDER;
  const displayName = PHASE_NAME_MAP[currentPhase] ?? currentPhase;
  const currentIdx = phaseOrder.indexOf(displayName);

  return phaseOrder.map((name, idx) => {
    if (scanStatus === 'completed' || scanStatus === 'complete') {
      return { name, status: 'complete' as const, progress: 100 };
    }
    if (scanStatus === 'failed') {
      if (idx < currentIdx) return { name, status: 'complete' as const, progress: 100 };
      if (idx === currentIdx) return { name, status: 'failed' as const, progress: 50 };
      return { name, status: 'pending' as const, progress: 0 };
    }
    if (currentIdx < 0) return { name, status: 'pending' as const, progress: 0 };
    if (idx < currentIdx) return { name, status: 'complete' as const, progress: 100 };
    if (idx === currentIdx) return { name, status: 'in_progress' as const, progress: 50 };
    return { name, status: 'pending' as const, progress: 0 };
  });
}

// ── Process a single WS message (extracted so it can be used in a loop) ─────

function processMessage(
  msg: WebSocketMessage,
  setOverallProgress: React.Dispatch<React.SetStateAction<number>>,
  setScanStatus: React.Dispatch<React.SetStateAction<string>>,
  setPhases: React.Dispatch<React.SetStateAction<PhaseInfo[]>>,
  setLogs: React.Dispatch<React.SetStateAction<string[]>>,
  setEndpoints: React.Dispatch<React.SetStateAction<EndpointInfo[]>>,
  completedViaWsRef: React.MutableRefObject<boolean>,
) {
  switch (msg.type) {
    case 'scan_progress': {
      if (typeof msg.progress === 'number') {
        setOverallProgress(msg.progress as number);
      }
      if (typeof msg.status === 'string') {
        const st = msg.status as string;
        setScanStatus(st);
        if (st === 'failed') break;
      }
      if (typeof msg.phase === 'string') {
        const displayName = PHASE_NAME_MAP[msg.phase as string] ?? (msg.phase as string);
        setPhases((prev) =>
          prev.map((p) => {
            if (p.name === displayName) {
              return { ...p, status: 'in_progress', progress: (msg.progress as number) ?? p.progress };
            }
            if (p.status === 'in_progress' && p.name !== displayName) {
              return { ...p, status: 'complete', progress: 100 };
            }
            return p;
          }),
        );
      }
      break;
    }
    case 'scan_log': {
      const line =
        typeof msg.message === 'string'
          ? (msg.message as string)
          : JSON.stringify(msg);
      setLogs((prev) => {
        const next = [...prev, line];
        return next.length > 500 ? next.slice(-500) : next;
      });
      break;
    }
    case 'scan_complete': {
      completedViaWsRef.current = true;
      setScanStatus('completed');
      setOverallProgress(100);
      setPhases((prev) =>
        prev.map((p) =>
          p.status === 'in_progress' || p.status === 'pending'
            ? { ...p, status: 'complete', progress: 100 }
            : p,
        ),
      );
      break;
    }
    case 'new_finding': {
      const findingData = (msg.finding ?? msg) as Record<string, unknown>;
      const title = (findingData.title as string) ?? 'New finding';
      const severity = (findingData.severity as string) ?? '';
      setLogs((prev) => [...prev, `[FINDING] ${severity.toUpperCase()}: ${title}`]);
      break;
    }
    case 'endpoint_discovered': {
      const ep = msg as unknown as { path?: string; method?: string };
      if (ep.path && ep.method) {
        setEndpoints((prev) => {
          if (prev.some((e) => e.path === ep.path && e.method === ep.method)) return prev;
          return [...prev, {
            path: ep.path!,
            method: ep.method!,
            status: 'pending',
            findings_count: 0,
          }];
        });
      }
      break;
    }
    case 'cancelled': {
      setScanStatus('cancelled');
      break;
    }
    default:
      break;
  }
}

// ── Component ───────────────────────────────────────────────────────────────

const ScanProgress: React.FC = () => {
  const { scanId } = useParams<{ scanId: string }>();
  const navigate = useNavigate();

  const [phases, setPhases] = useState<PhaseInfo[]>(getDefaultPhases());
  const [overallProgress, setOverallProgress] = useState(0);
  const [scanStatus, setScanStatus] = useState<string>('pending');
  const [endpoints, setEndpoints] = useState<EndpointInfo[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [loadedHistoricalLogs, setLoadedHistoricalLogs] = useState(false);
  const [hideHistoricalBanner, setHideHistoricalBanner] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [toast, setToast] = useState<{ message: string; tone: ToastTone } | null>(null);

  const logsEndRef = useRef<HTMLDivElement>(null);
  // Track whether completion happened via WS (live) vs already completed on mount
  const completedViaWsRef = useRef(false);
  // Track how many WS messages we've already processed
  const processedCountRef = useRef(0);

  const wsUrl = `/ws/scan/${scanId}`;
  const { messages, connected } = useWebSocket(wsUrl);

  // ── FIX #2: Fetch current scan state on mount via REST ──────────────────
  useEffect(() => {
    if (!scanId) return;
    let cancelled = false;

    async function loadInitialState() {
      try {
        const [scan, routesData] = await Promise.all([
          getScan(scanId!),
          getScanRoutes(scanId!, { page_size: 500 }).catch(() => ({ items: [] })),
        ]);
        if (cancelled) return;

        setScanStatus(scan.status);
        setOverallProgress(scan.progress ?? 0);

        setPhases(getDefaultPhases());
        if (scan.log) {
          const persisted = scan.log.split('\n').filter((line) => line.trim().length > 0).slice(-500);
          setLogs(persisted);
          setLoadedHistoricalLogs(persisted.length > 0);
          setHideHistoricalBanner(false);
        } else {
          setLoadedHistoricalLogs(false);
          setHideHistoricalBanner(false);
        }

        // Derive phase states from current_phase
        if (scan.current_phase) {
          setPhases(derivePhases(scan.current_phase, scan.status));
        } else if (scan.status === 'completed') {
          setPhases(getDefaultPhases().map((p) => ({ ...p, status: 'complete', progress: 100 })));
        }

        // Hydrate endpoints from DB if already available
        if (routesData?.items?.length) {
          const formattedEndpoints = routesData.items.map((r) => ({
            path: r.path,
            method: r.method,
            status: (r.tested ? 'complete' : 'pending') as EndpointInfo['status'],
            findings_count: r.finding_count || 0,
          }));
          setEndpoints(formattedEndpoints);
        }

        // Add informational logs
        if (scan.status === 'completed') {
          setLogs((prev) => [
            ...prev,
            '[SYSTEM] Scan completed successfully.',
            '[SYSTEM] Live logs stream is inactive for completed scans.',
          ]);
        } else if (scan.status === 'failed' || scan.status === 'cancelled') {
          setLogs((prev) => [
            ...prev,
            `[SYSTEM] Scan ${scan.status}.`,
            '[SYSTEM] Live logs stream is inactive.',
          ]);
        } else {
          setLogs((prev) => [
            ...prev,
            '[SYSTEM] Attached to active scan live log stream...',
          ]);
        }

        // If scan has error_message, add it to logs
        if (scan.error_message) {
          setLogs((prev) => [...prev, `[ERROR] ${scan.error_message}`]);
        }
      } catch {
        // Non-critical; WS will provide updates
      } finally {
        if (!cancelled) setInitialLoading(false);
      }
    }

    loadInitialState();
    return () => { cancelled = true; };
  }, [scanId]);

  // ── FIX #3: Process ALL new WS messages, not just the latest ────────────
  useEffect(() => {
    if (messages.length <= processedCountRef.current) return;

    // Process all unprocessed messages
    const newMessages = messages.slice(processedCountRef.current);
    processedCountRef.current = messages.length;

    for (const msg of newMessages) {
      processMessage(
        msg,
        setOverallProgress,
        setScanStatus,
        setPhases,
        setLogs,
        setEndpoints,
        completedViaWsRef,
      );
    }

    // Clear initial loading once we get any WS message
    setInitialLoading(false);
  }, [messages]);

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // ── FIX #8: Only auto-redirect if scan completed DURING this session ────
  useEffect(() => {
    if (scanStatus === 'completed' && completedViaWsRef.current) {
      const timer = setTimeout(() => {
        navigate(`/findings?scan_id=${scanId}`);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [scanStatus, scanId, navigate]);

  const handleCancel = useCallback(async () => {
    if (!scanId || cancelling) return;
    const confirmed = window.confirm(
      'Are you sure you want to cancel this scan?\n\n' +
      'Active scans can take 20–40 minutes. Cancelling now will lose all progress.\n\n' +
      'Click OK to cancel the scan, or Cancel to let it continue.'
    );
    if (!confirmed) return;
    setCancelling(true);
    try {
      await cancelScan(scanId);
      setScanStatus('cancelled');
      setToast({ message: 'Scan cancelled', tone: 'success' });
    } catch {
      setToast({ message: 'Failed to cancel scan', tone: 'error' });
      setCancelling(false);
    }
  }, [scanId, cancelling]);

  const isRunning = scanStatus === 'running' || scanStatus === 'pending';

  if (initialLoading) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading scan">
        <div className="flex items-center gap-3">
          <div className="skeleton h-10 w-10 rounded-md" />
          <div className="space-y-2">
            <div className="skeleton h-6 w-44" />
            <div className="skeleton h-3.5 w-64" />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <div className="space-y-6">
            <div className="skeleton h-28 rounded-lg" />
            <div className="skeleton h-72 rounded-lg" />
          </div>
          <div className="skeleton h-[26rem] rounded-lg lg:col-span-2 xl:col-span-3" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <PageHeader
        icon={Activity}
        title="Scan Progress"
        subtitle={<span className="font-mono">{scanId}</span>}
        actions={
          <>
            {/* Connection indicator */}
            <div className="flex items-center gap-1.5 text-xs" role="status">
              {connected ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-accent" />
                  <span className="text-accent">Connected</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-critical" />
                  <span className="text-critical">Disconnected</span>
                </>
              )}
            </div>

            {isRunning && (
              <button
                onClick={handleCancel}
                disabled={cancelling}
                className="btn-danger flex items-center justify-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                {cancelling ? 'Cancelling...' : 'Cancel Scan'}
              </button>
            )}
          </>
        }
      />

      {/* ── Main Layout: Progress & Logs ───────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-6 items-start">
        
        {/* Left Column: Progress & Phases */}
        <div className="lg:col-span-1 space-y-6">
          {/* ── Overall progress ────────────────────────────────────────────── */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-text-secondary">
                Overall Progress
              </span>
              <span className="text-lg font-bold text-text-primary">
                {Math.round(overallProgress)}%
              </span>
            </div>
            <div className="w-full h-4 bg-background rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ease-out ${
                  scanStatus === 'failed' ? 'bg-critical' : 'bg-accent'
                }`}
                style={{ width: `${overallProgress}%` }}
              />
            </div>
            {scanStatus === 'completed' && completedViaWsRef.current && (
              <div className="mt-3 flex items-start gap-2 text-accent text-sm">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Scan complete — redirecting to findings...</span>
              </div>
            )}
            {scanStatus === 'completed' && !completedViaWsRef.current && (
              <div className="mt-3 flex items-center gap-2 text-accent text-sm">
                <CheckCircle2 className="w-4 h-4" />
                Scan completed.
              </div>
            )}
            {scanStatus === 'failed' && (
              <div className="mt-3 flex items-center gap-2 text-critical text-sm">
                <AlertTriangle className="w-4 h-4" />
                Scan failed.
              </div>
            )}
            {scanStatus === 'cancelled' && (
              <div className="mt-3 flex items-center gap-2 text-medium text-sm">
                <XCircle className="w-4 h-4" />
                Scan cancelled.
              </div>
            )}
          </div>

          {/* ── Phase bars ──────────────────────────────────────────────────── */}
          <div className="card">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
              Phases
            </h2>
            <div className="space-y-3">
              {phases.map((phase) => (
                <div key={phase.name} className="flex items-center gap-3">
                  {phaseIcon(phase.status)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-text-primary truncate">
                        {phase.name}
                      </span>
                      <span className="text-[10px] text-text-secondary font-mono">
                        {phase.status === 'complete' ? '100%' : `${Math.round(phase.progress)}%`}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-background rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${phaseBarColor(phase.status)}`}
                        style={{
                          width: `${phase.status === 'complete' ? 100 : phase.progress}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Logs & Endpoints */}
        <div className="lg:col-span-2 xl:col-span-3 space-y-6 flex flex-col h-full min-h-[600px]">
          {/* ── Live log stream ─────────────────────────────────────────── */}
          <div className="flex flex-col overflow-hidden rounded-xl border border-white/10 bg-[#0d1117] shadow-[0_18px_50px_-12px_rgba(0,0,0,0.65),0_0_0_1px_rgba(16,185,129,0.06),0_0_40px_-18px_rgba(16,185,129,0.45)]">
            {/* Terminal window chrome */}
            <div className="flex items-center gap-3 border-b border-black/50 bg-gradient-to-b from-[#252e3c] to-[#1b212c] px-4 py-2.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.05)]">
              <span className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-[#ff5f56] ring-1 ring-black/20 shadow-[0_0_6px_rgba(255,95,86,0.5)]" />
                <span className="h-3 w-3 rounded-full bg-[#ffbd2e] ring-1 ring-black/20 shadow-[0_0_6px_rgba(255,189,46,0.5)]" />
                <span className="h-3 w-3 rounded-full bg-[#27c93f] ring-1 ring-black/20 shadow-[0_0_6px_rgba(39,201,63,0.5)]" />
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[11px] font-medium text-slate-300/90">
                <TerminalSquare className="h-3.5 w-3.5 text-emerald-400/80" />
                scan@traceon
                <span className="text-slate-500">:</span>
                <span className="text-sky-400/80">~/live-logs</span>
              </span>
              <span className="ml-auto flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider">
                {connected ? (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.9)]" />
                    </span>
                    <span className="text-emerald-400 [text-shadow:0_0_8px_rgba(16,185,129,0.6)]">live</span>
                  </>
                ) : (
                  <>
                    <span className="h-2 w-2 rounded-full bg-slate-500" />
                    <span className="text-slate-500">offline</span>
                  </>
                )}
              </span>
            </div>

            {/* Terminal body */}
            <div
              className="terminal-scroll h-96 overflow-y-auto overflow-x-hidden p-4 font-mono text-xs leading-relaxed text-slate-300 selection:bg-emerald-500/30"
              style={{
                backgroundColor: '#0d1117',
                backgroundImage:
                  'radial-gradient(130% 80% at 50% -10%, rgba(16,185,129,0.10), transparent 55%), radial-gradient(110% 60% at 100% 0%, rgba(56,189,248,0.07), transparent 50%)',
              }}
            >
              {loadedHistoricalLogs && !hideHistoricalBanner && (
                <div className="mb-3 flex items-center justify-between gap-2 rounded border border-amber-500/20 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-300/90">
                  <span># loaded historical logs — new entries stream live below</span>
                  <button
                    type="button"
                    className="text-amber-300/60 transition-colors hover:text-amber-200"
                    onClick={() => setHideHistoricalBanner(true)}
                    aria-label="Dismiss historical logs banner"
                  >
                    x
                  </button>
                </div>
              )}
              {logs.length === 0 ? (
                <div className="flex items-center gap-2 text-slate-500">
                  <span className="text-emerald-400">$</span>
                  <span>waiting for logs</span>
                  <span className="inline-block h-3.5 w-2 animate-pulse bg-slate-400 align-middle" />
                </div>
              ) : (
                logs.map((line, i) => (
                  <div
                    key={i}
                    className="group -mx-1 flex gap-3 whitespace-pre-wrap break-all rounded px-1 hover:bg-white/5"
                  >
                    <span className="select-none text-slate-600 group-hover:text-slate-500">
                      {String(i + 1).padStart(4, '0')}
                    </span>
                    <span className={logLineColor(line)}>{line}</span>
                  </div>
                ))
              )}
              {logs.length > 0 && isRunning && (
                <div className="mt-0.5 flex items-center gap-2">
                  <span className="text-emerald-400">$</span>
                  <span className="inline-block h-3.5 w-2 animate-pulse bg-emerald-400 align-middle" />
                </div>
              )}
              <div ref={logsEndRef} />
            </div>
          </div>

          {/* ── Endpoint status table ───────────────────────────────────── */}
          <div className="card flex flex-col max-h-[400px]">
            <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
              Endpoints ({endpoints.length})
            </h2>
            <div className="overflow-auto flex-1 bg-background rounded-lg">
              {endpoints.length === 0 ? (
                <div className="flex items-center justify-center h-32 text-sm text-text-secondary">
                  Waiting for endpoint discovery...
                </div>
              ) : (
                <table className="table text-xs">
                  <thead className="sticky top-0 bg-surface z-10">
                    <tr>
                      <th>Method</th>
                      <th>Path</th>
                      <th>Status</th>
                      <th className="text-right">Findings</th>
                    </tr>
                  </thead>
                  <tbody>
                    {endpoints.map((ep) => (
                      <tr key={`${ep.method}-${ep.path}`}>
                        <td>{methodBadge(ep.method)}</td>
                        <td className="font-mono text-xs">{ep.path}</td>
                        <td>{endpointStatusBadge(ep.status)}</td>
                        <td className="text-right font-mono text-xs">
                          {ep.findings_count > 0 ? (
                            <span className="text-critical font-bold">{ep.findings_count}</span>
                          ) : (
                            <span className="text-text-secondary">0</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Completed footer ────────────────────────────────────────────── */}
      {scanStatus === 'completed' && (
        <div className="flex justify-end border-t border-border pt-6 mt-6">
          <button
            className="btn-primary flex items-center gap-2 px-6 py-2.5"
            onClick={() => navigate(`/findings?scan_id=${scanId}`)}
          >
            View Findings
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
      <Toast
        open={Boolean(toast)}
        message={toast?.message ?? ''}
        tone={toast?.tone ?? 'info'}
        onClose={() => setToast(null)}
      />
    </div>
  );
};

export default ScanProgress;
