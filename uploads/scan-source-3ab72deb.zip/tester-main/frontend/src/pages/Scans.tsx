import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Eye,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';
import {
  getScans,
  type Scan,
} from '../services/api';
import StatusBadge from '../components/StatusBadge';
import PageHeader from '../components/PageHeader';
import { formatDate, formatDateTime } from '../utils/datetime';

// ── Component ───────────────────────────────────────────────────────────────

const PAGE_SIZE = 20;

const Scans: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [scans, setScans] = useState<Scan[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>(searchParams.get('status') || '');
  const [error, setError] = useState<string | null>(null);
  const projectId = searchParams.get('project_id');

  const fetchScans = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, unknown> = {
        page,
        page_size: PAGE_SIZE,
      };
      if (statusFilter) params.status = statusFilter;
      if (projectId) params.project_id = projectId;

      const res = await getScans(params as Parameters<typeof getScans>[0]);
      setScans(res.items);
      setTotal(res.total);
      setTotalPages(res.pages);
      setError(null);
    } catch {
      setScans([]);
      setError('Failed to load scans. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter, projectId]);

  useEffect(() => {
    fetchScans();
  }, [fetchScans]);

  useEffect(() => {
    const p = new URLSearchParams();
    if (projectId) {
      p.set('project_id', projectId);
    }
    if (page > 1) {
      p.set('page', String(page));
    }
    if (statusFilter) {
      p.set('status', statusFilter);
    }
    setSearchParams(p, { replace: true });
  }, [page, statusFilter, projectId, setSearchParams]);

  const handleRowKeyDown = (e: React.KeyboardEvent<HTMLTableRowElement>, scanId: string) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      navigate(`/scans/${scanId}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <PageHeader
        icon={Eye}
        title="Scan Monitor"
        count={total}
        subtitle="Live status and history of all scans."
        actions={
          <select
            className="select w-full sm:w-40"
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            aria-label="Filter by status"
          >
            <option value="">All Statuses</option>
            {['pending', 'running', 'completed', 'failed', 'cancelled'].map((s) => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>
        }
      />

      {/* ── Table ───────────────────────────────────────────────────────── */}
      {error && (
        <div className="card flex items-center gap-2 border-critical/30 text-critical">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span className="text-sm flex-1">{error}</span>
          <button type="button" className="btn-secondary text-xs" onClick={fetchScans}>
            Retry
          </button>
        </div>
      )}

      <div className="card p-0 overflow-hidden">
        <div className="md:hidden divide-y divide-border">
          {loading ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 3 }).map((_, idx) => (
                <div key={idx} className="rounded-xl border border-border p-4 space-y-3">
                  <div className="skeleton h-4 w-40" />
                  <div className="skeleton h-3 w-24" />
                  <div className="skeleton h-2 w-full" />
                  <div className="grid grid-cols-3 gap-2">
                    <div className="skeleton h-8" />
                    <div className="skeleton h-8" />
                    <div className="skeleton h-8" />
                  </div>
                </div>
              ))}
            </div>
          ) : scans.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center text-text-secondary">
              <AlertTriangle className="w-8 h-8 text-text-secondary/50" />
              <p className="text-sm">
                {statusFilter ? `No ${statusFilter} scans found.` : 'No scans yet. Start one from a project.'}
              </p>
              {!statusFilter && (
                <button className="btn-secondary text-sm" onClick={() => navigate('/projects')}>
                  Go to Projects
                </button>
              )}
            </div>
          ) : (
            scans.map((scan) => (
              <button
                key={scan.id}
                type="button"
                className="w-full text-left p-4 space-y-3 hover:bg-surface-hover/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                onClick={() => navigate(`/scans/${scan.id}`)}
                aria-label={`Open scan ${scan.id}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium text-text-primary text-sm">
                      {scan.project_name || scan.project_id.slice(0, 8)}
                    </p>
                    <p className="text-xs text-text-secondary mt-1">{scan.scan_type}</p>
                  </div>
                  <StatusBadge status={scan.status} />
                </div>
                <div>
                  <div className="flex items-center justify-between text-xs text-text-secondary mb-1">
                    <span>Progress</span>
                    <span>{scan.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                    <div className="h-full bg-accent rounded-full transition-all duration-500" style={{ width: `${scan.progress}%` }} />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <p className="text-text-secondary">Findings</p>
                    <p className="text-text-primary font-medium">
                      {(scan.results_summary as Record<string, number> | undefined)?.total_findings ?? 0}
                    </p>
                    {scan.scan_mode !== 'blackbox' && (
                      <p className="text-text-secondary">
                        {(scan.results_summary as Record<string, number> | undefined)?.verified ?? 0} verified
                      </p>
                    )}
                  </div>
                  <div>
                    <p className="text-text-secondary">Routes</p>
                    <p className="text-text-primary font-medium">{scan.routes_discovered ?? 0}</p>
                  </div>
                  <div>
                    <p className="text-text-secondary">Started</p>
                    <p className="text-text-primary font-medium">
                      {formatDate(scan.started_at)}
                    </p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>

        <div className="hidden md:block overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Project</th>
                <th>Type</th>
                <th>Status</th>
                <th>Progress</th>
                <th>Findings</th>
                <th>Routes</th>
                <th>Started</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, idx) => (
                  <tr key={`skeleton-${idx}`}>
                    <td colSpan={7} className="py-3">
                      <div className="skeleton h-6 w-full" />
                    </td>
                  </tr>
                ))
              ) : scans.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-text-secondary">
                    <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-text-secondary/50" />
                    <p className="text-sm mb-3">
                      {statusFilter ? `No ${statusFilter} scans found.` : 'No scans yet. Start one from a project.'}
                    </p>
                    {!statusFilter && (
                      <button className="btn-secondary text-sm" onClick={() => navigate('/projects')}>
                        Go to Projects
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                scans.map((scan) => (
                  <tr
                    key={scan.id}
                    className="cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    onClick={() => navigate(`/scans/${scan.id}`)}
                    onKeyDown={(e) => handleRowKeyDown(e, scan.id)}
                    tabIndex={0}
                    role="button"
                    aria-label={`Open scan ${scan.id}`}
                  >
                    <td className="font-medium text-text-primary">
                      {scan.project_name || scan.project_id.slice(0, 8)}
                    </td>
                    <td>
                      <span className="badge-info">{scan.scan_type}</span>
                    </td>
                    <td>
                      <StatusBadge status={scan.status} />
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-background rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent rounded-full transition-all duration-500"
                            style={{ width: `${scan.progress}%` }}
                          />
                        </div>
                        <span className="text-text-secondary text-xs">{scan.progress}%</span>
                      </div>
                    </td>
                    <td className="text-text-primary">
                      <div>
                        <div>{(scan.results_summary as Record<string, number> | undefined)?.total_findings ?? 0}</div>
                        {scan.scan_mode !== 'blackbox' && (
                          <div className="text-[11px] text-text-secondary">
                            {(scan.results_summary as Record<string, number> | undefined)?.verified ?? 0} verified
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="text-text-primary">{scan.routes_discovered ?? 0}</td>
                    <td className="text-text-secondary text-xs whitespace-nowrap">
                      {formatDateTime(scan.started_at)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* ── Pagination ──────────────────────────────────────────────── */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-sm text-text-secondary">
              Page {page} of {totalPages} ({total} results)
            </span>
            <div className="flex items-center gap-1">
              <button
                className="btn-secondary h-9 w-9 p-0"
                aria-label="Previous page"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                className="btn-secondary h-9 w-9 p-0"
                aria-label="Next page"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Scans;
