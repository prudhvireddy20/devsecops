import axios, { type AxiosResponse } from 'axios';
import { useEffect, useRef, useState, useCallback } from 'react';

// ---------------------------------------------------------------------------
// API key — resolved at runtime from (in order):
//   1. Optional global (window.__DT_API_KEY__) for compatibility deployments
//   2. VITE_API_KEY build-time env var (useful for local dev)
//   3. localStorage ("dt_api_key") — set manually via ApiKeyGate fallback
// ---------------------------------------------------------------------------

const _STORAGE_KEY = 'dt_api_key';

/** Read optional globally-provided API key. */
function _getInjectedKey(): string {
  return (window as unknown as Record<string, string>).__DT_API_KEY__ || '';
}

function _getApiKey(): string {
  return _getInjectedKey()
    || import.meta.env.VITE_API_KEY
    || localStorage.getItem(_STORAGE_KEY)
    || '';
}

/** Save the API key to localStorage so it survives page reloads. */
export function setApiKey(key: string): void {
  localStorage.setItem(_STORAGE_KEY, key);
  // Update the default header on the existing axios instance
  if (key) {
    api.defaults.headers.common['X-API-Key'] = key;
  } else {
    delete api.defaults.headers.common['X-API-Key'];
  }
}

/** Return the currently configured API key. */
export function getApiKey(): string {
  return _getApiKey();
}

/** Remove the stored API key (logout / re-prompt). */
export function clearApiKey(): void {
  localStorage.removeItem(_STORAGE_KEY);
  delete api.defaults.headers.common['X-API-Key'];
}

// ---------------------------------------------------------------------------
// Axios instance
// ---------------------------------------------------------------------------

const api = axios.create({
  baseURL: '/api/v1',
  // Send the CP embedded-app session cookie so cookie-authenticated users
  // (Pattern 2) are scoped to their own data even without an API key.
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Apply API key on every request (reads latest value from storage)
api.interceptors.request.use((config) => {
  const key = _getApiKey();
  if (key) {
    config.headers['X-API-Key'] = key;
  }
  return config;
});

// ---------------------------------------------------------------------------
// Axios error interceptor — extract FastAPI detail messages
// ---------------------------------------------------------------------------

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (axios.isAxiosError(error) && error.response?.data) {
      const data = error.response.data as Record<string, unknown>;
      if (typeof data.detail === 'string') {
        return Promise.reject(new Error(data.detail));
      }
      if (Array.isArray(data.detail)) {
        // FastAPI validation errors come as an array
        const messages = (data.detail as Array<{ msg: string }>).map((d) => d.msg).join('; ');
        return Promise.reject(new Error(messages));
      }
    }
    return Promise.reject(error);
  },
);

// ---------------------------------------------------------------------------
// Shared types
// ---------------------------------------------------------------------------

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';
export type Confidence = 'verified' | 'probable' | 'observed';
export type ScanStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'cancelled';
export type FindingStatus =
  | 'open'
  | 'confirmed'
  | 'false_positive'
  | 'resolved';

// ---------------------------------------------------------------------------
// Entity types — aligned with backend models
// ---------------------------------------------------------------------------

export interface Project {
  id: string;
  name: string;
  description: string;
  source_type: string;
  source_path: string;
  scan_mode: string;
  trustscan_url: string;
  has_trustscan_token: boolean;
  git_url: string;
  git_branch: string;
  target_url: string;
  framework: string;
  language: string;
  local_path: string;
  llm_provider?: string;
  llm_model?: string;
  has_llm_api_key?: boolean;
  openapi_spec_files?: string;
  postman_collection_files?: string;
  journey_replay_files?: string;
  is_active: boolean;
  created_at: string | null;
  updated_at: string | null;
}

export interface CreateProjectPayload {
  name: string;
  description?: string;
  source_type: string;
  source_path?: string;
  scan_mode?: string;
  trustscan_url?: string;
  trustscan_token?: string;
  trustscan_job_id?: string;
  trustscan_oauth_project_id?: string;
  target_url?: string;
  openapi_spec_files?: string;
  postman_collection_files?: string;
  journey_replay_files?: string;
  auth_config?: Record<string, unknown>;
}

export interface UpdateProjectPayload {
  name?: string;
  description?: string;
  target_url?: string;
  git_branch?: string;
  llm_provider?: string;
  llm_model?: string;
  llm_api_key?: string;
  openapi_spec_files?: string;
  postman_collection_files?: string;
  journey_replay_files?: string;
}

export interface ProjectFile {
  path: string;
  name: string;
  type: 'file' | 'directory';
  size?: number;
  language?: string | null;
  children?: ProjectFile[];
}

export interface FileContent {
  path: string;
  content: string;
  language: string;
}

export interface ScanConfig {
  project_id: string;
  scan_type?: string;
  modules_enabled?: Record<string, boolean>;
  auth_config?: Record<string, unknown>;
  scan_goals?: string[];
  scan_config?: Record<string, unknown>;
  external_findings_path?: string;
  external_findings_format?: string;
}

export interface UploadFindingsResult {
  path: string;
  format: string;
  finding_count: number;
}

export interface Scan {
  id: string;
  project_id: string;
  project_name?: string;
  scan_mode: string;
  status: ScanStatus;
  scan_type: string;
  progress: number;
  current_phase: string;
  modules_enabled: Record<string, boolean>;
  scan_goals?: string[];
  plan_intent?: Record<string, unknown>;
  scan_config: {
    [key: string]: unknown;
    llm_planner_enabled?: boolean;
    llm_provider?: string;
    llm_model?: string;
  };
  results_summary: Record<string, unknown>;
  plan_result?: Record<string, unknown>;
  routes_discovered: number;
  coverage_percentage: number;
  log?: string;
  error_message: string;
  started_at: string | null;
  completed_at: string | null;
  created_at: string | null;
}

export interface ScanRoute {
  method: string;
  path: string;
  handler: string;
  file?: string;
  line?: number;
  tested: boolean;
  finding_count: number;
}

export interface Finding {
  id: string;
  scan_id: string;
  title: string;
  vulnerability_type: string;
  severity: Severity;
  confidence: Confidence;
  cwe: string;
  owasp_category: string;
  endpoint: string;
  http_method: string;
  parameter: string;
  file_path: string;
  line_number: number;
  code_snippet: string;
  data_flow: string;
  payload: string;
  response_code: number;
  response_evidence: string;
  auth_role?: string;
  journey_source?: string;
  workflow_graph_id?: string;
  workflow_step_id?: string;
  repro_bundle?: Record<string, unknown>;
  flow_evidence?: Record<string, unknown> | null;
  risk_score?: number;
  risk_level?: string;
  scanner_source: string;
  scanner_rule_id: string;
  remediation_text: string;
  generated_fix_payload?: Record<string, unknown>;
  fix_available: boolean;
  fix_applied: boolean;
  status: FindingStatus;
  notes: string;
  duplicate_of: string;
  created_at: string | null;
  updated_at: string | null;
}

export interface FindingSummary {
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  info: number;
  verified: number;
  probable: number;
  observed: number;
  open: number;
  resolved: number;
  false_positive: number;
}

export interface UpdateFindingPayload {
  status?: FindingStatus;
  notes?: string;
}

export interface GeneratedFix {
  finding_id: string;
  fix_available: boolean;
  strategy_used?: 'llm' | 'template' | 'none';
  fix: {
    remediation_text?: string;
    original_code?: string;
    fixed_code?: string;
    explanation?: string;
    diff?: string;
    triage?: 'true_positive' | 'false_positive' | 'uncertain';
    triage_confidence?: 'low' | 'medium' | 'high';
    reasoning?: string;
    tests_to_add?: string[];
    safe_to_autofix?: boolean;
  } | null;
}

export interface Report {
  scan_id: string;
  format: string;
  file_path: string;
  download_url: string;
}

export interface ReportPreview {
  scan: Record<string, unknown>;
  project: Record<string, unknown>;
  findings: Finding[];
}

export type ReportFormat = 'pdf' | 'html' | 'json' | 'sarif';

export interface GenerateReportPayload {
  scan_id: string;
  format: ReportFormat;
}

export interface DashboardStats {
  total_projects: number;
  total_scans: number;
  recent_scans: Scan[];
  finding_summary: {
    total: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
    info: number;
  };
}

export interface LLMProviderInfo {
  provider: string;
  label: string;
  connected: boolean;
  source: 'stored' | 'env' | 'none';
  default_model: string;
  models: string[];
  needs_reconnect?: boolean;
  auth_mode?: 'api_key' | 'github_device';
}

export interface LLMProvidersResponse {
  enabled: boolean;
  providers: LLMProviderInfo[];
}

export interface GitHubDeviceAuthStartResponse {
  provider: 'github';
  label: string;
  deployment_type: 'github.com';
  auth_mode: 'github_device';
  auth_request_id: string;
  verification_uri: string;
  user_code: string;
  expires_in: number;
  interval: number;
  status: 'authorization_pending';
  default_model: string;
}

export interface GitHubDeviceAuthStatusResponse {
  provider: 'github';
  status: 'authorization_pending' | 'authorized' | 'expired_token' | 'access_denied';
  message?: string;
  verification_uri?: string;
  user_code?: string;
  retry_after_seconds?: number;
  label?: string;
  connected?: boolean;
  source?: 'stored' | 'env' | 'none';
  default_model?: string;
  models?: string[];
  needs_reconnect?: boolean;
  auth_mode?: 'api_key' | 'github_device' | 'github_oauth';
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
}

// ---------------------------------------------------------------------------
// Query param helpers
// ---------------------------------------------------------------------------

export interface ListParams {
  page?: number;
  page_size?: number;
  sort_by?: string;
  sort_order?: 'asc' | 'desc';
}

export interface FindingListParams extends ListParams {
  severity?: Severity;
  confidence?: Confidence;
  status?: FindingStatus;
  vulnerability_type?: string;
  scanner_source?: string;
  project_id?: string;
  scan_id?: string;
  search?: string;
}

export interface FindingSummaryParams {
  severity?: Severity;
  confidence?: Confidence;
  status?: FindingStatus;
  vulnerability_type?: string;
  scanner_source?: string;
  project_id?: string;
  scan_id?: string;
  search?: string;
}

// ---------------------------------------------------------------------------
// Unwrap helper
// ---------------------------------------------------------------------------

function unwrap<T>(res: AxiosResponse<T>): T {
  return res.data;
}

async function getWebSocketToken(payload: { scope: 'scan' | 'dashboard'; scan_id?: string }): Promise<{ ws_path: string }> {
  return unwrap(await api.post('/auth/ws-token', payload));
}

// ---------------------------------------------------------------------------
// Current user
// ---------------------------------------------------------------------------

export interface CurrentUser {
  id: string;
  label: string;
  is_admin: boolean;
  cp_sub?: string;
  cp_email?: string;
  cp_org_id?: string;
}

export async function getCurrentUser(): Promise<CurrentUser> {
  return unwrap(await api.get('/users/me'));
}

// ---------------------------------------------------------------------------
// Projects
// ---------------------------------------------------------------------------

export async function getProjects(
  params?: ListParams,
): Promise<PaginatedResponse<Project>> {
  return unwrap(await api.get('/projects', { params }));
}

export async function createProject(
  payload: CreateProjectPayload,
): Promise<Project> {
  return unwrap(await api.post('/projects', payload));
}

export async function getProject(id: string): Promise<Project> {
  return unwrap(await api.get(`/projects/${id}`));
}

export async function updateProject(
  id: string,
  payload: UpdateProjectPayload,
): Promise<Project> {
  return unwrap(await api.put(`/projects/${id}`, payload));
}

export async function deleteProject(id: string): Promise<void> {
  await api.delete(`/projects/${id}`);
}

export async function uploadProjectZip(
  projectId: string,
  file: File,
): Promise<{ status: string; local_path: string }> {
  const form = new FormData();
  form.append('file', file);
  return unwrap(
    await api.post(`/projects/${projectId}/upload`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120_000, // 2 min for large ZIPs
    }),
  );
}

export async function uploadProjectArtifact(
  projectId: string,
  kind: 'openapi' | 'postman' | 'journey',
  file: File,
): Promise<{ status: string; kind: string; file: string; project_id: string }> {
  const form = new FormData();
  form.append('kind', kind);
  form.append('file', file);
  return unwrap(
    await api.post(`/projects/${projectId}/artifacts`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120_000,
    }),
  );
}

export async function getProjectFiles(
  projectId: string,
): Promise<ProjectFile[]> {
  const resp = unwrap<unknown>(await api.get(`/projects/${projectId}/files`));
  // Backend returns { tree: [...] }
  if (resp && typeof resp === 'object' && 'tree' in (resp as Record<string, unknown>)) {
    return (resp as Record<string, unknown>).tree as ProjectFile[];
  }
  return resp as ProjectFile[];
}

export async function getFileContent(
  projectId: string,
  filePath: string,
): Promise<FileContent> {
  return unwrap(
    await api.get(`/projects/${projectId}/file`, {
      params: { path: filePath },
    }),
  );
}

// ---------------------------------------------------------------------------
// Scans
// ---------------------------------------------------------------------------

export async function startScan(config: ScanConfig): Promise<Scan> {
  return unwrap(await api.post('/scans', config));
}

export async function getScans(
  params?: ListParams & { project_id?: string; status?: ScanStatus },
): Promise<PaginatedResponse<Scan>> {
  return unwrap(await api.get('/scans', { params }));
}

export async function getScan(id: string): Promise<Scan> {
  return unwrap(await api.get(`/scans/${id}`));
}

export async function cancelScan(id: string): Promise<{ status: string; id: string }> {
  return unwrap(await api.post(`/scans/${id}/cancel`));
}

export async function getScanRoutes(
  scanId: string,
  params?: ListParams,
): Promise<PaginatedResponse<ScanRoute>> {
  return unwrap(await api.get(`/scans/${scanId}/routes`, { params }));
}

export interface ProjectRouteEntry {
  path: string;
  method: string;
  handler: string;
  function: string;
  file_path: string;
  line: number;
  auth_required: boolean;
  parameters: string[];
}

export async function getProjectRoutes(
  projectId: string,
): Promise<{ items: ProjectRouteEntry[]; total: number }> {
  return unwrap(await api.get(`/projects/${projectId}/routes`));
}

export async function uploadProjectFindings(
  projectId: string,
  file: File,
): Promise<UploadFindingsResult> {
  const form = new FormData();
  form.append('file', file);
  return unwrap(
    await api.post(`/projects/${projectId}/upload-findings`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120_000,
    }),
  );
}

export async function uploadExternalFindings(
  scanId: string,
  file: File,
  projectId: string,
): Promise<UploadFindingsResult> {
  const form = new FormData();
  form.append('file', file);
  form.append('project_id', projectId);
  return unwrap(
    await api.post(`/scans/${scanId}/upload-findings`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120_000,
    }),
  );
}

// ---------------------------------------------------------------------------
// Findings
// ---------------------------------------------------------------------------

export async function getFindings(
  params?: FindingListParams,
): Promise<PaginatedResponse<Finding>> {
  return unwrap(await api.get('/findings', { params }));
}

export async function getFindingSummary(
  params?: FindingSummaryParams,
): Promise<FindingSummary> {
  return unwrap(await api.get('/findings/summary', { params }));
}

export async function getFinding(id: string): Promise<Finding> {
  return unwrap(await api.get(`/findings/${id}`));
}

export async function updateFinding(
  id: string,
  payload: UpdateFindingPayload,
): Promise<Finding> {
  return unwrap(await api.put(`/findings/${id}`, payload));
}

export async function generateFix(
  findingId: string,
  strategy: 'auto' | 'template' | 'llm' = 'auto',
): Promise<GeneratedFix> {
  return unwrap(await api.post(`/findings/${findingId}/generate-fix`, null, { params: { strategy } }));
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export async function generateReport(
  payload: GenerateReportPayload,
): Promise<Report> {
  return unwrap(await api.post('/reports', payload));
}

export async function downloadReport(scanId: string, format: ReportFormat = 'html'): Promise<Blob> {
  const res = await api.get(`/reports/${scanId}/download`, {
    params: { format },
    responseType: 'blob',
  });
  return res.data as Blob;
}

export async function getReportPreview(
  scanId: string,
): Promise<ReportPreview> {
  return unwrap(await api.get(`/reports/${scanId}/preview`));
}

export async function generateComplianceReport(
  scanId: string,
  framework: string,
): Promise<unknown> {
  return unwrap(await api.post(`/reports/${scanId}/compliance`, { scan_id: scanId, standards: [framework] }));
}

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export async function getDashboardStats(): Promise<DashboardStats> {
  return unwrap(await api.get('/dashboard/stats'));
}

// ---------------------------------------------------------------------------
// Insights
// ---------------------------------------------------------------------------

export interface InsightsData {
  findingSummary: FindingSummary;
  findings: Finding[];
}

export async function getInsightsData(projectId?: string): Promise<InsightsData> {
  const params = projectId ? { project_id: projectId } : undefined;
  const [summary, findingsResp] = await Promise.all([
    getFindingSummary(params),
    getFindings({ page_size: 1000, ...params }),
  ]);
  return {
    findingSummary: summary,
    findings: findingsResp.items,
  };
}

// ---------------------------------------------------------------------------
// Integrations
// ---------------------------------------------------------------------------

export interface IntegrationSummary {
  key: string;
  name: string;
  category: string;
  description: string;
  auth_label: string;
  connected: boolean;
  enabled: boolean;
  recipients_count: number;
}

export interface EmailIntegrationConfig {
  enabled: boolean;
  recipients: string[];
  smtp_configured: boolean;
  from_email: string;
}

export async function getIntegrations(): Promise<IntegrationSummary[]> {
  return unwrap(await api.get('/integrations'));
}

export async function getEmailIntegration(): Promise<EmailIntegrationConfig> {
  return unwrap(await api.get('/integrations/email'));
}

export async function updateEmailIntegration(payload: {
  enabled: boolean;
  recipients: string[];
}): Promise<EmailIntegrationConfig> {
  return unwrap(await api.put('/integrations/email', payload));
}

export async function testEmailIntegration(): Promise<{ ok: boolean; recipients: string[] }> {
  return unwrap(await api.post('/integrations/email/test'));
}

// ---------------------------------------------------------------------------
// LLM providers
// ---------------------------------------------------------------------------

export async function getLLMProviders(): Promise<LLMProvidersResponse> {
  return unwrap(await api.get('/llm/providers'));
}

export async function connectLLMProvider(
  provider: string,
  payload: { api_key?: string; default_model?: string },
): Promise<LLMProviderInfo> {
  return unwrap(await api.put(`/llm/providers/${provider}`, payload));
}

export async function disconnectLLMProvider(provider: string): Promise<{ provider: string; connected: boolean; source: 'env' | 'none' }> {
  return unwrap(await api.delete(`/llm/providers/${provider}`));
}

export async function startGitHubDeviceAuth(
  payload: { deployment_type?: 'github.com'; default_model?: string },
): Promise<GitHubDeviceAuthStartResponse> {
  return unwrap(await api.post('/llm/providers/github/device/start', payload));
}

export async function pollGitHubDeviceAuthStatus(
  authRequestId: string,
): Promise<GitHubDeviceAuthStatusResponse> {
  return unwrap(
    await api.post('/llm/providers/github/device/status', {
      auth_request_id: authRequestId,
    }),
  );
}

// ---------------------------------------------------------------------------
// WebSocket hook
// ---------------------------------------------------------------------------

export interface WebSocketMessage {
  type: string;
  [key: string]: unknown;
}

export interface UseWebSocketReturn {
  messages: WebSocketMessage[];
  sendMessage: (msg: string) => void;
  connected: boolean;
}

const MAX_WS_MESSAGES = 500;

async function createWebSocketUrl(baseWsUrl: string): Promise<string> {
  const scanMatch = /\/ws\/scan\/([^/?]+)/.exec(baseWsUrl);
  const tokenPayload = scanMatch
    ? { scope: 'scan' as const, scan_id: decodeURIComponent(scanMatch[1]) }
    : { scope: 'dashboard' as const };

  const tokenResponse = await getWebSocketToken(tokenPayload);
  const wsPath = tokenResponse.ws_path;
  if (!wsPath) {
    throw new Error('Missing websocket path from token endpoint');
  }

  if (wsPath.startsWith('ws://') || wsPath.startsWith('wss://')) {
    return wsPath;
  }

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}${wsPath}`;
}

export function useWebSocket(url: string): UseWebSocketReturn {
  const [messages, setMessages] = useState<WebSocketMessage[]>([]);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const pingIntervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const mountedRef = useRef(true);

  const connect = useCallback(() => {
    if (!mountedRef.current) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const baseWsUrl = url.startsWith('ws')
      ? url
      : `${protocol}//${window.location.host}${url}`;

    createWebSocketUrl(baseWsUrl)
      .then((wsUrl) => {
        if (!mountedRef.current) return;

        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setConnected(true);
          // Start sending ping every 25 seconds to keep proxy alive
          pingIntervalRef.current = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send('ping');
            }
          }, 25000);
        };

        ws.onmessage = (event: MessageEvent) => {
          // Ignore ping/pong messages from server keepalive
          if (event.data === '{"type":"ping"}' || event.data === 'ping') {
            return;
          }

          try {
            const data = JSON.parse(event.data) as WebSocketMessage;
            // Also ignore if parsed ping message
            if (data.type === 'ping') {
              return;
            }
            setMessages((prev) => {
              const next = [...prev, data];
              return next.length > MAX_WS_MESSAGES ? next.slice(-MAX_WS_MESSAGES) : next;
            });
          } catch {
            setMessages((prev) => {
              const next = [...prev, { type: 'raw', payload: event.data }];
              return next.length > MAX_WS_MESSAGES ? next.slice(-MAX_WS_MESSAGES) : next;
            });
          }
        };

        ws.onclose = () => {
          setConnected(false);
          wsRef.current = null;
          if (pingIntervalRef.current) {
            clearInterval(pingIntervalRef.current);
            pingIntervalRef.current = undefined;
          }
          if (mountedRef.current) {
            reconnectTimer.current = setTimeout(connect, 3000);
          }
        };

        ws.onerror = () => {
          ws.close();
        };
      })
      .catch(() => {
        setConnected(false);
        if (pingIntervalRef.current) {
          clearInterval(pingIntervalRef.current);
          pingIntervalRef.current = undefined;
        }
        if (mountedRef.current) {
          reconnectTimer.current = setTimeout(connect, 3000);
        }
      });
  }, [url]);

  useEffect(() => {
    mountedRef.current = true;
    connect();

    return () => {
      mountedRef.current = false;
      clearTimeout(reconnectTimer.current);
      if (pingIntervalRef.current) {
        clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = undefined;
      }
      if (wsRef.current) {
        wsRef.current.onclose = null; // Prevent reconnect on unmount
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect]);

  const sendMessage = useCallback((msg: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(msg);
    }
  }, []);

  return { messages, sendMessage, connected };
}

// ---------------------------------------------------------------------------
// Default export for convenience
// ---------------------------------------------------------------------------

export default api;
