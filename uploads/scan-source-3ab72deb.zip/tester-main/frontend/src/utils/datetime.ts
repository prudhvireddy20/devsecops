export function formatDate(dateLike?: string | null): string {
  if (!dateLike) return '-';
  return new Date(dateLike).toLocaleDateString();
}

export function formatDateTime(dateLike?: string | null): string {
  if (!dateLike) return '-';
  return new Date(dateLike).toLocaleString();
}
