// ponytail: minimal self-check — the smallest thing that fails if core
// aggregation / chart logic in Insights.tsx breaks. No framework, no fixtures.

import assert from 'node:assert';

// ── vuln type colour cycling ─────────────────────────────────────────
const VULN_TYPE_PALETTE = [
  'rgb(var(--color-critical))',
  'rgb(var(--color-high))',
  'rgb(var(--color-medium))',
  'rgb(var(--color-info))',
  'rgb(var(--color-low))',
  'rgb(var(--color-observed))',
  'rgb(var(--color-probable))',
  'rgb(var(--color-verified))',
];
function vulnTypeColor(index) { return VULN_TYPE_PALETTE[index % VULN_TYPE_PALETTE.length]; }

assert.equal(vulnTypeColor(0), VULN_TYPE_PALETTE[0], 'index 0 -> first colour');
assert.equal(vulnTypeColor(7), VULN_TYPE_PALETTE[7], 'index 7 -> last colour');
assert.equal(vulnTypeColor(8), VULN_TYPE_PALETTE[0], 'index 8 wraps to first');
assert.equal(vulnTypeColor(-1), VULN_TYPE_PALETTE[-1 % 8], 'negative index');

// ── distribution aggregation (same pattern as useMemo in component) ──
function aggregate(items, keyFn) {
  const map = new Map();
  for (const item of items) {
    const key = keyFn(item);
    map.set(key, (map.get(key) || 0) + 1);
  }
  return [...map.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([label, value]) => ({ label, value }));
}

const findings = [
  { vulnerability_type: 'xss', scanner_source: 'dalfox' },
  { vulnerability_type: 'xss', scanner_source: 'dalfox' },
  { vulnerability_type: 'sqli', scanner_source: 'sqlmap' },
  { vulnerability_type: 'cmdi', scanner_source: 'zap' },
  { vulnerability_type: 'xss', scanner_source: 'nuclei' },
];

const vulnTypes = aggregate(findings, (f) => f.vulnerability_type || 'unknown');
const scanners = aggregate(findings, (f) => f.scanner_source || 'unknown');

assert.equal(vulnTypes.length, 3, '3 distinct vuln types');
assert.equal(vulnTypes[0].label, 'xss', 'xss is most frequent');
assert.equal(vulnTypes[0].value, 3, 'xss appears 3 times');
assert.equal(vulnTypes[1].label, 'sqli', 'sqli second');
assert.equal(vulnTypes[2].label, 'cmdi', 'cmdi third');

assert.equal(scanners.length, 4, '4 distinct scanner sources');
assert.equal(scanners[0].label, 'dalfox', 'dalfox most frequent');
assert.equal(scanners[0].value, 2, 'dalfox appears 2 times');

// ── empty input ─────────────────────────────────────────────────────
assert.deepEqual(aggregate([], (f) => f.x), [], 'empty array -> empty result');

// ── DistBar top-8 + Others ──────────────────────────────────────────
function distBarParts(items, maxTop = 8) {
  const sorted = [...items].sort((a, b) => b.value - a.value);
  if (sorted.length <= maxTop) return { top: sorted, others: 0 };
  return {
    top: sorted.slice(0, maxTop),
    others: sorted.slice(maxTop).reduce((s, i) => s + i.value, 0),
  };
}

const many = Array.from({ length: 12 }, (_, i) => ({ label: `t${i}`, value: 10 - i }));
const parts = distBarParts(many);
assert.equal(parts.top.length, 8, 'top 8 of 12');
assert.equal(parts.others, many.slice(8).reduce((s, i) => s + i.value, 0), 'others sum correct');

const few = many.slice(0, 5);
const partsFew = distBarParts(few);
assert.equal(partsFew.top.length, 5, 'fewer than 8, all shown');
assert.equal(partsFew.others, 0, 'no others when <= 8');

// ── Doughnut arc lengths ────────────────────────────────────────────
function doughnutSegments(segments, circumference) {
  let cumulative = 0;
  const total = segments.reduce((s, seg) => s + seg.value, 0);
  return segments.map((seg) => {
    const len = (seg.value / total) * circumference;
    const result = {
      ...seg,
      dasharray: `${len} ${circumference - len}`,
      dashoffset: -cumulative,
    };
    cumulative += len;
    return result;
  });
}

const circ = 100;
const segs = [{ value: 30, color: 'red', label: 'a' }, { value: 70, color: 'blue', label: 'b' }];
const arcs = doughnutSegments(segs, circ);
const [a, b] = arcs;

assert.equal(a.dasharray, '30 70', '30% arc dasharray');
assert.equal(a.dashoffset, -0, 'first arc starts at 0');
assert.equal(b.dasharray, '70 30', '70% arc dasharray');
assert.equal(b.dashoffset, -30, 'second arc starts after 30');

// ── empty segments ──────────────────────────────────────────────────
assert.deepEqual(doughnutSegments([], 100), [], 'no segments -> empty');

console.log('✓ insights.test.mjs — all checks passed');
