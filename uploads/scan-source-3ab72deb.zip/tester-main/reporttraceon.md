# TraceON — Full Technical Reference

**TraceON** is a self-hosted web application security scanner that combines dynamic application security testing (DAST), external static finding imports (via TrustScan / DevSecOps JSON), automated recon tools, LLM-assisted planning, and a full-featured React dashboard. It is designed for security teams who need full control over their toolchain without sending data to third-party SaaS platforms.

---

## Table of Contents

1. [What TraceON Does](#1-what-traceon-does)
2. [Architecture Overview](#2-architecture-overview)
3. [Deployment & Docker](#3-deployment--docker)
4. [Scanning Pipeline](#4-scanning-pipeline)
5. [External Tools Used](#5-external-tools-used)
6. [LLM Integration](#6-llm-integration)
7. [Correlation Engine](#7-correlation-engine)
8. [Source Analysis & Route Extraction](#8-source-analysis--route-extraction)
9. [TrustScan Integration](#9-trustscan-integration)
10. [Authentication & Multi-User](#10-authentication--multi-user)
11. [Security Measures](#11-security-measures)
12. [API Endpoints](#12-api-endpoints)
13. [Database Models](#13-database-models)
14. [Frontend Pages](#14-frontend-pages)
15. [Report Generation](#15-report-generation)
16. [Coverage Tracking](#16-coverage-tracking)
17. [Configuration Reference](#17-configuration-reference)

---

## 1. What TraceON Does

TraceON scans web applications for security vulnerabilities using three scan modes:

| Mode | Description | Static Findings | Dynamic Findings |
|------|-------------|----------------|-----------------|
| **Whitebox** | Target URL + optional TrustScan integration | Imported from TrustScan / DevSecOps JSON | ZAP + Nuclei |
| **Blackbox** | Target URL only | None | Recon → ZAP → Nuclei |
| **Hybrid** | External findings required + live target | Uploaded DevSecOps JSON | ZAP + Nuclei |

After scanning, the **Correlation Engine** links static findings (imported) with DAST findings (live) to assign confidence levels (Verified / Probable / Observed). An optional **LLM** synthesizes the findings into attack chains, flags probable false positives, and generates an executive summary.

---

## 2. Architecture Overview

```
Browser (React SPA)
      │  HTTP / WebSocket
      ▼
FastAPI Backend (Python 3.11)
      │
      ├── SQLAlchemy (async) ──► SQLite (default) / configurable DB
      ├── WebSocket manager ──► real-time scan progress per scan_id
      ├── Rate limiter (in-memory, 300 req/min per IP)
      │
      ├── ScanOrchestrator ──► runs each scan phase in sequence
      │        │
      │        ├── gau / ffuf / Nikto ──► recon (blackbox)
      │        ├── ExternalFindingImporter ──► TrustScan / SARIF / DevSecOps JSON
      │        ├── OWASP ZAP (sidecar container) ──► spider + active scan
      │        ├── Nuclei (Go binary) ──► CVE templates
      │        ├── Playwright (optional) ──► browser auth + journey replay
      │        ├── CorrelationEngine ──► confidence scoring
      │        └── LLM synthesizer ──► attack chains, summary
      │
      └── Reports ──► HTML / PDF / SARIF / JSON
```

**Key files:**
- `backend/app/main.py` — FastAPI app, lifespan (DB init, admin seed, rate limiter)
- `backend/app/core/orchestrator.py` — full scan pipeline (~2000 lines)
- `frontend/src/App.tsx` — React router, sidebar, lazy-loaded pages

---

## 3. Deployment & Docker

### Docker Compose Services

| Service | Image | Resources | Purpose |
|---------|-------|-----------|---------|
| `backend` | Custom (Python 3.11) | 2 GB RAM | FastAPI + all scan tools |
| `zap` | `zaproxy/zap-stable` | 4 GB heap, 2 CPU | OWASP ZAP DAST engine |

### Named Volumes

| Volume | Path in container | Contents |
|--------|------------------|---------|
| `projects_data` | `/data/projects` | Uploaded source ZIPs, artifact files |
| `db_data` | `/data/db` | SQLite database, `.api_key`, `.encryption_key` |
| `reports_data` | `/data/reports` | Generated HTML/PDF/SARIF/JSON reports |
| `uploads_data` | `/data/uploads` | External findings JSON uploads |
| `nuclei_templates` | `/root/nuclei-templates` | Nuclei template cache |

### Multi-Stage Dockerfile

| Stage | Base | Output |
|-------|------|--------|
| `frontend-build` | Node 20-alpine | React SPA static files |
| `go-tools` | Go 1.22-alpine | Pre-compiled `gau` and `ffuf` binaries |
| `python-builder` | Python 3.11 + build tools | Wheel cache |
| `runtime` | Python 3.11-slim | Final lean image with all of the above |

**Additional runtime content:**
- Nuclei binary (pre-compiled Go)
- Nikto (cloned from GitHub, symlinked to `/usr/local/bin/nikto`)
- SecLists wordlists at `/usr/share/seclists/` (for ffuf)
- Playwright browser bundle (optional, set `INCLUDE_PLAYWRIGHT=true` at build time)
- Healthcheck: `curl http://localhost:{PORT}/api/health`

---

## 4. Scanning Pipeline

The orchestrator (`orchestrator.py`) runs phases sequentially. Progress jumps as phases complete. The exact phases and order depend on scan mode.

### Whitebox Mode

| Phase | Progress | Tool / Code | Output |
|-------|---------|-------------|--------|
| source_analysis | 5% | Route/sink/auth detectors (Python AST + regex) | routes, framework, sinks |
| endpoint_discovery | 7% | OpenAPI spec probing, GraphQL introspection | additional API routes |
| importing | 12% | ExternalFindingImporter — TrustScan API or file | normalized findings in DB |
| fingerprinting | 18% | HTTP-based tech-stack probing | detected framework, server, language |
| auth | 45% | REST login or Playwright browser script | session cookies/tokens per role |
| spider | 55% | ZAP spider (zapv2 Python API) | crawled URLs added to scope |
| waf_detection | 60% | HTTP probing + rate-limit adjustment | WAF flag; ZAP rate-limited if detected |
| active_scan | 75% | ZAP active scan | DAST findings |
| dast_extended | 85% | Nuclei Go binary + optionally Wapiti | CVE/misconfiguration findings |
| correlation | 95% | CorrelationEngine (Python) | confidence-scored, deduplicated findings |
| complete | 100% | LLM post-scan synthesizer | attack chains, FP flags, executive summary |

### Blackbox Mode

Same DAST phases, with these recon phases added before auth:

| Phase | Progress | Tool |
|-------|---------|------|
| url_discovery | 5% | gau (Go binary) — historical URLs from Wayback/CommonCrawl/OTX |
| path_fuzzing | 8% | ffuf (Go binary) + SecLists wordlists |
| server_audit | 12% | Nikto — server misconfig, dangerous HTTP methods |
| endpoint_discovery | 15% | OpenAPI/GraphQL probing |
| fingerprinting | 20% | Tech-stack probing |

### Hybrid Mode

Importing phase is **required** (user must upload a DevSecOps JSON before scanning). If no external findings are found, the scan logs a warning and continues as DAST-only.

### Concurrency Controls

- `_dast_semaphore` (capacity=1) — serializes all ZAP operations across concurrent scans to prevent the 4 GB ZAP container from running out of heap memory
- `_db_lock` (asyncio.Lock) — serializes DB writes within a single scan since AsyncSession is not safe for concurrent coroutine access

### Multi-Role DAST

When auth config includes multiple role profiles (e.g., admin, user, guest):
- Each role runs its own auth → spider → active_scan cycle
- Findings are tagged with `_auth_role`
- The correlation engine uses `correlate_by_role()` to detect IDOR (same endpoint, different roles) and auth logic flaws (access differences between roles)

---

## 5. External Tools Used

| Tool | How installed | Purpose | Scan modes | Scanner file |
|------|--------------|---------|------------|-------------|
| **OWASP ZAP** | `zaproxy/zap-stable` Docker image | Active DAST — spider, active scan, alert aggregation | All | `scanners/dast_engine.py` |
| **Nuclei** | Pre-compiled Go binary in Docker | CVE templates, misconfiguration checks | After ZAP, all modes | `scanners/nuclei_engine.py` |
| **gau** (getallurls) | Pre-compiled Go binary in Docker | Historical URL harvesting from Wayback Machine, CommonCrawl, OTX | Blackbox | `scanners/url_discovery_engine.py` |
| **ffuf** | Pre-compiled Go binary in Docker | Hidden path/directory fuzzing using SecLists wordlists | Blackbox | `scanners/ffuf_engine.py` |
| **Nikto** | Cloned from GitHub at build time, symlinked to `/usr/local/bin/nikto` | Server misconfiguration audit, dangerous HTTP methods, version disclosure | Blackbox | `scanners/nikto_engine.py` |
| **Wapiti3** | pip | Alternative DAST: XXE, LDAP injection, CRLF injection, SSRF | Blackbox (optional) | `scanners/wapiti_engine.py` |
| **Playwright** | pip + optional browser bundle | Browser-based authentication automation; business logic journey replay | All (when auth config present) | `scanners/playwright_spider.py`, `scanners/replay_adapter.py` |
| **ExternalFindingImporter** | Python (internal) | Parses TrustScan JSON, DevSecOps JSON, SARIF, Semgrep JSON, Noir JSON into normalized Finding records | All (importing phase) | `scanners/external_importer.py` |

### OWASP ZAP — Detail

ZAP runs as a separate Docker container with its own 4 GB heap. The backend communicates with it via the `zapv2` Python API over the inter-container `app-network`. ZAP performs:
- **Passive spidering**: crawls all pages in scope, builds a site tree
- **Active scanning**: fires payloads for SQLi, XSS, path traversal, command injection, SSRF, and many other vulnerability types
- **Alert aggregation**: raw alerts are normalized into TraceON Finding records

The `_dast_semaphore` in the orchestrator ensures only one scan at a time drives ZAP, preventing memory exhaustion.

### Nuclei — Detail

Nuclei uses community templates to check for:
- Known CVEs (by service fingerprint)
- Misconfigurations (default credentials, exposed admin panels, header issues)
- Technology-specific vulnerabilities

Templates are cached in the `nuclei_templates` volume and updated on first run.

### ExternalFindingImporter — Detail

Supports multiple input formats (auto-detected or explicit):

| Format | Trigger | Typical source |
|--------|---------|---------------|
| `devsecops` | default | TrustScan platform API, generic DevSecOps JSON |
| `sarif` | SARIF `$schema` detected | GitHub Advanced Security, CodeQL, Semgrep CLI export |
| `semgrep` | Semgrep `results[]` key detected | Semgrep JSON output |
| `noir` | Noir `endpoints[]` key detected | Noir route extractor output |

TrustScan finding normalization: `severity`/`confidence` → lowercase; CWE gets `"CWE-"` prefix if missing; `SCA` vuln type → `dependency_cve`; `SECRET` → `secret`.

---

## 6. LLM Integration

### Supported Providers

| Provider | Models available |
|----------|----------------|
| **Anthropic** | claude-3-5-sonnet-latest, claude-3-5-haiku-latest, claude-3-opus-latest |
| **OpenAI** | gpt-4o-mini, gpt-4.1-mini, gpt-4.1, o3-mini |
| **OpenRouter** | 17+ models including Llama, Gemma, Gemini variants |
| **Google** | gemini-1.5-pro, gemini-1.5-flash, gemini-2.0-flash |
| **GitHub Copilot** | gpt-4o-mini, gpt-4, gpt-3.5-turbo |

### Configuration Resolution Priority

```
scan-level override (scan_config.llm_provider / llm_model / llm_api_key)
      ↓ (if not set)
DB credentials (LLMProviderCredential for current user)
      ↓ (if not set)
Project defaults (project.llm_provider / llm_model)
      ↓ (if not set)
Environment variables (LLM_PROVIDER / LLM_MODEL / *_API_KEY)
```

API keys are **never** pulled from the environment for actual scan runs — only from DB or scan config. This decouples deployment secrets from per-user credentials.

### Per-User Encrypted Credentials

Each user can connect their own LLM provider via the **LLM Config** page. Keys are stored encrypted (Fernet) in the `llm_provider_credentials` table, scoped to `user_id`.

### How LLM Is Used During a Scan

**1. Pre-scan planning** (`llm/pre_scan_planner.py`)
- Reads project description (only if > 15 characters)
- Asks LLM for: `focus_areas`, `skip_hint` (scan areas to de-prioritize), `risk_hypothesis` (predicted vuln types)
- Used to tune: Nuclei template selection, ZAP scope, planner priorities
- Result cached by SHA-256 of description for 24 hours
- If LLM is unavailable or returns an error, scan continues without planning

**2. Mid-scan checkpoint planner** (`llm/planner.py`)
- Called at checkpoints (e.g., after source analysis, after active scan)
- LLM receives current scan state (routes found, phase, config)
- Returns one of four allowed actions:
  - `no_change` — leave config as-is
  - `update_scan_config` — adjust bounded params: scan_depth (1–20), timeout (30–14400s), max_children (1–500), ajax_spider, inscope_only
  - `prioritize_vuln_types` — set top 12 vulnerability types for Nuclei/ZAP focus
  - `recommend_targeted_retry` — suggest a specific path or endpoint to re-scan
- Applied changes are written back to `scan.scan_config` and logged

**3. Post-scan synthesis** (`llm/post_scan_synthesizer.py`)
- Single combined LLM call after correlation completes
- Receives up to 50 findings (compressed; skips call if ≤ 2 findings)
- Outputs three things in one JSON response:
  - **Attack chains**: grouped finding IDs with severity + narrative
  - **False positive flags**: findings that are probably FPs (whitebox mode only, probable-confidence only)
  - **Executive summary**: 60-word plain-English summary of results
- Stored in `scan.attack_chains`, `scan.llm_summary`, and individual finding flags

**4. Per-finding AI chat** (`api/findings.py`)
- User asks natural-language questions about a specific finding
- Backend builds a context prompt: title, vulnerability type, severity, endpoint, CWE, code snippet
- LLM returns an answer (stateless — conversation history managed by frontend, max 4 messages / 2 exchanges)
- Parsed from `answer` or `text` field in LLM JSON response

### LLM Client (`llm/client.py`)

- Unified async client supporting all providers (Anthropic SDK, OpenAI-compatible REST, Google AI)
- Strict JSON response parsing with regex fallback (handles code-block-wrapped JSON)
- Up to 3 retries on transient failures
- Configurable timeout: 5–600 seconds
- OpenRouter fallback: if requested model returns 404, auto-retries with `openai/gpt-4o-mini`
- `verify()` method: fires a minimal test request to validate key + model before scan starts

---

## 7. Correlation Engine

**File:** `backend/app/correlation/correlation_engine.py`

The correlation engine links static findings (from TrustScan / DevSecOps import) with DAST findings (from ZAP / Nuclei) to assign confidence levels.

### Confidence Levels

| Level | Condition | Score |
|-------|-----------|-------|
| **Verified** | Strong static + DAST match | ≥ 70 points |
| **Probable** | One side confirmed or weak match | 30–69 points |
| **Observed** | DAST only, no static confirmation | < 30 points |

### Scoring Weights (`confidence_scorer.py`)

| Signal | Points |
|--------|--------|
| SAST finding match | 40 |
| DAST finding match | 40 |
| Same parameter | 10 |
| Same endpoint | 10 |
| CWE matches | 5 |
| Dangerous sink detected in file | 5 |

### Correlation Strategy

1. Group findings by canonical vulnerability type (40+ normalizations, e.g. `"sqli"` = `"sql_injection"` = `"sql-injection"`)
2. Build a file → endpoint index from routes discovered during source analysis
3. For each static finding: find DAST findings in the same vuln type bucket with matching endpoint/parameter
4. Score the match; assign confidence level
5. Deduplicate by finding hash before persisting

### Vulnerability Types Normalized

sqli, xss, cmdi, path_traversal, ssrf, idor, auth, mass_assignment, weak_crypto, cors, brute_force, open_redirect, lfi, rfi, xxe, ssti, deserialization, race_condition, business_logic, access_control, information_disclosure, dependency_cve, secret, and 20+ others.

### Role-Aware Correlation

When multiple auth roles are tested:
- `correlate_by_role([], dast_by_role)` groups DAST findings by auth role
- **IDOR detection**: same endpoint accessed by multiple roles → flag for privilege escalation
- **Auth logic**: role access differences → flag for broken access control

---

## 8. Source Analysis & Route Extraction

**Files:** `backend/app/analyzers/`

When a whitebox project has a `local_path` (source code cloned locally), the `source_analysis` phase runs before DAST:

| Analyzer | What it does |
|----------|-------------|
| `route_extractor.py` | Framework-specific parsers extract HTTP routes (path, method, handler, file, line) |
| `sink_detector.py` | Finds dangerous code patterns: SQL queries, OS commands, file writes, eval, deserialization |
| `auth_detector.py` | Detects login routes, credential patterns, session handling |

**Supported frameworks:** Django, Flask, FastAPI, Express.js, Next.js, Spring (Java), Ruby on Rails, Laravel (PHP)

If the framework is unknown, all parsers are tried and results merged.

Route data feeds into:
- ZAP scope (ensures the active scan covers discovered routes)
- Coverage tracking (which routes were tested vs. discovered)
- Correlation engine route index (file ↔ endpoint mapping for confidence scoring)

---

## 9. TrustScan Integration

**Files:** `backend/app/integrations/trustscan_client.py`, `backend/app/api/trustscan_connector.py`

TrustScan is an external security platform. TraceON can pull static findings from a TrustScan scan job and import them into a whitebox scan as the "importing" phase.

### OAuth Flow

```
User clicks "Connect TrustScan"
      ↓
POST /api/v1/trustscan/oauth/initiate
      → returns state token + authorize URL (5-minute TTL)
      ↓
User completes OAuth on TrustScan platform
      ↓
GET /trustscan/oauth/callback?code=...&state=...
      → token exchange; token stored in-memory
      ↓
Frontend polls GET /trustscan/oauth/status/{state}
      → returns token when complete
      ↓
User selects a TrustScan job from the list
```

### Project-Level Connection

Once connected, the encrypted PAT is stored in `Project.trustscan_token_encrypted` (Fernet encrypted). During a whitebox scan's `importing` phase:
1. Decrypts the PAT
2. Calls `TrustScanClient.get_findings(job_id)` → fetches normalized findings
3. Optionally calls `download_source(job_id)` → streams source ZIP, extracts to `{PROJECTS_DIR}/{project_id}/source/`
4. Creates Finding records in the DB with `scanner_source="trustscan"`

### Finding Normalization

TrustScan v2.0 `NormalizedFinding` → TraceON v1.0:

| TrustScan field | TraceON field | Transformation |
|----------------|--------------|----------------|
| `severity` | `severity` | lowercase |
| `confidence` | `confidence` | lowercase |
| `cwe` | `cwe` | ensures `"CWE-"` prefix |
| `vuln_type: "SAST"` | `vulnerability_type` | → `"unknown"` |
| `vuln_type: "SCA"` | `vulnerability_type` | → `"dependency_cve"` |
| `vuln_type: "SECRET"` | `vulnerability_type` | → `"secret"` |

---

## 10. Authentication & Multi-User

**Files:** `backend/app/core/auth.py`, `backend/app/models/user.py`, `backend/app/api/users.py`

### API Key Authentication

All API endpoints require the `X-API-Key` header. Flow:
1. Extract key from header
2. SHA-256 hash it
3. Query `users.api_key_hash` for a match
4. Verify `is_active = True`
5. Return the `User` object (or raise HTTP 401)

Raw keys are **never stored** — only their SHA-256 hash. The raw key is shown exactly once at user creation and cannot be retrieved again.

### User Model

| Field | Type | Description |
|-------|------|-------------|
| `id` | UUID | Primary key |
| `api_key_hash` | string | SHA-256 of the raw API key (indexed, unique) |
| `label` | string (optional) | Friendly name for the key/user |
| `is_active` | bool | If false, key is revoked |
| `is_admin` | bool | Admin flag — allows user management and cross-user data access |
| `created_at` | datetime | UTC creation timestamp |

### Multi-User Data Isolation

- **Projects**: `owner_id` field — non-admin users only see projects they created
- **LLM credentials**: `LLMProviderCredential.user_id` — each user's LLM API keys are stored separately
- **Admin bypass**: `is_admin=True` grants access to all projects and user management endpoints

### User Management API (admin-only)

| Endpoint | Action |
|----------|--------|
| `POST /api/v1/users/admin/users` | Create new user — returns raw key ONCE |
| `GET /api/v1/users/admin/users` | List all users (paginated) |
| `DELETE /api/v1/users/admin/users/{id}` | Deactivate user (revokes API access) |

### Admin API Key Bootstrap

On first startup, if `API_KEY` env var is set, the backend seeds an admin user with that key (persisted to `/data/db/.api_key`). This key survives container restarts.

---

## 11. Security Measures

### Encryption at Rest

Sensitive tokens (GitHub tokens, TrustScan PATs, LLM API keys) are encrypted before storage using **Fernet** (symmetric AES-128-CBC) via `encrypt_token()` / `decrypt_token()` in `core/security.py`.

The `ENCRYPTION_KEY` is:
1. Auto-generated on first startup if not set
2. Persisted to `/data/db/.encryption_key` (separate file from the DB)
3. If the DB is ever compromised, encrypted secrets remain protected as long as the key file is kept separate

### Rate Limiting

**File:** `backend/app/core/rate_limit.py`

- Algorithm: in-memory sliding window
- Limit: 300 requests per IP per minute (configurable)
- Background cleanup task runs every 300 seconds — removes entries older than 2 minutes
- **Localhost/private IP bypass**: requests from `127.x.x.x`, `10.x.x.x`, `192.168.x.x`, `::1` skip rate limiting (development / internal use)
- **Limitation**: in-memory only. Does not scale across multiple workers or machines. Use a Redis-backed limiter for production multi-worker setups.

### WebSocket Tokens

One-time tokens for WebSocket connections are:
- HMAC-SHA256 signed with a server secret
- 2-minute TTL
- Single use (invalidated after first connection)
- Issued via `POST /api/v1/auth/ws-token`

### Security Headers

Applied to all HTTP responses:
- `Content-Security-Policy` (custom policy)
- `Strict-Transport-Security` (HTTPS deployments only)
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`

### Input Validation

- All API inputs validated by Pydantic models at API boundary
- Path traversal guard on report downloads: filename validated against `^[a-zA-Z0-9_-]+$`
- SQL injection prevention: SQLAlchemy ORM parameterization throughout (no raw string queries)
- CORS allowlist: default `localhost:5173`, `localhost:3000` (configurable via env)

---

## 12. API Endpoints

### Projects (`/api/v1/projects`)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/projects` | List all projects for current user (admin sees all) |
| POST | `/projects` | Create project (name, target URL, scan mode, auth config, GitHub token) |
| GET | `/projects/{id}` | Fetch project details |
| PUT | `/projects/{id}` | Update project config |
| DELETE | `/projects/{id}` | Archive/delete project |
| POST | `/projects/{id}/artifacts` | Upload OpenAPI spec, Postman collection, or journey replay file |

### Scans (`/api/v1/scans`)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/scans` | Start a new scan (modules, scan goals, scan config, auth config) |
| GET | `/scans` | List scans (paginated; filter by status, project_id) |
| GET | `/scans/{id}` | Fetch scan details (progress, current phase, results summary) |
| POST | `/scans/{id}/cancel` | Cancel in-progress scan |
| POST | `/scans/{id}/upload-findings` | Upload external findings JSON (DevSecOps / SARIF) |
| GET | `/dashboard/stats` | Aggregate stats: total projects, scans, findings by severity |
| POST | `/auth/ws-token` | Issue one-time signed WebSocket token |

### Findings (`/api/v1/findings`)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/findings` | List findings (8 filter dimensions, pagination, sort) |
| GET | `/findings/summary` | Aggregated counts by severity, confidence, status |
| GET | `/findings/{id}` | Full finding details including repro bundle |
| PUT | `/findings/{id}` | Update status (open/confirmed/false_positive/resolved) or notes |
| POST | `/findings/{id}/generate-fix` | Auto-generate code fix (LLM or template strategy) |
| POST | `/findings/{id}/create-pr` | Open GitHub pull request with the generated fix |
| POST | `/findings/{id}/chat` | Ask the LLM a question about the finding |

**Finding filters:** scan_id, project_id, severity, confidence, vulnerability_type, scanner_source, status, search (title/endpoint/file_path)

**Finding sort options:** severity (critical→info), confidence, endpoint, title, CWE, file_path, vulnerability_type, status, created_at

### Reports (`/api/v1/reports`)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/reports` | Generate report (format: html, pdf, sarif, json) |
| GET | `/reports/{scan_id}/download?format=html` | Download generated report file |
| GET | `/reports/{scan_id}/preview` | In-browser preview (scan + findings data as JSON) |
| POST | `/reports/{scan_id}/compliance` | LLM-powered compliance mapping (PCI-DSS, GDPR, HIPAA) |

### LLM Providers (`/api/v1/llm/providers`)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/llm/providers` | List supported providers + connection status |
| GET | `/llm/providers/{provider}/models` | List available models for a provider |
| POST | `/llm/providers/{provider}/verify` | Test API key validity |
| POST | `/llm/providers/{provider}/set-default` | Save provider + model as default for current user |

### Users (`/api/v1/users`)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/users/me` | Current user profile |
| POST | `/users/admin/users` | Create new user (admin-only) |
| GET | `/users/admin/users` | List all users (admin-only) |
| DELETE | `/users/admin/users/{id}` | Deactivate user (admin-only) |

### TrustScan (`/api/v1/trustscan`)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/trustscan/oauth/initiate` | Start OAuth flow → state token + authorize URL |
| GET | `/trustscan/oauth/callback` | Token exchange callback |
| GET | `/trustscan/oauth/status/{state}` | Poll OAuth completion status |
| GET | `/trustscan/oauth/jobs` | List TrustScan jobs using temporary OAuth token |
| GET | `/trustscan/projects/{id}/jobs` | List jobs for a connected project |
| POST | `/trustscan/projects/{id}/import` | Import TrustScan job findings + optional source ZIP |
| DELETE | `/trustscan/projects/{id}/connect` | Revoke TrustScan connection |

### WebSocket

| Path | Description |
|------|-------------|
| `WS /ws/scan/{scan_id}?token=...` | Real-time scan progress, log lines, findings |
| `WS /ws/dashboard?token=...` | Dashboard-level updates across browser tabs |

---

## 13. Database Models

### User

| Field | Type | Description |
|-------|------|-------------|
| id | UUID | Primary key |
| api_key_hash | string | SHA-256 of API key |
| label | string | Optional friendly name |
| is_active | bool | Revocable access flag |
| is_admin | bool | Admin privileges |
| created_at | datetime | UTC timestamp |

### Project

Key fields (58+ total in the ORM model):

| Field | Description |
|-------|-------------|
| id, owner_id | UUID; links to User |
| name, description | Display info |
| target_url | Live application URL (required for DAST) |
| scan_mode | whitebox / blackbox / hybrid |
| source_type | zip / git / local |
| local_path, git_url, git_branch | Source location |
| github_token_encrypted | Encrypted GitHub PAT (for source clone + PR creation) |
| auth_config | JSON: login method, credentials, role profiles |
| trustscan_url, trustscan_job_id, trustscan_token_encrypted | TrustScan integration |
| llm_provider, llm_model, llm_api_key_encrypted | Project-level LLM override |

### Scan

| Field | Description |
|-------|-------------|
| id, project_id | UUIDs |
| status | pending / running / completed / failed / cancelled |
| scan_type | full / dast_only |
| scan_mode | whitebox / blackbox / hybrid |
| progress | 0–100 integer |
| current_phase | active phase name |
| modules_enabled | JSON: `{dast, nuclei, coverage, url_discovery, …}` |
| source_available | bool: whether local source code is present |
| results_summary | JSON: counts by severity/confidence |
| routes_discovered | int |
| coverage_percentage | int (0–100) |
| llm_status | pending / skipped / ok / failed |
| llm_summary | 60-word executive summary |
| attack_chains | JSON array of chained findings |
| plan_result | JSON: LLM pre-scan plan (focus_areas, skip_hint, risk_hypothesis) |
| plan_intent | JSON: compiled goals intent from scan goals |
| detected_stack | JSON: framework, server, language (from fingerprinting) |
| log, error_message | Text fields for scan log and error detail |

### Finding

58+ fields covering:

| Category | Fields |
|----------|--------|
| Identity | id, scan_id, title, vulnerability_type |
| Risk | severity (critical/high/medium/low/info), confidence (verified/probable/observed), risk_score, risk_level |
| Location | endpoint, http_method, parameter, response_code |
| Static context | file_path, line_number, code_snippet, data_flow, cwe, owasp_category |
| Dynamic evidence | payload, response_evidence (HTML excerpt) |
| Auth tracking | auth_role (admin/user/guest), journey_source |
| Scanner | scanner_source, scanner_rule_id, raw_scanner_output (JSON) |
| Status | status (open/confirmed/false_positive/resolved/duplicate), notes |
| Fix | fix_available, fix_pr_url, fix_applied |
| LLM | llm_false_positive_flag, remediation_text |
| Workflow | workflow_graph_id, workflow_step_id, repro_bundle (JSON) |

### LLMProviderCredential

| Field | Description |
|-------|-------------|
| id | UUID |
| user_id | FK to User (per-user scoping) |
| provider | anthropic / openai / openrouter / google / github |
| encrypted_token | Fernet-encrypted API key |
| default_model | Model name string |
| token_expiry | Optional expiry (for OAuth-based providers) |

### ProjectArtifact

Tracks uploaded OpenAPI specs, Postman collections, and journey replay files per project, with filename, content type, and upload timestamp.

### WorkflowGraph / WorkflowStep

DAG (directed acyclic graph) representation of business logic workflows:
- **WorkflowGraph**: named graph with nodes and edges, attack point markers
- **WorkflowStep**: individual step (API call + parameters) within a graph
- Used to target specific business processes during the active scan

---

## 14. Frontend Pages

The frontend is a React + TypeScript SPA (Vite build). All pages are lazy-loaded via React `Suspense`. The `ApiKeyGate` component blocks all page access until an API key is stored in `localStorage`.

### Navigation Structure

**Main:**
- Dashboard (`/`)
- Projects (`/projects`)
- Findings (`/findings`)
- Reports (`/reports`)

**Tools:**
- Scan Monitor (`/scans`)
- Coverage (`/coverage`)
- LLM Config (`/tools/llm`)

### Page Details

**Dashboard (`/`)**
- Stats panel: total projects, total scans, finding counts by severity (critical / high / medium / low)
- Recent scans table: project name, scan type, status badge, progress bar, verified finding count, routes discovered, start time
- Quick-action buttons: New Project, View All Scans

**Projects (`/projects`)**
- Grid of project cards: name, description, language, framework, created date, GitHub repo link
- Create Project modal:
  - Scan mode selector (White-box / Black-box)
  - Project name, description, target URL
  - TrustScan OAuth button → job selector (if connected)
  - Auth config: Basic Auth, Form Login URL + credentials, or Playwright script; multi-role support
  - DevSecOps findings upload (for whitebox without TrustScan)
- Per-card actions: Start Scan, Set GitHub Token, Delete

**Configure Scan (`/projects/:id/scan`)**
- **Scan Modules**: toggles for DAST, Coverage, Nuclei, URL Discovery, Path Fuzzing, Server Audit
- **Whitebox info badge**: explains that static findings come from TrustScan / DevSecOps (not internal tools)
- **LLM Planner**: optional enable switch + provider/model selector (lists connected providers)
- **Scan Profile**: Balanced, API, SPA, Auth-Heavy (applies preset defaults)
- **Scan Goals**: natural-language textarea (one goal per line)
- **Scan Depth** (1–20), **Timeout** (60–7200s), context-aware payloads toggle
- **Advanced** (collapsible): max URLs per page, AJAX spider, in-scope-only, OpenAPI spec paths, Postman collection, journey replay files

**Scan Monitor (`/scans`)**
- Paginated table of scans (20 per page)
- Filter by status (all / pending / running / completed / failed / cancelled)
- Columns: project name, scan type, status badge, progress bar, finding count, routes, start time
- Mobile responsive: card layout on small screens

**Scan Progress (`/scans/:id`)**
- Real-time WebSocket connection (HMAC-signed one-time token)
- Phase indicator with progress bar
- Live log viewer (streaming scan log lines)
- Finding count as findings arrive

**Findings (`/findings`)**
- Paginated findings table (20 per page, up to 1000 per page)
- 8 filter dimensions: scan, severity, confidence, vulnerability type, scanner source, status, search text
- Summary panel: totals by severity, confidence, status
- Click row → Finding Detail page

**Finding Detail (`/findings/:id`)**
- Multi-tab layout:
  - **Details**: full vulnerability info (endpoint, method, parameter, CWE, OWASP, scanner)
  - **Evidence**: payload, response excerpt, code snippet, data flow
  - **Remediation**: LLM-generated or template fix text
  - **AI Chat**: ask follow-up questions about the finding (LLM-powered, 2-exchange max)
  - **Generate Fix**: auto-generate a code fix (LLM or template); optionally open a GitHub PR

**Coverage (`/coverage`)**
- Scan selector (any completed scan)
- Coverage stats: total routes, routes tested, coverage percentage
- Route table: method, path, handler, tested (bool), finding count
- Risk level per route: high (3+ findings), medium (1–2), low (0)
- **Smart fallback**: if no routes from static analysis, reconstructs route list from DAST findings (endpoint + http_method → unique routes)

**Reports (`/reports`)**
- Scan selector (completed scans only)
- Format buttons: HTML (interactive), PDF (print-ready), SARIF (standard), JSON (raw)
- Report preview: severity/confidence breakdown before generating
- Generate → Download flow
- Optional compliance mapping: select PCI-DSS, GDPR, HIPAA → LLM maps findings to clauses

**LLM Config (`/tools/llm`)**
- List of supported providers with connection status (connected / disconnected)
- Connect: paste API key, select default model (fetched from provider API)
- Disconnect: revokes stored key (env key unaffected)
- Per-user — each user manages their own LLM credentials

### App Shell Features

- Dark/light theme toggle (default: dark glassmorphism; persisted in `localStorage` as `dt_theme`)
- Mobile sidebar with hamburger button and backdrop overlay
- Custom TraceON brand mark SVG (a trace routed through a node)
- `ApiKeyGate`: intercepts all routes until `dt_api_key` is set in `localStorage`; prompts user to paste their API key on first visit

---

## 15. Report Generation

**Files:** `backend/app/reports/`

| Format | File | Description |
|--------|------|-------------|
| HTML | `html_report.py` | Interactive browser report with severity charts, finding tables, expandable details |
| PDF | `pdf_report.py` | Print-ready PDF version of the HTML report |
| SARIF | `sarif_export.py` | SARIF 2.1 standard format for CI/CD integration (GitHub Advanced Security, etc.) |
| JSON | inline in `reports.py` | Raw dict: scan metadata + project + all findings |

Reports are written to `{REPORTS_DIR}/{scan_id}/report.{ext}` on disk and served via `FileResponse`.

### Compliance Report

`POST /api/v1/reports/{scan_id}/compliance` accepts a list of standards (default: pci-dss, gdpr, hipaa). The LLM maps each finding to relevant clauses and returns:
- `mappings[]`: finding_id + matched clause + rationale
- `summary`: counts per standard of compliant / non-compliant areas

---

## 16. Coverage Tracking

Coverage measures how many discovered routes were actively tested during the scan.

**Data flow:**
1. Source analysis (whitebox) extracts routes from code → stored in orchestrator `self.routes`
2. Blackbox recon (gau / ffuf / spider) discovers URLs → appended to `self.routes`
3. At scan end, `routes_discovered` and `coverage_percentage` are written to the `Scan` record
4. Frontend queries `GET /scans/{id}/routes` for the route list

**Smart fallback (frontend `Coverage.tsx`):**
If the scan has no stored routes (e.g., coverage module was disabled), the Coverage page reconstructs a route list from the findings themselves:
- Each finding's `endpoint` + `http_method` → unique route entry
- `finding_count` per route used for risk level (high ≥ 3, medium 1–2, low 0)
- `tested = True` for any route with at least one finding

---

## 17. Configuration Reference

### Environment Variables

**Application**

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_NAME` | TraceON | Application display name |
| `APP_VERSION` | 1.0.0 | Version string |
| `DEBUG` | false | Enable debug mode |
| `HOST` | 0.0.0.0 | Bind address |
| `PORT` | 8000 | Listen port |

**Database**

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `sqlite+aiosqlite:///data/db/app.db` | SQLAlchemy async DB URL |

**ZAP**

| Variable | Default | Description |
|----------|---------|-------------|
| `ZAP_API_URL` | `http://zap:8080` | ZAP API base URL (inter-container) |
| `ZAP_API_KEY` | (set in compose) | ZAP API key |

**DAST Timeouts**

| Variable | Default | Description |
|----------|---------|-------------|
| `DAST_BASE_TIMEOUT` | 2400s | Base ZAP active scan timeout |
| `DAST_ABSOLUTE_MAX_TIMEOUT` | varies | Hard cap on total DAST time |
| `DAST_STALL_TIMEOUT` | 120s | Kill ZAP phase if no progress for this many seconds |

**LLM**

| Variable | Default | Description |
|----------|---------|-------------|
| `LLM_ENABLED` | false | Global LLM enable switch |
| `LLM_PROVIDER` | — | Default provider (anthropic / openai / openrouter / google / github) |
| `LLM_MODEL` | — | Default model name |
| `ANTHROPIC_API_KEY` | — | Anthropic API key (env fallback) |
| `OPENAI_API_KEY` | — | OpenAI API key (env fallback) |
| `OPENROUTER_API_KEY` | — | OpenRouter API key (env fallback) |
| `GOOGLE_API_KEY` | — | Google AI API key (env fallback) |
| `COPILOT_API_KEY` | — | GitHub Copilot API key (env fallback) |

**Security**

| Variable | Default | Description |
|----------|---------|-------------|
| `API_KEY` | auto-generated | Initial admin API key; persisted to `/data/db/.api_key` |
| `ENCRYPTION_KEY` | auto-generated | Fernet key for token encryption; persisted to `/data/db/.encryption_key` |
| `ENCRYPTION_SALT` | (optional) | Additional salt for key derivation |

**Integrations**

| Variable | Default | Description |
|----------|---------|-------------|
| `TRUSTSCAN_ENABLED` | false | Enable TrustScan integration routes |
| `TRUSTSCAN_PLATFORM_URL` | — | Base URL of the TrustScan platform |
| `GITNEXUS_ENABLED` | false | Enable GitNexus MCP integration (flow confirmation) |
| `GITNEXUS_MCP_URL` | — | GitNexus MCP endpoint |
| `GAU_ENABLED` | true | Enable gau URL discovery phase |
| `FFUF_ENABLED` | true | Enable ffuf path fuzzing phase |
| `INCLUDE_PLAYWRIGHT` | false | Include Playwright browser bundle in Docker build |

**CloudGuard (CP) Integration**

| Variable | Description |
|----------|-------------|
| `CP_SHARED_SECRET` | HMAC secret for CP scan dispatch authentication |
| `CP_APP_LAUNCH_URL` | SSO entry URL the CP redirects users to for embedded-app launch |
| `CP_SCANNER_KEY` | Unique scanner identifier (`^[a-z][a-z0-9_]*$`) |
| `CP_SCANNER_NAME` | Human-readable scanner name shown in CP UI |

---

*This report was generated from the actual codebase. All described behavior reflects what is implemented in the code, not intended or planned functionality.*
