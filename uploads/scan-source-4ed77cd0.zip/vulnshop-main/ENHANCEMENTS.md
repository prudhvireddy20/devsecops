# VulnShop Enhanced: 30+ Vulnerabilities for TraceON Testing

This document outlines all enhancements made to VulnShop to maximize TraceON detection results.

## Overview

**Original VulnShop**: 15 vulnerabilities  
**Enhanced VulnShop**: 30+ vulnerabilities  
**Focus**: Maximizing detection across TraceON's 20+ vulnerability type categories

---

## New Vulnerabilities Added (15+)

### 1. API User Listing with SQL Injection
**Endpoint**: `GET /api/users`  
**Vulnerability Type**: SQL Injection (sqli)  
**Parameters**: `username`, `type`  
**Detection**: DAST (SQLMap, ZAP) + SAST matching  
**Payload**: `http://127.0.0.1:5000/api/users?username=' OR '1'='1`  
**TraceON Will Detect**: ✓ SQLi on username parameter  

---

### 2. User Profile IDOR
**Endpoint**: `GET /api/user/<user_id>`  
**Vulnerability Type**: IDOR (idor)  
**Detection**: DAST (ZAP response analysis)  
**Test Cases**: `/api/user/1`, `/api/user/2`, `/api/user/999`  
**TraceON Will Detect**: ✓ IDOR - returns any user profile  

---

### 3. Server-Side Request Forgery (SSRF)
**Endpoint**: `POST /api/fetch`  
**Vulnerability Type**: SSRF (ssrf)  
**Parameters**: `url` (JSON or form)  
**Detection**: DAST (Nuclei, ZAP)  
**Payload**: `http://127.0.0.1:5000/admin`, `http://localhost/`, `file:///etc/passwd`  
**TraceON Will Detect**: ✓ SSRF - can reach internal endpoints  

---

### 4. LDAP Injection
**Endpoint**: `POST /api/ldap-search`  
**Vulnerability Type**: LDAP Injection  
**Parameters**: `username` (JSON or form)  
**Detection**: DAST (Wapiti, manual testing)  
**Payload**: `admin*`, `*)(&`, `*))(&(mail=*`  
**TraceON Will Detect**: ✓ LDAP injection detection  

---

### 5. JWT Algorithm Downgrade Attack
**Endpoint**: `POST /api/generate-token` + `POST /api/verify-token`  
**Vulnerability Type**: Authentication bypass, weak crypto  
**Parameters**: `username`, `is_admin`  
**Weakness**: 
- Hardcoded weak secret: `jwt-secret-key-hardcoded`
- Accepts 'none' algorithm in verify endpoint
- No key rotation  
**Detection**: DAST (ZAP, Dalfox) + SAST (hardcoded secret)  
**TraceON Will Detect**: ✓ Weak JWT configuration  

---

### 6. Mass Assignment (Privilege Escalation)
**Endpoint**: `POST /api/register`  
**Vulnerability Type**: Mass Assignment (mass_assignment), broken access control  
**Parameters**: JSON body with `is_admin`, `username`, `password`, `email`  
**Risk**: User can register with `is_admin=true`  
**Detection**: DAST (ZAP parameter fuzzing), SAST (parameter binding)  
**TraceON Will Detect**: ✓ Unvalidated user input to privileged fields  

---

### 7. Weak API Key Authentication
**Endpoint**: `POST /api/login-api`  
**Vulnerability Type**: Weak authentication, hardcoded secrets  
**Parameters**: `api_key`, `username`, `password`  
**Hardcoded Keys**:
- `sk-1234567890abcdef`
- `sk-0987654321fedcba`
- `super-secret-api-key-2024`  
**Detection**: DAST (brute force patterns), SAST (secret scanning)  
**TraceON Will Detect**: ✓ Hardcoded API keys + weak credentials  

---

### 8. Insecure Deserialization (Pickle)
**Endpoint**: `POST /api/deserialize`  
**Vulnerability Type**: Deserialization (dangerous: allows RCE)  
**Parameters**: `data` (base64-encoded pickle object)  
**Risk**: Remote code execution  
**Detection**: SAST (pickle.loads() detection)  
**TraceON Will Detect**: ✓ Insecure deserialization pattern  

---

### 9. Weak Cryptography (MD5/SHA1)
**Endpoint**: `POST /api/hash`  
**Vulnerability Type**: Weak cryptography (weak_crypto)  
**Parameters**: `password`  
**Issue**: Demonstrates MD5 and SHA1 hashing (broken)  
**Detection**: SAST (uses weak hash algorithms) + Manual review  
**TraceON Will Detect**: ✓ Weak hashing algorithms  

---

### 10. Predictable Random Tokens
**Endpoint**: `POST /api/reset-password`  
**Vulnerability Type**: Weak randomness, predictable tokens  
**Parameters**: `email`  
**Risk**: Reset tokens are 4-digit numbers (10,000 possibilities - easily brute-forced)  
**Detection**: Logic analysis, fuzzing  
**TraceON Will Detect**: ✓ Weak token generation  

---

### 11. Directory Listing / Information Disclosure
**Endpoint**: `GET /api/files`  
**Vulnerability Type**: Information disclosure, directory listing  
**Parameters**: `dir` (path traversal in parameter)  
**Risk**: Lists directory contents; vulnerable to path traversal  
**Detection**: DAST (ZAP, ffuf)  
**TraceON Will Detect**: ✓ Directory traversal + info disclosure  

---

### 12. Stored XSS (Comments)
**Endpoint**: `GET/POST /api/comments`  
**Vulnerability Type**: Stored XSS (xss)  
**Parameters**: `comment`  
**Risk**: Payload stored and reflected without sanitization  
**Detection**: DAST (Dalfox, ZAP XSS scanner)  
**TraceON Will Detect**: ✓ Stored XSS detection  

---

### 13. Debug Information Disclosure
**Endpoint**: `GET /api/debug`  
**Vulnerability Type**: Information disclosure (info_disclosure)  
**Exposes**:
- `SECRET_KEY`
- `JWT_SECRET`
- `API_KEYS` dictionary
- Database paths
- Full environment variables  
**Detection**: DAST (endpoint analysis) + SAST (secret scanning)  
**TraceON Will Detect**: ✓ Multiple secrets exposed + config disclosure  

---

### 14. Arbitrary File Upload (No Validation)
**Endpoint**: `POST /api/file-upload`  
**Vulnerability Type**: Unrestricted file upload  
**Parameters**: `file` (multipart form), `filename`  
**Risk**: 
- No file type validation
- No extension filtering
- Can upload shell scripts  
**Detection**: DAST (ZAP file upload testing)  
**TraceON Will Detect**: ✓ Arbitrary file upload  

---

### 15. Open Proxy / Request Forwarding
**Endpoint**: `POST /api/proxy`  
**Vulnerability Type**: SSRF variant, open proxy  
**Parameters**: `url`, `method` (GET/POST), `headers`, `body`  
**Risk**: Can forward requests to any target, bypassing firewalls  
**Detection**: DAST (Nuclei open proxy detection)  
**TraceON Will Detect**: ✓ Open proxy behavior  

---

### 16. Direct SQL Execution
**Endpoint**: `POST /api/sql-exec`  
**Vulnerability Type**: SQL Injection, critical  
**Parameters**: `sql` (raw SQL query)  
**Risk**: Arbitrary SQL execution with no validation  
**Detection**: DAST (SQLMap, ZAP) + SAST  
**TraceON Will Detect**: ✓ Critical SQL execution endpoint  

---

### 17. Code Evaluation (Python eval())
**Endpoint**: `POST /api/eval`  
**Vulnerability Type**: Code injection (eval), RCE  
**Parameters**: `code` (Python expression)  
**Risk**: Remote code execution via eval()  
**Detection**: SAST (dangerous function call), DAST  
**TraceON Will Detect**: ✓ eval() RCE pattern  

---

### 18. Advanced SQL Injection (Multiple Parameters)
**Endpoint**: `POST /api/search-advanced`  
**Vulnerability Type**: SQL Injection (sqli)  
**Parameters**: 
- `query` (vulnerable)
- `filter` (column name injection)
- `sort` (ORDER BY injection)  
**Risk**: Multiple injection points in single endpoint  
**Detection**: DAST (SQLMap with multiple parameter testing)  
**TraceON Will Detect**: ✓ SQL injection with parameter depth  

---

### 19. Enhanced XXE Detection
**Endpoint**: `POST /api/xxe`  
**Vulnerability Type**: XXE (xml_bomb, entity_expansion)  
**Notes**: Existing `/api/import` endpoint also present  
**Detection**: DAST (Wapiti XXE module), SAST  
**TraceON Will Detect**: ✓ XXE via multiple methods  

---

## Security Header & CORS Issues (5+)

### CORS Misconfiguration
**Issue**: `Access-Control-Allow-Origin: *` with `Access-Control-Allow-Credentials: true`  
**Header**: All responses include open CORS  
**Detection**: DAST (ZAP CORS check)  
**TraceON Will Detect**: ✓ CORS misconfiguration (cors)  

### Missing Security Headers
**Missing Headers**:
- `Content-Security-Policy` (missing)
- `X-Frame-Options` (missing)
- `X-Content-Type-Options` (missing)
- `Strict-Transport-Security` (missing)  
**Detection**: DAST (Nikto, ZAP)  
**TraceON Will Detect**: ✓ Missing security headers (header)  

### Insecure Cookie Configuration
**Header**: `Set-Cookie: session_id=abc123def456; Path=/; SameSite=None`  
**Issues**:
- No `Secure` flag (sent over HTTP)
- No `HttpOnly` flag (accessible to JavaScript)
- `SameSite=None` with no Secure flag  
**Detection**: DAST (cookie analyzer)  
**TraceON Will Detect**: ✓ Insecure cookie (cookie)  

### Server Information Disclosure
**Headers Added**:
- `Server: VulnShop/1.0.0 (Flask 3.0.3)`
- `X-Powered-By: Python Flask`  
**Detection**: Nikto, banner grabbing  
**TraceON Will Detect**: ✓ Server version disclosure  

---

## Configuration Vulnerabilities (Existing + Enhanced)

### Plaintext Passwords
**Status**: Still present  
**Database**: Users table stores passwords as plaintext  
**Detection**: SAST (database schema review)  

### Hardcoded Secrets (Now 5+)
**New Secrets**:
1. `dev-secret-key-change-in-production` (Flask)
2. `jwt-secret-key-hardcoded` (JWT)
3. `sk-1234567890abcdef` (API Key)
4. `sk-0987654321fedcba` (API Key)
5. `super-secret-api-key-2024` (API Key)  
**Detection**: SAST (secret scanning), DAST (endpoint disclosure via `/api/debug`)  
**TraceON Will Detect**: ✓ Multiple hardcoded secrets  

---

## TraceON Detection Mapping

### Vulnerability Types Detected (by TraceON modules):

| Category | Vulnerabilities | Detection Method |
|----------|-----------------|-----------------|
| **Injection** | SQLi, Command, LDAP, XXE | ZAP, SQLMap, Wapiti, Dalfox |
| **XSS** | Reflected, Stored | Dalfox, ZAP, Nuclei |
| **SSRF** | URL fetching, proxy | Nuclei, ZAP, manual |
| **IDOR** | User/order access | ZAP auth matrix, manual |
| **Auth** | JWT downgrade, weak API keys | ZAP, SAST secret scanning |
| **Mass Assignment** | Parameter pollution | ZAP fuzzing |
| **Deserialization** | Pickle unsafe loading | SAST pattern matching |
| **Crypto** | MD5, SHA1, hardcoded secrets | SAST, Nikto |
| **CORS** | Open origin with credentials | ZAP CORS check |
| **Headers** | Missing CSP, HSTS, etc. | Nikto, ZAP |
| **Cookies** | No Secure/HttpOnly/SameSite | ZAP cookie analyzer |
| **Info Disclosure** | Debug endpoint, directory listing | ZAP, ffuf, manual |

---

## Expected TraceON Scan Results

### Baseline (Original VulnShop):
- **High Severity**: 5-7
- **Medium Severity**: 4-6
- **Low Severity**: 2-3
- **Total Findings**: 11-16

### Enhanced VulnShop:
- **Critical**: 4-5 (RCE endpoints)
- **High**: 10-15 (SSRF, SQLi, XXE, IDOR)
- **Medium**: 8-12 (XSS, LDAP, weak crypto, headers)
- **Low**: 5-8 (info disclosure, banner)
- **Total Findings**: 35-50+

### Confidence Levels Expected:
- **Verified** (SAST + DAST): 20-25 findings
- **Probable** (SAST only): 8-12 findings  
- **Observed** (DAST only): 8-15 findings

---

## Testing Checklist for TraceON

### Phase 1: Endpoint Discovery
- [ ] ZAP traditional spider discovers all `/api/*` endpoints
- [ ] ffuf fuzzing finds `/api/debug`, `/api/files`, hidden paths
- [ ] OpenAPI spec parsing (if implemented) shows all routes

### Phase 2: Parameter Analysis
- [ ] SQLi parameters identified on all `/api/*` endpoints
- [ ] URL parameters analyzed (fetch, proxy, redirect)
- [ ] JSON body parameters fuzzing (mass assignment, eval)
- [ ] File upload parameter detection

### Phase 3: Injection Testing
- [ ] SQLi payloads tested on `/api/users`, `/api/search-advanced`, `/api/sql-exec`
- [ ] XXE payloads tested on `/api/xxe`, `/api/import`
- [ ] LDAP payloads tested on `/api/ldap-search`
- [ ] Code injection on `/api/eval`

### Phase 4: Authentication Testing
- [ ] JWT algorithm downgrade attempted
- [ ] Weak API keys tested
- [ ] Mass assignment via `/api/register`
- [ ] IDOR on `/api/user/*` and `/api/orders/*`

### Phase 5: SSRF/File Access
- [ ] `/api/fetch` tested with internal URLs
- [ ] `/api/proxy` tested as open proxy
- [ ] `/api/files` tested for directory traversal
- [ ] File upload via `/api/file-upload`

### Phase 6: Header & Config Analysis
- [ ] CORS misconfiguration detected
- [ ] Missing security headers flagged
- [ ] Insecure cookies identified
- [ ] `/api/debug` information disclosure

---

## Running Enhanced VulnShop with TraceON

### 1. Start VulnShop
```bash
cd /home/cystar/analyser/vulnshop
docker-compose up -d
```

### 2. Verify it's running
```bash
curl http://127.0.0.1:5000/health
# Expected: {"status":"ok"}
```

### 3. Create TraceON Scan
```bash
curl -X POST http://localhost:8000/api/v1/scans \
  -H "X-API-Key: <api_key>" \
  -H "Content-Type: application/json" \
  -d '{
    "target_url": "http://vulnshop:5000",
    "scan_mode": "blackbox",
    "scan_type": "full",
    "modules_enabled": {
      "dast": true,
      "nuclei": true,
      "sqlmap": true,
      "dalfox": true,
      "wapiti": true,
      "feroxbuster": true,
      "path_fuzzing": true,
      "server_audit": true
    }
  }'
```

### 4. Monitor Scan Progress
```bash
# Watch WebSocket progress
websocat "ws://localhost:8000/ws/scan/<scan_id>?token=<token>"
```

### 5. Review Findings
- Navigate to TraceON UI at `http://localhost:8000`
- Filter by confidence: Verified, Probable, Observed
- Sort by severity: Critical, High, Medium, Low

---

## Comparison: Original vs. Enhanced

| Metric | Original | Enhanced |
|--------|----------|----------|
| Total Vulnerabilities | 15 | 30+ |
| SQL Injection Endpoints | 1 | 6+ |
| XSS Endpoints | 1 | 3+ |
| IDOR Endpoints | 1 | 2+ |
| SSRF/Proxy Endpoints | 0 | 2 |
| Code Injection | 1 | 3+ |
| API Endpoints | 2 | 18+ |
| Expected DAST Findings | 8-12 | 25-35 |
| Expected SAST Findings | 4-6 | 12-18 |
| TraceON "Verified" Results | 3-5 | 20-25 |

---

## Notes for Security Research

1. **Polyglot Parameters**: Many endpoints accept both JSON and form parameters, testing different parser paths
2. **Nested Injection**: Some endpoints chain vulnerabilities (e.g., file upload + path traversal)
3. **Multiple Detection Methods**: Each vuln can be detected via different tools (ZAP + SQLMap + manual)
4. **Realistic Patterns**: Vulnerabilities follow real-world code patterns from web app assessments
5. **Docker Integration**: Designed for TraceON's Docker Compose network; `vulnshop` service name used

---

## Maintenance

- Update Flask and dependencies regularly for realistic scanning
- Test with latest ZAP, SQLMap, Dalfox versions
- Periodically verify all endpoints are discoverable by DAST tools
- Keep security headers section intentionally vulnerable

---

Generated: 2024
For TraceON DAST Testing & Learning
