# VulnShop — Deliberately Vulnerable Target for TraceON

> ⚠️ **SAFETY FIRST** — This app contains **real RCE** (command injection + SSTI). It binds to `127.0.0.1:5000` only. **Never expose to the internet without a reverse proxy.** The database is re-seeded fresh on every container start, so every tester gets a clean lab.

---

## Quick Start (Local)

```bash
cd /home/cystar/analyser/vulnshop
docker compose up -d

# Verify health
curl -fsS http://127.0.0.1:5000/health
```

> Note: `docker compose` requires the Compose plugin; on older hosts use `docker-compose`.

## Fresh Lab State

Every time the container (re)starts, `entrypoint.sh`:
1. Deletes `/data/vulnshop.db`
2. Re-seeds users, products, and orders from `seed.py`
3. Starts the Flask app

So there is **no persistent volume** — any tester's modifications (registrations, uploaded files, XSS comments) are wiped on restart. To reset the lab: `docker restart vulnshop`. No `down -v` needed.

## Production Deployment (Dokploy / VPS with domain)

The compose file is Dokploy-ready. The app binds `127.0.0.1:5000` and expects the Dokploy reverse proxy (Caddy/Traefik) in front, terminating TLS and forwarding to `vulnshop:5000` (or `127.0.0.1:5000`).

### Option A — Dokploy Compose App (recommended)

1. In Dokploy, create a **Compose application** pointing at this repo (`main` branch).
2. Paste `docker-compose.yml` as the compose file.
3. Under **Advanced**, attach the app to the **Dokploy network** so the proxy can resolve `http://vulnshop:5000`:
   ```yaml
   networks:
     default:
       name: dokploy-network
       external: true
   ```
4. Add your **domain** (e.g. `vulnshop.yourlab.com`) and enable HTTPS.
5. Set the proxy forward URL to `http://vulnshop:5000`.
6. Deploy. Wait for health check to pass (green).

### Option B — Any VPS with a reverse proxy

```bash
# nginx site config example
server {
    listen 80;
    server_name vulnshop.yourlab.com;
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_read_timeout 60s;
    }
}
```

Then `docker compose up -d` on the server and point DNS at it. TLS via certbot/Let's Encrypt.

### Security notes for production

- Set `SECRET_KEY` in the compose `environment:` block to a random value.
- Do **not** open port 5000 to the internet — only the proxy talks to it.
- The app is intentionally full of RCE and data exposure. Keep it on a disposable VPS, not a production box.

---

## Target URL for TraceON

```
http://vulnshop:5000          # inside the Docker network (local demo)
https://vulnshop.yourlab.com  # production (behind the proxy)
```

Paste this into TraceON's **Target URL** field when creating a scan/project.

---

## Demo Scan Settings (Fast)

| Setting | Value |
|---------|-------|
| Profile | `blackbox` |
| Scan Depth | `3` |
| Max Children | `10` |
| Path Fuzzing | **Off** (turn on for `/backup.zip`, `/.env`) |
| Server Audit | **Off** (turn on for Nikto) |
| AJAX Spider | **Off** (default) |

These settings give a ~3-5 minute scan that reliably finds the demo vulns.

---

## Expected Findings (Auto-Detected)

| # | Vulnerability | Endpoint | Detected By |
|---|---------------|----------|-------------|
| 1 | SQL Injection | `GET /search?q=` | ZAP active, SQLMap |
| 2 | Reflected XSS + SSTI | `GET /greet?name=` | ZAP active, Dalfox |
| 3 | Command Injection | `GET /api/ping?host=` | ZAP active |
| 4 | Path Traversal | `GET /download?file=` | ZAP active |
| 5 | Open Redirect | `GET /redirect?url=` | ZAP active |
| 6 | Exposed `/.env` | `GET /.env` | Nuclei, ffuf, Nikto |
| 7 | Exposed `/backup.zip` | `GET /backup.zip` | ffuf, Feroxbuster, Nikto |
| 8 | Unauthenticated `/admin` | `GET /admin` | Nuclei, Nikto |
| 9 | Missing Security Headers | All responses | ZAP passive |
| 10 | Insecure Session Cookie | `POST /login` | ZAP passive |
| 11 | Stack Trace Disclosure | `GET /boom` | ZAP passive |

**Total: 11 findings** — well above the **>2** threshold for LLM synthesis.

---

## Manual Demo Endpoints (Not Auto-Detected)

| Vulnerability | Endpoint | Why Not Auto |
|---------------|----------|--------------|
| IDOR | `GET /api/orders/<id>` | Scanners can't infer ownership |
| XXE | `POST /api/import` (XML body) | ZAP spider doesn't POST XML |
| Hardcoded Secrets | `app.py` module scope | SAST, not DAST |
| Weak Credentials | `admin` / `admin123` | Payoff for SQLi demo |

---

## Quick Manual Verification

```bash
# SQL Injection
curl -s "http://127.0.0.1:5000/search?q=x'+OR+'1'='1"

# SSTI (renders 49)
curl -s "http://127.0.0.1:5000/greet?name={{7*7}}"

# Command Injection
curl -s "http://127.0.0.1:5000/api/ping?host=1;id"

# Path Traversal
curl -s "http://127.0.0.1:5000/download?file=../../etc/passwd"

# Missing Headers
curl -sI "http://127.0.0.1:5000/"
```

**From scanner containers (what actually matters):**
```bash
docker exec traceon-zap     curl -fsS http://vulnshop:5000/health
docker exec traceon-backend curl -fsS http://vulnshop:5000/health
```

---

## Discoverability (Why the Demo Works)

The home page (`/`) links **every** auto-detectable endpoint with a benign default parameter:

- `/search?q=shirt`
- `/greet?name=guest`
- `/api/ping?host=127.0.0.1`
- `/download?file=readme.txt`
- `/redirect?url=/`
- `/admin`
- `/login`
- `/boom`
- `/.env`
- `/backup.zip`

Plus:
- `robots.txt` with `Disallow: /admin, /backup.zip, /.env`
- `/sitemap` page linking everything

ZAP's standard spider (AJAX spider off by default) follows these links and fuzzes the parameters.

---

## Teardown

```bash
docker compose down
```

State is wiped on restart by design — no `-v` needed. To remove the image too: `docker compose down --rmi all`.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    docker network: app-network               │
├──────────────┬──────────────┬──────────────┬────────────────┤
│  traceon-    │  traceon-    │  traceon-    │  vulnshop      │
│  backend     │  zap         │  frontend    │  (this app)    │
│              │              │              │  :5000         │
└──────────────┴──────────────┴──────────────┴────────────────┘
```

- Local demo: VulnShop joins the **existing** TraceON network so ZAP can resolve `http://vulnshop:5000`
- Production: Dokploy proxy terminates TLS at the domain and forwards to `127.0.0.1:5000`
- Port `127.0.0.1:5000` on host for local browsing / proxy forwarding only
- No persistent data — every restart re-seeds a clean lab

---

## File Layout

```
/home/cystar/analyser/vulnshop/
├── app.py              # Flask app (all routes + vulns)
├── seed.py             # SQLite seeder
├── entrypoint.sh       # Reseeds fresh DB, then starts the app
├── requirements.txt    # flask, lxml, PyJWT, requests
├── Dockerfile          # python:3.12-slim + iputils-ping + curl
├── docker-compose.yml  # 127.0.0.1:5000, healthcheck, no volume
├── .dockerignore
├── templates/          # Jinja2 templates
├── static/             # vulnshop.css
├── files/              # readme.txt + backup.zip
└── README.md
```

## Solving the Labs

- [exercise.md](exercise.md) — lab exercises for testers (includes **Quest Mode**: 10 CTF flags)
- [solution.md](solution.md) — walkthrough / expected findings / **flag answers**
- [TESTING_NEW_ENDPOINTS.md](TESTING_NEW_ENDPOINTS.md) — curl recipes for every vulnerable endpoint

> Give testers the **public URL only** and let them work through `exercise.md` — the solutions stay private.

### Quest Mode (CTF)

The app ships with 10 `VULNSHOP{...}` flags hidden behind real vulnerabilities:

- Quest board with hints: `GET /flags`
- Submit a flag: `POST /api/submit-flag` `{"player":"name","flag":"VULNSHOP{...}"}`
- Standings: `GET /leaderboard` (HTML) or `GET /api/leaderboard` (JSON)

Flags and scores are stored in the lab DB, so `docker restart vulnshop` gives
every tester a fresh scoreboard. Flag values are in `flags_data.py` (repo) and
`solution.md` — keep both private.

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `vulnshop:5000` not reachable from ZAP | Confirm the container is on the same network: `docker network ls \| grep app-network` |
| Scan finds < 3 findings | Increase `scan_depth` to 5, ensure `max_children >= 10` |
| Path fuzzing misses `/.env` | Enable `path_fuzzing: true` in scan config |
| Proxy 502s in production | Proxy must reach `127.0.0.1:5000` (or use the dokploy network + `vulnshop:5000`) |
| Testers saw each other's data | Expected in a lab — restart to reseed: `docker restart vulnshop` |
| Container unhealthy | Check `docker logs vulnshop` — entrypoint reseeds, then app must bind `0.0.0.0:5000` |