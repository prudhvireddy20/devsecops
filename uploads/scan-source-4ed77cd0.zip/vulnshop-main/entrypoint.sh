#!/bin/sh
set -e

# Fresh lab state on every container start: drop the DB, reseed, then serve.
echo "[vulnshop] Resetting lab database..."
rm -f /data/vulnshop.db
python seed.py

exec python app.py
