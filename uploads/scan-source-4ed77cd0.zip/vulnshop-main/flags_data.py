"""VulnShop CTF quest data - single source of truth for seed.py and app.py.

Each quest flag must be obtained through the intended vulnerability -
none of them are visible without exploiting something.
"""

FLAGS = [
    {
        'slug': 'sql_secrets',
        'name': 'Secret Stash',
        'category': 'SQL Injection',
        'hint': "There is a table nobody lists on the shop floor.",
        'flag': 'VULNSHOP{sql_union_is_forever}',
    },
    {
        'slug': 'path_traversal',
        'name': 'Off the Shelf',
        'category': 'Path Traversal',
        'hint': "The download shelf keeps stock out of reach of the rack.",
        'flag': 'VULNSHOP{walk_the_tree}',
    },
    {
        'slug': 'backup_leak',
        'name': 'The Forgotten Zip',
        'category': 'Exposed Backup',
        'hint': "Someone archived a flag and left it on the web root.",
        'flag': 'VULNSHOP{backup_bonanza}',
    },
    {
        'slug': 'dot_env_leak',
        'name': 'Left Lying Around',
        'category': 'Secret Exposure',
        'hint': "Config files should never ship with the app.",
        'flag': 'VULNSHOP{dot_env_dot_oh}',
    },
    {
        'slug': 'jwt_none_alg',
        'name': 'Forged Badge',
        'category': 'JWT / Auth Bypass',
        'hint': "The back office badge can be forged if the algorithm is not checked.",
        'flag': 'VULNSHOP{jwt_none_is_done}',
    },
    {
        'slug': 'xxe_file_read',
        'name': 'Entity Digestion',
        'category': 'XXE',
        'hint': "An XML parser that resolves external entities can read files.",
        'flag': 'VULNSHOP{external_entities_go_brrr}',
    },
    {
        'slug': 'idor_order',
        'name': "Someone Else's Receipt",
        'category': 'IDOR',
        'hint': "One receipt has a secret note. Try ids nobody told you about.",
        'flag': 'VULNSHOP{your_receipt_is_mine}',
    },
    {
        'slug': 'predictable_token',
        'name': 'Four Little Numbers',
        'category': 'Weak Crypto',
        'hint': "Password resets use a 4-digit token derived from the email.",
        'flag': 'VULNSHOP{ten_k_tries_is_nothing}',
    },
    {
        'slug': 'debug_dump',
        'name': 'Open Book',
        'category': 'Information Disclosure',
        'hint': "The debug endpoint spills everything, including one quest.",
        'flag': 'VULNSHOP{info_leaks_are_free}',
    },
    {
        'slug': 'rce_flag',
        'name': 'Full Send',
        'category': 'Remote Code Execution',
        'hint': "If you can run code, read the flag file in /app/files.",
        'flag': 'VULNSHOP{code_exec_with_a_smile}',
    },
]

BY_SLUG = {f['slug']: f for f in FLAGS}

# Files written by seed.py into /app/files - contents match the DB flags
# exactly, so a successful exploit yields a submittable flag.
FLAG_FILES = {
    'flag.txt': BY_SLUG['path_traversal']['flag'] + '\n',
    'xxe-flag.txt': BY_SLUG['xxe_file_read']['flag'] + '\n',
    'rce-flag.txt': BY_SLUG['rce_flag']['flag'] + '\n',
}
