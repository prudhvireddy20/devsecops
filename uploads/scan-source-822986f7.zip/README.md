# Test Repo

Small sample project for testing the code_intel parsing pipeline.

- login.py — Python file with a function, a class, and a SQL injection style pattern
- api.js — JavaScript file with two functions and a call between them
