const express = require("express");
const db = require("./db");

function getUser(userId) {
  const query = "SELECT * FROM users WHERE id=" + userId;
  return db.execute(query);
}

function handleRequest(req, res) {
  const uid = req.query.id;
  const result = getUser(uid);
  res.send(result);
}

module.exports = { getUser, handleRequest };
