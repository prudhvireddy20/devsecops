from flask import request
from db import db


def get_user(user_id):
    query = "SELECT * FROM users WHERE id=" + user_id
    return db.execute(query)


def profile():
    uid = request.args.get("id")
    return get_user(uid)


class UserController:
    def admin_panel(self):
        token = request.headers.get("Authorization")
        return get_user(token)
