#requires -Version 5.1
param([switch]$GuiOnly)

# ============================================================
# BOOTSTRAP (FIX: ensures script actually launches)
# - Forces Windows PowerShell 5.1 Desktop (not pwsh)
# - Forces STA
# - Shows errors instead of silently exiting
# ============================================================
try {
    $bootRoot = Join-Path $env:LOCALAPPDATA "USB_Evidence_Transfer_Tool"
    $bootDir  = Join-Path $bootRoot "Logs"
    New-Item -ItemType Directory -Path $bootDir -Force | Out-Null
    $script:BootLog = Join-Path $bootDir ("Bootstrap_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
    "BOOT: start $(Get-Date)" | Out-File -FilePath $script:BootLog -Encoding UTF8 -Force

    function BootLog([string]$m) {
        try { Add-Content -Path $script:BootLog -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m) -Encoding UTF8 } catch {}
    }

    BootLog ("PSEdition={0} PSVersion={1} STA={2} GuiOnly={3}" -f $PSVersionTable.PSEdition, $PSVersionTable.PSVersion, [System.Threading.Thread]::CurrentThread.ApartmentState, $GuiOnly)

    # If launched from PowerShell 7+ (pwsh), relaunch using Windows PowerShell 5.1
    if ($PSVersionTable.PSEdition -ne 'Desktop') {
        BootLog "Not Desktop edition. Relaunching with powershell.exe (Windows PowerShell 5.1)."

        if (-not $PSCommandPath) {
            Add-Type -AssemblyName System.Windows.Forms | Out-Null
            [System.Windows.Forms.MessageBox]::Show(
                "Save this script as a .ps1 file before running.",
                "Cannot launch",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            exit 1
        }

        $argsList = @(
            "-NoProfile",
            "-ExecutionPolicy","Bypass",
            "-STA",
            "-File", "`"$PSCommandPath`""
        )
        if ($GuiOnly) { $argsList += "-GuiOnly" }

        Start-Process -FilePath (Get-Command powershell.exe).Source -ArgumentList $argsList | Out-Null
        exit
    }

    # Force STA if not already
    if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
        BootLog "Not STA. Relaunching with -STA."

        if (-not $PSCommandPath) {
            Write-Host "Save this script as a .ps1 file before running." -ForegroundColor Red
            exit 1
        }

        $argsList = @(
            "-NoProfile",
            "-ExecutionPolicy","Bypass",
            "-STA",
            "-File", "`"$PSCommandPath`""
        )
        if ($GuiOnly) { $argsList += "-GuiOnly" }

        Start-Process -FilePath (Get-Command powershell.exe).Source -ArgumentList $argsList | Out-Null
        exit
    }

    # WinForms load sanity check
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    Add-Type -AssemblyName System.Drawing     | Out-Null
    BootLog "WinForms + Drawing loaded OK."
}
catch {
    try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.ToString(),
            "Startup error (WinForms bootstrap)",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {
        Write-Host $_.Exception.ToString() -ForegroundColor Red
    }
    exit 1
}


$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"

#Add-Type -AssemblyName System.Windows.Forms | Out-Null
#Add-Type -AssemblyName System.Drawing     | Out-Null
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch {}
try { [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException) } catch {}

[System.Windows.Forms.Application]::add_ThreadException({
    param($sender, $e)
    try {
        [System.Windows.Forms.MessageBox]::Show(
            $e.Exception.ToString(),
            "Unhandled UI error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {}
})

trap {
    try { [System.Windows.Forms.MessageBox]::Show($_.Exception.ToString(), "Error", "OK", "Error") | Out-Null } catch {}
    continue
}

# ============================================================
# Logging
# ============================================================
$AppRoot = Join-Path $env:LOCALAPPDATA "USB_Evidence_Transfer_Tool"
$LogDir  = Join-Path $AppRoot "Logs"
$ManDir  = Join-Path $AppRoot "Manifests"
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
New-Item -ItemType Directory -Path $ManDir -Force | Out-Null

$script:LogPath = Join-Path $LogDir ("EvidenceTransfer_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType File -Path $script:LogPath -Force | Out-Null

function Write-Log([string]$msg) {
    try {
        if ($null -eq $msg) { $msg = "" }
        $msg = $msg -replace "[\r\n]+", " "
        $ts  = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        Add-Content -Path $script:LogPath -Value ("[{0}] {1}" -f $ts, $msg) -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {}
}
Write-Log "=== Application started ==="

# ============================================================
# Helpers / Admin (if not started as Admin)
# ============================================================
function Set-EnabledSafe($ctrl, [bool]$val) {
    if ($null -ne $ctrl -and $ctrl.PSObject.Properties.Match("Enabled").Count -gt 0) { $ctrl.Enabled = $val }
}
function Set-TextSafe($ctrl, [string]$val) {
    if ($null -ne $ctrl -and $ctrl.PSObject.Properties.Match("Text").Count -gt 0) { $ctrl.Text = $val }
}
function Test-IsAdmin {
    try {
        $p = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}
$script:IsAdmin = Test-IsAdmin
$script:RequestedRestartAsAdmin = $false

function Restart-AsAdmin {
    try {
        if (-not $PSCommandPath) {
            [System.Windows.Forms.MessageBox]::Show(
                "Save this script as a .ps1 file before restarting as admin.",
                "Cannot self-elevate",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            return
        }
        $ps = (Get-Command powershell.exe -ErrorAction Stop).Source
        Start-Process -FilePath $ps -Verb RunAs -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy","Bypass",
            "-STA",
            "-NoLogo",
            "-NonInteractive",
            "-File","`"$PSCommandPath`"",
            "-GuiOnly"
        ) | Out-Null

        $script:RequestedRestartAsAdmin = $true
        if ($null -ne $global:form) { $global:form.Close() }
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            ("Failed to restart as admin: {0}" -f $_.Exception.Message),
            "Restart as Admin failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function DriveFromPath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $null }
    try { return ([System.IO.Path]::GetPathRoot($path)).Substring(0,1) } catch { return $null }
}

# ============================================================
# Global State Tower
# ============================================================
$global:State = @{
    DestFolder               = $null
    DestDriveLetter          = $null
    DestDriveInfo            = $null
    DestOverrideAccepted     = $false

    WriteBlockEnabled        = $false
    TestPassed               = $false

    EvidenceDriveLetter      = $null
    SourcePath               = $null

    Algo                     = "SHA256"
    ManifestCsv              = $null

    Copied                   = $false
    DestCopyPath             = $null

    Verified                 = $false
    VerifySummary            = ""

    PdfSaved                 = $false
    PdfPath                  = $null

    LastStep2Drive           = $null
    LastStep2Status          = "(not run)"
    LastStep2Summary         = ""
    LastStep2Attempts        = @()

    IsBusy                   = $false
    Step4Job                 = $null
    Step4Timer               = $null
}
function GetS([string]$k) { return $global:State[$k] }
function SetS([string]$k, $v) { $global:State[$k] = $v }

# ============================================================
# Drive detection (robust)
# ============================================================
function Get-DriveInfo([string]$driveLetter) {
    $d = ($driveLetter + "").Trim().TrimEnd(':')
    if ($d -notmatch '^[A-Z]$') { return $null }

    $info = [ordered]@{
        DriveLetter   = $d
        Path          = "$d`:\"
        DriveType     = $null
        VolumeLabel   = $null
        FileSystem    = $null
        SizeGB        = $null
        FreeGB        = $null
        BusType       = $null
        InterfaceType = $null
        MediaType     = $null
        Model         = $null
        PNPDeviceID   = $null
        Friendly      = $null
        IsUsb         = $false
    }

    try {
        $ld = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='{0}:'" -f $d) -ErrorAction Stop
        $info.DriveType   = $ld.DriveType
        $info.VolumeLabel = [string]$ld.VolumeName
        $info.FileSystem  = [string]$ld.FileSystem
        if ($ld.Size)      { $info.SizeGB = [math]::Round(($ld.Size/1GB),2) }
        if ($ld.FreeSpace) { $info.FreeGB = [math]::Round(($ld.FreeSpace/1GB),2) }
    } catch {}

    try {
        $vol = Get-Volume -DriveLetter $d -ErrorAction Stop
        $info.BusType = [string]$vol.BusType
        if ($vol.DriveType -eq 'Removable') { $info.IsUsb = $true }
        if ($vol.BusType -eq 'USB')         { $info.IsUsb = $true }
    } catch {}

    try {
        $ld2  = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='{0}:'" -f $d) -ErrorAction Stop
        $part = Get-CimAssociatedInstance -InputObject $ld2 -ResultClassName Win32_DiskPartition -ErrorAction Stop | Select-Object -First 1
        if ($part) {
            $disk = Get-CimAssociatedInstance -InputObject $part -ResultClassName Win32_DiskDrive -ErrorAction Stop | Select-Object -First 1
            if ($disk) {
                $info.InterfaceType = [string]$disk.InterfaceType
                $info.MediaType     = [string]$disk.MediaType
                $info.Model         = [string]$disk.Model
                $info.PNPDeviceID   = [string]$disk.PNPDeviceID
                $info.Friendly      = ("{0} | {1} | {2}" -f $info.Model, $info.InterfaceType, $info.MediaType)

                if ($info.InterfaceType -eq 'USB')         { $info.IsUsb = $true }
                if ($info.PNPDeviceID -match '^USBSTOR\\') { $info.IsUsb = $true }
                if ($info.PNPDeviceID -match 'USB')        { $info.IsUsb = $true }
            }
        }
    } catch {}

    return [pscustomobject]$info
}

function Test-DestinationAcceptable {
    param(
        [Parameter(Mandatory)][string]$DriveLetter,
        [Parameter(Mandatory)][System.Windows.Forms.IWin32Window]$Owner
    )

    $sys = ($env:SystemDrive + "").Trim().TrimEnd(':')
    $d   = ($DriveLetter + "").Trim().TrimEnd(':')
    if ($d -notmatch '^[A-Z]$') { return [pscustomobject]@{ Ok=$false; Reason="Invalid drive letter."; Info=$null } }

    $info = Get-DriveInfo $d

    if (-not (Test-Path "$d`:\")) {
        return [pscustomobject]@{ Ok=$false; Reason="Drive is not accessible: $d`:"; Info=$info }
    }
    if ($d -eq $sys) {
        return [pscustomobject]@{ Ok=$false; Reason="Destination cannot be the system drive ($sys`:)."; Info=$info }
    }
    if ($info -and $info.DriveType -eq 4) {
        return [pscustomobject]@{ Ok=$false; Reason="Destination cannot be a network drive."; Info=$info }
    }

    if ($info -and $info.IsUsb) {
        return [pscustomobject]@{ Ok=$true; Reason="USB detected."; Info=$info; Override=$false }
    }

    $detail = ""
    if ($info) {
        $detail = "Detected as:`n" +
                  ("DriveType: {0}`n" -f $info.DriveType) +
                  ("BusType: {0}`n" -f ($(if($info.BusType){$info.BusType}else{"(unknown)"}))) +
                  ("InterfaceType: {0}`n" -f ($(if($info.InterfaceType){$info.InterfaceType}else{"(unknown)"}))) +
                  ("Model: {0}`n" -f ($(if($info.Model){$info.Model}else{"(unknown)"})))
    }

    $msg = "Windows did NOT positively identify $d`: as USB (some USB enclosures report as SATA/other).`n`n" +
           "If this really is your DEST external drive, you can continue anyway.`n`n" +
           "$detail`n`nContinue with this destination?"

    $ans = [System.Windows.Forms.MessageBox]::Show(
        $Owner,
        $msg,
        "Destination not identified as USB",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) {
        return [pscustomobject]@{ Ok=$true; Reason="User override accepted."; Info=$info; Override=$true }
    }

    return [pscustomobject]@{ Ok=$false; Reason="User cancelled destination override."; Info=$info }
}

function Get-UsbVolumes {
    $out = New-Object System.Collections.Generic.List[object]
    try {
        $vols = @(Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter -match '^[A-Z]$' })
        foreach ($v in $vols) {
            if ($v.DriveType -eq 'Removable' -or $v.BusType -eq 'USB') {
                $out.Add([pscustomobject]@{
                    DriveLetter = [string]$v.DriveLetter
                    Label       = [string]$v.FileSystemLabel
                    FileSystem  = [string]$v.FileSystem
                    BusType     = [string]$v.BusType
                }) | Out-Null
            }
        }
        return ($out.ToArray() | Sort-Object DriveLetter)
    } catch { }

    try {
        $ld = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=2" |
              Where-Object { $_.DeviceID -match '^[A-Z]:$' }
        foreach ($d in $ld) {
            $out.Add([pscustomobject]@{
                DriveLetter = $d.DeviceID.Substring(0,1)
                Label       = [string]$d.VolumeName
                FileSystem  = [string]$d.FileSystem
                BusType     = "Removable"
            }) | Out-Null
        }
    } catch { }
    return ($out.ToArray() | Sort-Object DriveLetter)
}
function VolToDisplay($v) {
    $label = if ($v.Label) { $v.Label } else { "(no label)" }
    $fs    = if ($v.FileSystem) { $v.FileSystem } else { "?" }
    $bus   = if ($v.BusType) { $v.BusType } else { "" }
    if ($bus) { "{0}:\  {1}  [{2}]  ({3})" -f $v.DriveLetter, $label, $fs, $bus }
    else      { "{0}:\  {1}  [{2}]"       -f $v.DriveLetter, $label, $fs }
}

# ============================================================
# Write-block registry
# ============================================================
$sdRegPath    = "HKLM:\SYSTEM\CurrentControlSet\Control\StorageDevicePolicies"
$sdValueName  = "WriteProtect"
$polBasePath  = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices"
$diskGuid     = "{53f5630d-b6bf-11d0-94f2-00a0c91efb8b}"
$polRegPath   = Join-Path $polBasePath $diskGuid
$polValueName = "Deny_Write"

function Ensure-Dword([string]$path, [string]$name, [int]$value) {
    if (!(Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    if (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue) {
        Set-ItemProperty -Path $path -Name $name -Value $value | Out-Null
    } else {
        New-ItemProperty -Path $path -Name $name -Value $value -PropertyType DWord -Force | Out-Null
    }
}
function Set-WriteBlockMode([bool]$enable) {
    if (-not $script:IsAdmin) { throw "Admin privileges are required to enable/disable write-block." }
    $v = if ($enable) { 1 } else { 0 }
    Ensure-Dword $sdRegPath $sdValueName $v
    if (!(Test-Path $polBasePath)) { New-Item -Path $polBasePath -Force | Out-Null }
    Ensure-Dword $polRegPath $polValueName $v
}

# ============================================================
# Step 2 test (TEST USB, 3 attempts)
# ============================================================
function Test-WriteBlocked3x {
    param([Parameter(Mandatory)][string]$DriveLetter)

    $d = $DriveLetter.Trim().TrimEnd(':')
    $root  = "$d`:\"
    $bytes = [byte[]](1..64)

    $attempts = New-Object System.Collections.Generic.List[object]
    for ($i=1; $i -le 3; $i++) {
        $testFile = Join-Path $root ("__wb_test_{0}_{1}.bin" -f $i, ([guid]::NewGuid().ToString('N')))
        try {
            $fs = [System.IO.File]::Open($testFile,
                [System.IO.FileMode]::CreateNew,
                [System.IO.FileAccess]::Write,
                [System.IO.FileShare]::None)
            try { $fs.Write($bytes,0,$bytes.Length); $fs.Flush() }
            finally { $fs.Dispose() }

            Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue | Out-Null
            $attempts.Add([pscustomobject]@{ Attempt=$i; Writable=$true; Detail="Write succeeded" }) | Out-Null
        } catch {
            $attempts.Add([pscustomobject]@{ Attempt=$i; Writable=$false; Detail=$_.Exception.Message }) | Out-Null
        }
        Start-Sleep -Milliseconds 250
    }

    $anyWritable = $attempts.Writable -contains $true
    $anyBlocked  = $attempts.Writable -contains $false

    if ($anyWritable -and $anyBlocked) {
        return [pscustomobject]@{
            Drive    = "$d`:"
            Status   = "INCONCLUSIVE"
            Pass     = $false
            Attempts = $attempts.ToArray()
            Summary  = "Mixed results. Remove + reinsert the TEST USB, then run Step 2 again."
        }
    }

    if (-not $anyWritable) {
        return [pscustomobject]@{
            Drive    = "$d`:"
            Status   = "PASS"
            Pass     = $true
            Attempts = $attempts.ToArray()
            Summary  = "All attempts were blocked. Write-block is enforced."
        }
    }

    return [pscustomobject]@{
        Drive    = "$d`:"
        Status   = "FAIL"
        Pass     = $false
        Attempts = $attempts.ToArray()
        Summary  = "At least one write succeeded. The USB is writable."
    }
}

# ============================================================
# Step 5: Copy (into timestamped run folder)
# ============================================================
function Copy-SourceToDestination {
    param(
        [Parameter(Mandatory)][string]$SourcePath,
        [Parameter(Mandatory)][string]$DestFolder
    )

    if (-not (Test-Path -LiteralPath $DestFolder -PathType Container)) {
        throw "Destination folder does not exist: $DestFolder"
    }

    $runFolder = Join-Path $DestFolder ("Transfer_{0}" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
    New-Item -ItemType Directory -Path $runFolder -Force | Out-Null

    if (Test-Path -LiteralPath $SourcePath -PathType Leaf) {
        $name = [System.IO.Path]::GetFileName($SourcePath)
        $dest = Join-Path $runFolder $name
        Copy-Item -LiteralPath $SourcePath -Destination $dest -Force -ErrorAction Stop | Out-Null
        return $dest
    }

    if (Test-Path -LiteralPath $SourcePath -PathType Container) {
        $folderName = Split-Path $SourcePath -Leaf
        if ([string]::IsNullOrWhiteSpace($folderName)) { $folderName = "EvidenceSource" }
        $destRoot = Join-Path $runFolder $folderName
        Copy-Item -LiteralPath $SourcePath -Destination $destRoot -Recurse -Force -ErrorAction Stop | Out-Null
        return $destRoot
    }

    throw "Source path does not exist: $SourcePath"
}

# ============================================================
# Post-copy verification (manifest -> destination)
# ============================================================
function Get-RelativePathSimple {
    param(
        [Parameter(Mandatory)][string]$BasePath,
        [Parameter(Mandatory)][string]$FullPath
    )
    $base = $BasePath.TrimEnd('\')
    $full = $FullPath

    try { $base = (Resolve-Path -LiteralPath $base -ErrorAction Stop).Path.TrimEnd('\') } catch {}
    try { $full = (Resolve-Path -LiteralPath $full -ErrorAction Stop).Path } catch {}

    if ($full.StartsWith($base, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $full.Substring($base.Length).TrimStart('\')
    }
    return $null
}

function Verify-DestinationAgainstManifest {
    param(
        [Parameter(Mandatory)][string]$SourcePath,
        [Parameter(Mandatory)][string]$DestCopyPath,
        [Parameter(Mandatory)][string]$ManifestCsv,
        [Parameter(Mandatory)][ValidateSet("MD5","SHA1","SHA256")][string]$Algo
    )

    if (-not (Test-Path -LiteralPath $ManifestCsv -PathType Leaf)) {
        throw "Manifest CSV not found: $ManifestCsv"
    }

    $rows = Import-Csv -LiteralPath $ManifestCsv

    $srcIsFile = Test-Path -LiteralPath $SourcePath -PathType Leaf
    $srcBase   = if ($srcIsFile) { (Split-Path -LiteralPath $SourcePath -Parent) } else { $SourcePath }
    $dstBase   = if ($srcIsFile) { (Split-Path -LiteralPath $DestCopyPath -Parent) } else { $DestCopyPath }

    $results = New-Object System.Collections.Generic.List[object]

    foreach ($r in $rows) {
        $srcFull = [string]$r.FullPath
        if ([string]::IsNullOrWhiteSpace($srcFull)) { continue }

        $rel = $null
        if (-not $srcIsFile) {
            $rel = Get-RelativePathSimple -BasePath $srcBase -FullPath $srcFull
        } else {
            $rel = [System.IO.Path]::GetFileName($srcFull)
        }

        $dstFull = if ($srcIsFile) {
            $DestCopyPath
        } else {
            if ($rel) { Join-Path $dstBase $rel } else { $null }
        }

        if (-not $dstFull -or -not (Test-Path -LiteralPath $dstFull -PathType Leaf)) {
            $results.Add([pscustomobject]@{
                RelativePath = $rel
                Status       = "MISSING"
                ExpectedHash = [string]$r.Hash
                ActualHash   = ""
            }) | Out-Null
            continue
        }

        $actual = ""
        try { $actual = (Get-FileHash -LiteralPath $dstFull -Algorithm $Algo -ErrorAction Stop).Hash } catch { $actual = "" }

        $expected = ([string]$r.Hash)
        $ok = ($actual -and $expected -and ($actual.ToUpperInvariant() -eq $expected.ToUpperInvariant()))

        $results.Add([pscustomobject]@{
            RelativePath = $rel
            Status       = $(if ($ok) { "OK" } else { "MISMATCH" })
            ExpectedHash = $expected
            ActualHash   = $actual
        }) | Out-Null
    }

    $bad = @($results | Where-Object { $_.Status -ne "OK" })
    return [pscustomobject]@{
        Pass     = ($bad.Count -eq 0)
        Total    = $results.Count
        BadCount = $bad.Count
        BadItems = $bad
        AllItems = $results
    }
}

# ============================================================
# Step 6: Robust PDF (no external deps)
# ============================================================
function Save-TextAsPdfRobust {
    param(
        [Parameter(Mandatory)][string]$TextFile,
        [Parameter(Mandatory)][string]$PdfFile
    )

    $lines = Get-Content -LiteralPath $TextFile -ErrorAction Stop

    $ms  = New-Object System.IO.MemoryStream
    $enc = New-Object System.Text.ASCIIEncoding

    function Write-Ascii([string]$s) {
        $b = $enc.GetBytes($s)
        $ms.Write($b, 0, $b.Length)
    }

    $offsets = @{}
    function Begin-Obj([int]$n) { $offsets[$n] = [int]$ms.Position; Write-Ascii ("{0} 0 obj`n" -f $n) }
    function End-Obj { Write-Ascii "endobj`n" }

    function Pdf-Escape([string]$s) {
        if ($null -eq $s) { return "" }
        $chars = $s.ToCharArray() | ForEach-Object {
            $code = [int][char]$_
            if ($code -lt 32 -or $code -gt 126) { '?' } else { $_ }
        }
        $t = -join $chars
        $t = $t.Replace('\','\\').Replace('(','\(').Replace(')','\)')
        return $t
    }

    $pageW = 612; $pageH = 792
    $marginL = 36; $marginT = 36
    $fontSize = 10; $lineH = 12
    $maxLines = [int](($pageH - ($marginT*2)) / $lineH)

    $usableW = $pageW - ($marginL * 2)
    $avgCharW = [Math]::Max(1.0, (0.6 * $fontSize))
    $maxChars = [int][Math]::Floor($usableW / $avgCharW)
    if ($maxChars -lt 40) { $maxChars = 40 }

    function Wrap-Line([string]$line, [int]$limit) {
        if ($null -eq $line) { return @("") }
        if ($line.Length -le $limit) { return @($line) }

        $out = New-Object System.Collections.Generic.List[string]
        $s = $line
        while ($s.Length -gt $limit) {
            $chunk = $s.Substring(0, $limit)
            $breakAt = $chunk.LastIndexOf(' ')
            if ($breakAt -lt 10) { $breakAt = $limit }
            $out.Add($s.Substring(0, $breakAt).TrimEnd()) | Out-Null
            $s = $s.Substring($breakAt).TrimStart()
        }
        if ($s.Length -gt 0) { $out.Add($s) | Out-Null }
        return $out.ToArray()
    }

    $wrappedLines = New-Object System.Collections.Generic.List[string]
    foreach ($ln in $lines) {
        foreach ($w in (Wrap-Line -line $ln -limit $maxChars)) { $wrappedLines.Add($w) | Out-Null }
    }
    if ($wrappedLines.Count -eq 0) { $wrappedLines.Add("") | Out-Null }

    $pages = New-Object System.Collections.Generic.List[object]
    for ($i=0; $i -lt $wrappedLines.Count; $i += $maxLines) {
        $end = [Math]::Min($i + $maxLines - 1, $wrappedLines.Count - 1)
        $pages.Add($wrappedLines[$i..$end]) | Out-Null
    }
    $pageCount = $pages.Count

    $firstPageObj = 4
    $maxObj = 3 + ($pageCount * 2)

    Write-Ascii "%PDF-1.4`n%`xE2`xE3`xCF`xD3`n"

    Begin-Obj 1; Write-Ascii "<< /Type /Catalog /Pages 2 0 R >>`n"; End-Obj

    $kids = @()
    for ($p=0; $p -lt $pageCount; $p++) { $kids += ("{0} 0 R" -f ($firstPageObj + ($p*2))) }
    Begin-Obj 2; Write-Ascii ("<< /Type /Pages /Kids [ {0} ] /Count {1} >>`n" -f ($kids -join " "), $pageCount); End-Obj

    Begin-Obj 3; Write-Ascii "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>`n"; End-Obj

    for ($p=0; $p -lt $pageCount; $p++) {
        $pageObj = $firstPageObj + ($p*2)
        $contentObj = $pageObj + 1
        $chunk = $pages[$p]

        $sb = New-Object System.Text.StringBuilder
        [void]$sb.Append("BT`n")
        [void]$sb.AppendFormat("/F1 {0} Tf`n", $fontSize)
        [void]$sb.AppendFormat("{0} {1} Td`n", $marginL, ($pageH - $marginT - $fontSize))

        foreach ($ln in $chunk) {
            $safe = Pdf-Escape $ln
            [void]$sb.AppendFormat("({0}) Tj`n", $safe)
            [void]$sb.AppendFormat("0 -{0} Td`n", $lineH)
        }
        [void]$sb.Append("ET`n")

        $streamText  = $sb.ToString()
        $streamBytes = $enc.GetBytes($streamText)
        $len = $streamBytes.Length

        Begin-Obj $contentObj
        Write-Ascii ("<< /Length {0} >>`nstream`n" -f $len)
        $ms.Write($streamBytes, 0, $streamBytes.Length)
        Write-Ascii "`nendstream`n"
        End-Obj

        Begin-Obj $pageObj
        Write-Ascii ("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {0} {1}] /Resources << /Font << /F1 3 0 R >> >> /Contents {2} 0 R >>`n" -f $pageW, $pageH, $contentObj)
        End-Obj
    }

    $xrefStart = [int]$ms.Position
    Write-Ascii "xref`n"
    Write-Ascii ("0 {0}`n" -f ($maxObj + 1))
    Write-Ascii "0000000000 65535 f `n"
    for ($n=1; $n -le $maxObj; $n++) {
        $off = 0
        if ($offsets.ContainsKey($n)) { $off = $offsets[$n] }
        Write-Ascii ($off.ToString("0000000000") + " 00000 n `n")
    }

    Write-Ascii "trailer`n"
    Write-Ascii ("<< /Size {0} /Root 1 0 R >>`n" -f ($maxObj + 1))
    Write-Ascii "startxref`n"
    Write-Ascii ($xrefStart.ToString() + "`n")
    Write-Ascii "%%EOF`n"

    [System.IO.File]::WriteAllBytes($PdfFile, $ms.ToArray())
    $ms.Dispose()
}

# ============================================================
# Step 4: Manifest job (async, responsive UI)
# ============================================================
function Start-Step4Job {
    param(
        [Parameter(Mandatory)][string]$SourcePath,
        [Parameter(Mandatory)][ValidateSet("MD5","SHA1","SHA256")][string]$Algo,
        [Parameter(Mandatory)][string]$ManifestDir,
        [Parameter(Mandatory)][string]$LogPath
    )

    Start-Job -ArgumentList @($SourcePath, $Algo, $ManifestDir, $LogPath) -ScriptBlock {
        param($src, $algo, $manDir, $logPath)

        $ErrorActionPreference = "Stop"
        $ProgressPreference    = "SilentlyContinue"

        function Write-LogJ([string]$msg) {
            try {
                if ($null -eq $msg) { $msg = "" }
                $msg = $msg -replace "[\r\n]+", " "
                $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                Add-Content -Path $logPath -Value ("[{0}] {1}" -f $ts, $msg) -Encoding UTF8 -ErrorAction SilentlyContinue
            } catch {}
        }
        function Out-Progress([string]$msg) { Write-Output ("PROGRESS: " + $msg) }

        if (-not (Test-Path -LiteralPath $manDir -PathType Container)) {
            New-Item -ItemType Directory -Path $manDir -Force | Out-Null
        }

        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $csv   = Join-Path $manDir ("manifest_{0}.csv" -f $stamp)

        "FullPath,FileName,Length,LastWriteTimeUtc,Algorithm,Hash" | Out-File -FilePath $csv -Encoding UTF8
        Write-LogJ ("Step4 Manifest start. Source={0} Algo={1}" -f $src, $algo)

        if (Test-Path -LiteralPath $src -PathType Leaf) {
            $f = Get-Item -LiteralPath $src -ErrorAction Stop
            Out-Progress ("Step 4 hashing #1/1: {0} ({1})" -f $f.Name, $algo)
            $h = (Get-FileHash -LiteralPath $f.FullName -Algorithm $algo -ErrorAction Stop).Hash

            $row = ('"{0}","{1}",{2},"{3}",{4},{5}' -f
                $f.FullName.Replace('"','""'),
                $f.Name.Replace('"','""'),
                $f.Length,
                $f.LastWriteTimeUtc.ToString("o"),
                $algo,
                $h
            )
            Add-Content -Path $csv -Value $row -Encoding UTF8
        }
        elseif (Test-Path -LiteralPath $src -PathType Container) {
            $files = @(Get-ChildItem -LiteralPath $src -Recurse -File -Force -ErrorAction SilentlyContinue)
            $total = $files.Count
            $i = 0
            foreach ($f in $files) {
                $i++
                Out-Progress ("Step 4 hashing #{0}/{1}: {2} ({3})" -f $i, $total, $f.Name, $algo)
                try {
                    $h = (Get-FileHash -LiteralPath $f.FullName -Algorithm $algo -ErrorAction Stop).Hash
                    $row = ('"{0}","{1}",{2},"{3}",{4},{5}' -f
                        $f.FullName.Replace('"','""'),
                        $f.Name.Replace('"','""'),
                        $f.Length,
                        $f.LastWriteTimeUtc.ToString("o"),
                        $algo,
                        $h
                    )
                    Add-Content -Path $csv -Value $row -Encoding UTF8
                } catch {}
            }
        }
        else { throw "Source path does not exist: $src" }

        Write-LogJ ("Step4 Manifest done: {0}" -f $csv)
        [pscustomobject]@{ Type="RESULT"; Csv=$csv }
    }
}

# ============================================================
# Build report text for PDF (Log + Verification + Manifest hashes)
# ============================================================
function Build-ReportTextFile {
    param(
        [Parameter(Mandatory)][string]$LogPath,
        [Parameter(Mandatory)][string]$OutTextFile,
        [string]$ManifestCsv
    )

    $sb = New-Object System.Text.StringBuilder

    if (Test-Path -LiteralPath $LogPath) {
        foreach ($l in (Get-Content -LiteralPath $LogPath -ErrorAction SilentlyContinue)) {
            [void]$sb.AppendLine($l)
        }
    }

    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("============================================================")
    [void]$sb.AppendLine("POST-COPY HASH VERIFICATION")
    [void]$sb.AppendLine("============================================================")
    [void]$sb.AppendLine("Verified: " + ($(if (GetS 'Verified') { "PASS" } else { "FAIL/NOT RUN" })))
    [void]$sb.AppendLine("Summary:  " + ($(if (GetS 'VerifySummary') { GetS 'VerifySummary' } else { "(none)" })))
    [void]$sb.AppendLine("")

    [void]$sb.AppendLine("============================================================")
    [void]$sb.AppendLine("MANIFEST (HASHES)")
    [void]$sb.AppendLine("============================================================")

    if (-not [string]::IsNullOrWhiteSpace($ManifestCsv) -and (Test-Path -LiteralPath $ManifestCsv)) {
        [void]$sb.AppendLine("Manifest file: " + $ManifestCsv)
        [void]$sb.AppendLine("")
        foreach ($l in (Get-Content -LiteralPath $ManifestCsv -ErrorAction SilentlyContinue)) {
            [void]$sb.AppendLine($l)
        }
    } else {
        [void]$sb.AppendLine("Manifest file not available.")
    }

    [System.IO.File]::WriteAllText($OutTextFile, $sb.ToString(), [System.Text.Encoding]::UTF8)
}

# ============================================================
# GUI
# ============================================================
$fontUI = New-Object System.Drawing.Font("Segoe UI", 10)

$global:form = New-Object System.Windows.Forms.Form
$form = $global:form
$form.AutoScroll = $false
$form.Text = "TamperFree Evidence Transferer"
$form.Font = $fontUI
$form.StartPosition = "CenterScreen"
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
$form.Size = New-Object System.Drawing.Size(1500, 950)
$form.MinimumSize = New-Object System.Drawing.Size(1200, 780)

function New-GroupBox([string]$text) {
    $g = New-Object System.Windows.Forms.GroupBox
    $g.Text = $text
    $g.Dock = "Fill"
    $g.Padding = New-Object System.Windows.Forms.Padding(10, 22, 10, 10)
    return $g
}

# ----------------------------
# HEADER (fixed height)
# ----------------------------
$header = New-Object System.Windows.Forms.TableLayoutPanel
$header.Dock = "Top"
$header.Height = 70
$header.AutoSize = $true
$header.AutoSizeMode = "GrowAndShrink"
$header.Padding = New-Object System.Windows.Forms.Padding(16, 4, 16, 4)
$header.BackColor = [System.Drawing.Color]::FromArgb(245,245,245)
$header.ColumnCount = 2
$header.RowCount = 1
$header.ColumnStyles.Clear()
[void]$header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
$form.Controls.Add($header)

$hdrLeft = New-Object System.Windows.Forms.FlowLayoutPanel
$hdrLeft.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
$hdrLeft.WrapContents = $false
$hdrLeft.AutoSize = $true
$hdrLeft.Dock = "Fill"
$hdrLeft.Margin = New-Object System.Windows.Forms.Padding(0)
$header.Controls.Add($hdrLeft, 0, 0)

$title = New-Object System.Windows.Forms.Label
$title.Text = "USB Evidence Transfer Tool"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Margin = New-Object System.Windows.Forms.Padding(0,0,0,4)
$hdrLeft.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "One Stop controller Dashboard for tamper free evidence transfer"
$subtitle.AutoSize = $true
$subtitle.MaximumSize = New-Object System.Drawing.Size(1000, 0)  # wraps if needed
$subtitle.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$hdrLeft.Controls.Add($subtitle)


$hdrRight = New-Object System.Windows.Forms.FlowLayoutPanel
$hdrRight.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
$hdrRight.WrapContents = $false
$hdrRight.AutoSize = $true
$hdrRight.Dock = "None"
$hdrRight.Anchor = "Top,Right"
$hdrRight.Margin = New-Object System.Windows.Forms.Padding(0)
$header.Controls.Add($hdrRight, 1, 0)

$btnRestartAdmin = New-Object System.Windows.Forms.Button
$btnRestartAdmin.Text = "Restart as Admin"
$btnRestartAdmin.Size = New-Object System.Drawing.Size(150, 32)
$btnRestartAdmin.Margin = New-Object System.Windows.Forms.Padding(0,0,8,0)
$hdrRight.Controls.Add($btnRestartAdmin)

$btnOpenLog = New-Object System.Windows.Forms.Button
$btnOpenLog.Text = "Open log"
$btnOpenLog.Size = New-Object System.Drawing.Size(120, 32)
$btnOpenLog.Margin = New-Object System.Windows.Forms.Padding(0)
$hdrRight.Controls.Add($btnOpenLog)

# ----------------------------
# Main layout (fixed row 0)
# ----------------------------
$main = New-Object System.Windows.Forms.TableLayoutPanel
$main.Dock = "Fill"
$main.Padding = New-Object System.Windows.Forms.Padding(20, 35, 20, 10)
$main.ColumnCount = 2
$main.RowCount = 3
[void]$main.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 60)))
[void]$main.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 40)))

$main.RowStyles.Clear()
[void]$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 170))) # <-- FIX: Step 0-2 row never collapses
[void]$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 85)))
[void]$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 90)))
$form.Controls.Add($main)

# Status group (top right)
$gbStatus = New-GroupBox "Status && Devices"
$gbStatus.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$main.Controls.Add($gbStatus, 1, 0)

$stateBox = New-Object System.Windows.Forms.TextBox
$stateBox.Multiline = $true
$stateBox.ReadOnly = $true
$stateBox.ScrollBars = "Vertical"
$stateBox.Dock = "Fill"
$stateBox.Font = New-Object System.Drawing.Font("Consolas", 10)
$gbStatus.Controls.Add($stateBox)

# ----------------------------
# Steps 0-2 (top left) - ALWAYS visible
# ----------------------------
$gbSteps02 = New-GroupBox "Steps 0-2"
$gbSteps02.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$main.Controls.Add($gbSteps02, 0, 0)

$stepsPanel = New-Object System.Windows.Forms.TableLayoutPanel
$stepsPanel.Dock = "Fill"
$stepsPanel.Margin = New-Object System.Windows.Forms.Padding(0)
$stepsPanel.Padding = New-Object System.Windows.Forms.Padding(0)
$stepsPanel.ColumnCount = 1
$stepsPanel.RowCount = 3
$stepsPanel.RowStyles.Clear()
#Adding Void to suppress the console jitter
[void]$stepsPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 60)))  # row with step0+step1
[void]$stepsPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 55)))  # step2
[void]$stepsPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))  # destination label
[void]$gbSteps02.Controls.Add($stepsPanel)

# row0: step0 + step1 enable/disable
$row0 = New-Object System.Windows.Forms.TableLayoutPanel
$row0.Dock = "Fill"
$row0.Margin = New-Object System.Windows.Forms.Padding(0,0,0,6)
$row0.ColumnCount = 3
$row0.ColumnStyles.Clear()
[void]$row0.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 200))) # small step0
[void]$row0.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
[void]$row0.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
$stepsPanel.Controls.Add($row0, 0, 0)

$btnPickDestFolder = New-Object System.Windows.Forms.Button
$btnPickDestFolder.Text = " Destination Folder"
$btnPickDestFolder.Dock = "Fill"
$btnPickDestFolder.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnPickDestFolder.Margin = New-Object System.Windows.Forms.Padding(0)
$row0.Controls.Add($btnPickDestFolder, 0, 0)

$btnEnableWB = New-Object System.Windows.Forms.Button
$btnEnableWB.Text = "1) Enable write-block"
$btnEnableWB.Dock = "Fill"
$btnEnableWB.Enabled = $false
$btnEnableWB.Margin = New-Object System.Windows.Forms.Padding(6,0,0,0)
$row0.Controls.Add($btnEnableWB, 1, 0)

$btnDisableWB = New-Object System.Windows.Forms.Button
$btnDisableWB.Text = "Disable write-block (final)"
$btnDisableWB.Dock = "Fill"
$btnDisableWB.Enabled = $false
$btnDisableWB.Margin = New-Object System.Windows.Forms.Padding(6,0,0,0)
$row0.Controls.Add($btnDisableWB, 2, 0)

# step2
$btnTestWB = New-Object System.Windows.Forms.Button
$btnTestWB.Text = "2) Mandatory: Test write-block (insert TEST USB)"
$btnTestWB.Dock = "Fill"
$btnTestWB.Enabled = $false
$btnTestWB.Margin = New-Object System.Windows.Forms.Padding(0,0,0,6)
$stepsPanel.Controls.Add($btnTestWB, 0, 1)

# destination label
$lblDest = New-Object System.Windows.Forms.Label
$lblDest.Text = "Destination: (not selected)"
$lblDest.Dock = "Fill"
$lblDest.TextAlign = "MiddleLeft"
$lblDest.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Italic)
$lblDest.Margin = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
$stepsPanel.Controls.Add($lblDest, 0, 2)

# ----------------------------
# Steps 3-4 (mid left)
# ----------------------------
$gbSteps35 = New-GroupBox "Integrity Engine"
$main.Controls.Add($gbSteps35, 0, 1)

$lm = New-Object System.Windows.Forms.TableLayoutPanel
$lm.Dock = "Fill"
$lm.ColumnCount = 3
$lm.RowCount = 4
[void]$lm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 140)))
[void]$lm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 140)))
[void]$lm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
$lm.RowStyles.Clear()
[void]$lm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 50)))
[void]$lm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 55)))
[void]$lm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 55)))
[void]$lm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
$gbSteps35.Controls.Add($lm)

$btnRefreshDevices = New-Object System.Windows.Forms.Button
$btnRefreshDevices.Text = "Refresh devices"
$btnRefreshDevices.Dock = "Fill"
$lm.Controls.Add($btnRefreshDevices, 0, 0)

$algoDrop = New-Object System.Windows.Forms.ComboBox
$algoDrop.Dock = "Fill"
$algoDrop.DropDownStyle = "DropDownList"
[void]$algoDrop.Items.AddRange(@("SHA256","SHA1","MD5"))
$algoDrop.SelectedIndex = 0
$lm.Controls.Add($algoDrop, 1, 0)

$lblAlgo = New-Object System.Windows.Forms.Label
$lblAlgo.Text = "Hash algorithm"
$lblAlgo.Dock = "Fill"
$lblAlgo.TextAlign = "MiddleLeft"
$lm.Controls.Add($lblAlgo, 2, 0)

$btnPickSource = New-Object System.Windows.Forms.Button
$btnPickSource.Text = "3) Select evidence source (file/folder)"
$btnPickSource.Dock = "Fill"
$btnPickSource.Enabled = $false
$lm.Controls.Add($btnPickSource, 0, 1)
$lm.SetColumnSpan($btnPickSource, 3)

$btnBuildManifest = New-Object System.Windows.Forms.Button
$btnBuildManifest.Text = "4) Pre-hash + create CSV manifest"
$btnBuildManifest.Dock = "Fill"
$btnBuildManifest.Enabled = $false
$lm.Controls.Add($btnBuildManifest, 0, 2)
$lm.SetColumnSpan($btnBuildManifest, 3)

$lblSource = New-Object System.Windows.Forms.Label
$lblSource.Text = "Source: (not selected)"
$lblSource.Dock = "Fill"
$lblSource.TextAlign = "MiddleLeft"
$lblSource.Padding = New-Object System.Windows.Forms.Padding(6,0,6,0)
$lm.Controls.Add($lblSource, 0, 3)
$lm.SetColumnSpan($lblSource, 2)

$lblManifest = New-Object System.Windows.Forms.Label
$lblManifest.Text = "Manifest: (not created)"
$lblManifest.Dock = "Fill"
$lblManifest.TextAlign = "MiddleLeft"
$lblManifest.Padding = New-Object System.Windows.Forms.Padding(6,0,6,0)
$lm.Controls.Add($lblManifest, 2, 3)

# ----------------------------
# Steps 5-6 (mid right)
# ----------------------------
$gbSteps57 = New-GroupBox "Transfer + Integrity Validator"
$main.Controls.Add($gbSteps57, 1, 1)

$rm = New-Object System.Windows.Forms.TableLayoutPanel
$rm.Dock = "Fill"
$rm.ColumnCount = 1
$rm.RowCount = 2
$rm.RowStyles.Clear()
[void]$rm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 50)))
[void]$rm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 50)))
$gbSteps57.Controls.Add($rm)

$btnCopy = New-Object System.Windows.Forms.Button
$btnCopy.Text = "5) Copy source to destination (auto-verify hashes)"
$btnCopy.Dock = "Fill"
$btnCopy.Enabled = $false
$rm.Controls.Add($btnCopy, 0, 0)

$btnMakePdf = New-Object System.Windows.Forms.Button
$btnMakePdf.Text = "6) Convert log + hashes to PDF"
$btnMakePdf.Dock = "Fill"
$btnMakePdf.Enabled = $false
$rm.Controls.Add($btnMakePdf, 0, 1)

# ----------------------------
# Progress
# ----------------------------
$gbProgress = New-GroupBox "Progress"
$main.Controls.Add($gbProgress, 0, 2)
$main.SetColumnSpan($gbProgress, 2)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Dock = "Fill"
$statusLabel.Text = "Ready. Pick Destination Folder to kickstart the flow."
$statusLabel.TextAlign = "MiddleLeft"
$statusLabel.Margin = New-Object System.Windows.Forms.Padding(10)
$gbProgress.Controls.Add($statusLabel)

function Set-StatusText([string]$t) {
    Set-TextSafe $statusLabel $t
    [System.Windows.Forms.Application]::DoEvents()
}

function Lock-Ui([bool]$lock) {
    SetS 'IsBusy' $lock

    Set-EnabledSafe $btnPickDestFolder (-not $lock)
    Set-EnabledSafe $btnOpenLog        (-not $lock)
    Set-EnabledSafe $btnRefreshDevices (-not $lock)

    if ($lock) {
        Set-EnabledSafe $btnRestartAdmin $false
        Set-EnabledSafe $btnEnableWB $false
        Set-EnabledSafe $btnTestWB $false
        Set-EnabledSafe $btnPickSource $false
        Set-EnabledSafe $btnBuildManifest $false
        Set-EnabledSafe $btnCopy $false
        Set-EnabledSafe $btnMakePdf $false
        Set-EnabledSafe $btnDisableWB $false
    }
}


function Refresh-StateBox {
    $vols = Get-UsbVolumes

    $destInfo = GetS 'DestDriveInfo'
    $destInfoLine = "(none)"
    if ($destInfo) {
        $destInfoLine = ("{0}:\ Bus={1} Iface={2} Model={3}" -f
            $destInfo.DriveLetter,
            ($(if($destInfo.BusType){$destInfo.BusType}else{"?"})),
            ($(if($destInfo.InterfaceType){$destInfo.InterfaceType}else{"?"})),
            ($(if($destInfo.Model){$destInfo.Model}else{"?"}))
        )
    }

    $lines = @(
        "IsAdmin: $script:IsAdmin"
        "Busy: $(GetS 'IsBusy')"
        "Destination: $(if(GetS 'DestFolder'){GetS 'DestFolder'}else{'(not set)'})"
        "DestDrive: $(if(GetS 'DestDriveLetter'){"$(GetS 'DestDriveLetter'):"}else{'(not set)'})"
        "DestDriveInfo: $destInfoLine"
        "DestOverrideAccepted: $(GetS 'DestOverrideAccepted')"
        ""
        "WriteBlockEnabled: $(GetS 'WriteBlockEnabled')"
        "TestPassed: $(GetS 'TestPassed')"
        ""
        "EvidenceDriveLetter: $(if(GetS 'EvidenceDriveLetter'){"$(GetS 'EvidenceDriveLetter'):\\"}else{'(not set)'})"
        "SourcePath: $(if(GetS 'SourcePath'){GetS 'SourcePath'}else{'(not set)'})"
        "Algorithm: $(GetS 'Algo')"
        "ManifestCsv: $(if(GetS 'ManifestCsv'){GetS 'ManifestCsv'}else{'(not set)'})"
        ""
        "Copied: $(GetS 'Copied')"
        "Verified: $(GetS 'Verified')"
        "VerifySummary: $(if(GetS 'VerifySummary'){GetS 'VerifySummary'}else{'(none)'})"
        "PdfSaved: $(GetS 'PdfSaved')"
        ""
        "Last Step2: $(GetS 'LastStep2Status')"
        "Last Step2 Drive: $(if(GetS 'LastStep2Drive'){GetS 'LastStep2Drive'}else{'(none)'})"
        "Last Step2 Summary: $(if(GetS 'LastStep2Summary'){GetS 'LastStep2Summary'}else{'(none)'})"
    )

    $stateBox.Lines = $lines + @(
        ""
        "USB volumes (Removable/BusType USB):"
    ) + @(
        if (-not $vols -or $vols.Count -eq 0) { "  (none detected)" }
        else { $vols | ForEach-Object { "  " + (VolToDisplay $_) } }
    )
}

function Gate-Buttons {
    if (GetS 'IsBusy') { return }

    Set-EnabledSafe $btnRestartAdmin (-not $script:IsAdmin)

    Set-EnabledSafe $btnEnableWB ((GetS 'DestFolder') -ne $null -and $script:IsAdmin -and (-not (GetS 'WriteBlockEnabled')))
    Set-EnabledSafe $btnTestWB   ((GetS 'WriteBlockEnabled') -and (-not (GetS 'TestPassed')))
    Set-EnabledSafe $btnPickSource ((GetS 'WriteBlockEnabled') -and (GetS 'TestPassed'))
    Set-EnabledSafe $btnBuildManifest ((GetS 'SourcePath') -ne $null -and (GetS 'ManifestCsv') -eq $null)

    Set-EnabledSafe $btnCopy ((GetS 'ManifestCsv') -ne $null -and (GetS 'DestFolder') -ne $null -and (-not (GetS 'Copied')))
    Set-EnabledSafe $btnMakePdf ((GetS 'Verified') -and (-not (GetS 'PdfSaved')) -and (GetS 'DestFolder') -ne $null)

    Set-EnabledSafe $btnDisableWB $script:IsAdmin
}

function Refresh-All {
    Set-TextSafe $lblDest     ("Destination: " + ($(if(GetS 'DestFolder'){GetS 'DestFolder'}else{"(not selected)"})))
    Set-TextSafe $lblSource   ("Source: "      + ($(if(GetS 'SourcePath'){GetS 'SourcePath'}else{"(not selected)"})))
    Set-TextSafe $lblManifest ("Manifest: "    + ($(if(GetS 'ManifestCsv'){GetS 'ManifestCsv'}else{"(not created)"})))
    Refresh-StateBox
    Gate-Buttons
    $form.Refresh()
}

# ============================================================
# Events
# ============================================================
$btnRestartAdmin.Add_Click({ Restart-AsAdmin })

$btnOpenLog.Add_Click({
    try { Start-Process -FilePath "notepad.exe" -ArgumentList "`"$script:LogPath`"" | Out-Null } catch {}
})

$btnRefreshDevices.Add_Click({ Refresh-All })

$algoDrop.Add_SelectedIndexChanged({
    $a = [string]$algoDrop.SelectedItem
    SetS 'Algo' $a
    Write-Log ("Algorithm changed to: {0}" -f (GetS 'Algo'))
    Refresh-All
})

# Step 0: Choose DEST folder
$btnPickDestFolder.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "Select destination folder (on DEST external drive)"
    if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {

        $path = $dlg.SelectedPath
        $dd   = DriveFromPath $path
        if (-not $dd) { return }

        $check = Test-DestinationAcceptable -DriveLetter $dd -Owner $form
        SetS 'DestDriveInfo' $check.Info

        if (-not $check.Ok) {
            SetS 'DestFolder' $null
            SetS 'DestDriveLetter' $null
            SetS 'DestOverrideAccepted' $false

            Write-Log ("DEST rejected. Drive={0} Reason={1}" -f $dd, $check.Reason)
            [System.Windows.Forms.MessageBox]::Show(
                $form,
                ("Invalid destination.`n`n{0}" -f $check.Reason),
                "Invalid destination",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            Refresh-All
            return
        }

        SetS 'DestFolder' $path
        SetS 'DestDriveLetter' $dd
        SetS 'DestOverrideAccepted' ([bool]$check.Override)

        # Reset workflow
        SetS 'WriteBlockEnabled' $false
        SetS 'TestPassed' $false
        SetS 'EvidenceDriveLetter' $null
        SetS 'SourcePath' $null
        SetS 'ManifestCsv' $null
        SetS 'Copied' $false
        SetS 'DestCopyPath' $null
        SetS 'Verified' $false
        SetS 'VerifySummary' ""
        SetS 'PdfSaved' $false
        SetS 'PdfPath' $null

        SetS 'LastStep2Drive' $null
        SetS 'LastStep2Status' "(not run)"
        SetS 'LastStep2Summary' ""
        SetS 'LastStep2Attempts' @()

        Write-Log ("Destination selected: {0} (Drive={1}: Override={2})" -f (GetS 'DestFolder'), (GetS 'DestDriveLetter'), (GetS 'DestOverrideAccepted'))
        Set-StatusText "Destination set. Next: Step 1 Enable write-block."
        Refresh-All
    }
})

# Step 1: Enable write-block
$btnEnableWB.Add_Click({
    try {
        Set-StatusText "Enabling write-block..."
        Set-WriteBlockMode $true
        SetS 'WriteBlockEnabled' $true
        SetS 'TestPassed' $false
        Write-Log "Write-block enabled."
        Set-StatusText "Write-block enabled. Next: Step 2 test with a TEST USB."
    } catch {
        Write-Log ("ERROR enable WB: {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Error", "OK", "Error") | Out-Null
    } finally { Refresh-All }
})

# Step 2: Test write-block (excludes DEST drive)
$btnTestWB.Add_Click({
    try {
        $destDrive = GetS 'DestDriveLetter'
        if (-not $destDrive) {
            [System.Windows.Forms.MessageBox]::Show($form, "Step 0 not completed. Choose DEST first.", "Destination not set", "OK", "Warning") | Out-Null
            return
        }

        $volsAll = Get-UsbVolumes
        $vols = @($volsAll | Where-Object { $_.DriveLetter -ne $destDrive })

        if (-not $vols -or $vols.Count -eq 0) {
            SetS 'LastStep2Status' "NO TEST USB"
            SetS 'LastStep2Summary' ("No TEST USB detected (DEST is {0}:). Insert a separate TEST USB and click Step 2 again." -f $destDrive)
            SetS 'LastStep2Attempts' @()
            Refresh-All

            [System.Windows.Forms.MessageBox]::Show(
                $form,
                ("No TEST USB detected.`n`nDEST is {0}:.`nInsert a separate TEST USB, then click Step 2 again." -f $destDrive),
                "Insert TEST USB",
                "OK",
                "Information"
            ) | Out-Null
            return
        }

        $pick = New-Object System.Windows.Forms.Form
        $pick.Text = "Select TEST USB to validate write-block (NOT the DEST USB)"
        $pick.Size = New-Object System.Drawing.Size(640, 360)
        $pick.StartPosition = "CenterParent"
        $pick.TopMost = $true
        $pick.Font = $fontUI
        $pick.FormBorderStyle = "FixedDialog"
        $pick.MaximizeBox = $false
        $pick.MinimizeBox = $false
        $pick.ShowInTaskbar = $false

        $info = New-Object System.Windows.Forms.Label
        $info.AutoSize = $true
        $info.Location = New-Object System.Drawing.Point(18, 14)
        $info.Text = ("DEST is {0}:. Pick the separate TEST USB below:" -f $destDrive)
        $pick.Controls.Add($info)

        $lb = New-Object System.Windows.Forms.ListBox
        $lb.Location = New-Object System.Drawing.Point(18, 40)
        $lb.Size = New-Object System.Drawing.Size(590, 220)
        foreach ($v in $vols) { [void]$lb.Items.Add((VolToDisplay $v)) }
        $lb.SelectedIndex = 0
        $pick.Controls.Add($lb)

        $ok = New-Object System.Windows.Forms.Button
        $ok.Text = "Run test"
        $ok.Location = New-Object System.Drawing.Point(18, 275)
        $ok.Size = New-Object System.Drawing.Size(120, 36)
        $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $pick.Controls.Add($ok)

        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Text = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(150, 275)
        $cancel.Size = New-Object System.Drawing.Size(120, 36)
        $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $pick.Controls.Add($cancel)

        $pick.AcceptButton = $ok
        $pick.CancelButton = $cancel

        $dr = $pick.ShowDialog($form)
        if ($dr -ne [System.Windows.Forms.DialogResult]::OK) {
            SetS 'LastStep2Status' "CANCELLED"
            SetS 'LastStep2Summary' "User cancelled Step 2."
            SetS 'LastStep2Attempts' @()
            Write-Log "Step2 cancelled by user."
            Set-StatusText "Step 2 cancelled."
            Refresh-All
            return
        }

        $selectedText = [string]$lb.SelectedItem
        if ($selectedText -notmatch '^(?<d>[A-Z]):\\') { throw "Could not parse drive letter from selection: $selectedText" }
        $testDrive = $Matches['d']

        if ($testDrive -eq $destDrive) { throw "You selected the DEST drive. Insert/choose a separate TEST USB." }

        Set-StatusText ("Running Step 2 test on {0}:\ (3 attempts)..." -f $testDrive)

        $res = Test-WriteBlocked3x -DriveLetter $testDrive

        SetS 'LastStep2Drive' $res.Drive
        SetS 'LastStep2Status' $res.Status
        SetS 'LastStep2Summary' $res.Summary
        SetS 'LastStep2Attempts' $res.Attempts

        Write-Log ("Step2 {0} on {1} Summary={2}" -f $res.Status, $res.Drive, $res.Summary)
        foreach ($a in $res.Attempts) {
            Write-Log ("Step2 Attempt {0}: Writable={1} Detail={2}" -f $a.Attempt, $a.Writable, $a.Detail)
        }

        if ($res.Status -eq "PASS") {
            SetS 'TestPassed' $true
            Set-StatusText ("Step 2 PASS on {0}. Step 3 enabled." -f $res.Drive)
            [System.Windows.Forms.MessageBox]::Show($form, $res.Summary, "PASS", "OK", "Information") | Out-Null
        } elseif ($res.Status -eq "INCONCLUSIVE") {
            SetS 'TestPassed' $false
            Set-StatusText "Step 2 INCONCLUSIVE. Replug TEST USB and retry."
            [System.Windows.Forms.MessageBox]::Show($form, $res.Summary, "INCONCLUSIVE", "OK", "Warning") | Out-Null
        } else {
            SetS 'TestPassed' $false
            Set-StatusText "Step 2 FAIL. The TEST USB was writable."
            [System.Windows.Forms.MessageBox]::Show($form, $res.Summary, "FAIL", "OK", "Error") | Out-Null
        }
    } catch {
        Write-Log ("ERROR Step2: {0}" -f $_.Exception.ToString())
        SetS 'TestPassed' $false
        SetS 'LastStep2Status' "ERROR"
        SetS 'LastStep2Summary' $_.Exception.Message
        SetS 'LastStep2Attempts' @()
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Step 2 error", "OK", "Error") | Out-Null
    } finally { Refresh-All }
})

# Step 3: Select evidence source (file/folder)
$btnPickSource.Add_Click({
    try {
        if (-not (GetS 'WriteBlockEnabled')) { return }
        if (-not (GetS 'TestPassed')) { return }

        $p = New-Object System.Windows.Forms.Form
        $p.Text = "Select evidence source type"
        $p.Size = New-Object System.Drawing.Size(420, 170)
        $p.StartPosition = "CenterParent"
        $p.TopMost = $true
        $p.FormBorderStyle = "FixedDialog"
        $p.MaximizeBox = $false
        $p.MinimizeBox = $false
        $p.ShowInTaskbar = $false
        $p.Font = $fontUI

        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = "Choose what you want to select:"
        $lbl.AutoSize = $true
        $lbl.Location = New-Object System.Drawing.Point(16, 14)
        $p.Controls.Add($lbl)

        $btnFolder = New-Object System.Windows.Forms.Button
        $btnFolder.Text = "Folder"
        $btnFolder.Size = New-Object System.Drawing.Size(110, 34)
        $btnFolder.Location = New-Object System.Drawing.Point(16, 50)
        $btnFolder.DialogResult = [System.Windows.Forms.DialogResult]::Yes
        $p.Controls.Add($btnFolder)

        $btnFile = New-Object System.Windows.Forms.Button
        $btnFile.Text = "File"
        $btnFile.Size = New-Object System.Drawing.Size(110, 34)
        $btnFile.Location = New-Object System.Drawing.Point(140, 50)
        $btnFile.DialogResult = [System.Windows.Forms.DialogResult]::No
        $p.Controls.Add($btnFile)

        $btnCancel2 = New-Object System.Windows.Forms.Button
        $btnCancel2.Text = "Cancel"
        $btnCancel2.Size = New-Object System.Drawing.Size(110, 34)
        $btnCancel2.Location = New-Object System.Drawing.Point(264, 50)
        $btnCancel2.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $p.Controls.Add($btnCancel2)

        $p.AcceptButton = $btnFolder
        $p.CancelButton = $btnCancel2

        $choice = $p.ShowDialog($form)
        if ($choice -eq [System.Windows.Forms.DialogResult]::Cancel) { return }

        $pickedPath = $null
        if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
            $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
            $dlg.Description = "Select evidence SOURCE folder (on EVIDENCE USB)"
            if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
            $pickedPath = $dlg.SelectedPath
        } else {
            $dlg = New-Object System.Windows.Forms.OpenFileDialog
            $dlg.Title = "Select evidence SOURCE file (on EVIDENCE USB)"
            $dlg.CheckFileExists = $true
            $dlg.Multiselect = $false
            if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
            $pickedPath = $dlg.FileName
        }

        if ([string]::IsNullOrWhiteSpace($pickedPath)) { return }

        SetS 'Algo' ([string]$algoDrop.SelectedItem)
        SetS 'SourcePath' $pickedPath
        $ev = DriveFromPath $pickedPath
        SetS 'EvidenceDriveLetter' $ev

        $destDrive = GetS 'DestDriveLetter'
        if ($ev -and $destDrive -and ($ev -eq $destDrive)) {
            SetS 'SourcePath' $null
            SetS 'EvidenceDriveLetter' $null
            [System.Windows.Forms.MessageBox]::Show($form, "Source is on the SAME drive as destination. Choose a different drive.", "Invalid selection", "OK", "Error") | Out-Null
            Refresh-All
            return
        }

        SetS 'ManifestCsv' $null
        SetS 'Copied' $false
        SetS 'DestCopyPath' $null
        SetS 'Verified' $false
        SetS 'VerifySummary' ""
        SetS 'PdfSaved' $false
        SetS 'PdfPath' $null

        Write-Log ("Step3 selected SourcePath={0} EvidenceDrive={1} Algo={2}" -f (GetS 'SourcePath'), (GetS 'EvidenceDriveLetter'), (GetS 'Algo'))
        Set-StatusText "Source selected. Next: Step 4 Pre-hash."
        Refresh-All
    } catch {
        Write-Log ("ERROR Step3: {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Step 3 error", "OK", "Error") | Out-Null
    }
})

# Step 4: Pre-hash + manifest (async)
$btnBuildManifest.Add_Click({
    try {
        if (-not (GetS 'SourcePath')) { return }
        if ((GetS 'ManifestCsv')) { return }
        if (GetS 'IsBusy') { return }

        $algo = (GetS 'Algo')
        if ([string]::IsNullOrWhiteSpace($algo)) { $algo = [string]$algoDrop.SelectedItem }
        if ([string]::IsNullOrWhiteSpace($algo)) { $algo = "SHA256" }
        SetS 'Algo' $algo

        $src = (GetS 'SourcePath')

        Lock-Ui $true
        Set-StatusText ("Step 4 starting ({0})..." -f $algo)
        Write-Log ("Step4 clicked. SourcePath={0} Algo={1}" -f $src, $algo)

        $job = Start-Step4Job -SourcePath $src -Algo $algo -ManifestDir $ManDir -LogPath $script:LogPath
        SetS 'Step4Job' $job

        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 300
        SetS 'Step4Timer' $timer

        $timer.Add_Tick({
            try {
                $j = GetS 'Step4Job'
                if (-not $j) { return }

                $outs = @(Receive-Job -Job $j -Keep -ErrorAction SilentlyContinue)
                foreach ($o in $outs) {
                    if ($o -is [string] -and $o.StartsWith("PROGRESS:")) {
                        $msg = $o.Substring(9).Trim()
                        if ($msg) { Set-StatusText $msg }
                    } elseif ($o -is [pscustomobject] -and $o.Type -eq "RESULT") {
                        $csv = [string]$o.Csv
                        SetS 'ManifestCsv' $csv

                        $t = GetS 'Step4Timer'
                        if ($t) { $t.Stop(); $t.Dispose(); SetS 'Step4Timer' $null }
                        try { Remove-Job -Job $j -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
                        SetS 'Step4Job' $null

                        Lock-Ui $false
                        Refresh-All

                        Set-StatusText "Step 4 complete. Manifest created."
                        [System.Windows.Forms.MessageBox]::Show($form, ("Manifest created:`n{0}" -f $csv), "Step 4 complete", "OK", "Information") | Out-Null
                        return
                    }
                }

                if ($j.State -in @("Failed","Stopped")) {
                    $errText = ""
                    try { $errText = (($j.ChildJobs[0].Error | Out-String).Trim()) } catch {}
                    if ([string]::IsNullOrWhiteSpace($errText)) { $errText = "Step 4 job failed." }

                    Write-Log ("ERROR Step4 job: {0}" -f $errText)

                    $t = GetS 'Step4Timer'
                    if ($t) { $t.Stop(); $t.Dispose(); SetS 'Step4Timer' $null }
                    try { Remove-Job -Job $j -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
                    SetS 'Step4Job' $null

                    Lock-Ui $false
                    Refresh-All

                    [System.Windows.Forms.MessageBox]::Show($form, $errText, "Step 4 error", "OK", "Error") | Out-Null
                    return
                }
            } catch { Write-Log ("ERROR Step4 timer: {0}" -f $_.Exception.ToString()) }
        })

        $timer.Start()
    } catch {
        Write-Log ("ERROR Step4 (click): {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Step 4 error", "OK", "Error") | Out-Null
        Lock-Ui $false
        Refresh-All
    }
})

# Step 5: Copy + auto verify
$btnCopy.Add_Click({
    try {
        if (-not (GetS 'ManifestCsv')) { return }
        if (-not (GetS 'SourcePath'))  { return }
        if (-not (GetS 'DestFolder'))  { return }

        Set-StatusText "Step 5 copying to destination..."
        Write-Log ("Step5 start copy. Source={0} DestFolder={1}" -f (GetS 'SourcePath'), (GetS 'DestFolder'))

        $destPath = Copy-SourceToDestination -SourcePath (GetS 'SourcePath') -DestFolder (GetS 'DestFolder')
        SetS 'DestCopyPath' $destPath
        SetS 'Copied' $true
        Write-Log ("Step5 copy complete. DestPath={0}" -f $destPath)

        Set-StatusText "Step 5 verifying destination hashes..."
        Write-Log "Step5 verification started (post-copy)."

        $verify = Verify-DestinationAgainstManifest `
            -SourcePath (GetS 'SourcePath') `
            -DestCopyPath $destPath `
            -ManifestCsv (GetS 'ManifestCsv') `
            -Algo (GetS 'Algo')

        if ($verify.Pass) {
            SetS 'Verified' $true
            $sum = "HASH VERIFY: PASS ($($verify.Total) file(s) checked)."
            SetS 'VerifySummary' $sum
            Write-Log $sum
            Set-StatusText "Step 5 complete + hash verified. Next: Step 6 PDF."

            [System.Windows.Forms.MessageBox]::Show(
                $form,
                ("Copy complete + verified:`n{0}`n`n{1}" -f $destPath, $sum),
                "Step 5 complete",
                "OK",
                "Information"
            ) | Out-Null
        } else {
            SetS 'Verified' $false
            $sum = "HASH VERIFY: FAIL ($($verify.BadCount)/$($verify.Total) problem(s))."
            SetS 'VerifySummary' $sum
            Write-Log $sum

            $example = ""
            if ($verify.BadItems -and $verify.BadItems.Count -gt 0) {
                $b = $verify.BadItems[0]
                $example = "`nExample: $($b.Status) - $($b.RelativePath)"
            }

            Set-StatusText "Copy done but hash verification FAILED."
            [System.Windows.Forms.MessageBox]::Show(
                $form,
                ($sum + $example),
                "Integrity verification FAILED",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    } catch {
        SetS 'Verified' $false
        $sum = "HASH VERIFY: ERROR - " + $_.Exception.Message
        SetS 'VerifySummary' $sum
        Write-Log ("ERROR Step5: {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Step 5 error", "OK", "Error") | Out-Null
    } finally { Refresh-All }
})

# Step 6: PDF
$btnMakePdf.Add_Click({
    try {
        if (-not (GetS 'Verified'))   { return }
        if (-not (GetS 'DestFolder')) { return }

        $pdfPath = Join-Path (GetS 'DestFolder') ("EvidenceTransferReport_{0}.pdf" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        $tmpTxt  = Join-Path $env:TEMP ("EvidenceTransferReport_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

        Build-ReportTextFile -LogPath $script:LogPath -OutTextFile $tmpTxt -ManifestCsv (GetS 'ManifestCsv')

        Set-StatusText "Step 6 generating PDF (includes hashes)..."
        Write-Log ("Step6 start PDF. ReportTxt={0} Pdf={1}" -f $tmpTxt, $pdfPath)

        Save-TextAsPdfRobust -TextFile $tmpTxt -PdfFile $pdfPath
        Remove-Item -LiteralPath $tmpTxt -Force -ErrorAction SilentlyContinue | Out-Null

        SetS 'PdfPath'  $pdfPath
        SetS 'PdfSaved' $true

        Write-Log ("Step6 PDF saved: {0}" -f $pdfPath)
        Set-StatusText "Step 6 complete. PDF saved."

        [System.Windows.Forms.MessageBox]::Show($form, ("PDF saved (with hashes):`n{0}" -f $pdfPath), "Step 6 complete", "OK", "Information") | Out-Null
    } catch {
        Write-Log ("ERROR Step6: {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Step 6 error", "OK", "Error") | Out-Null
    } finally { Refresh-All }
})

# Final: Disable write-block
$btnDisableWB.Add_Click({
    try {
        if (-not $script:IsAdmin) { throw "Admin required to disable write-block." }

        $ans = [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Disable write-block now?",
            "Confirm",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }

        Set-StatusText "Disabling write-block..."
        Set-WriteBlockMode $false
        SetS 'WriteBlockEnabled' $false
        SetS 'TestPassed' $false
        Write-Log "Write-block disabled."
        Set-StatusText "Write-block disabled."
        [System.Windows.Forms.MessageBox]::Show($form, "Write-block disabled.", "Done", "OK", "Information") | Out-Null
    } catch {
        Write-Log ("ERROR disable WB: {0}" -f $_.Exception.ToString())
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Error", "OK", "Error") | Out-Null
    } finally { Refresh-All }
})

# Init
$form.Add_Shown({ Refresh-All })
Refresh-All
[void]$form.ShowDialog()

# Cleanup
try {
    $t = GetS 'Step4Timer'
    if ($t) { $t.Stop(); $t.Dispose() }
} catch {}
try {
    $j = GetS 'Step4Job'
    if ($j) { Stop-Job $j -Force -ErrorAction SilentlyContinue; Remove-Job -Job $j -Force -ErrorAction SilentlyContinue | Out-Null }
} catch {}

Write-Log "=== Application exited ==="
if ($script:RequestedRestartAsAdmin) { return }
