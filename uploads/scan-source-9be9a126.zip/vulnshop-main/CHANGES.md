# VulnShop UI Redesign — Changes

## What changed

The app now has a **shop-floor aesthetic** for the front and a **security lab** for the back room. Two distinct visual voices tell you which part you're in.

### Visual & UX

- **Stylesheet**: Single inline CSS file (`static/vulnshop.css`) — no external assets, works offline in Docker.
- **Two-room design**: Warm paper palette (shop) vs. hazard-tape yellow + black (lab).
- **Deterministic product art**: Each product gets a unique pattern from its ID, no image files.
- **Interactive lab**: Every endpoint has a working form so you can fire payloads without leaving the page.
- **Readable code**: All templates use semantic HTML5, ARIA labels, and keyboard navigation.

### New routes

- `GET /orders` — Customer's order history (requires login). Shows IDOR vulnerability.
- `POST /buy` — Place an order. Redirects to `/orders?placed={id}` with a receipt link.
- CSS is served from `GET /static/vulnshop.css` (Flask's built-in static folder).

### Template updates

- **base.html**: New header with search, sticky nav, two-tier navigation (shop + lab).
- **index.html**: Hero pitch, sample products, threshold divider, lab snippet index.
- **search.html**: Better form UI, search chips with SQLi example, helpful empty state.
- **product.html**: Full detail page with rotated price sticker, buy form, IDOR note.
- **orders.html**: Table of user's orders, receipt links, IDOR disclosure in lab note.
- **login.html**: Credentials table pre-filled, click-to-fill chips, session cookie note.
- **admin.html**: Stats cards, customer + order tables, unauth disclosure alert.
- **sitemap.html** (was very bare): Now a full **security lab** — every endpoint with a form, payload examples, inline notes.
- **macros.html**: New — shared card templates for products and lab entries.

### Design rationale

1. **One stylesheet**: Self-contained, no CDN, works in Docker. Organized into logical sections (base, header, shell, cards, forms, tables, alerts, back room, footer).

2. **Palette**:
   - Shop: warm paper (#FFFCF6), purple brand (#4A2FBD), coral accent (#FF6B4A).
   - Lab: same colors + hazard tape (yellow #FFC93C, black #221E2E) for a visual break.
   - Full dark-mode support with `@media (prefers-color-scheme: dark)`.

3. **Typography**: System fonts (Trebuchet/Segoe UI) for body, monospace for lab. No custom fonts = no file downloads.

4. **Signature element**: The price sticker on product detail — rotated -7deg, dashed border, cropped at the corner. Feels retail, memorable, unique to this brand.

5. **Lab UX**: Each defect is a card with:
   - Method badge (GET/POST).
   - Plain-English description.
   - Direct link to the vulnerable endpoint.
   - Pre-filled form or button to fire it.
   - Optional: inline output or a note on why it's interesting.

6. **Accessibility**: Focus states, ARIA labels, semantic headings, skip link, reduced-motion support.

### How to test

```bash
cd /home/cystar/analyser/vulnshop

# Build and run
docker compose up -d

# Open in browser
open http://127.0.0.1:5000
```

Browse the shop floor (products, search, login, orders), then hit **Security Lab** in the nav to open the back room and fire payloads.

### Teardown

```bash
docker compose down -v
```

---

## Testing checklist

- [ ] Page load: no 404s on `/`, `/search`, `/product/1`, `/login`, `/admin`, `/sitemap`.
- [ ] Search: try `shirt`, `mug`, then `x' OR '1'='1` (SQLi chip).
- [ ] Product detail: sticker is visible and rotated.
- [ ] Login: credentials table is shown; try `admin`/`admin123`.
- [ ] Orders: place an order, see it in `/orders`, try `/api/orders/1` (IDOR).
- [ ] Admin: page loads and lists users + orders without login.
- [ ] Lab (sitemap): every form fires without errors; payloads show output.
- [ ] Dark mode: `prefers-color-scheme: dark` works (browser DevTools → Rendering → emulate).
- [ ] Mobile: resizes cleanly down to 320px (no horizontal scroll).
- [ ] CSS: `curl -s http://127.0.0.1:5000/static/vulnshop.css | head -20` returns valid CSS (not 404).
- [ ] No console errors: open DevTools → Console on every major page.

---

## Files touched

```
vulnshop/
├── app.py                    # Added /orders, /buy routes; updated others for templates
├── static/vulnshop.css       # NEW — 500+ lines, all sections inline
├── templates/
│   ├── base.html             # Complete rewrite (header, nav, footer)
│   ├── index.html            # Complete rewrite (hero, product grid, lab snippet)
│   ├── search.html           # Rewrite (form, chips, better table)
│   ├── product.html          # Rewrite (full detail, sticker, lab note)
│   ├── orders.html           # NEW — customer order history + IDOR note
│   ├── login.html            # Rewrite (creds table, click-fill, session note)
│   ├── admin.html            # Rewrite (stats, better tables, alert)
│   ├── sitemap.html          # Complete rewrite (security lab with forms)
│   └── macros.html           # NEW — product_card, lab_link helpers
```

No changes to `Dockerfile`, `docker-compose.yml`, `seed.py`, `requirements.txt`, or `.dockerignore`.
