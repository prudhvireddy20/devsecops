# VulnShop — Deliberately Vulnerable Target for TraceON

> ⚠️ **SAFETY FIRST** — This app contains **real RCE** (command injection + SSTI). It binds to `127.0.0.1:5000` only. **Never expose to the internet.** Tear down after the workshop: `docker compose down -v`.

---

## Quick Start

```bash
# 1. Confirm TraceON network name (default: dynamic-code_app-network)
docker network ls | grep app-network

# 2. If different, export it:
# export TRACEON_NETWORK=your-network-name

# 3. Start VulnShop
cd /home/cystar/analyser/vulnshop
docker compose up -d

# 4. Verify health
curl -fsS http://127.0.0.1:5000/health
```

## Target URL for TraceON

```
http://vulnshop:5000
```

Paste this into TraceON's **Target URL** field when creating a scan/project.

---

## Demo Scan Settings (Fast)

| Setting | Value |
|---------|-------|
| Profile | `blackbox` |
| Scan Depth | `3` |
| Max Children | `10` |
| Path Fuzzing | **Off** (turn on for `/backup.zip`, `/.env`) |
| Server Audit | **Off** (turn on for Nikto) |
| AJAX Spider | **Off** (default) |

These settings give a ~3-5 minute scan that reliably finds the demo vulns.

---

## Expected Findings (Auto-Detected)

| # | Vulnerability | Endpoint | Detected By |
|---|---------------|----------|-------------|
| 1 | SQL Injection | `GET /search?q=` | ZAP active, SQLMap |
| 2 | Reflected XSS + SSTI | `GET /greet?name=` | ZAP active, Dalfox |
| 3 | Command Injection | `GET /api/ping?host=` | ZAP active |
| 4 | Path Traversal | `GET /download?file=` | ZAP active |
| 5 | Open Redirect | `GET /redirect?url=` | ZAP active |
| 6 | Exposed `/.env` | `GET /.env` | Nuclei, ffuf, Nikto |
| 7 | Exposed `/backup.zip` | `GET /backup.zip` | ffuf, Feroxbuster, Nikto |
| 8 | Unauthenticated `/admin` | `GET /admin` | Nuclei, Nikto |
| 9 | Missing Security Headers | All responses | ZAP passive |
| 10 | Insecure Session Cookie | `POST /login` | ZAP passive |
| 11 | Stack Trace Disclosure | `GET /boom` | ZAP passive |

**Total: 11 findings** — well above the **>2** threshold for LLM synthesis.

---

## Manual Demo Endpoints (Not Auto-Detected)

| Vulnerability | Endpoint | Why Not Auto |
|---------------|----------|--------------|
| IDOR | `GET /api/orders/<id>` | Scanners can't infer ownership |
| XXE | `POST /api/import` (XML body) | ZAP spider doesn't POST XML |
| Hardcoded Secrets | `app.py` module scope | SAST, not DAST |
| Weak Credentials | `admin` / `admin123` | Payoff for SQLi demo |

---

## Quick Manual Verification

```bash
# SQL Injection
curl -s "http://127.0.0.1:5000/search?q=x'+OR+'1'='1"

# SSTI (renders 49)
curl -s "http://127.0.0.1:5000/greet?name={{7*7}}"

# Command Injection
curl -s "http://127.0.0.1:5000/api/ping?host=1;id"

# Path Traversal
curl -s "http://127.0.0.1:5000/download?file=../../etc/passwd"

# Missing Headers
curl -sI "http://127.0.0.1:5000/"
```

**From scanner containers (what actually matters):**
```bash
docker exec traceon-zap     curl -fsS http://vulnshop:5000/health
docker exec traceon-backend curl -fsS http://vulnshop:5000/health
```

---

## Discoverability (Why the Demo Works)

The home page (`/`) links **every** auto-detectable endpoint with a benign default parameter:

- `/search?q=shirt`
- `/greet?name=guest`
- `/api/ping?host=127.0.0.1`
- `/download?file=readme.txt`
- `/redirect?url=/`
- `/admin`
- `/login`
- `/boom`
- `/.env`
- `/backup.zip`

Plus:
- `robots.txt` with `Disallow: /admin, /backup.zip, /.env`
- `/sitemap` page linking everything

ZAP's standard spider (AJAX spider off by default) follows these links and fuzzes the parameters.

---

## Teardown

```bash
docker compose down -v
```

The `-v` removes the SQLite volume (`vulnshop-data`).

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    docker network: app-network               │
├──────────────┬──────────────┬──────────────┬────────────────┤
│  traceon-    │  traceon-    │  traceon-    │  vulnshop      │
│  backend     │  zap         │  frontend    │  (this app)    │
│              │              │              │  :5000         │
└──────────────┴──────────────┴──────────────┴────────────────┘
```

- VulnShop joins the **existing** TraceON network (`dynamic-code_app-network`) via external compose
- TraceON scans `http://vulnshop:5000` — resolves inside the shared network
- Port `127.0.0.1:5000` on host for local browsing only
- No changes to production `docker-compose.yml`, `Dockerfile`, or `.gitignore`

---

## File Layout

```
/home/cystar/analyser/vulnshop/
├── app.py              # Flask app (all routes + vulns)
├── seed.py             # SQLite seeder
├── requirements.txt    # flask, lxml
├── Dockerfile          # python:3.12-slim + iputils-ping
├── docker-compose.yml  # joins external network
├── .dockerignore
├── templates/          # 6 Jinja2 templates
├── files/              # readme.txt + backup.zip
└── README.md
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `vulnshop:5000` not reachable from ZAP | Confirm `docker network ls | grep app-network` matches `TRACEON_NETWORK` |
| Scan finds < 3 findings | Increase `scan_depth` to 5, ensure `max_children >= 10` |
| Path fuzzing misses `/.env` | Enable `path_fuzzing: true` in scan config |
| `host.docker.internal` errors | You're using `http://vulnshop:5000` — no rewrite needed |
| Permission denied on `/data` | Run `docker compose down -v && docker compose up -d` |