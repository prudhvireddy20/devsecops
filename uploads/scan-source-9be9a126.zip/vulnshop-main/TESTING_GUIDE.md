# VulnShop Testing Guide

The redesigned app is **live at http://127.0.0.1:5000** in a Docker container. Here's how to explore it.

---

## Quick Start

```bash
cd /home/cystar/analyser/vulnshop

# If not running, start it:
docker-compose up -d --build

# If running stale code, rebuild:
docker-compose down -v
docker-compose up -d --build

# Stop when done:
docker-compose down -v
```

Open **http://127.0.0.1:5000** in a browser.

---

## What You'll See

### 1. **Home Page** (`/`)
- Hero pitch explaining what VulnShop is
- "What's in stock today" sidebar (sales receipt aesthetic)
- 8-item product grid below
- Threshold divider into the security lab
- Lab index (snippet of the 15 defects)

### 2. **Shop Floor**

#### Search (`/search`)
- Product search by name or description
- Try `shirt`, `mug`, `hoodie`
- **Try the SQLi chip**: `x' OR '1'='1` — SQL concatenation vulnerability
- Empty state if nothing matches

#### Product Detail (`/product/1`)
- Full product description
- Rotated price sticker (design detail)
- "Place order" button if signed in
- Lab note about IDOR vulnerability

#### Login (`/login`)
- Username & password form
- Pre-filled credentials table (admin / alice / bob / charlie / diana)
- **Click any name** in the table to auto-fill username & password
- Session note: plaintext comparison, insecure cookie flags

#### Your Orders (`/orders`)
- List of orders you placed (after login)
- "View JSON" link for each order
- Lab note: **try changing the order id in the URL** — you'll see other users' orders (IDOR)

### 3. **Back Office**

#### Admin Panel (`/admin`)
- Full user table (no login required!)
- Recent orders
- Stats cards
- Alert: "This panel has no access control"

#### Security Lab (`/sitemap`)
- **15 vulnerability cards** organized in three groups:
  1. **Input it trusts** — 6 web vulns (SQLi, XSS, SSTI, RCE, path traversal, XXE)
  2. **Data it hands out** — 4 exposure vulns (IDOR, unauth admin, exposed secrets, stack trace)
  3. **Configuration issues** — 4 code-review-only findings (plaintext passwords, hardcoded secrets, insecure cookies, missing headers)

- Each card has:
  - Method badge (GET or POST)
  - Plain-English description
  - Direct link to the vulnerable endpoint
  - Pre-filled form or button to fire the payload
  - (Forms open a new tab so you stay on the lab page)

---

## Testing the Vulnerabilities

### SQLi Example
1. Go to `/search`
2. In the search field, enter: `x' OR '1'='1`
3. See: all products returned (instead of just matches)
4. Watch: result count jumps from 1 to 12

### SSTI Example
1. Go to `/sitemap`
2. Find the "Reflected XSS + SSTI" card
3. In the input field, clear the placeholder and enter: `{{7*7}}`
4. Click "Fire"
5. See: a new tab opens to `/greet?name={{7*7}}`
6. Watch: page says "Hello, 49!" (template expression was evaluated)

### IDOR Example
1. Sign in with `admin` / `admin123`
2. Go to a product page and place an order
3. Click "Your orders" → `/orders`
4. Click any receipt link (e.g., `/api/orders/1`)
5. In the URL bar, change the id: `/api/orders/1` → `/api/orders/2` → `/api/orders/3`
6. See: full JSON of orders belonging to other users, unguarded

### Command Injection Example
1. Go to `/sitemap`
2. Find the "Command Injection" card
3. In the input, replace `127.0.0.1` with: `127.0.0.1;id`
4. Click "Fire"
5. See: ping output, then the output of `id` command (uid=0, gid=0, etc.)

### Path Traversal Example
1. Go to `/sitemap`
2. Find the "Path Traversal" card
3. In the input, enter: `../../etc/passwd`
4. Click "Fire"
5. See: contents of `/etc/passwd` (or permission denied if Docker restricts it)

### Admin Panel (No Auth)
1. Go directly to `/admin` (no login required)
2. See: full user table + all recent orders
3. Note: `robots.txt` lists this under `Disallow`, so scanners find it

### Exposed Secrets
1. Click `/.env` in the lab → see fake API keys, admin password, database URL
2. Click `/backup.zip` → download a fake backup file
3. Note: both are routes in the app, not static files

### Stack Trace
1. Click `/boom` in the lab
2. See: full Python traceback with filenames, line numbers, local variables
3. Note: this is what production apps leak in 500 errors

---

## Key Credentials

Use anywhere they're needed (login form, XXE, etc.):

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | Admin |
| `alice` | `alice123` | Customer |
| `bob` | `bob123` | Customer |
| `charlie` | `charlie123` | Customer |
| `diana` | `diana123` | Customer |

All stored as plaintext in the database (intentional).

---

## Design Notes

### Visual Structure
- **Shop floor** (light, warm palette): home, search, products, login, orders
- **Back room** (hazard-tape yellow + black): admin, security lab
- **Threshold divider**: yellow/black stripe on the home page marks the transition

### CSS & Assets
- Single stylesheet: `/static/vulnshop.css` (24 KB, no CDN)
- System fonts only (no Google Fonts)
- Deterministic product art (CSS patterns, not images)
- Price sticker on product detail rotated -7°

### Accessibility
- Semantic HTML5 (`<button>`, `<form>`, `<main>`, etc.)
- ARIA labels on forms
- Focus states (3px purple outline)
- Keyboard navigation works everywhere
- Dark mode supported (system preference)
- Reduced motion respected

---

## Testing With Security Scanners

The app is designed to be found and tested by tools like ZAP, Nikto, and Nuclei:

**Good scan settings:**
- Scan depth: 3–5
- Max children per node: 10+
- Path fuzzing: on (to find `/.env`, `/backup.zip`, `/admin`)
- AJAX spider: off (default; not needed here)
- Active scanning: on
- Passive scanning: on

**Expected findings:**
- 11 active scanner findings (SQLi, XSS, RCE, path traversal, open redirect, XXE, IDOR, exposed files, missing headers, stack trace)
- 4 passive findings (plaintext passwords, session cookie flags, hardcoded secrets in code)

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Container won't start | `docker logs vulnshop` to see the error |
| CSS not loading | Rebuild: `docker-compose down -v && docker-compose up -d --build` |
| Port 5000 already in use | `docker-compose down && kill $(lsof -t -i:5000) && docker-compose up -d` |
| Database errors | `docker-compose down -v` (clears the persistent volume) |
| Page 500 errors | Check `/boom` to see a real 500 response; others should all be 200 |

---

## What's New vs. Original

**Original:**
- Bare-bones templates (no styling)
- Single sitemap page linking endpoints
- No order flow
- No login session support
- Focus on demonstrating vulnerabilities

**Redesigned:**
- Professional storefront aesthetic
- Two visual zones (shop + lab)
- Complete order/IDOR demo flow
- Session-based login
- 15 organized, runnable vulnerability cards
- Self-contained CSS (no external dependencies)
- Mobile-responsive
- Dark mode support
- Accessible (ARIA, keyboard nav, focus states)

All vulnerabilities remain **exactly the same** — only the UI and UX are improved.

---

## Next Steps

1. **Browse the shop**: feel the retail aesthetic
2. **Place an order**: test the IDOR vulnerability
3. **Open the security lab**: fire payloads from the cards
4. **Run a scanner**: watch ZAP or Nikto find the defects
5. **Read the code**: see how each vulnerability works in `app.py`

Enjoy! The app is meant to be broken in obvious ways.
