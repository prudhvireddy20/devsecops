from __future__ import annotations

import os
import sqlite3
import subprocess
import traceback
from pathlib import Path

from flask import Flask, render_template, render_template_string, request, session, redirect, url_for, make_response, send_file
from lxml import etree

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key-change-in-production'

DB_PATH = Path('/data/vulnshop.db')
FILES_DIR = Path('/app/files')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    FILES_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            is_admin BOOLEAN DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            total REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
    """)

    try:
        conn.execute('ALTER TABLE products ADD COLUMN image_url TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        for pid, url in PRODUCT_IMAGES.items():
            conn.execute('UPDATE products SET image_url = ? WHERE id = ? AND (image_url IS NULL OR image_url = "")', (url, pid))
    except Exception:
        pass

    conn.commit()
    conn.close()


PRODUCT_IMAGES = {
    1: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80',
    2: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&auto=format&fit=crop&q=80',
    3: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
    4: 'https://images.unsplash.com/photo-1572375992501-4b0892d50c69?w=600&auto=format&fit=crop&q=80',
    5: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=600&auto=format&fit=crop&q=80',
    6: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=600&auto=format&fit=crop&q=80',
    7: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=600&auto=format&fit=crop&q=80',
    8: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
    9: 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=600&auto=format&fit=crop&q=80',
    10: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&auto=format&fit=crop&q=80',
    11: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&auto=format&fit=crop&q=80',
    12: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=600&auto=format&fit=crop&q=80',
}


@app.context_processor
def inject_stats():
    """Make counts and product images available to all templates."""
    conn = get_db()
    stats = {
        'total_products': conn.execute('SELECT COUNT(*) as c FROM products').fetchone()['c'],
        'total_users': conn.execute('SELECT COUNT(*) as c FROM users').fetchone()['c'],
        'total_orders': conn.execute('SELECT COUNT(*) as c FROM orders').fetchone()['c'],
        'product_images': PRODUCT_IMAGES,
    }
    conn.close()
    return stats


def get_lab_entries():
    """Lab endpoints for the security lab page."""
    return [
        {
            'method': 'GET',
            'title': 'SQL Injection',
            'what': 'The q parameter is concatenated into SQL with no binding.',
            'path': '/search?q=shirt',
        },
        {
            'method': 'GET',
            'title': 'Reflected XSS + SSTI',
            'what': 'User input rendered with Jinja2 without escaping.',
            'path': '/greet?name=guest',
        },
        {
            'method': 'GET',
            'title': 'Command Injection',
            'what': 'Host parameter passed to shell ping command.',
            'path': '/api/ping?host=127.0.0.1',
        },
        {
            'method': 'GET',
            'title': 'Path Traversal',
            'what': 'File parameter not sanitized for .. sequences.',
            'path': '/download?file=readme.txt',
        },
        {
            'method': 'GET',
            'title': 'Open Redirect',
            'what': 'URL parameter passed directly to redirect().',
            'path': '/redirect?url=/',
        },
        {
            'method': 'GET',
            'title': 'IDOR',
            'what': 'Order endpoint returns any order by id, no ownership check.',
            'path': '/api/orders/1',
        },
        {
            'method': 'POST',
            'title': 'XXE (XML External Entity)',
            'what': 'XML parser accepts external entity declarations.',
            'path': '/api/import',
        },
    ]


@app.route('/health')
def health():
    return {'status': 'ok'}, 200


@app.route('/robots.txt')
def robots():
    return 'User-agent: *\nDisallow: /admin\nDisallow: /backup.zip\nDisallow: /.env\n', 200, {'Content-Type': 'text/plain'}


@app.route('/')
def index():
    conn = get_db()
    products = conn.execute('SELECT * FROM products LIMIT 8').fetchall()
    conn.close()
    return render_template('index.html', products=products, lab_entries=get_lab_entries())


@app.route('/search')
def search():
    q = request.args.get('q', '')
    conn = get_db()
    if q:
        query = f"SELECT * FROM products WHERE name LIKE '%{q}%' OR description LIKE '%{q}%'"
        products = conn.execute(query).fetchall()
    else:
        products = conn.execute('SELECT * FROM products').fetchall()
    conn.close()
    return render_template('search.html', products=products, query=q)


@app.route('/product/<int:product_id>')
def product(product_id):
    conn = get_db()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    conn.close()
    if not product:
        return render_template('404.html',
                               heading='No such product',
                               detail=f'Nothing on the shelf has id {product_id}.'), 404
    return render_template('product.html', product=product)


# The greeting page is assembled as template *source* around whatever the visitor
# sends, then handed to the renderer — which is exactly why it is injectable.
GREET_TOP = """{% extends "base.html" %}
{% block title %}Greeting - VulnShop{% endblock %}
{% block content %}
<div class="wrap"><section class="section">
<p class="eyebrow">Greeter &middot; renders whatever it is handed</p>
<div class="card">
"""

GREET_BOTTOM = """
<p class="mute mb-m">That name went into the template source before rendering, so HTML tags run as
markup and <code>{{ '{{' }} ... {{ '}}' }}</code> runs as a template expression.</p>
<form class="inline-form" method="GET" action="/greet">
  <label class="sr-only" for="name">Name</label>
  <input id="name" type="text" name="name" value="guest" placeholder="Your name">
  <button class="btn btn--sm" type="submit">Greet me</button>
</form>
<div class="chips">
  <span class="mute mono chips__label">Try:</span>
  <a class="chip" href="/greet?name=guest">guest</a>
  <a class="chip" href="/greet?name=%7B%7B7*7%7D%7D">{{ '{{7*7}}' }}</a>
  <a class="chip" href="/greet?name=%3Cs%3Estruck%3C/s%3E">&lt;s&gt;struck&lt;/s&gt;</a>
</div>
</div>
<p class="mute mt-m"><a href="/sitemap">&larr; Back to the security lab</a></p>
</section></div>
{% endblock %}
"""


@app.route('/greet')
def greet():
    name = request.args.get('name', 'guest')
    template = f"<h1>Hello, {name}!</h1>"
    return render_template_string(GREET_TOP + template + GREET_BOTTOM)


@app.route('/api/ping')
def api_ping():
    host = request.args.get('host', '127.0.0.1')
    try:
        result = subprocess.run(
            ['sh', '-c', f'ping -c 3 {host}'],
            capture_output=True,
            text=True,
            timeout=10
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        output = 'Timeout'
    except Exception as e:
        output = str(e)
    return {'host': host, 'output': output}


@app.route('/download')
def download():
    filename = request.args.get('file', 'readme.txt')
    filepath = FILES_DIR / filename
    try:
        return send_file(str(filepath))
    except Exception:
        return render_template('404.html',
                               heading='No such file',
                               detail=f'Nothing readable at {filepath}.'), 404


@app.route('/redirect')
def redirect_route():
    url = request.args.get('url', '/')
    return redirect(url)


@app.route('/admin')
def admin():
    conn = get_db()
    users = conn.execute('SELECT id, username, email, is_admin FROM users').fetchall()
    orders = conn.execute('''
        SELECT o.*, u.username, p.name as product_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN products p ON o.product_id = p.id
        ORDER BY o.id DESC
        LIMIT 20
    ''').fetchall()
    stats = {
        'users': conn.execute('SELECT COUNT(*) as c FROM users').fetchone()['c'],
        'products': conn.execute('SELECT COUNT(*) as c FROM products').fetchone()['c'],
        'orders': conn.execute('SELECT COUNT(*) as c FROM orders').fetchone()['c'],
        'revenue': conn.execute('SELECT SUM(total) as sum FROM orders').fetchone()['sum'] or 0,
    }
    conn.close()
    return render_template('admin.html', users=users, orders=orders, stats=stats)


@app.route('/api/orders/<int:order_id>')
def api_order(order_id):
    conn = get_db()
    order = conn.execute('''
        SELECT o.*, u.username, p.name as product_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN products p ON o.product_id = p.id
        WHERE o.id = ?
    ''', (order_id,)).fetchone()
    conn.close()
    if not order:
        return {'error': 'Not found'}, 404
    return dict(order)


@app.route('/api/import', methods=['POST'])
def api_import():
    xml_data = request.get_data(as_text=True)
    parser = etree.XMLParser(resolve_entities=True)
    try:
        root = etree.fromstring(xml_data.encode(), parser=parser)
        items = [child.text for child in root]
        return {'imported': items}
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        conn = get_db()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, password)
        ).fetchone()
        conn.close()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['is_admin'] = user['is_admin']
            return redirect(url_for('index'))
        return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    placed = request.args.get('placed')
    conn = get_db()
    user_orders = conn.execute('''
        SELECT o.*, p.name as product_name
        FROM orders o
        JOIN products p ON o.product_id = p.id
        WHERE o.user_id = ?
        ORDER BY o.created_at DESC
    ''', (session['user_id'],)).fetchall()
    conn.close()

    return render_template('orders.html', orders=user_orders, placed=placed)


@app.route('/buy', methods=['POST'])
def buy():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', 1, type=int)

    conn = get_db()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        conn.close()
        return redirect(url_for('index'))

    total = product['price'] * quantity
    cursor = conn.execute(
        'INSERT INTO orders (user_id, product_id, quantity, total) VALUES (?, ?, ?, ?)',
        (session['user_id'], product_id, quantity, total)
    )
    conn.commit()
    order_id = cursor.lastrowid
    conn.close()

    return redirect(url_for('orders', placed=order_id))


@app.route('/boom')
def boom():
    try:
        raise RuntimeError('Intentional error for stack trace demo')
    except Exception:
        tb = traceback.format_exc()
    return f'<pre>{tb}</pre>', 500


@app.route('/sitemap')
def sitemap():
    return render_template('sitemap.html')


@app.route('/.env')
def dotenv():
    return '''SECRET_KEY=dev-secret-key-change-in-production
DATABASE_URL=sqlite:///vulnshop.db
ADMIN_PASSWORD=admin123
API_KEY=sk-live-fake-key-for-demo''', 200, {'Content-Type': 'text/plain'}


@app.route('/backup.zip')
def backup_zip():
    return b'PK\x03\x04' + b'\x00' * 100, 200, {'Content-Type': 'application/zip'}


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=False)
