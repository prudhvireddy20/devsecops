VulnShop - Deliberately Vulnerable Demo App
==========================================

This directory contains files served by the /download endpoint for path traversal demos.

Files:
- readme.txt - This file (safe default)
- backup.zip - Fake backup archive (triggers exposed backup finding)

Path traversal example:
  /download?file=../../etc/passwd

The endpoint uses unsanitized join under /app/files/, so directory traversal works.