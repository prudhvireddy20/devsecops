#!/usr/bin/env python3
"""Seed the VulnShop SQLite database with demo data."""

import sqlite3
from pathlib import Path

DB_PATH = Path('/data/vulnshop.db')

def seed():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            is_admin BOOLEAN DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            total REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
    """)
    conn.execute('DELETE FROM orders')
    conn.execute('DELETE FROM products')
    conn.execute('DELETE FROM users')
    conn.commit()

    users = [
        ('admin', 'admin123', 'admin@vulnshop.local', 1),
        ('alice', 'alice123', 'alice@vulnshop.local', 0),
        ('bob', 'bob123', 'bob@vulnshop.local', 0),
        ('charlie', 'charlie123', 'charlie@vulnshop.local', 0),
        ('diana', 'diana123', 'diana@vulnshop.local', 0),
    ]
    conn.executemany(
        'INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, ?)',
        users
    )

    products = [
        ('VulnShop T-Shirt', 'Classic cotton tee with VulnShop logo', 19.99, 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80'),
        ('Hacker Hoodie', 'Comfortable hoodie for late-night coding', 44.99, 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&auto=format&fit=crop&q=80'),
        ('SQL Injection Mug', 'Ceramic mug with classic payload', 12.99, 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80'),
        ('XSS Sticker Pack', '5 vinyl stickers for your laptop', 7.99, 'https://images.unsplash.com/photo-1572375992501-4b0892d50c69?w=600&auto=format&fit=crop&q=80'),
        ('Buffer Overflow Beanie', 'Keeps your stack warm', 22.99, 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=600&auto=format&fit=crop&q=80'),
        ('RCE Tote Bag', 'Carry your exploits in style', 15.99, 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=600&auto=format&fit=crop&q=80'),
        ('IDOR Keychain', 'Access any order with this key', 5.99, 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=600&auto=format&fit=crop&q=80'),
        ('XXE XML Parser', 'Parses external entities for you', 29.99, 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80'),
        ('Path Traversal Socks', 'Step up the directory tree', 9.99, 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=600&auto=format&fit=crop&q=80'),
        ('Open Redirect Hat', 'Redirects compliments to your face', 17.99, 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&auto=format&fit=crop&q=80'),
        ('Admin Panel Pin', 'Enamel pin for unauthorized access', 6.99, 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&auto=format&fit=crop&q=80'),
        ('Stack Trace Tee', 'Wear your errors proudly', 21.99, 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=600&auto=format&fit=crop&q=80'),
    ]
    conn.executemany(
        'INSERT INTO products (name, description, price, image_url) VALUES (?, ?, ?, ?)',
        products
    )

    orders = [
        (1, 1, 2, 39.98),
        (1, 3, 1, 12.99),
        (2, 2, 1, 44.99),
        (2, 5, 1, 22.99),
        (3, 4, 3, 23.97),
        (3, 7, 2, 11.98),
        (4, 6, 1, 15.99),
        (4, 9, 1, 9.99),
        (5, 8, 1, 29.99),
        (5, 10, 2, 35.98),
    ]
    conn.executemany(
        'INSERT INTO orders (user_id, product_id, quantity, total) VALUES (?, ?, ?, ?)',
        orders
    )

    conn.commit()
    conn.close()
    print('Database seeded successfully.')

if __name__ == '__main__':
    seed()