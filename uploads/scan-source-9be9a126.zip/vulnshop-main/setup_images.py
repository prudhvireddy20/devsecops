#!/usr/bin/env python3
"""Download/copy product images into static/images/ for VulnShop."""
import shutil, os, urllib.request

SRC_DIR = "/home/cystar/.gemini/antigravity-ide/brain/90ef3a90-cb29-4634-9438-4d28b0177b5d"
DEST_DIR = "/home/cystar/analyser/vulnshop/static/images"

# Map generated images to product IDs
generated = {
    1: f"{SRC_DIR}/product_01_tshirt_1785424634605.png",
    2: f"{SRC_DIR}/product_02_hoodie_1785424646039.png",
    3: f"{SRC_DIR}/product_03_mug_1785424659414.png",
    4: f"{SRC_DIR}/product_04_stickers_1785424673107.png",
    5: f"{SRC_DIR}/product_05_beanie_1785424697070.png",
    6: f"{SRC_DIR}/product_06_tote_1785424712060.png",
}

# Curated Unsplash images for remaining products (direct image downloads)
# Using Unsplash Source API for specific images
unsplash = {
    7:  "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",  # keychain
    8:  "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&q=80",  # circuit board / tech
    9:  "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=600&q=80",  # socks
    10: "https://images.unsplash.com/photo-1521369909029-2afed882baee?w=600&q=80",  # cap/hat
    11: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80",  # enamel pin / badge
    12: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&q=80",  # black t-shirt (stack trace)
}

os.makedirs(DEST_DIR, exist_ok=True)

for pid, src in generated.items():
    dest = f"{DEST_DIR}/product_{pid:02d}.png"
    if os.path.exists(src):
        shutil.copy2(src, dest)
        print(f"Copied product_{pid:02d}.png")
    else:
        print(f"WARNING: source not found: {src}")

for pid, url in unsplash.items():
    dest = f"{DEST_DIR}/product_{pid:02d}.jpg"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r, open(dest, "wb") as f:
            f.write(r.read())
        print(f"Downloaded product_{pid:02d}.jpg")
    except Exception as e:
        print(f"ERROR downloading product_{pid:02d}: {e}")

print("Done.")
