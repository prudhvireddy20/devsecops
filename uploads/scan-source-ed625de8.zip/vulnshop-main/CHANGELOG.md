# Changelog

Development history for VulnShop, the deliberately vulnerable target used to
exercise TraceON. Newest first.

> This file replaces the earlier `ENHANCEMENTS.md`, `ENHANCEMENT_SUMMARY.md`,
> `ENHANCEMENTS_README.md`, `BEFORE_AFTER_COMPARISON.md`, `CHANGES.md` and
> `TEST_RESULTS.md`, which were snapshots of the same two work items. The
> originals remain in git history.

---

## 2026-08-04 — Correctness pass

Audit of the app against the running container. No vulnerabilities were
removed; everything here fixed something that was broken or that undermined
the lab.

### Quest mode no longer self-defeating

The `flags` table stored plaintext flags, so a single `SELECT * FROM flags`
through `/api/sql-exec` or the `/search` UNION hole handed over all ten at
once — and the documented solution to quest #1 was exactly that query.

- `flags.flag` → `flags.flag_hash`, storing SHA-256 only
- `POST /api/submit-flag` hashes the submission and compares digests
- Plaintext now lives in `flags_data.py` and in the one endpoint that
  intentionally leaks each flag. Dumping the table yields digests.

### Form-encoded POSTs returned 415

`request.form.get(x) or request.json.get(x)` was used across twelve endpoints.
In Flask 2.3+ `request.json` *raises* `UnsupportedMediaType` on a non-JSON
request rather than returning `None`, so form clients got a 415 HTML page and
an empty POST never reached its own validation branch. Scanners saw 415 and
moved on.

- Added `req_data()`, which reads a form or JSON body, whichever was sent
- Every endpoint now accepts both encodings and returns its intended JSON 400

### Password-reset quest was unobtainable

`/api/reset-password` returned a fresh `random.randint(1000, 9999)` unrelated
to the token `seed.py` had written into `reset_tokens`, so the issued token
always failed verification. The hint promised a token "derived from the email"
and nothing derived anything.

- Added `derive_reset_token()` — `int(md5(email), 16) % 9000 + 1000` — as the
  single source of truth shared by `seed.py` and the endpoint
- `/api/reset-password` stores the token instead of returning it, the way a
  real reset email works, and advertises the format
- The flag now falls to either brute force or to noticing the derivation

### SQLite connections leaked on every error path

Handlers called `conn.close()` only after a successful query, but several
endpoints raise mid-query *by design* — that is the SQL injection tell. A
scanner firing SQLi payloads leaked a handle per request (measured 2 → 9 open
handles over 40 requests).

- All handlers now use `contextlib.closing`
- `submit_flag()` rolls back after `IntegrityError`

### Comments now match the code

`/api/users` and `/api/search-advanced` documented the column and sort
parameters as injection points while whitelisting all three. The whitelists
are gone — this is a deliberately vulnerable app, so the code was brought in
line with its comments rather than the reverse. Both endpoints now reflect the
failing statement back, which is a stronger signal for scanners.

### Smaller fixes

- `init_db()` creates `reset_tokens` and backfills quest data idempotently, so
  running `python app.py` without `seed.py` no longer 500s on a missing table
- `/api/file-upload` keeps its path traversal, but refuses writes that resolve
  onto the app's own source tree — overwriting `app.py` bricked the lab for
  every other tester and survived `docker restart`
- JWT `exp` uses `datetime.now(timezone.utc)` instead of naive local time

---

## 2026-08-02 — CTF quest mode

Ten `VULNSHOP{...}` flags, each hidden behind a real vulnerability.

- `flags_data.py` as the single source of truth for flags, hints and the files
  planted on disk
- Quest board at `GET /flags`, submission via `POST /api/submit-flag`,
  standings at `GET /leaderboard` and `GET /api/leaderboard`
- `flags` and `submissions` tables; scoring is one point per distinct flag per
  player, ties broken by earliest last submission
- `seed.py` plants flag files, builds a real `backup.zip`, and seeds order 11
  with a flag in its `note` for the IDOR quest
- `exercise.md` (public) and `solution.md` (private) document the board

## 2026-08-01 — Production deployment + endpoint expansion

**Deployment.** Made the compose file Dokploy/VPS-ready: binds
`127.0.0.1:5000` behind a reverse proxy, adds a healthcheck, and drops the
persistent volume. `entrypoint.sh` deletes and re-seeds the database on every
container start, so `docker restart vulnshop` returns a clean lab and no
tester's changes persist.

**18 new vulnerable endpoints**, taking the app from ~11 findings to ~25
vulnerability classes: SSRF (`/api/fetch`), open proxy (`/api/proxy`), LDAP
injection, JWT generation/verification with a weak secret and `alg:none`
acceptance, mass assignment (`/api/register`), pickle deserialization, MD5/SHA1
hashing, weak reset tokens, directory listing, stored XSS, hardcoded API keys,
debug disclosure (`/api/debug`), enhanced XXE, arbitrary file upload, direct
SQL execution, `eval()` RCE, and a multi-injection-point search.

Also: CORS set to `Allow-Origin: *` with credentials, `Server`/`X-Powered-By`
banners, an insecure `Set-Cookie`, and PyJWT pinned to 2.13.0.

## 2026-07-30 — Product images and lab docs

- Product images seeded into the database and rendered across the UI
- First pass at `exercise.md` / `solution.md`
- Dropped the external network requirement for Dokploy compatibility

## 2026-07-28 — UI/UX redesign

Rebuilt the front end around two ideas: a **shop floor** that behaves like a
real storefront, and a **security lab** that indexes every vulnerable endpoint
with a benign default parameter so ZAP's standard spider actually reaches it.

- New `base.html` / `macros.html`, a single `vulnshop.css`, and a consistent
  card/section system
- `/sitemap` and `robots.txt` linking every auto-detectable endpoint
- Templates for search, product, orders, admin, login, and a real 404
