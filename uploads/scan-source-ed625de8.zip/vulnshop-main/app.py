from __future__ import annotations

import os
import sqlite3
import subprocess
import traceback
import hashlib
import pickle
import base64
import jwt
import requests
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

from flask import Flask, render_template, render_template_string, request, session, redirect, url_for, send_file, jsonify
from lxml import etree

from flags_data import BY_SLUG, FLAG_ROWS, derive_reset_token, flag_hash

app = Flask(__name__)
# Intentionally weak default; override with SECRET_KEY env var in production
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['CORS_ALLOW'] = True

DB_PATH = Path('/data/vulnshop.db')
FILES_DIR = Path('/app/files')

# Hardcoded API keys (intentional vulnerability)
API_KEYS = {
    'sk-1234567890abcdef': 'admin',
    'sk-0987654321fedcba': 'user',
    'super-secret-api-key-2024': 'admin'
}

# Weak JWT secret (should be strong)
JWT_SECRET = 'jwt-secret-key-hardcoded'


def get_db():
    """Open a connection. Always wrap in `closing()` - several endpoints raise
    mid-query by design (that is the SQL injection tell), and a bare
    conn.close() after the query would never run on those paths."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def req_data():
    """Read params from a form or JSON body, whichever the client sent.

    `request.json` *raises* UnsupportedMediaType on non-JSON requests in
    Flask 2.3+, so the old `request.form.get(x) or request.json.get(x)` idiom
    turned every form-encoded POST into a 415 instead of reaching the route.
    """
    if request.form:
        return request.form
    return request.get_json(silent=True) or {}


def init_db():
    """Create any missing tables and backfill quest data.

    seed.py normally does all of this; this is the safety net for someone
    running `python app.py` directly, so it has to cover every table seed.py
    creates - including reset_tokens.
    """
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    FILES_DIR.mkdir(parents=True, exist_ok=True)
    with closing(get_db()) as conn:
        _init_schema(conn)


def _init_schema(conn):
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            is_admin BOOLEAN DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            total REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS secrets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS flags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            hint TEXT NOT NULL,
            flag_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player TEXT NOT NULL,
            flag_id INTEGER NOT NULL,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(player, flag_id),
            FOREIGN KEY (flag_id) REFERENCES flags(id)
        );
        CREATE TABLE IF NOT EXISTS reset_tokens (
            email TEXT PRIMARY KEY,
            token TEXT NOT NULL
        );
    """)

    try:
        conn.execute('ALTER TABLE products ADD COLUMN image_url TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        conn.execute('ALTER TABLE orders ADD COLUMN note TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        for pid, url in PRODUCT_IMAGES.items():
            conn.execute('UPDATE products SET image_url = ? WHERE id = ? AND (image_url IS NULL OR image_url = "")', (url, pid))
    except Exception:
        pass

    # Backfill quest data if seed.py never ran. Each statement is idempotent
    # on its own, so a partially seeded DB still ends up complete.
    conn.executemany(
        'INSERT OR IGNORE INTO flags (slug, name, category, hint, flag_hash)'
        ' VALUES (?, ?, ?, ?, ?)',
        FLAG_ROWS
    )
    if conn.execute('SELECT COUNT(*) as c FROM secrets').fetchone()['c'] == 0:
        conn.executemany(
            'INSERT INTO secrets (name, value) VALUES (?, ?)',
            [
                ('sql_quest', BY_SLUG['sql_secrets']['flag']),
                ('admin_password_hint', 'admin123'),
            ]
        )
    conn.execute(
        'INSERT OR IGNORE INTO reset_tokens (email, token) VALUES (?, ?)',
        ('admin@vulnshop.local', derive_reset_token('admin@vulnshop.local'))
    )

    conn.commit()


PRODUCT_IMAGES = {
    1: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80',
    2: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&auto=format&fit=crop&q=80',
    3: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
    4: 'https://images.unsplash.com/photo-1572375992501-4b0892d50c69?w=600&auto=format&fit=crop&q=80',
    5: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=600&auto=format&fit=crop&q=80',
    6: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=600&auto=format&fit=crop&q=80',
    7: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=600&auto=format&fit=crop&q=80',
    8: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
    9: 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=600&auto=format&fit=crop&q=80',
    10: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&auto=format&fit=crop&q=80',
    11: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&auto=format&fit=crop&q=80',
    12: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=600&auto=format&fit=crop&q=80',
}


@app.context_processor
def inject_stats():
    """Make counts and product images available to all templates."""
    with closing(get_db()) as conn:
        return {
            'total_products': conn.execute('SELECT COUNT(*) as c FROM products').fetchone()['c'],
            'total_users': conn.execute('SELECT COUNT(*) as c FROM users').fetchone()['c'],
            'total_orders': conn.execute('SELECT COUNT(*) as c FROM orders').fetchone()['c'],
            'product_images': PRODUCT_IMAGES,
        }


def get_lab_entries():
    """Lab endpoints for the security lab page."""
    return [
        {
            'method': 'GET',
            'title': 'SQL Injection',
            'what': 'The q parameter is concatenated into SQL with no binding.',
            'path': '/search?q=shirt',
        },
        {
            'method': 'GET',
            'title': 'Reflected XSS + SSTI',
            'what': 'User input rendered with Jinja2 without escaping.',
            'path': '/greet?name=guest',
        },
        {
            'method': 'GET',
            'title': 'Command Injection',
            'what': 'Host parameter passed to shell ping command.',
            'path': '/api/ping?host=127.0.0.1',
        },
        {
            'method': 'GET',
            'title': 'Path Traversal',
            'what': 'File parameter not sanitized for .. sequences.',
            'path': '/download?file=readme.txt',
        },
        {
            'method': 'GET',
            'title': 'Open Redirect',
            'what': 'URL parameter passed directly to redirect().',
            'path': '/redirect?url=/',
        },
        {
            'method': 'GET',
            'title': 'IDOR',
            'what': 'Order endpoint returns any order by id, no ownership check.',
            'path': '/api/orders/1',
        },
        {
            'method': 'POST',
            'title': 'XXE (XML External Entity)',
            'what': 'XML parser accepts external entity declarations.',
            'path': '/api/import',
        },
    ]


@app.route('/health')
def health():
    return {'status': 'ok'}, 200


@app.route('/robots.txt')
def robots():
    return 'User-agent: *\nDisallow: /admin\nDisallow: /backup.zip\nDisallow: /.env\n', 200, {'Content-Type': 'text/plain'}


@app.route('/')
def index():
    with closing(get_db()) as conn:
        products = conn.execute('SELECT * FROM products LIMIT 8').fetchall()
    return render_template('index.html', products=products, lab_entries=get_lab_entries())


@app.route('/search')
def search():
    q = request.args.get('q', '')
    with closing(get_db()) as conn:
        if q:
            query = f"SELECT * FROM products WHERE name LIKE '%{q}%' OR description LIKE '%{q}%'"
            products = conn.execute(query).fetchall()
        else:
            products = conn.execute('SELECT * FROM products').fetchall()
    return render_template('search.html', products=products, query=q)


@app.route('/product/<int:product_id>')
def product(product_id):
    with closing(get_db()) as conn:
        product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        return render_template('404.html',
                               heading='No such product',
                               detail=f'Nothing on the shelf has id {product_id}.'), 404
    return render_template('product.html', product=product)


# The greeting page is assembled as template *source* around whatever the visitor
# sends, then handed to the renderer — which is exactly why it is injectable.
GREET_TOP = """{% extends "base.html" %}
{% block title %}Greeting - VulnShop{% endblock %}
{% block content %}
<div class="wrap"><section class="section">
<p class="eyebrow">Greeter &middot; renders whatever it is handed</p>
<div class="card">
"""

GREET_BOTTOM = """
<p class="mute mb-m">That name went into the template source before rendering, so HTML tags run as
markup and <code>{{ '{{' }} ... {{ '}}' }}</code> runs as a template expression.</p>
<form class="inline-form" method="GET" action="/greet">
  <label class="sr-only" for="name">Name</label>
  <input id="name" type="text" name="name" value="guest" placeholder="Your name">
  <button class="btn btn--sm" type="submit">Greet me</button>
</form>
<div class="chips">
  <span class="mute mono chips__label">Try:</span>
  <a class="chip" href="/greet?name=guest">guest</a>
  <a class="chip" href="/greet?name=%7B%7B7*7%7D%7D">{{ '{{7*7}}' }}</a>
  <a class="chip" href="/greet?name=%3Cs%3Estruck%3C/s%3E">&lt;s&gt;struck&lt;/s&gt;</a>
</div>
</div>
<p class="mute mt-m"><a href="/sitemap">&larr; Back to the security lab</a></p>
</section></div>
{% endblock %}
"""


@app.route('/greet')
def greet():
    name = request.args.get('name', 'guest')
    template = f"<h1>Hello, {name}!</h1>"
    return render_template_string(GREET_TOP + template + GREET_BOTTOM)


@app.route('/api/ping')
def api_ping():
    host = request.args.get('host', '127.0.0.1')
    try:
        result = subprocess.run(
            ['sh', '-c', f'ping -c 3 {host}'],
            capture_output=True,
            text=True,
            timeout=10
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        output = 'Timeout'
    except Exception as e:
        output = str(e)
    return {'host': host, 'output': output}


@app.route('/download')
def download():
    filename = request.args.get('file', 'readme.txt')
    filepath = FILES_DIR / filename
    try:
        return send_file(str(filepath))
    except Exception:
        return render_template('404.html',
                               heading='No such file',
                               detail=f'Nothing readable at {filepath}.'), 404


@app.route('/redirect')
def redirect_route():
    url = request.args.get('url', '/')
    return redirect(url)


@app.route('/admin')
def admin():
    with closing(get_db()) as conn:
        users = conn.execute('SELECT id, username, email, is_admin FROM users').fetchall()
        orders = conn.execute('''
            SELECT o.*, u.username, p.name as product_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            JOIN products p ON o.product_id = p.id
            ORDER BY o.id DESC
            LIMIT 20
        ''').fetchall()
        stats = {
            'users': conn.execute('SELECT COUNT(*) as c FROM users').fetchone()['c'],
            'products': conn.execute('SELECT COUNT(*) as c FROM products').fetchone()['c'],
            'orders': conn.execute('SELECT COUNT(*) as c FROM orders').fetchone()['c'],
            'revenue': conn.execute('SELECT SUM(total) as sum FROM orders').fetchone()['sum'] or 0,
        }
    return render_template('admin.html', users=users, orders=orders, stats=stats)


@app.route('/api/orders/<int:order_id>')
def api_order(order_id):
    with closing(get_db()) as conn:
        order = conn.execute('''
            SELECT o.*, u.username, p.name as product_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            JOIN products p ON o.product_id = p.id
            WHERE o.id = ?
        ''', (order_id,)).fetchone()
    if not order:
        return {'error': 'Not found'}, 404
    return dict(order)


@app.route('/api/import', methods=['POST'])
def api_import():
    xml_data = request.get_data(as_text=True)
    parser = etree.XMLParser(resolve_entities=True)
    try:
        root = etree.fromstring(xml_data.encode(), parser=parser)
        items = [child.text for child in root]
        return {'imported': items}
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        with closing(get_db()) as conn:
            user = conn.execute(
                'SELECT * FROM users WHERE username = ? AND password = ?',
                (username, password)
            ).fetchone()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['is_admin'] = user['is_admin']
            return redirect(url_for('index'))
        return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    placed = request.args.get('placed')
    with closing(get_db()) as conn:
        user_orders = conn.execute('''
            SELECT o.*, p.name as product_name
            FROM orders o
            JOIN products p ON o.product_id = p.id
            WHERE o.user_id = ?
            ORDER BY o.created_at DESC
        ''', (session['user_id'],)).fetchall()

    return render_template('orders.html', orders=user_orders, placed=placed)


@app.route('/buy', methods=['POST'])
def buy():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', 1, type=int)

    with closing(get_db()) as conn:
        product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
        if not product:
            return redirect(url_for('index'))

        total = product['price'] * quantity
        cursor = conn.execute(
            'INSERT INTO orders (user_id, product_id, quantity, total) VALUES (?, ?, ?, ?)',
            (session['user_id'], product_id, quantity, total)
        )
        conn.commit()
        order_id = cursor.lastrowid

    return redirect(url_for('orders', placed=order_id))


@app.route('/boom')
def boom():
    try:
        raise RuntimeError('Intentional error for stack trace demo')
    except Exception:
        tb = traceback.format_exc()
    return f'<pre>{tb}</pre>', 500


# ===== ADDITIONAL VULNERABILITIES FOR TRACEON DETECTION =====

@app.route('/api/users')
def list_users():
    """Endpoint that exposes user list with multiple injection points"""
    username = request.args.get('username', '')
    # SQL Injection: the column name is taken straight from the query string
    search_type = request.args.get('type', 'username')

    # SQL Injection: both the column and the value are concatenated in
    query = f"SELECT id, username, email FROM users WHERE {search_type} LIKE '%{username}%'"
    with closing(get_db()) as conn:
        try:
            users = conn.execute(query).fetchall()
        except sqlite3.Error as e:
            return {'error': str(e), 'query': query}, 400
    return jsonify([dict(u) for u in users])


@app.route('/api/user/<user_id>')
def get_user(user_id):
    """Endpoint with IDOR vulnerability - returns any user by ID"""
    conn = get_db()
    # No ownership check - anyone can request any user
    user = conn.execute('SELECT id, username, email, is_admin FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if not user:
        return {'error': 'Not found'}, 404
    return dict(user)


@app.route('/api/fetch', methods=['POST'])
def fetch_url():
    """SSRF vulnerability - fetches user-supplied URLs"""
    url = req_data().get('url')

    if not url:
        return {'error': 'url parameter required'}, 400

    try:
        # No validation of URL - allows internal network access
        response = requests.get(url, timeout=5, allow_redirects=True)
        return {
            'url': url,
            'status': response.status_code,
            'content': response.text[:500],
            'headers': dict(response.headers)
        }
    except Exception as e:
        return {'url': url, 'error': str(e)}, 400


@app.route('/api/ldap-search', methods=['POST'])
def ldap_search():
    """LDAP Injection vulnerability"""
    username = req_data().get('username')

    if not username:
        return {'error': 'username required'}, 400

    # LDAP filter constructed with user input - vulnerable to LDAP injection
    ldap_filter = f"(uid={username})"

    # Simulate LDAP query (in real scenario would connect to LDAP server)
    # This is intentionally vulnerable: filter like (uid=*) returns all users
    if '*' in username or '*)' in username or '|' in username:
        return {'result': 'Multiple matches found', 'filter': ldap_filter}

    return {'result': 'User found', 'filter': ldap_filter, 'user': username}


@app.route('/api/generate-token', methods=['POST'])
def generate_token():
    """JWT generation with weak secret and no algorithm verification"""
    data = req_data()
    username = data.get('username')
    is_admin = data.get('is_admin', False)

    if not username:
        return {'error': 'username required'}, 400

    # Weak JWT secret, allows algorithm downgrade
    payload = {
        'username': username,
        'is_admin': is_admin,
        'exp': datetime.now(timezone.utc) + timedelta(hours=24)
    }

    # Vulnerable: weak secret, no algorithm specification allows 'none' algo
    token = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
    return {'token': token, 'username': username}


@app.route('/api/verify-token', methods=['POST'])
def verify_token():
    """JWT verification without proper algorithm validation"""
    token = req_data().get('token')

    if not token:
        return {'error': 'token required'}, 400

    try:
        # Vulnerable: trusts attacker-controlled 'alg' header, so a token
        # forged with the 'none' algorithm passes verification
        alg = jwt.get_unverified_header(token).get('alg', 'HS256')
        if alg == 'none':
            payload = jwt.decode(token, options={'verify_signature': False})
        else:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[alg])
        return {'valid': True, 'payload': payload}
    except Exception as e:
        return {'valid': False, 'error': str(e)}, 401


@app.route('/api/register', methods=['POST'])
def api_register():
    """Endpoint vulnerable to mass assignment"""
    data = req_data()

    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    is_admin = data.get('is_admin', False)  # User can set is_admin=true

    if not username or not password:
        return {'error': 'username and password required'}, 400

    with closing(get_db()) as conn:
        try:
            # Mass assignment vulnerability: is_admin can be set by user
            conn.execute(
                'INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, ?)',
                (username, password, email, is_admin)
            )
            conn.commit()
            return {'success': True, 'username': username, 'is_admin': is_admin}
        except sqlite3.IntegrityError:
            return {'error': 'User already exists'}, 409


@app.route('/api/deserialize', methods=['POST'])
def deserialize_data():
    """Insecure deserialization with pickle"""
    data = req_data().get('data')

    if not data:
        return {'error': 'data parameter required'}, 400

    try:
        # Dangerous: pickle.loads on untrusted data allows RCE
        decoded = base64.b64decode(data)
        obj = pickle.loads(decoded)
        return {'deserialized': str(obj), 'type': type(obj).__name__}
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/api/hash', methods=['POST'])
def weak_hash():
    """Weak cryptography: uses MD5 for password hashing"""
    password = req_data().get('password')

    if not password:
        return {'error': 'password required'}, 400

    # Weak: MD5 is broken, should use bcrypt/argon2
    md5_hash = hashlib.md5(password.encode()).hexdigest()
    sha1_hash = hashlib.sha1(password.encode()).hexdigest()

    return {
        'password': password,
        'md5': md5_hash,
        'sha1': sha1_hash,
        'recommendation': 'Use bcrypt or argon2 instead'
    }


@app.route('/api/reset-password', methods=['POST'])
def reset_password():
    """Weak reset token: 4 digits, and deterministically derived from the
    email address. Issues the *same* token /api/reset-verify will accept -
    it is stored, not returned, the way a real reset email would work."""
    email = req_data().get('email')

    if not email:
        return {'error': 'email required'}, 400

    token = derive_reset_token(email)
    with closing(get_db()) as conn:
        conn.execute(
            'INSERT INTO reset_tokens (email, token) VALUES (?, ?)'
            ' ON CONFLICT(email) DO UPDATE SET token = excluded.token',
            (email, token)
        )
        conn.commit()

    return {
        'email': email,
        'sent': True,
        'token_format': '4 digits (1000-9999), derived from the email address',
        'note': 'Reset token sent to the address on file.'
    }


@app.route('/api/reset-verify', methods=['POST'])
def reset_verify():
    """Checks a reset token against the stored one; leaks the quest flag
    when it matches admin's. The stored token is only 4 digits - brute force."""
    data = req_data()
    email = data.get('email')
    token = data.get('token')

    if not email or not token:
        return {'error': 'email and token required'}, 400

    with closing(get_db()) as conn:
        row = conn.execute(
            'SELECT token FROM reset_tokens WHERE email = ?', (email,)
        ).fetchone()

    if row and str(token).strip() == row['token']:
        return {
            'valid': True,
            'flag': BY_SLUG['predictable_token']['flag'],
            'note': 'Token accepted. Password would be reset here.'
        }
    return {'valid': False, 'error': 'Invalid token'}, 401


@app.route('/api/files')
def list_files():
    """Directory listing vulnerability"""
    directory = request.args.get('dir', '/app/files')

    # No path validation - directory traversal possible
    try:
        path = Path(directory)
        if path.is_dir():
            files = [str(f.relative_to(path)) for f in path.iterdir()]
            return {'directory': directory, 'files': files}
        return {'error': 'Not a directory'}, 404
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/api/comments', methods=['GET', 'POST'])
def comments():
    """Stored XSS vulnerability via comments"""
    if request.method == 'POST':
        comment = req_data().get('comment')
        # No sanitization - stored XSS vulnerability
        return {
            'success': True,
            'comment': comment,
            'note': 'Comment stored without sanitization'
        }

    # Simulate retrieving stored comments
    return {
        'comments': [
            '<img src=x onerror="alert(\'XSS\')">',
            '<script>alert(\'Stored XSS\')</script>'
        ]
    }


@app.route('/api/login-api', methods=['POST'])
def login_api():
    """API endpoint with weak authentication"""
    data = req_data()
    username = data.get('username')
    password = data.get('password')
    api_key = data.get('api_key')

    # Accept hardcoded API keys - vulnerability
    if api_key in API_KEYS:
        return {
            'success': True,
            'token': jwt.encode({'user': API_KEYS[api_key]}, JWT_SECRET),
            'api_key': api_key
        }

    # Weak credentials
    if username == 'admin' and password in ['admin', 'admin123', '123456', 'password']:
        return {'success': True, 'token': jwt.encode({'user': 'admin'}, JWT_SECRET)}

    return {'success': False, 'error': 'Invalid credentials'}, 401


@app.route('/api/debug', methods=['GET'])
def debug_info():
    """Information disclosure - exposes debug information"""
    return {
        'flask_debug': app.debug,
        'secret_key': app.config['SECRET_KEY'],
        'database_path': str(DB_PATH),
        'files_dir': str(FILES_DIR),
        'jwt_secret': JWT_SECRET,
        'api_keys': API_KEYS,
        'environment': os.environ.copy(),
        'version': 'VulnShop 1.0.0 (Debug Mode)',
        'quest_flag': BY_SLUG['debug_dump']['flag'],
    }


@app.route('/api/xxe', methods=['POST'])
def xxe_parser():
    """Enhanced XXE vulnerability endpoint"""
    xml_data = request.get_data(as_text=True)

    try:
        # Vulnerable XXE configuration
        parser = etree.XMLParser(resolve_entities=True, remove_blank_text=True)
        root = etree.fromstring(xml_data.encode(), parser=parser)

        # Extract all text content (root text included so entity refs in
        # <root>&xxe;</root> form are returned too)
        items = [t for t in [root.text] + [child.text for child in root] if t]

        return {
            'success': True,
            'parsed': items,
            'root_tag': root.tag,
            'count': len(items)
        }
    except etree.XMLSyntaxError as e:
        return {'error': f'XML Error: {str(e)}'}, 400
    except Exception as e:
        return {'error': str(e)}, 400


APP_ROOT = Path('/app')


def _is_app_source(target: Path) -> bool:
    """True if `target` resolves inside /app but outside /app/files."""
    try:
        resolved = Path(os.path.abspath(str(target)))
    except Exception:
        return False
    if not resolved.is_relative_to(APP_ROOT):
        return False
    return not resolved.is_relative_to(FILES_DIR)


@app.route('/api/file-upload', methods=['POST'])
def file_upload():
    """Arbitrary file upload vulnerability"""
    if 'file' not in request.files:
        return {'error': 'No file provided'}, 400

    file = request.files['file']
    filename = request.form.get('filename') or file.filename

    # No file type validation and no path sanitization - traversal in the
    # filename writes wherever it points. The one exception is the app's own
    # source tree: overwriting app.py bricks the lab for every other tester
    # and survives `docker restart`, so that single case is refused.
    filepath = FILES_DIR / filename
    if _is_app_source(filepath):
        return {'error': 'Refused: would overwrite the running application'}, 403

    try:
        file.save(str(filepath))
        return {
            'success': True,
            'filename': filename,
            'path': str(filepath),
            'url': f'/download?file={filename}'
        }
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/api/proxy', methods=['POST'])
def proxy():
    """Open proxy - forwards requests with headers"""
    data = req_data()
    target_url = data.get('url')
    method = (data.get('method') or 'GET').upper()
    headers = data.get('headers') or {}
    body = data.get('body')

    if not target_url:
        return {'error': 'url required'}, 400

    try:
        # No validation - acts as open proxy
        if method == 'GET':
            resp = requests.get(target_url, headers=headers, timeout=5)
        elif method == 'POST':
            resp = requests.post(target_url, headers=headers, data=body, timeout=5)
        else:
            return {'error': 'Method not supported'}, 400

        return {
            'status': resp.status_code,
            'content': resp.text[:1000],
            'headers': dict(resp.headers)
        }
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/api/sql-exec', methods=['POST'])
def sql_exec():
    """Direct SQL execution endpoint"""
    sql = req_data().get('sql')

    if not sql:
        return {'error': 'sql parameter required'}, 400

    with closing(get_db()) as conn:
        try:
            # Dangerous: executes arbitrary SQL
            result = conn.execute(sql).fetchall()
            return {'success': True, 'rows': [dict(r) for r in result]}
        except Exception as e:
            return {'error': str(e)}, 400


@app.route('/api/eval', methods=['POST'])
def eval_code():
    """Code evaluation vulnerability"""
    code = req_data().get('code')

    if not code:
        return {'error': 'code parameter required'}, 400

    try:
        # Dangerous: eval() on user input
        result = eval(code)
        return {'result': str(result), 'type': type(result).__name__}
    except Exception as e:
        return {'error': str(e)}, 400


@app.route('/api/search-advanced', methods=['POST'])
def search_advanced():
    """Multiple injection points in search"""
    data = req_data()
    query = data.get('query', '')
    filter_type = data.get('filter') or 'username'
    sort = data.get('sort') or 'asc'

    # Three injection points, none of them validated: the filter column, the
    # search value, and the sort direction all land in the statement as-is.
    sql = f"SELECT * FROM users WHERE {filter_type} LIKE '%{query}%' ORDER BY {filter_type} {sort}"

    with closing(get_db()) as conn:
        try:
            result = conn.execute(sql).fetchall()
            return {'results': [dict(r) for r in result]}
        except Exception as e:
            return {'error': str(e), 'query': sql}, 400


@app.route('/sitemap')
def sitemap():
    return render_template('sitemap.html')


@app.route('/flags')
def quests_page():
    with closing(get_db()) as conn:
        quests = conn.execute(
            'SELECT slug, name, category, hint, id FROM flags ORDER BY id'
        ).fetchall()
    return render_template('quests.html', quests=quests)


LEADERBOARD_SQL = '''
    SELECT s.player,
           COUNT(DISTINCT s.flag_id) as flags_found,
           MAX(s.submitted_at) as last_submission
    FROM submissions s
    GROUP BY s.player
    ORDER BY flags_found DESC, last_submission ASC
'''


@app.route('/api/submit-flag', methods=['POST'])
def submit_flag():
    data = req_data()
    player = (data.get('player') or '').strip()[:40]
    flag = (data.get('flag') or '').strip()

    if not player or not flag:
        return {'valid': False, 'error': 'player and flag required'}, 400

    with closing(get_db()) as conn:
        # Compare digests - the plaintext flag is never stored in the DB, so
        # dumping this table via SQLi yields hashes, not the board.
        row = conn.execute(
            'SELECT id FROM flags WHERE flag_hash = ?', (flag_hash(flag),)
        ).fetchone()
        if not row:
            return {'valid': False, 'correct': False, 'error': 'Not a valid quest flag'}

        try:
            conn.execute(
                'INSERT INTO submissions (player, flag_id) VALUES (?, ?)',
                (player, row['id'])
            )
            conn.commit()
            first = True
        except sqlite3.IntegrityError:
            conn.rollback()
            first = False

        score = conn.execute(
            'SELECT COUNT(*) as c FROM submissions WHERE player = ?', (player,)
        ).fetchone()['c']
    return {'valid': True, 'correct': True, 'first': first, 'player_score': score}


@app.route('/api/leaderboard')
def api_leaderboard():
    with closing(get_db()) as conn:
        rows = conn.execute(LEADERBOARD_SQL).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route('/leaderboard')
def leaderboard():
    with closing(get_db()) as conn:
        rows = conn.execute(LEADERBOARD_SQL).fetchall()
        total = conn.execute('SELECT COUNT(*) as c FROM flags').fetchone()['c']
    return render_template('leaderboard.html', entries=rows, total=total)


@app.route('/api/admin-flag')
def admin_flag():
    token = request.headers.get('Authorization', '').replace('Bearer ', '').strip()
    token = token or request.args.get('token', '')
    if not token:
        return {'error': 'Admin token required'}, 401
    try:
        alg = jwt.get_unverified_header(token).get('alg', 'HS256')
        if alg == 'none':
            payload = jwt.decode(token, options={'verify_signature': False})
        else:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[alg])
        if payload.get('is_admin') or payload.get('user') == 'admin':
            return {'flag': BY_SLUG['jwt_none_alg']['flag']}
        return {'error': 'Not admin'}, 403
    except Exception:
        return {'error': 'Invalid token'}, 401


@app.route('/.env')
def dotenv():
    return f'''SECRET_KEY=dev-secret-key-change-in-production
DATABASE_URL=sqlite:///vulnshop.db
ADMIN_PASSWORD=admin123
API_KEY=sk-live-fake-key-for-demo
QUEST_FLAG={BY_SLUG['dot_env_leak']['flag']}
''', 200, {'Content-Type': 'text/plain'}


@app.route('/backup.zip')
def backup_zip():
    real_zip = FILES_DIR / 'backup.zip'
    if real_zip.exists():
        return send_file(str(real_zip), mimetype='application/zip', as_attachment=False)
    return b'PK\x03\x04' + b'\x00' * 100, 200, {'Content-Type': 'application/zip'}


@app.after_request
def add_headers(response):
    """Add insecure headers that expose security issues"""
    # CORS misconfiguration - allows any origin
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = '*'
    response.headers['Access-Control-Allow-Credentials'] = 'true'

    # Missing security headers
    # Intentionally NOT setting:
    # - Content-Security-Policy
    # - X-Frame-Options
    # - X-Content-Type-Options
    # - Strict-Transport-Security

    # Expose server info
    response.headers['Server'] = 'VulnShop/1.0.0 (Flask 3.0.3)'
    response.headers['X-Powered-By'] = 'Python Flask'

    # Insecure cookies
    response.headers['Set-Cookie'] = 'session_id=abc123def456; Path=/; SameSite=None'

    return response


@app.errorhandler(404)
def page_not_found(_error):
    return render_template('404.html'), 404


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=False)
