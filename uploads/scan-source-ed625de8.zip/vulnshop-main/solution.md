# VulnShop — Instructor Solution Key

> Companion to `exercise.md`. Contains expected answers, teaching notes, and TraceON findings map.
> **Do not distribute to participants.**

---

## Quest Flags (Answer Key)

All flags live in `flags_data.py`; `seed.py` plants them at container start.
Fresh instance = new scoreboard.

> The `flags` table stores only a **SHA-256 of each flag**, so dumping it via
> SQL injection yields hashes, not the board. Each flag is only reachable
> through its own vulnerability. Plaintext exists in `flags_data.py` and in
> the single endpoint that intentionally leaks it.

| # | Quest | Flag | How to get it |
|---|-------|------|---------------|
| 1 | Secret Stash | `VULNSHOP{sql_union_is_forever}` | `POST /api/sql-exec` → `SELECT * FROM secrets` (or UNION SQLi in `/api/users`) |
| 2 | Off the Shelf | `VULNSHOP{walk_the_tree}` | `GET /download?file=flag.txt` (in `/app/files/`) |
| 3 | The Forgotten Zip | `VULNSHOP{backup_bonanza}` | `GET /backup.zip` → real zip, extract `flag.txt` |
| 4 | Left Lying Around | `VULNSHOP{dot_env_dot_oh}` | `GET /.env` → `QUEST_FLAG` line |
| 5 | Forged Badge | `VULNSHOP{jwt_none_is_done}` | Forge `none`-alg admin JWT, `GET /api/admin-flag?token=...` |
| 6 | Entity Digestion | `VULNSHOP{external_entities_go_brrr}` | `POST /api/xxe` with `file:///app/files/xxe-flag.txt` |
| 7 | Someone Else's Receipt | `VULNSHOP{your_receipt_is_mine}` | `GET /api/orders/11` — order 11 has the flag in `note` |
| 8 | Four Little Numbers | `VULNSHOP{ten_k_tries_is_nothing}` | Two ways against `POST /api/reset-verify` with `email=admin@vulnshop.local`: brute force 1000–9999, or derive it — the token is `int(md5(email), 16) % 9000 + 1000`, which `/api/reset-password` advertises as "derived from the email address" |
| 9 | Open Book | `VULNSHOP{info_leaks_are_free}` | `GET /api/debug` → `quest_flag` field |
| 10 | Full Send | `VULNSHOP{code_exec_with_a_smile}` | `POST /api/eval` → `open("/app/files/rce-flag.txt").read()` (or ping injection `cat /app/files/rce-flag.txt`) |

### Leaderboard mechanics

- `POST /api/submit-flag` `{player, flag}` — hashes the submission and matches it against `flags.flag_hash`; first find per player per flag wins the point (`UNIQUE(player, flag_id)`). Accepts JSON or form-encoded bodies.
- `GET /api/leaderboard` — JSON standings: score = distinct flags, ties broken by earliest last submission
- `GET /leaderboard` — HTML standings page
- `GET /flags` — quest board with hints (safe to show participants)
- Scores live in the lab DB → wiped on `docker restart vulnshop` (by design)

---

## Answer Key

### 2.1 SQL Injection

| | |
|---|---|
| **Expected output** | All 12 products returned in the table |
| **Why it works** | `app.py:73` — `query = f"SELECT * FROM products WHERE name LIKE '%{q}%' OR description LIKE '%{q}%'"` — the `q` parameter is interpolated directly. Payload `x' OR '1'='1` closes the string and injects `OR 1=1` which is always true |
| **App.py lines** | `app.py:68-78` (search route) |
| **Secure alternative** | Use parameterized query: `conn.execute('SELECT * FROM products WHERE name LIKE ? OR description LIKE ?', ('%'+q+'%', '%'+q+'%'))` |

### 2.2 Reflected XSS

| | |
|---|---|
| **Expected output** | Browser alert dialog or script tag in HTML body |
| **Why it works** | `app.py:94-95` — `template = f"<h1>Hello, {name}!</h1>"` then `render_template_string(template)` — user input becomes Jinja2 template source, so HTML/JS is not escaped |
| **App.py lines** | `app.py:91-95` (greet route) |
| **Secure alternative** | Use `render_template('greet.html', name=name)` with a static template file. Jinja2's auto-escaping would then encode `<script>` as `&lt;script&gt;` |

### 2.3 SSTI

| | |
|---|---|
| **Expected output** | `<h1>Hello, 49!</h1>` — the `{{7*7}}` expression is evaluated to `49` on the server |
| **Why it works** | Same as XSS — `render_template_string` treats input as template code. `{{7*7}}` is Jinja2 syntax for "compute 7*7 and print the result" |
| **App.py lines** | `app.py:91-95` (same route) |
| **Secure alternative** | Same as XSS — never use `render_template_string` with user input |

### 2.4 Command Injection

| | |
|---|---|
| **Expected output** | `{"host":"1;id","output":"...uid=0(root)...ping statistics..."}` |
| **Why it works** | `app.py:102-103` — `['sh', '-c', f'ping -c 3 {host}']` — the `host` value is passed to `sh -c` which interprets `;` as a command separator |
| **App.py lines** | `app.py:98-113` (api_ping route) |
| **Secure alternative** | Use `shlex.quote(host)` or pass arguments as `['ping', '-c', '3', host]` without `shell=True` equivalent |

### 2.5 Path Traversal

| | |
|---|---|
| **Expected output** | Contents of `/etc/passwd` (~20 lines) |
| **Why it works** | `app.py:119` — `filepath = FILES_DIR / filename` — Pathlib's `/` operator allows `..` to climb directories. No normalization check |
| **App.py lines** | `app.py:116-123` (download route) |
| **Secure alternative** | Use `send_from_directory(FILES_DIR, filename)` which rejects `..` sequences, or resolve the path and verify it starts with FILES_DIR: `filepath.resolve().startswith(FILES_DIR.resolve())` |

### 2.6 Open Redirect

| | |
|---|---|
| **Expected output** | HTTP 302 with `Location: https://example.com` |
| **Why it works** | `app.py:128-129` — `redirect(url)` — Flask's `redirect()` accepts any string. No validation of the URL |
| **App.py lines** | `app.py:126-129` (redirect route) |
| **Secure alternative** | Check `url` against an allowlist: `if url.startswith('/')` (internal redirect only), or validate against `urlparse(url).netloc` |

### 2.7 Exposed Secrets & Backups

| | |
|---|---|
| **Expected output** | `/.env` — 4 lines of fake secrets (`SECRET_KEY`, `DATABASE_URL`, `ADMIN_PASSWORD`, `API_KEY`). `/backup.zip` — binary zip content (PK header) |
| **Why it works** | `app.py:221-226` and `app.py:229-231` — explicit routes serving sensitive files |
| **App.py lines** | `app.py:221-231` |
| **Secure alternative** | Never serve `.env` or backup files from any web route. Block access at reverse proxy level |

### 2.8 Unauthenticated Admin

| | |
|---|---|
| **Expected output** | Table with 5 users: admin (admin), alice, bob, charlie, diana |
| **Why it works** | `app.py:132-137` — no authentication check before querying DB |
| **App.py lines** | `app.py:132-137` |
| **Secure alternative** | Add `@login_required` decorator and check `session.get('is_admin')` |

### 2.9a Missing Security Headers

| | |
|---|---|
| **Expected output** | Response headers contain only `Server`, `Date`, `Content-Type`, `Content-Length`, `Connection`. No `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`, `Strict-Transport-Security` |
| **Why it works** | Flask doesn't add these by default; app doesn't configure them |
| **Secure alternative** | Use `after_request` handler or Flask-Talisman to set headers |

### 2.9b Insecure Cookie

| | |
|---|---|
| **Expected output** | `Set-Cookie: session=<value>; HttpOnly; Path=/` — note `HttpOnly` present but `Secure` and `SameSite` are missing |
| **Why it works** | Flask default config: `SESSION_COOKIE_SECURE=False`, `SESSION_COOKIE_HTTPONLY=True`, `SESSION_COOKIE_SAMESITE=None` |
| **Secure alternative** | Set `app.config['SESSION_COOKIE_SECURE'] = True`, `app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'` |

### 2.9c Stack Trace Disclosure

| | |
|---|---|
| **Expected output** | Full Python traceback in HTML `<pre>` block showing `File "/app/app.py"`, line numbers, and the error chain |
| **Why it works** | `app.py:194-200` — `traceback.format_exc()` renders the full traceback into the response body |
| **App.py lines** | `app.py:194-200` |
| **Secure alternative** | Register `@app.errorhandler(500)` and return a generic error page. Log the traceback server-side, never show it to the client |

### 2.10 IDOR

| | |
|---|---|
| **Expected output** | Order 3 returns `{"username": "alice", "user_id": 2, ...}` — you are not logged in as alice, yet you see her order |
| **Why it works** | `app.py:140-153` — the query uses `WHERE o.id = ?` but never checks `user_id` against the session |
| **App.py lines** | `app.py:140-153` |
| **Secure alternative** | After auth: `WHERE o.id = ? AND o.user_id = ?` and pass `session['user_id']` |

### 2.11 XXE

| | |
|---|---|
| **Expected output** | `{"imported": ["xxe-works"]}` — the entity `&x;` was resolved to `"xxe-works"` |
| **Why it works** | `app.py:159` — `etree.XMLParser(resolve_entities=True)` — lxml resolves DTD entities by default when this flag is set |
| **App.py lines** | `app.py:156-165` |
| **Secure alternative** | Set `resolve_entities=False` (modern lxml defaults to this). Never parse untrusted XML with entity resolution |

---

## TraceON Findings Map

| Vulnerability | Section | Expected TraceON Finding | Severity | Auto/Manual |
|---|---|---|---|---|
| SQL Injection | 2.1 | "SQL Injection" | High | Auto (active scan) |
| Reflected XSS | 2.2 | "Reflected Cross-Site Scripting" | High | Auto (active scan) |
| SSTI | 2.3 | (may flag as XSS or Web Fingerprinting) | Medium | Auto (partial — ZAP may miss SSTI without custom rule) |
| Command Injection | 2.4 | "OS Command Injection" | High | Auto (active scan) |
| Path Traversal | 2.5 | "Path Traversal" | Medium | Auto (active scan) |
| Open Redirect | 2.6 | "Open Redirect" | Low | Auto (active scan) |
| Exposed `.env` | 2.7 | (file existence — depends on fuzzing) | Medium | Auto (with path fuzzing ON) |
| Exposed `/backup.zip` | 2.7 | (file existence) | Medium | Auto (with path fuzzing ON) |
| Unauth `/admin` | 2.8 | "Unauthenticated Access" or content detection | High | Auto (spider finds link) |
| Missing Headers | 2.9a | "Missing Content-Security-Policy" etc. | Low-Medium | Auto (passive scan) |
| Insecure Cookie | 2.9b | "Cookie Without Secure Flag" or "Cookie Without SameSite" | Low | Auto (passive scan) |
| Stack Trace | 2.9c | "Information Disclosure" / "Stack Trace" | Low | Auto (passive scan) |
| IDOR | 2.10 | **Not** detected | Critical | **Manual only** |
| XXE | 2.11 | **Not** detected (unless POST body fuzzed) | High | **Manual only** |
| Hardcoded Secrets | — | **Not** detected by DAST | Critical | SAST / Code Review |
| Plaintext Passwords | — | **Not** detected by DAST | High | SAST / Code Review |

### If TraceON finds < 3 findings

| Cause | Fix |
|---|---|
| Spider didn't crawl deep enough | Increase `scan_depth` to 5 |
| `.env` / `backup.zip` not found | Enable `path_fuzzing: true` |
| Target URL is wrong | Ensure `http://vulnshop:5000` resolves inside the Docker network |
| Network not shared | Confirm `docker network ls \| grep app-network` shows the TraceON network, and vulnshop is connected |

---

## Teaching Notes

### Common Student Confusion

| Issue | Clarification |
|---|---|
| "I clicked the XSS link but nothing happened" | The curl command shows the raw script tag. Browser may block `alert()` but the vulnerability is still present — the HTML is unescaped. Show them View Source |
| "SQLi didn't return anything" | The payload `x' OR '1'='1` requires the quote to close. If they mistype it, suggest copy-pasting from the `/sitemap` form which has the exact payload |
| "SSTI and XSS are the same thing" | No — XSS executes in the *browser* (JavaScript), SSTI executes on the *server* (Jinja2). XSS is client-side, SSTI is server-side RCE. `{{7*7}}` computed on the server proves it's SSTI, not just XSS |
| "Command injection didn't work, I see ping errors" | The output includes ping errors (timeout) AND `id` output. Scroll down. The container has no network to 0.0.0.1 but the shell still ran `id` after `;` |
| "XXE gave an error" | Make sure they use POST with correct Content-Type header. The `/sitemap` form uses the pre-filled textarea which works |
| "IDOR is just guessing numbers" | That's exactly the point — no auth check means anyone can enumerate orders. Real-world equivalent: `/api/users/1`, `/api/invoices/12345` |

### Root Cause Pattern

Every vulnerability in VulnShop shares one root cause: **user input is trusted without validation or encoding.**

| Trust Violation | Vulnerability |
|---|---|
| Trusted input in SQL query | SQLi |
| Trusted input as template | XSS + SSTI |
| Trusted input in shell | Command Injection |
| Trusted input in file path | Path Traversal |
| Trusted input in redirect | Open Redirect |
| Trusted XML entities | XXE |
| No auth guard | Admin, IDOR |

When asked "If you could fix only 3 to close the most risk", the best answers are:
1. **Command Injection** (immediate RCE at the OS level)
2. **SQL Injection** (data exfiltration, authentication bypass)
3. **SSTI** (server-side code execution)

### Timing Guide

| Section | Minutes | Notes |
|---|---|---|
| 0. Setup | 5 | Pre-workshop: have compose running before students arrive |
| 1. Orientation | 5 | Let them click around freely |
| 2.1-2.6 (6 vulns) | 20 | Fast — browser URLs, observe, move on |
| 2.7-2.10 (4 vulns) | 10 | Quick — just click and see |
| 2.11 XXE | 5 | May need curl help |
| 3. TraceON Scan | 25 | Run in parallel with reflection discussion |
| 4. Reflection | 10 | Group discussion or individual journal |
| **Total** | **80 min** | Buffer: 10 min = 90 min workshop |

---

## Common Questions from Participants

### "Why does the scanner miss IDOR but find SQL injection?"
**Answer:** IDOR requires knowing that order #3 belongs to alice, not admin. A scanner can't infer that alice should only see her own orders — it sees the same HTTP response regardless of who asks. SQL injection detection is pattern-based: the scanner sends a quote `'` and looks for a database error message or behavioral change. IDOR needs a human to compare "what I get when logged in as me" vs "what I get as someone else".

### "Is SSTI really RCE?"
**Answer:** In this app, yes. `{{7*7}}` is harmless math, but `{{config}}` dumps Flask config, and `{{''.__class__.__mro__[1].__subclasses__()}}` can enumerate Python classes to find `os` module access. The Jinja2 sandbox blocks full RCE in this version, but the principle is the same: server-side template execution = code execution.

### "Why keep Flask debug off? Wouldn't debug=True be a realistic vuln too?"
**Answer:** `debug=True` exposes the Werkzeug debugger console, which is unauthenticated RCE with a web-based Python shell. That turns the container from "instructively vulnerable" into "trivially hostile" — one click compromise. The `/boom` route gives the same information-disclosure finding (stack trace) without the console.

### "Can I run this on a VM for the workshop?"
**Answer:** Yes — the entire VulnShop folder is self-contained. Copy `/home/cystar/analyser/vulnshop/` to any machine with Docker. The network name will differ; update `TRACEON_NETWORK` environment variable or the network name in `docker-compose.yml`.

---

## Troubleshooting

| Problem | Likely Cause | Solution |
|---|---|---|
| Scan finds 0-2 findings | Spider didn't discover endpoints | Check network: `docker exec traceon-zap curl http://vulnshop:5000/` — if unreachable, confirm network name match |
| Scan finds only passive findings | Active scan didn't attack discovered URLs | Increase `scan_depth` to 5, `max_children` to 20 |
| `.env` and `backup.zip` not found | Path fuzzing is off | Enable `path_fuzzing: true` in scan config (or demonstrate with curl) |
| SSTI payload `{{7*7}}` shows literal text | URL encoding issue | The `{` and `}` must be URL-encoded as `%7B` and `%7D`. Use the link from exercise.md |
| XXE returns parsing error | Missing Content-Type header | Add `-H "Content-Type: application/xml"` |
| Container won't start | Port conflict | Check if another service is on port 5000: `lsof -i :5000` |
| Can't access from another machine | Port bound to 127.0.0.1 | Change docker-compose.yml to `"5000:5000"` — but only in isolated lab network |
| Seeded data missing | Old image without `entrypoint.sh` | Rebuild: `docker-compose up -d --build` (seeding is automatic on every start — no volume exists) |